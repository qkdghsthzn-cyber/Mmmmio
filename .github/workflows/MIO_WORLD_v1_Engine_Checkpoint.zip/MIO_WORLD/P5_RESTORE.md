# P5 복구 중 시간 진행과 native cache 복원

검증 범위는 loopback HTTP fixture다. 실제 GPT·정본 서버 왕복·운영 배포·Android를 완료로 표시하지 않는다. 기준 명세와 core/data/reference는 보존한다.

## 미확정 거래 중 시간 진행

거래 준비 시 before 상태를 durable cache_binding_bases에 보존한다. 응답 유실 등으로 거래가 미확정이면 다음 정시의 시각·욕구·이미 확정된 Journey·일정 종료 구간·hook 만료만 진행한다. wallet/Inventory는 마지막 확인 상태를 유지하고 관련 영역 확정은 차단한다. 새로운 후보·LLM 판단·외부 금전 쓰기를 실행하지 않는다.

| 상태 | 처리 |
|---|---|
| BLOCKED_RECOVERY | 같은 시간의 미확정 사건; 중복 물리 시간 변화 없음 |
| COMPLETED_CLOCK_ONLY | 다음 UTC 1시간을 진행하고 clock journal 저장; 새 사건/LLM 없음 |
| RECOVERED | 뒤늦게 거래가 확인된 오래된 tick; 나머지 오래된 proposal을 skip |
| COMPLETED / COMPLETED_DEFERRED | 일반 시간별 실행 및 native snapshot 확인/지연 |

cache_clock_steps의 before hash·순서·time·after 전체 상태를 검증한다. 거래가 확인되면 원래 projection에 같은 물리 시간 변화를 재생한다. 현재 욕구에 단순 delta를 늦게 더하지 않는다. 예를 들어 원래 hunger=1에서 -45로 0이 된 뒤 2시간 동안 +10이 되어야 하면 10으로 복구한다. 현재 hunger=11에 뒤늦게 -45를 더해 0으로 만들지 않는다.

consequence/hook 생성은 원래 사건 시각에서 수행하고 시간 재생으로 만료 조건을 적용한다. native Inventory/Calendar ID는 영수증에 바인딩한다. 확실한 실패의 보상은 금전 변경만 되돌리고 경과한 시계를 되돌리지 않는다. cache의 임의 변경·손상된 journal·누락된 초기 before 상태는 merge하지 않는다. 과거 snapshot을 현재 시각으로 작성하지 않는다.

이 지원은 clock에 따른 독립 상태 변화다. 미확정 거래 중 다른 domain의 새 event를 병렬 실행하거나 독립적인 외부 변경을 임의로 merge하는 기능으로 확대 해석하지 않는다.

## native checkpoint 저장

기존의 별도 WORLD runtime 페이지에 append한다. 기존 문서/표/DB 구조를 대체하지 않는다. checkpoint에는 전체 State, 전체 인과 archive, 초기화 proof hash, 이미 확인된 native transaction 집합과 원장 import proof 집합을 포함한다.

JSON을 압축/base64로 나누어 각 native code block의 text budget을 지킨다. overview는 WORLD와 state hash·조각 수·payload hash를 저장한다. 각 조각과 overview를 같은 durable WritePlan으로 처리하고 모든 native 영수증의 재읽기가 일치해야 VERIFIED다. 크기는 최대 16MiB/39조각이며 한도를 넘으면 snapshot 실패를 표시하고 시계 진행을 계속한다. 보존한 역사와 cache를 임의로 잘라 성공 처리하지 않는다.

## 복원 진입점과 범위

```python
from connectors.native_restore import NativeRuntimeRestorer
result = NativeRuntimeRestorer(bridge, notion, calendar, clock).restore()
```

캐시가 삭제/손상되었거나 인과 archive가 유실된 경우 사용한다. 원래 durable coordinator·초기화 proof·tick/mutation·receipt/commit·원장 anchor/import DB는 보존되어 있어야 한다. 오래된 WORLD-only snapshot은 전체 상태 복원 근거가 아니다. coordinator DB 전체 유실을 native 문서만으로 복원한다고 선언하지 않는다.

1. 초기화 proof와 fixture/provider scope, 별도 runtime 페이지 identity를 확인한다.
2. 최신 VERIFIED checkpoint의 native 블록 ID·parent·버전·전체 native hash·관리 필드를 각 outbox 영수증과 비교한다.
3. 조각 순서·개수·tick·scope·압축 크기·payload hash 및 State 스키마/invariant를 검증한다.
4. 보존된 최신 clock/mutation, native commit/import 집합이 checkpoint와 일치해야 한다. 빠진 이후 변화나 더 오래된 기록이 있으면 복원하지 않는다.
5. 사용할 수 있는 다른 cache를 덮어쓰지 않는다. cache/인과 archive를 같은 SQLite transaction에서 복원하고 외부 영역은 stale로 유지한다.
6. fresh native Wallet/Inventory/Calendar를 다시 검증한다. 근거가 있는 외부 ledger 변화는 기존 rebaser로 반영한다. 읽기 실패/설명되지 않은 잔액 차이는 RESTORED_STALE로 남기며 사실을 확정하지 않는다.

복원은 외부 쓰기와 LLM 호출을 하지 않는다. 동일 상태의 재호출은 ALREADY_PRESENT다. fixture 정보는 계속 mock이다. 기록의 편집/삭제·누락·미확정 native snapshot·scope 변경·새로운 commit/import·인과 archive 충돌은 복원을 막는다. 새로운 정보를 잃고 예전 상태를 현재로 되돌리지 않는다.

## 검증

```bash
python3 tools/test_report.py P5_clock P5_restore
python3 mio.py p5-hourly-demo --hours 168
```

clock 14개와 native 복원 19개, 월 조정 34개를 포함한 현재 전체 회귀 293개 PASS. 응답 유실 뒤 시간 진행·뒤늦은 구매/지출·보상·상한/하한 욕구 재생·DST·재시작·과거 proposal skip·임의 cache 편집과 journal 손상을 검사했다. 복원은 cache 삭제/손상·archive 테이블 유실·native 소지품 ID/unknown 필드·편집/조각 누락·시계 역행 방지·외부 원장 반영·scope·DB proof 부재를 검사했다.

168시간 HTTP 실행에서 snapshot 168개를 확인한 뒤 cache/archive를 실제 삭제하고 native에서 복원하여 상태가 일치함을 확인했다. 실제 GPT/정본 서버 쓰기는 0회다. core 변경 후 앞서 통과한 10,000시간 시험은 그대로 보존했고 이번 native runtime 변경에서 다시 실행한 것으로 표시하지 않는다.

P5의 남은 작업은 실제 native 월 마감 근거 설정/검증, 실제 초기화와 비용 signal 취득, 실제 API·native 왕복·동시 편집 보호, 운영 timer/안전한 credential 입력·배포, 독립 vault/witness/key 운영 구성·복원 실습이다. 이 완료 조건 뒤 P6→P7→P8로 진행한다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.
