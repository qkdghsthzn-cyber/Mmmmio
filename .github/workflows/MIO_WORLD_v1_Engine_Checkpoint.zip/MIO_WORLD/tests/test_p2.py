import unittest
from datetime import timedelta
from core.models import Action,Decision,ContinuityEdge
from core.mock_state import mock_state
from core.state_manager import StateStore
from core.event_grammar import Grammar
from core.novelty_engine import NoveltyEngine
from core.candidate_generator import CandidateGenerator
from core.validator import Validator
from core.transaction_manager import TransactionManager
from core.simulator import Simulator
from agents.simulator_policy import simulator_decision


def candidate(state,family):
    g=Grammar(); generator=CandidateGenerator(g)
    # Isolate a family to test its validator independently of probabilistic rank.
    g.families={family:g.families[family]}
    for e in generator.generate(state,42,NoveltyEngine(g.rules)):
        if e.family==family: return e
    raise AssertionError("family not found "+family)


class P2Tests(unittest.TestCase):
    def setUp(self):
        self.store=StateStore(); self.state=mock_state(); self.store.initialize(self.state)
        self.g=Grammar(); self.tx=TransactionManager(self.store,Validator(self.g))

    def execute(self,event,decision,**kwargs):
        with self.store.atomic():
            self.store.log_event(event)
            return self.tx.commit(event,decision,self.store.load().revision,**kwargs)

    def test_purchase_atomic_and_idempotent(self):
        e=candidate(self.state,"PURCHASE_ITEM"); cost=e.payload["cost"]
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="purchase",item_id=e.payload["item_id"],amount=cost)])
        r=self.execute(e,d); self.assertEqual(r.status,"committed")
        state=self.store.load(); self.assertEqual(state.wallet.balance,self.state.wallet.balance-cost)
        self.assertEqual(state.inventory[e.payload["item_id"]].status,"owned")
        self.assertEqual(state.wishlist[e.payload["item_id"]],"purchased")
        again=self.execute(e,d); self.assertEqual(again.transaction_id,r.transaction_id)
        self.assertEqual(state,self.store.load()); self.assertEqual(len(state.wallet.ledger),1)
        from core.models import Event
        self.assertEqual(Event.model_validate_json(self.store.records("events")[0]["body"]).status,"committed")
        second=candidate(state,"OUTFIT_CHOICE")
        duplicate=Decision(decision_id=d.decision_id,event_id=second.event_id,choice="accept",reason_tags=[],actions=[Action(type="use_item",item_id=second.payload["item_id"])])
        self.assertEqual(self.execute(second,duplicate).status,"rejected"); self.assertEqual(state,self.store.load())

    def test_wallet_reservation_and_no_fabricated_money(self):
        e=candidate(self.state,"PURCHASE_ITEM")
        state=self.store.load(); state.wallet.reserved_amount=state.wallet.balance-1
        self.store.save(state,"tick_test","fixture")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="purchase",item_id=e.payload["item_id"],amount=e.payload["cost"])])
        self.assertEqual(self.execute(e,d).status,"rejected")
        self.assertEqual(self.store.load().wallet.balance,self.state.wallet.balance)

    def test_partial_failure_rollback(self):
        e=candidate(self.state,"PURCHASE_ITEM")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="purchase",item_id=e.payload["item_id"],amount=e.payload["cost"])])
        before=self.store.load(); self.assertEqual(self.execute(e,d,fault_after=0).status,"rolled_back")
        self.assertEqual(before,self.store.load())

    def test_unowned_item_rejected(self):
        e=candidate(self.state,"OUTFIT_CHOICE")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="use_item",item_id="imaginary_skirt")])
        self.assertEqual(self.execute(e,d).status,"rejected")

    def test_fixed_calendar_conflict(self):
        e=candidate(self.state,"CALENDAR_OPEN_SLOT"); c=self.state.calendar[0]
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="calendar_create",start=c.start,end=c.start+timedelta(minutes=e.payload["duration_minutes"]),title="conflict",location=c.location)])
        self.assertEqual(self.execute(e,d).status,"rejected")

    def test_unreachable_location(self):
        e=candidate(self.state,"OUTING_CAFE"); state=self.store.load(); state.travel_minutes={}; self.store.save(state,"tick_test","fixture")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="move",location=e.payload["location"])])
        self.assertEqual(self.execute(e,d).status,"rejected")

    def test_travel_is_not_instant_and_indoor_actions_require_location(self):
        e=candidate(self.state,"OUTING_CAFE")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="move",location=e.payload["location"])])
        self.assertEqual(self.execute(e,d).status,"committed")
        state=self.store.load(); self.assertEqual(state.world.place,"home"); self.assertIsNotNone(state.world.journey)
        sim=Simulator(self.store); sim.tick(self.state.world.time+timedelta(hours=1))
        self.assertEqual(self.store.load().world.place,e.payload["location"])

    def test_nan_relationship_delta_rejected_at_schema_boundary(self):
        from pydantic import ValidationError
        with self.assertRaises(ValidationError): Action(type="relationship_update",npc_id="npc_0",delta=float("nan"))

    def test_unknown_npc_and_delta_cap(self):
        e=candidate(self.state,"FRIEND_CONTACT")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="relationship_update",npc_id=e.actors[0],delta=50)])
        self.assertEqual(self.execute(e,d).status,"rejected")

    def test_llm_cannot_change_effect_or_past_fact(self):
        e=candidate(self.state,"BUDGET_CHECK")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="spend",amount=-10000)])
        self.assertEqual(self.execute(e,d).status,"rejected")

    def test_stale_canonical_blocks_purchase(self):
        e=candidate(self.state,"PURCHASE_ITEM"); state=self.store.load(); state.notion_stale=True; self.store.save(state,"tick_test","fixture")
        d=Decision(decision_id="dec_test",event_id=e.event_id,choice="accept",reason_tags=[],actions=[Action(type="purchase",item_id=e.payload["item_id"],amount=e.payload["cost"])])
        self.assertEqual(self.execute(e,d).status,"rejected")

    def test_duplicate_scheduler_and_revision_conflict(self):
        sim=Simulator(self.store); t=self.state.world.time
        self.assertTrue(sim.tick(t)); before=self.store.load(); self.assertFalse(sim.tick(t)); self.assertEqual(before,self.store.load())
        e=candidate(before,"BUDGET_CHECK"); d=simulator_decision(before,e)
        with self.store.atomic():
            self.store.log_event(e); r=self.tx.commit(e,d,expected_revision=0)
        self.assertEqual(r.status,"rejected")

    def test_week_safety(self):
        report=Simulator(self.store).run(168)
        for key in ["wallet_violation_count","calendar_conflict_count","unsupported_fact_count","inventory_violation_count"]:
            self.assertEqual(report[key],0)
        self.assertGreater(report["event_count"],0)

    def test_full_history_survives_cache_bound_and_rollback(self):
        state=self.store.load()
        state.continuity=[ContinuityEdge(cause=f"fixture_{i}",consequence=f"result_{i}",transaction_id=f"tx_{i}",depth=0) for i in range(300)]
        self.store.save(state,"fixture_v1","archive_test")
        self.assertEqual(len(self.store.load().continuity),256)
        self.assertEqual(len(self.store.load(history=True).continuity),300)
        with self.assertRaises(RuntimeError):
            with self.store.atomic():
                state=self.store.load(); state.continuity.append(ContinuityEdge(cause="extra",consequence="extra",transaction_id="extra",depth=0))
                self.store.save(state,"fixture_v1","rollback_archive"); raise RuntimeError("failure")
        self.assertEqual(len(self.store.load(history=True).continuity),300)

    def test_rule_replay_and_restart_produce_identical_events(self):
        a=StateStore(); a.initialize(mock_state()); Simulator(a,seed=97).run(48)
        b=StateStore(); b.initialize(mock_state()); Simulator(b,seed=97).run(24); Simulator(b,seed=97).run(24)
        self.assertEqual(a.load(history=True),b.load(history=True))
        self.assertEqual(a.records("events"),b.records("events"))
        self.assertEqual(a.records("transactions"),b.records("transactions"))

    def test_tick_crash_rolls_back_lock_and_state(self):
        sim=Simulator(self.store); before=self.store.load()
        original=sim.generator.generate
        sim.generator.generate=lambda *a,**k: (_ for _ in ()).throw(RuntimeError("tick crash"))
        # Force a candidate gate for this exact tick without changing the clock.
        sim.grammar.rules["random_gate_probability"]=1
        with self.assertRaises(RuntimeError): sim.tick(before.world.time)
        self.assertEqual(self.store.load(),before); self.assertEqual(self.store.records("ticks"),[])
        sim.generator.generate=original
        self.assertTrue(sim.tick(before.world.time))

    def test_crash_after_event_restores_novelty_index(self):
        sim=Simulator(self.store); sim.grammar.rules["random_gate_probability"]=1
        original=self.store.save
        def fail_after_save(state,cause,kind):
            original(state,cause,kind)
            if kind=="consequences_novelty": raise RuntimeError("crash after novelty")
        self.store.save=fail_after_save
        with self.assertRaises(RuntimeError):
            sim.tick(self.state.world.time)
        self.store.save=original; sim.tick(self.state.world.time)
        reference=StateStore(); reference.initialize(mock_state()); other=Simulator(reference)
        other.grammar.rules["random_gate_probability"]=1; other.tick(self.state.world.time)
        self.assertEqual(self.store.load(history=True),reference.load(history=True))
        self.assertEqual(self.store.records("events"),reference.records("events"))
