import json
import tempfile
import unittest
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
from connectors.mock_native import fixture_purchase
from connectors.native_plans import purchase_plan, plain, rich
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.http_json import HTTPJSON, HTTPFailure, ConnectorUnavailable
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.write_models import WritePlan
from connectors.write_coordinator import WriteCoordinator
from core.mock_state import mock_state
from .native_http_server import NativeHTTPFixture


class P5HTTPTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.evidence,self.proposal,self.now=fixture_purchase()
        self.server=NativeHTTPFixture(self.evidence,page_size=1)
        self.http=HTTPJSON(self.server.url,'fixture-only-token',fixture=True)
        self.notion=NotionConnector(http=self.http)
        self.adapter=NativeHTTPAdapter(self.notion)
        self.calendar=CalendarConnector(calendar_id='fixture.calendar',http=self.http)
        self.calendar_adapter=NativeHTTPAdapter(self.calendar)
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':self.adapter,'calendar':self.calendar_adapter})
        self.plan=purchase_plan(self.evidence,self.proposal,'fixture.http.event','fixture.http.decision',self.now)

    def tearDown(self):
        self.coordinator.close(); self.server.close(); self.temp.cleanup()

    def prepare(self): return self.coordinator.prepare(self.plan)

    def reopen(self):
        self.coordinator.close()
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':self.adapter,'calendar':self.calendar_adapter})

    def calendar_plan(self):
        commitment=mock_state().calendar[0].model_copy(update={'source_event':self.plan.event_id})
        op=self.calendar.create_operation(commitment,self.plan.transaction_id)
        return self.plan.model_copy(update={'operations':self.plan.operations+[op]})

    def test_http_native_purchase_roundtrip_preserves_structures(self):
        tx=self.prepare(); self.assertEqual(self.coordinator.run(tx),'COMMITTED')
        self.assertEqual(len(json.loads(self.coordinator.committed(tx)['receipts'])),6)
        self.assertEqual(plain(self.server.objects['fixture.balance']['bulleted_list_item']['rich_text']),'残高: ¥23,050')
        self.assertEqual(self.server.objects['fixture.moneylog']['table']['table_width'],5)
        inventory=self.notion.inventory_rows('fixture.inventory')
        self.assertEqual(len(inventory),1); self.assertNotIn('Condition',inventory[0]['properties'])
        self.assertTrue(any(c['method']=='POST' and c['path']=='/pages' for c in self.server.calls))
        self.assertFalse(any(c['path'].startswith('https:') for c in self.server.calls))

    def test_disconnected_successful_inventory_create_recovers_by_marker_once(self):
        self.server.fault('POST','/pages','after_disconnect'); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED'); self.reopen()
        self.assertEqual(self.coordinator.reconcile(tx),'COMMITTED')
        self.assertEqual(len([c for c in self.server.calls if c['method']=='POST' and c['path']=='/pages']),1)

    def test_disconnected_before_notion_create_is_not_resent(self):
        self.server.fault('POST','/pages','before_disconnect'); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED'); self.reopen()
        self.assertEqual(self.coordinator.reconcile(tx),'RECONCILE_REQUIRED')
        self.assertEqual(len([c for c in self.server.calls if c['method']=='POST' and c['path']=='/pages']),1)
        self.assertFalse(self.coordinator.confirmations_allowed('inventory'))

    def test_lost_patch_receipt_does_not_invent_write_authorship(self):
        self.server.fault('PATCH','/blocks/fixture.balance','after_disconnect'); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED'); self.reopen()
        self.assertEqual(self.coordinator.reconcile(tx),'RECONCILE_REQUIRED')
        self.assertEqual(plain(self.server.objects['fixture.balance']['bulleted_list_item']['rich_text']),'残高: ¥23,050')
        self.assertIsNone(self.coordinator.committed(tx))

    def test_definitive_http_rejection_rolls_back_native_fields_and_log(self):
        self.server.fault('POST','/pages',403); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK')
        self.assertEqual(plain(self.server.objects['fixture.balance']['bulleted_list_item']['rich_text']),'残高: ¥27,850')
        self.assertEqual(len(self.notion.children('fixture.moneylog')),1)  # original header remains
        self.assertTrue(any(o.get('archived') for o in self.server.objects.values()))
        self.assertIsNone(self.coordinator.committed(tx))

    def test_unavailable_provider_does_not_publish_confirmed_state(self):
        self.server.fault('POST','/pages',503); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertIsNone(self.coordinator.committed(tx))

    def test_duplicate_marker_and_foreign_parent_are_conflicts(self):
        op=next(o for o in self.plan.operations if o.kind=='inventory.create')
        self.adapter.apply(op); row=self.notion.inventory_rows(op.target)[0]
        duplicate=deepcopy(row); duplicate['id']='duplicate'; self.server.objects['duplicate']=duplicate
        self.server.children[op.target].append('duplicate')
        self.assertEqual(self.adapter.observe(op).state,'CONFLICT')
        self.server.children[op.target].remove('duplicate'); self.server.objects[row['id']]['parent']['data_source_id']='other-source'
        self.assertEqual(self.adapter.observe(op).state,'CONFLICT')

    def test_native_version_edit_detected_before_compensation(self):
        op=self.plan.operations[0]; receipt=self.adapter.apply(op)
        self.server.edit(op.target,{'outside_note':'external edit'})
        self.assertEqual(self.adapter.observe(op,receipt).state,'CONFLICT')
        with self.assertRaises(ValueError): self.adapter.compensate(op,receipt)
        self.assertEqual(self.server.objects[op.target]['outside_note'],'external edit')

    def test_http_calendar_create_and_if_match_compensation(self):
        self.plan=self.calendar_plan(); op=self.plan.operations[-1]
        receipt=self.calendar_adapter.apply(op)
        self.assertEqual(self.calendar_adapter.observe(op,receipt).state,'AFTER')
        undo=self.calendar_adapter.compensate(op,receipt)
        self.assertEqual(self.calendar_adapter.observe(op,undo,undo=True).state,'BEFORE')
        call=next(c for c in self.server.calls if c['method']=='DELETE' and c['path'].startswith('/calendars'))
        self.assertEqual(call['if_match'],receipt['version'])
        self.assertNotIn('attendees',op.after)

    def test_calendar_412_conflict_never_deletes_external_edit(self):
        self.plan=self.calendar_plan(); op=self.plan.operations[-1]; receipt=self.calendar_adapter.apply(op)
        self.server.fault('DELETE',self.calendar.path+'/'+receipt['resource_id'],412)
        with self.assertRaises(HTTPFailure) as error: self.calendar_adapter.compensate(op,receipt)
        self.assertEqual(error.exception.status,412); self.assertIn(receipt['resource_id'],self.server.objects)

    def test_calendar_response_loss_recovers_supplied_id(self):
        self.plan=self.calendar_plan(); self.server.fault('POST',self.calendar.path,'after_disconnect')
        tx=self.prepare(); self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.reopen(); self.assertEqual(self.coordinator.reconcile(tx),'COMMITTED')
        calls=[c for c in self.server.calls if c['method']=='POST' and c['path']==self.calendar.path]
        self.assertEqual(len(calls),1)

    def test_calendar_compensation_response_loss_is_verified_by_absence_after_restart(self):
        combined=self.calendar_plan(); calendar=combined.operations[-1]
        self.plan=combined.model_copy(update={'operations':[calendar]+combined.operations[:-1]})
        self.server.fault('POST','/pages',403)
        self.server.fault('DELETE',self.calendar.path+'/'+calendar.after['id'],'after_disconnect')
        tx=self.prepare(); self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.reopen(); self.assertEqual(self.coordinator.reconcile(tx),'ROLLED_BACK')
        deletes=[c for c in self.server.calls if c['method']=='DELETE' and c['path'].startswith('/calendars')]
        self.assertEqual(len(deletes),1); self.assertEqual(self.coordinator.committed(tx),None)

    def test_http_error_contains_only_status_and_no_provider_body(self):
        self.server.fault('GET','/blocks/fixture.balance',403)
        with self.assertRaises(HTTPFailure) as error: self.notion.block('fixture.balance')
        self.assertNotIn('PRIVATE_ERROR_SENTINEL',str(error.exception))
        self.assertNotIn('fixture-only-token',str(error.exception))

    def test_production_adapter_is_read_only_and_fixture_cannot_point_outside_loopback(self):
        with self.assertRaises(ValueError): HTTPJSON('https://api.notion.com/v1','fixture',fixture=True)
        with self.assertRaises(ValueError): HTTPJSON('http://other.invalid','fixture')
        http=HTTPJSON('https://api.notion.com/v1','not-used')
        adapter=NativeHTTPAdapter(NotionConnector(http=http))
        with self.assertRaises(ConnectorUnavailable): adapter.apply(self.plan.operations[0])
        self.assertEqual(adapter.evidence_scope,'canonical')
        with self.assertRaises(ValueError): self.http.request('GET','//other.invalid')
        with self.assertRaises(ValueError): self.http.request('GET','/blocks/fixture.balance',headers={'Authorization':'override'})
