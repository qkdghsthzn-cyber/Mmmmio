import unittest
from datetime import timedelta
from core.mock_state import mock_state
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.http_json import ConnectorUnavailable
from connectors.sync import CanonicalReadSync


class FakeHTTP:
    def __init__(self,outputs): self.outputs=list(outputs); self.calls=[]
    def request(self,method,path,body=None,dry_run=False):
        self.calls.append((method,path,body,dry_run))
        if dry_run: return {"dry_run":True,"method":method,"path":path,"body":body}
        value=self.outputs.pop(0)
        if isinstance(value,Exception): raise value
        return value


class P5ContractTests(unittest.TestCase):
    def test_notion_block_pagination_preserves_structure(self):
        http=FakeHTTP([{"id":"page","last_edited_time":"version"},
            {"results":[{"id":"a","has_children":True,"type":"table"}],"has_more":True,"next_cursor":"cursor"},
            {"results":[{"id":"row","type":"table_row"}],"has_more":False},
            {"results":[{"id":"b","type":"paragraph"}],"has_more":False}])
        result=NotionConnector(http=http).page("page")
        self.assertEqual(len(result["blocks"]),2); self.assertEqual(result["blocks"][0]["children"][0]["type"],"table_row")
        self.assertIn("start_cursor=cursor",http.calls[-1][1])

    def test_native_inventory_properties_are_not_flattened(self):
        properties={"Item":{"type":"title","title":[{"plain_text":"confirmed item","text":{"content":"confirmed item"}}]},"Purchase Price":{"type":"number","number":None}}
        http=FakeHTTP([{"results":[{"id":"real_item","properties":properties}],"has_more":False}])
        rows=NotionConnector(http=http).inventory_rows("source")
        self.assertEqual(rows[0]["properties"],properties)

    def test_calendar_time_window_and_pagination(self):
        http=FakeHTTP([{"items":[{"id":"one"}],"nextPageToken":"next"},{"items":[{"id":"two"}]}])
        state=mock_state(); calendar=CalendarConnector(calendar_id="fixture",http=http)
        self.assertEqual(len(calendar.events(state.world.time,state.world.time+timedelta(days=7))),2)
        self.assertIn("pageToken=next",http.calls[-1][1]); self.assertIn("timeMin=",http.calls[0][1])

    def test_dry_run_idempotency_and_no_invitations(self):
        http=FakeHTTP([]); c=CalendarConnector(calendar_id="fixture",http=http); event=mock_state().calendar[0]
        a=c.create_plan(event,"tx_test"); b=c.create_plan(event,"tx_test")
        self.assertEqual(a,b); self.assertTrue(a["dry_run"]); self.assertNotIn("attendees",a["body"])
        self.assertEqual(a["body"]["extendedProperties"]["private"]["mio_source_event"],"fixture_v1")

    def test_sync_failure_marks_stale_without_invented_state(self):
        state=mock_state(); before=state.wallet.model_dump()
        n=NotionConnector(http=FakeHTTP([ConnectorUnavailable("offline")]))
        c=CalendarConnector(calendar_id="fixture",http=FakeHTTP([ConnectorUnavailable("offline")]))
        result=CanonicalReadSync(n,c).read(state,{"wallet":"page"},"source",state.world.time,state.world.time+timedelta(days=1))
        self.assertTrue(state.notion_stale); self.assertTrue(state.calendar_stale)
        self.assertEqual(state.wallet.model_dump(),before); self.assertNotIn("inventory",result)

    def test_live_writes_remain_blocked_until_phase_gate_passes(self):
        with self.assertRaises(ConnectorUnavailable): NotionConnector(http=FakeHTTP([])).apply_live()
        with self.assertRaises(ConnectorUnavailable): CalendarConnector(calendar_id="fixture",http=FakeHTTP([])).apply_live()
