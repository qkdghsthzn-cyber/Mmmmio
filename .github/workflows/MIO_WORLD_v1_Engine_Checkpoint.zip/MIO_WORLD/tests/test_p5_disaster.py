import json
import sqlite3
import tempfile
import subprocess
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
from datetime import timedelta
from connectors.database_recovery import DatabaseRecoveryVault,RecoveryUnavailable,revalidate_recovered,logical_hash
from connectors.http_json import ConnectorUnavailable
from connectors.native_plans import money_field
from tests import test_p5_hourly as support


class P5DisasterTests(unittest.TestCase):
    connect=support.P5HourlyTests.connect
    initialize=support.P5HourlyTests.initialize
    runtime=support.P5HourlyTests.runtime
    one_event=support.P5HourlyTests.one_event

    def setUp(self):
        support.P5HourlyTests.setUp(self); self.initialize(); self.runner=self.runtime()
        self.offsite=tempfile.TemporaryDirectory(); root=Path(self.offsite.name)
        self.vault=DatabaseRecoveryVault(root/'images',root/'witness/head.json',b'fixture-disaster-signing-key-0000','fixture.world.recovery')
        self.coordinator.enable_recovery(self.vault)

    def tearDown(self):
        support.P5HourlyTests.tearDown(self); self.offsite.cleanup()

    def completed(self):
        self.runner._selected=lambda state:[]
        self.assertEqual(self.runner.tick(self.now)['status'],'COMPLETED')

    def lose(self):
        self.coordinator.close()
        for suffix in ['', '-wal','-shm','.worker','.scheduler']:
            Path(str(self.path)+suffix).unlink(missing_ok=True)

    def restore(self,attach=True):
        result=self.vault.restore(self.path); self.assertEqual(result['status'],'RESTORED_FROZEN')
        self.connect()
        if attach:self.coordinator.enable_recovery(self.vault)
        self.runner=self.runtime(); return result

    def revalidate(self):return revalidate_recovered(self.runner)
    def calls(self,method,path):return [c for c in self.server.calls if c['method']==method and c['path']==path]
    def image(self):return self.vault.directory/self.vault.latest()['file']
    def late_response(self,tx):
        row=next(r for r in self.coordinator.rows(tx) if r['status']=='APPLYING'); op=json.loads(row['body'])
        method,path=('POST','/pages') if op['kind']=='inventory.create' else ('PATCH','/blocks/'+op['target']+'/children')
        self.assertEqual(self.server.route(method,path,{},op['after'],{})[0],200)

    def test_entire_database_loss_restores_all_tables_then_requires_fresh_reads(self):
        self.completed(); before=logical_hash(self.bridge.db,base=True); state=self.bridge.state()
        self.lose(); self.vault.restore(self.path)
        db=sqlite3.connect(self.path); self.assertEqual(logical_hash(db,base=True),before); db.close()
        self.connect(); self.runner=self.runtime()
        self.assertEqual(self.bridge.state(),state); self.assertFalse(self.bridge.confirmations_allowed('wallet'))
        self.coordinator.enable_recovery(self.vault)
        self.assertEqual(self.revalidate()['status'],'VERIFIED'); self.assertTrue(self.bridge.confirmations_allowed())
        self.assertEqual(self.bridge.state().wallet,state.wallet)

    def test_restored_tick_is_frozen_without_new_decision_or_clock(self):
        self.completed(); state=self.bridge.state(); self.lose(); self.restore()
        with self.assertRaises(RecoveryUnavailable):self.runner.tick(self.now+timedelta(hours=1))
        self.assertEqual(self.bridge.state(),state); self.assertEqual(self.agent.calls,[])

    def test_restored_database_without_vault_cannot_mutate_or_run_provider(self):
        self.completed(); self.lose(); self.restore(attach=False)
        calls=len(self.server.calls)
        with self.assertRaises(RecoveryUnavailable):
            with self.coordinator.atomic(): self.bridge.db.execute("DELETE FROM hourly_ticks")
        tx=self.bridge.db.execute('SELECT transaction_id FROM external_transactions LIMIT 1').fetchone()[0]
        with self.assertRaises(RecoveryUnavailable):self.coordinator.run(tx)
        self.assertEqual(len(self.server.calls),calls)

    def test_resume_next_hour_after_revalidation_has_one_tick(self):
        self.completed(); self.lose(); self.restore(); self.revalidate()
        self.runner._selected=lambda state:[]
        self.assertEqual(self.runner.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(self.runner.tick(self.now+timedelta(hours=1))['status'],'ALREADY_COMPLETED')
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM hourly_ticks').fetchone()[0],2)

    def test_committed_purchase_is_not_bought_or_charged_again(self):
        self.one_event(self.runner,'PURCHASE_ITEM'); self.runner.tick(self.now)
        state=self.bridge.state(); created=len(self.calls('POST','/pages')); self.lose(); self.restore()
        self.assertEqual(self.revalidate()['status'],'VERIFIED')
        self.assertEqual(self.bridge.state().wallet,state.wallet); self.assertEqual(self.bridge.state().inventory,state.inventory)
        self.assertEqual(len(self.calls('POST','/pages')),created)
        self.assertEqual(self.runner.tick(self.now)['status'],'ALREADY_COMPLETED')

    def test_lost_notion_create_ack_restores_intent_and_recovers_once(self):
        self.one_event(self.runner,'PURCHASE_ITEM'); self.server.fault('POST','/pages','after_disconnect')
        self.assertEqual(self.runner.tick(self.now)['status'],'BLOCKED_RECOVERY')
        self.lose(); self.restore(); self.assertEqual(self.revalidate()['status'],'VERIFIED')
        self.assertEqual(len(self.calls('POST','/pages')),1); self.assertEqual(self.bridge.state().wallet.balance,23050)
        self.assertEqual(len(self.bridge.state().inventory),1); self.assertEqual(len(self.agent.calls),1)

    def test_unknown_in_flight_create_remains_frozen_without_resend(self):
        self.one_event(self.runner,'PURCHASE_ITEM'); self.server.fault('POST','/pages','before_disconnect')
        self.runner.tick(self.now); self.lose(); self.restore()
        self.assertEqual(self.revalidate()['status'],'WAITING_NATIVE_RECOVERY')
        self.assertEqual(len(self.calls('POST','/pages')),1); self.assertFalse(self.bridge.confirmations_allowed())
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        tx=self.bridge.db.execute("SELECT transaction_id FROM cache_bindings WHERE status='PENDING'").fetchone()[0]
        self.late_response(tx); self.assertEqual(self.revalidate()['status'],'VERIFIED')
        self.assertEqual(self.bridge.state().wallet.balance,23050); self.assertEqual(len(self.calls('POST','/pages')),1)

    def test_lost_field_patch_ack_preserves_unknown_authorship(self):
        self.one_event(self.runner,'SMALL_EXPENSE'); self.server.fault('PATCH','/blocks/fixture.balance','after_disconnect')
        self.runner.tick(self.now); self.lose(); self.restore()
        self.assertEqual(self.revalidate()['status'],'WAITING_NATIVE_RECOVERY')
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertEqual(len(self.calls('PATCH','/blocks/fixture.balance')),1)

    def test_clock_journal_survives_primary_loss_and_late_publication(self):
        self.one_event(self.runner,'SMALL_EXPENSE'); self.server.fault('PATCH','/blocks/fixture.continuity/children','before_disconnect')
        self.runner.tick(self.now); self.runner.tick(self.now+timedelta(hours=1))
        state=self.bridge.state(); self.lose(); self.restore()
        self.assertEqual(self.bridge.state(),state)
        tx=self.bridge.db.execute("SELECT transaction_id FROM cache_bindings WHERE status='PENDING'").fetchone()[0]
        self.late_response(tx); self.assertEqual(self.revalidate()['status'],'VERIFIED')
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=1))
        self.assertEqual(self.bridge.state().wallet.balance,27600); self.assertEqual(len(self.agent.calls),1)

    def test_decision_calling_stage_survives_loss_without_repeat_api_call(self):
        self.one_event(self.runner,'SMALL_EXPENSE')
        def interrupted(state,event):self.agent.calls.append(event.event_id); raise SystemExit('fixture decision response lost')
        self.agent.decide=interrupted
        with self.assertRaises(SystemExit):self.runner.tick(self.now)
        self.lose(); self.restore(); self.revalidate()
        self.assertEqual(self.runner.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(len(self.agent.calls),1); self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_native_read_failure_keeps_gate_frozen_then_recovers(self):
        self.completed(); self.lose(); self.restore(); self.server.fault('GET','/pages/fixture.wallet',503)
        self.assertEqual(self.revalidate()['status'],'WAITING_FRESH_NATIVE_READ'); self.assertFalse(self.bridge.confirmations_allowed())
        self.assertEqual(self.revalidate()['status'],'VERIFIED')

    def test_unexplained_native_balance_does_not_release_restore_gate(self):
        self.completed(); self.lose(); self.restore()
        self.server.edit('fixture.balance',money_field(self.server.objects['fixture.balance'],'残高:',99999)[1])
        self.assertEqual(self.revalidate()['status'],'WAITING_FRESH_NATIVE_READ')
        self.assertFalse(self.bridge.confirmations_allowed()); self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_repeat_revalidation_does_not_duplicate_commit_or_cause(self):
        self.completed(); self.lose(); self.restore(); self.revalidate(); before=logical_hash(self.bridge.db)
        self.assertEqual(self.revalidate()['status'],'ALREADY_VERIFIED'); self.assertEqual(logical_hash(self.bridge.db),before)

    def test_corrupted_latest_image_has_no_older_fallback(self):
        self.completed(); image=self.image(); raw=image.read_bytes(); image.write_bytes(raw[:-1]+bytes([raw[-1]^1]))
        self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)
        self.assertFalse(self.path.exists())

    def test_missing_latest_image_has_no_older_fallback(self):
        self.completed(); self.image().unlink(); self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)
        self.assertFalse(self.path.exists())

    def test_wrong_key_or_world_identity_cannot_restore(self):
        self.completed(); self.lose()
        for key,world in [(b'wrong-key-that-is-at-least-32-bytes','fixture.world.recovery'),(self.vault.key,'another.world')]:
            with self.subTest(world=world):
                vault=DatabaseRecoveryVault(self.vault.directory,self.vault.witness,key,world)
                with self.assertRaises(RecoveryUnavailable):vault.restore(self.path)
        self.assertFalse(self.path.exists())

    def test_witness_tampering_is_rejected(self):
        self.completed(); body=json.loads(self.vault.witness.read_text()); body['body']['sequence']-=1
        self.vault.witness.write_text(json.dumps(body)); self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)

    def test_caller_latest_sequence_rejects_replayed_signed_old_witness(self):
        old=self.vault.witness.read_bytes(); self.completed(); latest=self.vault.latest()['sequence']
        self.vault.witness.write_bytes(old); self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path,expected_sequence=latest)

    def test_existing_primary_or_wal_is_not_overwritten(self):
        self.completed(); before=self.path.read_bytes()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)
        self.assertEqual(self.path.read_bytes(),before); self.lose(); Path(str(self.path)+'-wal').write_bytes(b'preserved WAL')
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)
        self.assertEqual(Path(str(self.path)+'-wal').read_bytes(),b'preserved WAL')

    def test_wrong_target_path_cannot_fork_the_world(self):
        self.completed(); self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path.parent/'other.sqlite3')
        self.assertFalse((self.path.parent/'other.sqlite3').exists())

    def test_atomic_rollback_keeps_latest_clean_snapshot_unchanged(self):
        head=self.vault.latest(); before=self.bridge.state()
        with self.assertRaises(RuntimeError):
            with self.coordinator.atomic():
                self.bridge.db.execute('DELETE FROM runtime_cache'); raise RuntimeError('fixture rollback')
        self.assertEqual(self.vault.latest(),head); self.assertEqual(self.bridge.state(),before)

    def test_failed_checkpoint_after_commit_keeps_dirty_fence_and_blocks_provider(self):
        with patch.object(self.vault,'finish',side_effect=RecoveryUnavailable('fixture save failure')):
            with self.assertRaises(RecoveryUnavailable):
                with self.coordinator.atomic():self.coordinator.audit('fixture','save failure')
        self.assertEqual(self.vault.latest(allow_dirty=True)['status'],'DIRTY')
        self.assertFalse(self.bridge.confirmations_allowed()); calls=len(self.server.calls)
        with self.assertRaises(RecoveryUnavailable):self.runner.tick(self.now)
        self.assertEqual(len(self.server.calls),calls)
        self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)

    def test_interrupted_checkpoint_can_be_repaired_only_from_surviving_primary(self):
        with patch.object(self.vault,'finish',side_effect=RecoveryUnavailable('fixture save failure')):
            with self.assertRaises(RecoveryUnavailable):
                with self.coordinator.atomic():self.coordinator.audit('fixture','committed before save failure')
        sequence=self.vault.latest(allow_dirty=True)['sequence']
        self.assertEqual(self.vault.repair_live(self.coordinator)['status'],'CHECKPOINT_REPAIRED')
        self.assertGreater(self.vault.latest()['sequence'],sequence); self.vault.ensure_clean(self.bridge.db)

    def test_backup_failure_at_applying_marker_sends_no_native_write(self):
        self.one_event(self.runner,'SMALL_EXPENSE'); original=self.vault.finish
        def finish(db):
            row=db.execute("SELECT 1 FROM external_outbox WHERE status='APPLYING'").fetchone()
            if row:raise RecoveryUnavailable('fixture write-ahead save failed')
            return original(db)
        with patch.object(self.vault,'finish',side_effect=finish):
            with self.assertRaises(RecoveryUnavailable):self.runner.tick(self.now)
        self.assertEqual(self.calls('PATCH','/blocks/fixture.balance'),[])
        self.assertEqual(self.vault.latest(allow_dirty=True)['status'],'DIRTY')

    def test_checkpoint_contains_wal_commits_and_retains_bounded_images(self):
        self.completed()
        self.assertLessEqual(len(list(self.vault.directory.glob('checkpoint-*.sqlite3'))),3)
        self.assertGreater(self.vault.latest()['sequence'],1)
        self.lose(); self.restore(); self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM hourly_ticks').fetchone()[0],1)

    def test_backup_and_latest_witness_cannot_share_primary_failure_directory(self):
        other=DatabaseRecoveryVault(self.path.parent/'unsafe-images',Path(self.offsite.name)/'separate/head.json',self.vault.key,'fixture.world.recovery')
        with self.assertRaises(RecoveryUnavailable):other.attach(self.coordinator)
        with self.assertRaises(ValueError):DatabaseRecoveryVault(self.vault.directory,self.vault.directory/'head.json',self.vault.key,'fixture.world.recovery')

    def test_untracked_database_edit_does_not_become_a_signed_checkpoint(self):
        self.bridge.db.execute("UPDATE runtime_cache SET body='{}' WHERE id=1")
        with self.assertRaises(RecoveryUnavailable):
            with self.coordinator.atomic():pass
        self.assertFalse(self.bridge.confirmations_allowed())

    def test_missing_protected_witness_does_not_create_new_lineage(self):
        self.vault.witness.unlink(); self.coordinator.close(); self.connect()
        with self.assertRaises(RecoveryUnavailable):self.coordinator.enable_recovery(self.vault)

    def test_replaced_primary_is_rejected_by_still_open_worker(self):
        replacement=self.path.parent/'replacement'; replacement.write_bytes(self.path.read_bytes())
        replacement.replace(self.path)
        with self.assertRaises(RecoveryUnavailable):self.vault.ensure_clean(self.bridge.db)

    def test_process_death_inside_checkpoint_preserves_dirty_fence(self):
        code='''
import os,sys
from connectors.database_recovery import DatabaseRecoveryVault
from connectors.write_coordinator import WriteCoordinator
c=WriteCoordinator(sys.argv[1],{})
v=DatabaseRecoveryVault(sys.argv[2],sys.argv[3],b'fixture-disaster-signing-key-0000','fixture.world.recovery')
c.enable_recovery(v)
with c.atomic():
    c.audit('fixture','interrupted checkpoint transaction')
    os._exit(17)
'''
        result=subprocess.run([sys.executable,'-c',code,str(self.path),str(self.vault.directory),str(self.vault.witness)],capture_output=True,timeout=20)
        self.assertEqual(result.returncode,17,result.stderr.decode())
        self.assertEqual(self.vault.latest(allow_dirty=True)['status'],'DIRTY')
        self.lose()
        with self.assertRaises(RecoveryUnavailable):self.vault.restore(self.path)

    def test_fixture_checkpoint_does_not_promote_canonical_scope(self):
        with self.assertRaises(RecoveryUnavailable):
            with self.coordinator.atomic():self.bridge.db.execute("UPDATE runtime_cache SET scope='canonical' WHERE id=1")
        self.assertEqual(self.vault.latest(allow_dirty=True)['status'],'DIRTY')
        self.assertFalse(self.bridge.confirmations_allowed())
