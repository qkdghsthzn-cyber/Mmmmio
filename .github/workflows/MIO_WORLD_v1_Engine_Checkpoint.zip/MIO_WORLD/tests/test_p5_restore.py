import json
import unittest
from copy import deepcopy
from datetime import timedelta
from core.models import State
from core.validator import RuleViolation
from connectors.native_restore import NativeRuntimeRestorer,checkpoint_operations,decode_payload
from connectors.native_plans import plain
from connectors.write_models import digest,transaction_id
from connectors.http_json import ConnectorUnavailable
from tests import test_p5_hourly as support


class P5RestoreTests(unittest.TestCase):
    setUp=support.P5HourlyTests.setUp
    tearDown=support.P5HourlyTests.tearDown
    connect=support.P5HourlyTests.connect
    initialize=support.P5HourlyTests.initialize
    runtime=support.P5HourlyTests.runtime
    one_event=support.P5HourlyTests.one_event

    def checkpoint(self,family=None):
        self.initialize(); runtime=self.runtime()
        if family: self.one_event(runtime,family)
        else: runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.expected=self.bridge.state(); return runtime

    def restorer(self): return NativeRuntimeRestorer(self.bridge,self.notion,self.calendar,lambda:self.now)
    def lose(self): self.bridge.db.execute('DELETE FROM runtime_cache')

    def test_restore_missing_cache_from_native_verified_full_state(self):
        self.checkpoint('SMALL_EXPENSE'); calls=len(self.agent.calls)
        before=len([c for c in self.server.calls if c['method'] in {'PATCH','DELETE'} or c['path']=='/pages' and c['method']=='POST'])
        self.lose(); result=self.restorer().restore()
        self.assertEqual(result['status'],'RESTORED'); state=self.bridge.confirmed_state()
        self.assertEqual(state.wallet,self.expected.wallet); self.assertEqual(state.world,self.expected.world)
        self.assertEqual(state.relationships,self.expected.relationships); self.assertEqual(state.taste,self.expected.taste)
        self.assertEqual(state.novelty_memory,self.expected.novelty_memory); self.assertEqual(state.continuity,self.expected.continuity)
        self.assertEqual(len(self.agent.calls),calls)
        after=len([c for c in self.server.calls if c['method'] in {'PATCH','DELETE'} or c['path']=='/pages' and c['method']=='POST'])
        self.assertEqual(after,before)
        self.assertEqual(self.restorer().restore()['status'],'ALREADY_PRESENT')

    def test_restore_corrupt_cache_and_missing_causal_archive_then_resume(self):
        self.checkpoint('BUDGET_CHECK')
        count=self.bridge.db.execute('SELECT COUNT(*) FROM runtime_continuity_archive').fetchone()[0]
        self.bridge.db.execute("UPDATE runtime_cache SET body='broken' WHERE id=1")
        self.bridge.db.execute('DROP TABLE runtime_continuity_archive')
        self.assertEqual(self.restorer().restore()['status'],'RESTORED')
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM runtime_continuity_archive').fetchone()[0],count)
        runtime=self.runtime(); runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(len(self.agent.calls),1)

    def test_restore_purchase_preserves_native_id_price_and_unknowns(self):
        self.checkpoint('PURCHASE_ITEM'); key=next(iter(self.expected.inventory)); self.lose()
        self.assertEqual(self.restorer().restore()['status'],'RESTORED')
        item=self.bridge.state().inventory[key]; self.assertEqual(item,self.expected.inventory[key])
        self.assertEqual(item.provenance.source,'mock'); self.assertIsNone(item.condition)
        self.assertEqual(self.bridge.state().wallet.balance,23050)

    def test_native_block_edit_or_deletion_prevents_restore(self):
        self.checkpoint(); self.lose()
        key=self.server.children['fixture.world'][-1]
        self.server.edit(key,{'code':{'language':'json','rich_text':[{'type':'text','text':{'content':'{}'}}]}})
        with self.assertRaises(RuleViolation): self.restorer().restore()
        self.assertIsNone(self.bridge.db.execute('SELECT 1 FROM runtime_cache').fetchone())

    def test_missing_fragment_prevents_restore(self):
        self.checkpoint(); self.lose(); key=self.server.children['fixture.world'][0]
        self.server.children['fixture.world'].remove(key)
        del self.server.objects[key]
        with self.assertRaises((RuleViolation,KeyError)): self.restorer().restore()
        self.assertIsNone(self.bridge.db.execute('SELECT 1 FROM runtime_cache').fetchone())

    def test_usable_newer_cache_is_never_overwritten(self):
        self.checkpoint(); state=self.bridge.state(); state.world.mood='newer independent mood'; state.revision+=1
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        with self.assertRaises(RuleViolation): self.restorer().restore()
        self.assertEqual(self.bridge.state(),state)

    def test_same_usable_state_needs_no_import(self):
        self.checkpoint(); self.assertEqual(self.restorer().restore()['status'],'ALREADY_PRESENT')
        self.assertEqual(self.bridge.state(),self.expected)

    def test_older_native_snapshot_cannot_rewind_newer_durable_clock(self):
        runtime=self.checkpoint(); self.server.fault('PATCH','/blocks/fixture.world/children',403)
        runtime.tick(self.now+timedelta(hours=1)); self.lose()
        with self.assertRaises(RuleViolation): self.restorer().restore()
        self.assertIsNone(self.bridge.db.execute('SELECT 1 FROM runtime_cache').fetchone())

    def test_pending_native_transaction_blocks_restore(self):
        runtime=self.checkpoint(); self.one_event(runtime,'SMALL_EXPENSE')
        self.server.fault('PATCH','/blocks/fixture.continuity/children','before_disconnect')
        runtime.tick(self.now+timedelta(hours=1)); self.lose()
        with self.assertRaises(ConnectorUnavailable): self.restorer().restore()

    def test_native_outage_leaves_recovered_external_domains_stale(self):
        self.checkpoint(); self.lose(); self.server.fault('GET','/pages/fixture.wallet',503)
        result=self.restorer().restore(); self.assertEqual(result['status'],'RESTORED_STALE')
        self.assertEqual(self.bridge.state().world,self.expected.world)
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_unexplained_native_money_change_stays_frozen_after_internal_restore(self):
        self.checkpoint(); self.lose()
        from connectors.native_plans import money_field
        self.server.edit('fixture.balance',money_field(self.server.objects['fixture.balance'],'残高:',99000)[1])
        result=self.restorer().restore(); self.assertEqual(result['status'],'RESTORED_STALE')
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertEqual(self.bridge.state().wallet.ledger,[])

    def test_fixture_checkpoint_cannot_replace_live_scope_cache(self):
        self.checkpoint(); self.bridge.db.execute("UPDATE runtime_cache SET scope='canonical',body='broken' WHERE id=1")
        with self.assertRaises(RuleViolation): self.restorer().restore()
        self.assertEqual(self.bridge.db.execute('SELECT scope FROM runtime_cache').fetchone()[0],'canonical')

    def test_initialization_tampering_prevents_restore(self):
        self.checkpoint(); self.lose(); self.bridge.db.execute("UPDATE runtime_initialization SET proof_hash='tampered'")
        with self.assertRaises(RuleViolation): self.restorer().restore()

    def test_causal_archive_conflict_rolls_back_cache_restore(self):
        self.checkpoint('BUDGET_CHECK'); self.lose()
        row=self.bridge.db.execute('SELECT edge_id,body FROM runtime_continuity_archive').fetchone()
        changed=json.loads(row['body']); changed['depth']+=1
        self.bridge.db.execute('UPDATE runtime_continuity_archive SET body=? WHERE edge_id=?',(json.dumps(changed),row['edge_id']))
        with self.assertRaises(RuleViolation): self.restorer().restore()
        self.assertIsNone(self.bridge.db.execute('SELECT 1 FROM runtime_cache').fetchone())

    def test_multi_part_payload_roundtrip_respects_native_text_budget(self):
        self.checkpoint(); page=self.notion.page('fixture.world')
        # Deterministic incompressible-ish test content forces several parts.
        from hashlib import sha256
        extra=''.join(sha256(str(i).encode()).hexdigest() for i in range(5000))
        payload={'format':'native-cache-v1','example':extra}
        record={'kind':'world_snapshot','scope':'fixture','tick_id':'chunk.test','cache_checkpoint':payload}
        ops=checkpoint_operations(page,transaction_id('chunk.test'),record)
        self.assertGreater(len(ops),2)
        parts=[]; header=None
        for op in ops:
            value=json.loads(plain(op.after['children'][0]['code']['rich_text']))
            self.assertLessEqual(len(op.after['children'][0]['code']['rich_text']),100)
            if value['kind']=='runtime_checkpoint_part': parts.append(value['payload'])
            else: header=value
        self.assertEqual(decode_payload(parts,header['recovery']['size_bytes']),payload)
        self.assertEqual(header['recovery']['payload_hash'],digest(payload))

    def test_corrupt_or_oversized_compressed_payload_is_rejected(self):
        with self.assertRaises(RuleViolation): decode_payload(['not-base64'],100)
        with self.assertRaises(RuleViolation): decode_payload(['eA=='],17*1024*1024)

    def test_external_ledger_delta_can_be_verified_after_native_cache_restore(self):
        self.checkpoint(); self.lose()
        from connectors.native_plans import rich,money_field
        key='external.restore.expense'
        self.server.objects[key]={'id':key,'object':'block','type':'table_row','last_edited_time':'external.v1',
            'parent':{'type':'block_id','block_id':'fixture.moneylog'},'table_row':{'cells':[rich(c) for c in
                [self.now.date().isoformat(),'EXPENSE','external native cause','-¥250','¥27,600']]}}
        self.server.children['fixture.moneylog'].append(key)
        for identifier,label,value in [('fixture.balance','残高:',27600),('fixture.monthly','今月の支出:',250)]:
            self.server.edit(identifier,money_field(self.server.objects[identifier],label,value)[1])
        self.assertEqual(self.restorer().restore()['status'],'RESTORED')
        self.assertEqual(self.bridge.state().wallet.balance,27600)
        self.assertEqual(self.bridge.state().wallet.ledger[-1].event_id,'native:notion:'+key)
        self.assertEqual(self.bridge.state().world,self.expected.world)

    def test_native_read_failure_before_validation_does_not_install_cache(self):
        self.checkpoint(); self.lose(); self.server.fault('GET','/pages/fixture.world',503)
        with self.assertRaises(ConnectorUnavailable): self.restorer().restore()
        self.assertIsNone(self.bridge.db.execute('SELECT 1 FROM runtime_cache').fetchone())

    def test_missing_durable_proof_does_not_seed_default_world(self):
        with self.assertRaises(RuleViolation): self.restorer().restore()
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM runtime_cache').fetchone()[0],0)
        self.assertEqual(self.server.calls,[])
