import json
import unittest
from datetime import timedelta,timezone
from core.models import State,Hook,Journey,Commitment,Provenance
from core.validator import RuleViolation
from connectors.write_models import digest
from connectors.http_json import ConnectorUnavailable
from tests import test_p5_hourly as support


class P5ClockTests(unittest.TestCase):
    setUp=support.P5HourlyTests.setUp
    tearDown=support.P5HourlyTests.tearDown
    connect=support.P5HourlyTests.connect
    initialize=support.P5HourlyTests.initialize
    runtime=support.P5HourlyTests.runtime
    one_event=support.P5HourlyTests.one_event

    def block(self,family='SMALL_EXPENSE'):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,family)
        target='/pages' if family=='PURCHASE_ITEM' else '/blocks/fixture.continuity/children'
        method='POST' if family=='PURCHASE_ITEM' else 'PATCH'
        self.server.fault(method,target,'before_disconnect')
        self.assertEqual(runtime.tick(self.now)['status'],'BLOCKED_RECOVERY')
        row=self.bridge.db.execute("SELECT transaction_id FROM cache_bindings WHERE status='PENDING'").fetchone()
        self.tx=row[0]; self.runtime_instance=runtime; return runtime

    def late_response(self):
        row=next(r for r in self.coordinator.rows(self.tx) if r['status']=='APPLYING')
        op=json.loads(row['body'])
        if op['kind']=='inventory.create': method,path='POST','/pages'
        else: method,path='PATCH','/blocks/'+op['target']+'/children'
        status,_=self.server.route(method,path,{},op['after'],{})
        self.assertEqual(status,200)

    def test_unresolved_money_continues_clock_needs_without_new_llm_or_confirmations(self):
        runtime=self.block(); hunger=self.bridge.state().world.needs.hunger
        for hours in [1,2,3]:
            self.assertEqual(runtime.tick(self.now+timedelta(hours=hours))['status'],'COMPLETED_CLOCK_ONLY')
        state=self.bridge.state(); self.assertEqual(state.world.time,self.now+timedelta(hours=3))
        self.assertEqual(state.world.needs.hunger,hunger+15); self.assertEqual(state.wallet.balance,27850)
        self.assertEqual(state.inventory,{}); self.assertEqual(len(self.agent.calls),1)
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))
        with self.assertRaises(ConnectorUnavailable): self.bridge.confirmed_state()
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM cache_clock_steps').fetchone()[0],3)

    def test_late_money_publication_preserves_current_clock_and_applies_once(self):
        runtime=self.block(); runtime.tick(self.now+timedelta(hours=1)); runtime.tick(self.now+timedelta(hours=2))
        self.late_response(); runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now+timedelta(hours=3))['status'],'COMPLETED')
        state=self.bridge.state(); self.assertEqual(state.wallet.balance,27600)
        self.assertEqual(state.world.time,self.now+timedelta(hours=3)); self.assertEqual(len(state.wallet.ledger),1)
        self.assertEqual(len(self.agent.calls),1); self.assertTrue(self.bridge.confirmations_allowed())
        self.assertEqual(runtime.tick(self.now)['status'],'ALREADY_COMPLETED')
        self.assertEqual(self.bridge.state(),state)
        self.assertEqual(self.bridge.db.execute("SELECT stage FROM hourly_ticks WHERE time=?",(self.now.isoformat(),)).fetchone()[0],'RECOVERED')

    def test_delayed_purchase_binds_native_id_and_original_cause_after_clock(self):
        runtime=self.block('PURCHASE_ITEM'); runtime.tick(self.now+timedelta(hours=1)); self.late_response()
        runtime._selected=lambda state:[]; runtime.tick(self.now+timedelta(hours=2))
        state=self.bridge.state(); self.assertEqual(state.wallet.balance,23050); self.assertEqual(len(state.inventory),1)
        key=next(iter(state.inventory)); self.assertIn(key,self.server.objects)
        self.assertEqual(state.inventory[key].acquired_at,self.now)
        self.assertEqual(state.inventory[key].provenance.source,'mock')
        self.assertEqual(len(self.agent.calls),1)

    def test_need_effect_is_replayed_before_elapsed_clamped_clock_not_added_late(self):
        data=self.request.model_dump(mode='json'); data['world']['needs']['hunger']=1
        self.request=type(self.request).model_validate(data)
        runtime=self.block('COOK_MEAL'); runtime.tick(self.now+timedelta(hours=1)); runtime.tick(self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state().world.needs.hunger,11)
        self.late_response()
        self.assertTrue(runtime._recover()); self.assertEqual(self.bridge.state().world.needs.hunger,10)
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=2))

    def test_restart_keeps_clock_journal_and_does_not_repeat_decision(self):
        runtime=self.block(); runtime.tick(self.now+timedelta(hours=1))
        self.coordinator.close(); self.connect(); runtime=self.runtime(); self.runtime_instance=runtime
        runtime.tick(self.now+timedelta(hours=2)); self.late_response(); runtime._selected=lambda state:[]
        runtime.tick(self.now+timedelta(hours=3))
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=3)); self.assertEqual(len(self.agent.calls),1)
        self.assertEqual(self.bridge.state().wallet.balance,27600)

    def test_duplicate_and_skipped_clock_are_not_reapplied(self):
        runtime=self.block(); runtime.tick(self.now+timedelta(hours=1)); state=self.bridge.state()
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'BLOCKED_RECOVERY')
        self.assertEqual(self.bridge.state(),state)
        with self.assertRaises(RuleViolation): runtime.tick(self.now+timedelta(hours=3))
        self.assertEqual(self.bridge.state(),state)

    def test_manual_world_or_money_edit_cannot_be_laundered_as_clock_merge(self):
        runtime=self.block(); runtime.tick(self.now+timedelta(hours=1))
        state=self.bridge.state(); state.world.mood='unrelated edit'; state.revision+=1
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        self.late_response()
        self.assertFalse(runtime._recover()); self.assertEqual(self.bridge.state().world.mood,'unrelated edit')
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))
        with self.assertRaises(RuleViolation): runtime.tick(self.now+timedelta(hours=2))

    def test_corrupt_clock_step_cannot_publish_or_grant_consequence(self):
        runtime=self.block(); runtime.tick(self.now+timedelta(hours=1))
        row=self.bridge.db.execute('SELECT after_body FROM cache_clock_steps').fetchone()
        changed=State.model_validate_json(row[0]); changed.wallet.balance=99999
        self.bridge.db.execute('UPDATE cache_clock_steps SET after_body=?',(changed.model_dump_json(),))
        self.late_response(); self.assertFalse(runtime._recover())
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertEqual(self.bridge.state().novelty_memory,[])

    def test_clock_preserves_money_but_expires_hooks_and_finishes_known_journey(self):
        self.initialize(); state=self.bridge.state()
        state.hooks=[Hook(hook_id='known',family='BUDGET_CHECK',due_at=self.now,expires_at=self.now+timedelta(hours=1),
                         cause_event='verified.old',depth=1)]
        state.world.journey=Journey(destination='cafe',departure=self.now,arrival=self.now+timedelta(minutes=10),
                                   source_event='verified.old',transaction_id='verified.old.tx')
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        self.server.fault('PATCH','/blocks/fixture.continuity/children','before_disconnect')
        runtime.tick(self.now); self.tx=self.bridge.db.execute('SELECT transaction_id FROM cache_bindings').fetchone()[0]
        runtime.tick(self.now+timedelta(hours=1))
        self.assertEqual(self.bridge.state().world.place,'cafe'); self.assertIsNone(self.bridge.state().world.journey)
        self.assertEqual(self.bridge.state().hooks[0].status,'expired'); self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_bounded_run_advances_hours_during_provider_uncertainty(self):
        runtime=self.block(); results=runtime.run(4)
        self.assertEqual([r['status'] for r in results],['COMPLETED_CLOCK_ONLY']*4)
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=4)); self.assertEqual(len(self.agent.calls),1)

    def test_uncertain_provider_read_does_not_consume_next_tick_or_reset_clock(self):
        runtime=self.block(); self.server.fault('GET','/pages/fixture.continuity',503)
        runtime.tick(self.now+timedelta(hours=1)); self.late_response()
        runtime._selected=lambda state:[]; runtime.tick(self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state().wallet.balance,27600)

    def test_late_definite_failure_rolls_back_money_but_keeps_elapsed_clock(self):
        runtime=self.block(); runtime.tick(self.now+timedelta(hours=1)); self.late_response()
        self.server.fault('PATCH','/blocks/fixture.taste/children',403)
        self.assertTrue(runtime._recover()); state=self.bridge.state()
        self.assertEqual(state.wallet.balance,27850); self.assertEqual(state.wallet.ledger,[])
        self.assertEqual(state.world.time,self.now+timedelta(hours=1)); self.assertEqual(state.novelty_memory,[])
        self.assertEqual(self.bridge.db.execute('SELECT status FROM hourly_decisions').fetchone()[0],'REJECTED')
        self.assertTrue(self.bridge.confirmations_allowed('wallet'))

    def test_dst_repeated_hour_recovery_uses_utc_hour_and_does_not_double_charge(self):
        from datetime import datetime
        from zoneinfo import ZoneInfo
        self.now=datetime(2026,11,1,1,0,tzinfo=ZoneInfo('America/New_York'),fold=0)
        data=self.request.model_dump(mode='json'); data['world']['time']=self.now.isoformat(); data['world']['timezone']='America/New_York'
        self.request=type(self.request).model_validate(data)
        runtime=self.block(); next_hour=(self.now.astimezone(timezone.utc)+timedelta(hours=1)).astimezone(ZoneInfo('America/New_York'))
        runtime.tick(next_hour); self.assertEqual(self.bridge.state().world.time.utcoffset(),next_hour.utcoffset())
        self.late_response(); self.assertTrue(runtime._recover())
        self.assertEqual(self.bridge.state().world.time.astimezone(timezone.utc),next_hour.astimezone(timezone.utc))
        self.assertEqual(self.bridge.state().wallet.balance,27600)

    def test_old_unprepared_proposals_are_skipped_after_delayed_recovery(self):
        from tests.test_p2 import candidate
        runtime=self.block(); first=json.loads(self.bridge.db.execute('SELECT events FROM hourly_ticks').fetchone()[0])
        later=candidate(self.bridge.state(),'COOK_MEAL')
        self.bridge.db.execute('UPDATE hourly_ticks SET events=?',(json.dumps([*first,later.model_dump(mode='json')]),))
        runtime.tick(self.now+timedelta(hours=1)); self.late_response(); runtime._selected=lambda state:[]
        runtime.tick(self.now+timedelta(hours=2))
        row=self.bridge.db.execute('SELECT status,reason FROM hourly_decisions WHERE event_id=?',(later.event_id,)).fetchone()
        self.assertEqual(tuple(row),('SKIPPED','superseded_tick_after_recovery')); self.assertEqual(len(self.agent.calls),1)
