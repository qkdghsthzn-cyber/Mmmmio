import json
import tempfile
import unittest
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from threading import Event
from unittest.mock import patch
from connectors.google_oauth import (OAuthGrant, MemoryTokenStore, GoogleTokenEndpoint,
    GoogleAccessTokenProvider, OAuthRefreshUnavailable, ReauthorizationRequired, OAuthConfigurationRequired)
from connectors.google_calendar import CalendarConnector
from connectors.http_json import HTTPJSON, HTTPFailure, ConnectorUnavailable
from tests.oauth_http_server import OAuthHTTPFixture
from tests import test_p5_hourly as hourly
from runtime.host_resume import pending, resume_after_delay, revalidate_host_resume

SCOPE = 'https://www.googleapis.com/auth/calendar.events.readonly'


class P5OAuthTests(unittest.TestCase):
    def setUp(self):
        self.now = datetime(2026,10,6,12,tzinfo=timezone.utc); self.wall = self.now
        self.server = OAuthHTTPFixture()
        self.grant = OAuthGrant('fixture.client', 'fixture.refresh.old', scopes=(SCOPE,))
        self.store = MemoryTokenStore(self.grant)
        self.endpoint = GoogleTokenEndpoint(self.server.url+'/token', fixture=True, timeout=2)
        self.provider = GoogleAccessTokenProvider(self.store,self.endpoint,lambda:self.wall,required_scopes=(SCOPE,))
        self.http = HTTPJSON(self.server.url,fixture=True,token_provider=self.provider,timeout=2)

    def tearDown(self): self.server.close()

    def valid(self, token='fixture.access.new', seconds=3600):
        self.store.save(replace(self.grant,access_token=token,expires_at=self.now+timedelta(seconds=seconds),issued_at=self.now))

    def test_expired_token_refreshes_with_form_and_no_bearer(self):
        self.assertEqual(self.http.request('GET','/read')['status'],'fixture success')
        self.assertEqual(self.server.refresh_count,1)
        self.assertEqual(self.server.forms[0],{'grant_type':['refresh_token'],'client_id':['fixture.client'],'refresh_token':['fixture.refresh.old']})
        self.assertEqual(self.server.token_authorizations,[None])
        self.assertEqual(self.store.load().refresh_token,self.grant.refresh_token)
        self.assertEqual(self.store.load().expires_at,self.now+timedelta(hours=1))

    def test_valid_token_does_not_refresh_or_request_consent(self):
        self.valid(); self.http.request('GET','/read'); self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,0); self.assertEqual(self.server.api_count,2)

    def test_margin_refreshes_before_access_expiry(self):
        self.valid(seconds=60); self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,1)

    def test_grant_rotation_saved_and_used_on_next_refresh(self):
        self.server.response['refresh_token']='fixture.refresh.rotated'
        self.provider.access_token(); self.wall += timedelta(hours=1)
        self.provider.access_token()
        self.assertEqual(self.server.forms[1]['refresh_token'],['fixture.refresh.rotated'])

    def test_client_secret_and_special_refresh_token_are_form_encoded(self):
        grant=replace(self.grant,refresh_token='fixture.+/&%=token',client_secret='fixture.client.secret')
        self.store.save(grant); self.provider.access_token()
        self.assertEqual(self.server.forms[0]['refresh_token'],[grant.refresh_token])
        self.assertEqual(self.server.forms[0]['client_secret'],[grant.client_secret])

    def test_invalid_grant_requires_reauthorization_without_more_io(self):
        self.server.refresh_errors.append((400,{'error':'invalid_grant','error_description':'PRIVATE_ERROR_SENTINEL'}))
        for _ in range(2):
            with self.assertRaises(ReauthorizationRequired) as caught: self.http.request('GET','/read')
            self.assertNotIn('PRIVATE_ERROR_SENTINEL',str(caught.exception))
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.api_count,0)
        self.assertIsNone(self.store.load()); self.assertTrue(self.store.diagnostic()['reauthorization_required'])

    def test_explicit_new_grant_resumes_after_reauthorization(self):
        self.store.invalidate()
        with self.assertRaises(ReauthorizationRequired): self.provider.access_token()
        self.store.save(replace(self.grant,refresh_token='fixture.new.consent'))
        self.http.request('GET','/read')
        self.assertEqual(self.server.forms[0]['refresh_token'],['fixture.new.consent'])
        self.assertFalse(self.store.diagnostic()['reauthorization_required'])

    def test_transient_outage_has_retry_delay_and_no_api_request(self):
        self.server.refresh_errors.append((503,{'error':'PRIVATE_ERROR_SENTINEL'}))
        for _ in range(3):
            with self.assertRaises(OAuthRefreshUnavailable): self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.api_count,0)
        self.wall += timedelta(seconds=30); self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,2)

    def test_refresh_disconnect_does_not_repeat_exchange_in_same_request(self):
        self.server.refresh_errors.append('disconnect')
        with self.assertRaises(OAuthRefreshUnavailable): self.http.request('POST','/write',{'value':1})
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.api_count,0)
        self.assertEqual(self.store.load(),self.grant)

    def test_configuration_error_is_held_until_configuration_changes(self):
        self.server.refresh_errors.append((401,{'error':'invalid_client','error_description':'PRIVATE_ERROR_SENTINEL'}))
        for _ in range(2):
            with self.assertRaises(OAuthConfigurationRequired): self.provider.access_token()
        self.assertEqual(self.server.refresh_count,1)
        self.store.save(replace(self.grant,client_id='fixture.correct.client'))
        self.provider.access_token(); self.assertEqual(self.server.refresh_count,2)

    def test_get_401_refreshes_and_retries_only_once(self):
        self.valid(token='fixture.access.rejected'); self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.api_count,2)
        self.assertEqual(self.server.sent_tokens,['Bearer fixture.access.rejected','Bearer fixture.access.new'])

    def test_second_get_401_requires_reauthorization_and_stops_refresh_storm(self):
        self.valid(token='fixture.access.rejected'); self.server.accepted_token='fixture.never.accepted'
        with self.assertRaises(HTTPFailure) as caught: self.http.request('GET','/read')
        self.assertEqual(caught.exception.status,401)
        with self.assertRaises(ReauthorizationRequired): self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.api_count,2)

    def test_mutation_401_is_never_resent_or_refreshed_in_response_path(self):
        self.valid(token='fixture.access.rejected')
        with self.assertRaises(HTTPFailure) as caught: self.http.request('POST','/write',{'value':1})
        self.assertEqual(caught.exception.status,401)
        self.assertEqual(self.server.api_count,1); self.assertEqual(self.server.write_count,0)
        self.assertEqual(self.server.refresh_count,0)
        # Recovery may make a fresh read with a renewed token, not resend POST.
        self.http.request('GET','/read')
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.write_count,0)

    def test_preflight_refresh_sends_successful_write_once(self):
        self.http.request('PATCH','/write',{'value':1})
        self.assertEqual(self.server.refresh_count,1); self.assertEqual(self.server.api_count,1)
        self.assertEqual(self.server.write_count,1)

    def test_other_provider_errors_and_disconnect_never_retry_mutation(self):
        self.valid()
        for status in [403,429,503,'disconnect']:
            self.server.api_errors.append(status); before=self.server.api_count
            with self.assertRaises(ConnectorUnavailable): self.http.request('POST','/write',{'value':1})
            self.assertEqual(self.server.api_count,before+1)
        self.assertEqual(self.server.refresh_count,0); self.assertEqual(self.server.write_count,0)

    def test_dry_run_requires_no_refresh_or_network(self):
        value=self.http.request('POST','/write',{'value':1},dry_run=True)
        self.assertTrue(value['dry_run']); self.assertEqual(self.server.refresh_count,0)
        self.assertEqual(self.server.api_count,0)

    def test_concurrent_callers_share_one_refresh(self):
        arrived=Event(); release=Event()
        def pause():
            arrived.set()
            if not release.wait(3): raise RuntimeError('fixture synchronization timeout')
        self.server.before_refresh=pause
        with ThreadPoolExecutor(max_workers=8) as pool:
            futures=[pool.submit(self.provider.access_token) for _ in range(8)]
            self.assertTrue(arrived.wait(3)); release.set()
            tokens=[f.result(timeout=5) for f in futures]
        self.assertEqual(set(tokens),{'fixture.access.new'}); self.assertEqual(self.server.refresh_count,1)

    def test_two_providers_share_store_refresh_and_late_401_does_not_erase_rotation(self):
        self.valid(token='fixture.old.access')
        other=GoogleAccessTokenProvider(self.store,self.endpoint,lambda:self.wall)
        self.provider.reject('fixture.old.access'); self.provider.access_token()
        other.reject('fixture.old.access')
        self.assertEqual(other.access_token(),'fixture.access.new')
        self.assertEqual(self.server.refresh_count,1)

    def test_refresh_expiry_requires_consent_without_network(self):
        self.store.save(replace(self.grant,refresh_expires_at=self.now))
        with self.assertRaises(ReauthorizationRequired): self.provider.access_token()
        self.assertEqual(self.server.refresh_count,0)

    def test_refresh_expiry_response_is_saved(self):
        self.server.response['refresh_token_expires_in']=7200
        self.provider.access_token()
        self.assertEqual(self.store.load().refresh_expires_at,self.now+timedelta(hours=2))

    def test_invalid_response_never_replaces_credential(self):
        for change in [{'access_token':None},{'access_token':'bad\r\nTOKEN'}, {'expires_in':True}, {'expires_in':0},
                       {'expires_in':86401},{'token_type':'DPoP'},{'refresh_token':''}, {'scope':123},
                       {'refresh_token_expires_in':False}]:
            with self.subTest(change=change):
                base={'access_token':'fixture.access.new','expires_in':3600,'token_type':'Bearer'}
                self.server.response={**base,**change}; self.store.save(self.grant)
                with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
                self.assertEqual(self.store.load(),self.grant)

    def test_missing_scope_holds_configuration_and_does_not_publish_token(self):
        self.server.response['scope']='https://www.googleapis.com/auth/userinfo.email'
        with self.assertRaises(OAuthConfigurationRequired): self.provider.access_token()
        self.assertEqual(self.store.load(),self.grant)
        with self.assertRaises(OAuthConfigurationRequired): self.provider.access_token()
        self.assertEqual(self.server.refresh_count,1)

    def test_valid_response_scopes_and_short_remaining_ttl(self):
        self.server.response['scope']=SCOPE; self.provider.access_token()
        self.assertEqual(self.store.load().scopes,(SCOPE,))
        self.store.save(self.grant)
        self.server.before_refresh=lambda:setattr(self,'wall',self.now+timedelta(seconds=3590))
        with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
        self.assertEqual(self.store.load(),self.grant)

    def test_clock_backwards_and_naive_clock_fail_before_io(self):
        self.valid(); self.provider.access_token(); self.wall -= timedelta(seconds=1)
        with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
        self.assertEqual(self.server.refresh_count,0)
        self.wall=self.now.replace(tzinfo=None)
        with self.assertRaises(ValueError): self.provider.access_token()
        self.assertEqual(self.server.refresh_count,0)

    def test_endpoint_validation_and_transport_scope_prevent_token_leak(self):
        for url in ['http://oauth2.googleapis.com/token','https://oauth2.googleapis.com:443/token',
                    'https://example.com/token','https://secret@oauth2.googleapis.com/token',
                    'https://oauth2.googleapis.com/token?key=secret','https://oauth2.googleapis.com/token#secret']:
            with self.subTest(url=url),self.assertRaises(ValueError): GoogleTokenEndpoint(url)
        with self.assertRaises(ValueError): GoogleTokenEndpoint('https://example.com/token',fixture=True)
        with self.assertRaises(ValueError): HTTPJSON('https://www.googleapis.com/calendar/v3',token_provider=self.provider)
        real=GoogleAccessTokenProvider(self.store,GoogleTokenEndpoint())
        with self.assertRaises(ValueError): HTTPJSON('https://api.notion.com/v1',token_provider=real)
        with self.assertRaises(ConnectorUnavailable): HTTPJSON(self.server.url,'other-token',fixture=True,token_provider=self.provider)

    def test_redirect_and_oversize_oauth_responses_fail_without_api_io(self):
        self.server.refresh_errors.append('redirect')
        with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
        self.assertEqual(self.server.api_count,0)
        self.store.save(self.grant); self.server.refresh_errors.append((200,b'X'*65537))
        with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
        self.assertEqual(self.store.load(),self.grant); self.assertEqual(self.server.api_count,0)

    def test_static_notion_credential_behavior_is_preserved(self):
        static=HTTPJSON(self.server.url,'fixture.access.new',fixture=True)
        self.assertEqual(static.request('GET','/read')['status'],'fixture success')
        self.server.api_errors.append(401)
        with self.assertRaises(HTTPFailure): static.request('GET','/read')
        self.assertEqual(self.server.api_count,2); self.assertEqual(self.server.refresh_count,0)

    def test_grant_reprs_errors_and_diagnostic_contain_no_secrets(self):
        values=[repr(self.grant),repr(self.store),repr(self.provider),json.dumps(self.store.diagnostic())]
        for text in values:
            for secret in [self.grant.client_id,self.grant.refresh_token,'PRIVATE_ERROR_SENTINEL']: self.assertNotIn(secret,text)
        with self.assertRaises(ValueError) as error: OAuthGrant('fixture.client','PRIVATE_ERROR_SENTINEL\n')
        self.assertNotIn('PRIVATE_ERROR_SENTINEL',str(error.exception))

    def test_invalid_provider_configuration_is_rejected(self):
        for key,values in [('refresh_margin',[True,-1,301]),('retry_delay',[False,0,301])]:
            for value in values:
                with self.assertRaises(ValueError): GoogleAccessTokenProvider(self.store,self.endpoint,**{key:value})
        with self.assertRaises(ValueError): GoogleTokenEndpoint(timeout=True)
        with self.assertRaises(ValueError): OAuthGrant('fixture.client','fixture.refresh',expires_at=self.now)


    def test_many_stale_401s_do_not_defeat_refresh_retry_delay(self):
        self.valid(token='fixture.rejected')
        self.provider.reject('fixture.rejected')
        self.server.refresh_errors.append((503,{'error':'unavailable'}))
        with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
        for _ in range(5):
            self.provider.reject('fixture.rejected')
            with self.assertRaises(OAuthRefreshUnavailable): self.provider.access_token()
        self.assertEqual(self.server.refresh_count,1)

    def test_calendar_connector_owns_one_credential_source(self):
        with self.assertRaises(ValueError): CalendarConnector('fixture.calendar',http=self.http,token_provider=self.provider)
        with patch.dict('os.environ',{'GOOGLE_ACCESS_TOKEN':'unrelated.environment.token'}):
            provider=GoogleAccessTokenProvider(self.store,GoogleTokenEndpoint())
            connector=CalendarConnector('fixture.calendar',token_provider=provider)
            self.assertIsNone(connector.http._token); self.assertIs(connector.http.token_provider,provider)
        self.assertEqual(self.server.refresh_count,0)


class P5OAuthHourlyTests(unittest.TestCase):
    setUp=hourly.P5HourlyTests.setUp
    connect=hourly.P5HourlyTests.connect
    initialize=hourly.P5HourlyTests.initialize
    runtime=hourly.P5HourlyTests.runtime

    def tearDown(self):
        if hasattr(self,'oauth_server'): self.oauth_server.close()
        hourly.P5HourlyTests.tearDown(self)

    def attach(self, wall):
        self.oauth_server=OAuthHTTPFixture(self.server)
        self.store=MemoryTokenStore(OAuthGrant('fixture.calendar.client','fixture.refresh'))
        provider=GoogleAccessTokenProvider(self.store,GoogleTokenEndpoint(self.oauth_server.url+'/token',fixture=True),lambda:wall)
        self.calendar=CalendarConnector('fixture.calendar',http=HTTPJSON(self.oauth_server.url,fixture=True,token_provider=provider))
        from connectors.native_http_adapter import NativeHTTPAdapter
        self.coordinator.adapters['calendar']=NativeHTTPAdapter(self.calendar)
        return self.runtime()

    def test_calendar_metadata_events_and_hourly_snapshot_use_refreshed_token(self):
        self.initialize(); runtime=self.attach(self.now); runtime._selected=lambda state:[]
        self.assertEqual(self.calendar.metadata()['timeZone'],'Asia/Tokyo')
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.oauth_server.refresh_count,1)
        self.assertEqual(self.agent.calls,[])
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_resume_native_gate_stays_closed_after_token_revocation_then_new_grant_unlocks(self):
        self.initialize(); runtime=self.attach(self.now+timedelta(hours=2,minutes=20))
        runtime._selected=lambda state:[]; wall=self.now+timedelta(hours=2,minutes=20)
        resume_after_delay(runtime,wall)
        self.oauth_server.refresh_errors.append((400,{'error':'invalid_grant','error_description':'PRIVATE_ERROR_SENTINEL'}))
        self.assertEqual(revalidate_host_resume(runtime,wall)['status'],'WAITING_FRESH_NATIVE_READ')
        self.assertTrue(pending(runtime.db)); self.assertFalse(self.bridge.confirmations_allowed())
        self.assertEqual(revalidate_host_resume(runtime,wall)['status'],'WAITING_FRESH_NATIVE_READ')
        self.assertEqual(self.oauth_server.refresh_count,1)
        self.store.save(OAuthGrant('fixture.calendar.client','fixture.new.consent'))
        self.assertEqual(revalidate_host_resume(runtime,wall)['status'],'VERIFIED')
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertEqual(self.agent.calls,[])

    def calendar_plan(self):
        from connectors.mock_native import fixture_purchase
        from connectors.native_plans import purchase_plan
        from core.mock_state import mock_state
        evidence,proposal,now=fixture_purchase()
        plan=purchase_plan(evidence,proposal,'fixture.auth.event','fixture.auth.decision',now)
        commitment=mock_state().calendar[0].model_copy(update={'source_event':plan.event_id})
        op=self.calendar.create_operation(commitment,plan.transaction_id)
        return plan.model_copy(update={'operations':[op]})

    def test_native_calendar_write_after_refresh_has_one_request_and_verified_receipt(self):
        self.initialize(); self.attach(self.now)
        plan=self.calendar_plan(); tx=self.coordinator.prepare(plan)
        self.assertEqual(self.coordinator.run(tx),'COMMITTED')
        self.assertEqual(self.oauth_server.refresh_count,1)
        attempts=[r for r in self.oauth_server.api_requests if r['method']=='POST']
        self.assertEqual(len(attempts),1); self.assertEqual(self.oauth_server.write_count,1)
        self.assertEqual(len(json.loads(self.coordinator.committed(tx)['receipts'])),1)
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_native_calendar_write_401_rolls_back_without_automatic_replay(self):
        self.initialize(); self.attach(self.now)
        plan=self.calendar_plan(); self.oauth_server.api_faults[('POST',self.calendar.path)]=401
        tx=self.coordinator.prepare(plan)
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK')
        attempts=[r for r in self.oauth_server.api_requests if r['method']=='POST']
        self.assertEqual(len(attempts),1); self.assertEqual(self.oauth_server.write_count,0)
        self.assertIsNone(self.coordinator.committed(tx)); self.assertNotIn(plan.operations[0].after['id'],self.server.objects)
        self.assertEqual(self.oauth_server.refresh_count,1)
