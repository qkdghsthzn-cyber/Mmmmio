import hashlib
import os
import sys
import subprocess
import json
import sqlite3
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from mobile_host.probe import diagnose, entrypoint, run_mock, run_native_fixture, run_database_loss_fixture, _home, _worker
from tools.prepare_mobile_sources import ROOT, prepare


class P5MobileTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def test_desktop_pass_does_not_claim_android_execution(self):
        report = diagnose(self.root)
        self.assertEqual(report['status'], 'HOST_CAPABILITIES_PASS_ANDROID_NOT_RUN')
        self.assertFalse(report['runtime']['android_verified'])
        self.assertEqual(len(report['checks']), 5)

    def test_missing_dependency_produces_safe_diagnostic_failure(self):
        with patch('mobile_host.probe.importlib.import_module', side_effect=ImportError('SECRET_VALUE')):
            report = diagnose(self.root)
        self.assertEqual(report['status'], 'CAPABILITY_FAILURE')
        self.assertNotIn('SECRET_VALUE', json.dumps(report))

    def test_actual_engine_resumes_its_persisted_fixture(self):
        first = run_mock(self.root, 6)
        second = run_mock(self.root, 6)
        self.assertEqual((first['previous_ticks'], first['stored_ticks']), (0, 6))
        self.assertEqual((second['previous_ticks'], second['stored_ticks']), (6, 12))
        self.assertEqual(second['rule_invariants'], 'PASS')
        self.assertFalse(second['production_enabled'])

    def test_probe_never_uses_live_api_transport(self):
        with patch('urllib.request.urlopen', side_effect=AssertionError('external API forbidden')):
            report = run_mock(self.root, 2)
            diagnosis = diagnose(self.root)
        self.assertEqual(report['actual_api_calls'], 0)
        self.assertEqual(diagnosis['actual_canonical_writes'], 0)

    def test_workers_cannot_mutate_same_fixture_concurrently(self):
        with _worker(_home(self.root)):
            result = json.loads(entrypoint(str(self.root), 'mock'))
        self.assertEqual(result['status'], 'FAILED')
        self.assertEqual(result['error_type'], 'OperationalError')
        self.assertFalse((_home(self.root) / 'fixture-world.sqlite3').exists())

    def test_mock_refuses_non_fixture_existing_state(self):
        run_mock(self.root, 1)
        path = _home(self.root) / 'fixture-world.sqlite3'
        db = sqlite3.connect(path)
        body = json.loads(db.execute('SELECT body FROM state WHERE id=1').fetchone()[0])
        body['mode'] = 'live'
        db.execute('UPDATE state SET body=? WHERE id=1', (json.dumps(body),))
        db.commit(); db.close()
        result = json.loads(entrypoint(str(self.root), 'mock'))
        self.assertEqual(result['status'], 'FAILED')
        db = sqlite3.connect(path)
        self.assertEqual(db.execute('SELECT count(*) FROM ticks').fetchone()[0], 1)
        db.close()

    def test_unbounded_hours_and_unknown_actions_are_rejected(self):
        for hours in [0, 25, True, 1.5, '6']:
            with self.assertRaises(ValueError): run_mock(self.root, hours)
        self.assertEqual(json.loads(entrypoint(str(self.root), 'live'))['status'], 'FAILED')

    def test_private_files_and_environment_are_not_read_or_changed(self):
        import os
        before = os.getcwd()
        with patch.dict(os.environ, {'OPENAI_API_KEY': 'PRIVATE_KEY_SENTINEL'}):
            self.assertNotIn('PRIVATE_KEY_SENTINEL', entrypoint(str(self.root), 'diagnose'))
            self.assertEqual(os.environ['OPENAI_API_KEY'], 'PRIVATE_KEY_SENTINEL')
        self.assertEqual(os.getcwd(), before)
        self.assertFalse((self.root / '.env').exists())

    def test_complete_sources_are_staged_byte_for_byte(self):
        target = self.root / 'generated'
        manifest = prepare(target)
        self.assertEqual(len(list((target / 'data/event_families').glob('*.json'))), 160)
        for value in manifest['files']:
            self.assertEqual((ROOT / value['path']).read_bytes(), (target / value['path']).read_bytes())
            self.assertEqual(hashlib.sha256((target / value['path']).read_bytes()).hexdigest(), value['sha256'])
        self.assertFalse((target / '.env').exists())
        self.assertFalse((target / 'connectors/resources.json').exists())
        self.assertEqual({p.name for p in (target / 'reference').iterdir()}, {'01_Core_Identity.md'})
        self.assertEqual((ROOT / 'reference/01_Core_Identity.md').read_bytes(),
                         (target / 'reference/01_Core_Identity.md').read_bytes())

    def test_staging_will_not_replace_unowned_or_foreign_directory(self):
        target = self.root / 'generated'; target.mkdir()
        (target / 'user.txt').write_text('keep')
        with self.assertRaises(ValueError): prepare(target)
        self.assertEqual((target / 'user.txt').read_text(), 'keep')
        with self.assertRaises(ValueError): prepare(ROOT)

    def test_staged_engine_runs_without_original_project_on_import_path(self):
        import os
        import subprocess
        import sys
        target = self.root / 'generated'
        prepare(target)
        environment = dict(os.environ, PYTHONPATH=str(target))
        code = "from mobile_host.probe import entrypoint; print(entrypoint('private', 'native'))"
        run = subprocess.run([sys.executable, '-c', code], cwd=self.root, env=environment,
                             capture_output=True, text=True, timeout=30)
        self.assertEqual(run.returncode, 0, run.stderr)
        result = json.loads(run.stdout)
        self.assertEqual(result['status'], 'PASS')
        self.assertEqual(result['completed_hours'], 6)

    def test_staging_refuses_symlink_to_private_outside_file(self):
        target = self.root / 'generated'
        prepare(target)
        private = self.root / 'private.txt'; private.write_text('must remain unchanged')
        member = target / 'mobile_host/probe.py'; member.unlink(); member.symlink_to(private)
        with self.assertRaises(ValueError): prepare(target)
        self.assertEqual(private.read_text(), 'must remain unchanged')

    def test_existing_native_hourly_stages_run_in_probe(self):
        report = run_native_fixture(self.root)
        self.assertEqual(report['status'], 'PASS')
        self.assertEqual(report['completed_hours'], 6)
        self.assertEqual(report['actual_canonical_writes'], 0)
        self.assertEqual(report['unresolved_cache_bindings'], 0)

    def test_existing_database_loss_recovery_runs_in_probe(self):
        report = run_database_loss_fixture(self.root)
        self.assertEqual(report['status'], 'PASS')
        self.assertTrue(report['primary_db_and_journals_deleted'])
        self.assertEqual(report['fixture_ledger_entries'], 1)
        self.assertEqual(report['final_revalidation'], 'VERIFIED')
        self.assertEqual(report['actual_canonical_writes'], 0)

    def test_host_suspension_action_preserves_clock_and_single_ledger(self):
        report = json.loads(entrypoint(self.root, 'host_resume'))
        self.assertEqual(report['status'], 'PASS')
        self.assertEqual(report['android_execution'], 'NOT_RUN')
        self.assertEqual(report['catchup']['processed_hours'], 5)
        self.assertEqual(report['decision_calls_total'], 1)
        self.assertEqual(report['original_ambiguous_append_attempts'], 1)
        self.assertEqual(report['fixture_ledger_entries'], 1)
        self.assertTrue(report['frozen_after_process_restart'])
        self.assertEqual(report['actual_canonical_writes'], 0)

    def test_staged_host_resume_action_runs_without_original_tree(self):
        destination = self.root / 'isolated.resume.source'; prepare(destination)
        code = "from mobile_host.probe import entrypoint; print(entrypoint('fixture-home','host_resume'))"
        result = subprocess.run([sys.executable, '-c', code], cwd=destination,
            env={k:v for k,v in os.environ.items() if k != 'PYTHONPATH'}, text=True, capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report['status'], 'PASS')
        self.assertEqual(report['fresh_revalidation'], 'VERIFIED')
        self.assertEqual(report['runtime']['android_verified'], False)

    def test_oauth_fixture_action_is_private_and_does_not_replay_write(self):
        raw = entrypoint(self.root, 'oauth'); report = json.loads(raw)
        self.assertEqual(report['status'], 'PASS'); self.assertEqual(report['android_execution'], 'NOT_RUN')
        self.assertEqual(report['mutation_401_attempts'], 1)
        self.assertEqual(report['mutation_401_successful_writes'], 0)
        self.assertEqual(report['fresh_revalidation_after_synthetic_new_consent'], 'VERIFIED')
        self.assertEqual(report['actual_canonical_writes'], 0)
        self.assertNotIn('fixture.oauth.refresh', raw); self.assertNotIn('PRIVATE_ERROR_SENTINEL', raw)
        self.assertEqual(report['credential_storage']['storage'], 'PROCESS_MEMORY_ONLY')

    def test_staged_oauth_action_runs_without_original_tree(self):
        destination = self.root / 'isolated.oauth.source'; prepare(destination)
        code = "from mobile_host.probe import entrypoint; print(entrypoint('fixture-home','oauth'))"
        result = subprocess.run([sys.executable, '-c', code], cwd=destination,
            env={k:v for k,v in os.environ.items() if k != 'PYTHONPATH'}, text=True, capture_output=True, timeout=60)
        self.assertEqual(result.returncode, 0, result.stderr)
        report = json.loads(result.stdout)
        self.assertEqual(report['status'], 'PASS')
        self.assertEqual(report['mutation_401_attempts'], 1)
        self.assertEqual(report['runtime']['android_verified'], False)
