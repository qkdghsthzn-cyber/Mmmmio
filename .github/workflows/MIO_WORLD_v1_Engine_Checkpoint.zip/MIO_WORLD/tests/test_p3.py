import json
import tempfile
import unittest
import threading
from http.server import BaseHTTPRequestHandler,HTTPServer
from pathlib import Path
from agents.openai_transport import OpenAITransport,RequestBudget,BudgetExceeded,ProviderUnavailable,strict_schema
from agents.mio_llm import MioDecisionAgent
from agents.world_llm import WorldRealizer
from agents.simulator_policy import simulator_decision
from core.mock_state import mock_state
from core.event_grammar import Grammar
from core.models import Decision,Action
from core.state_manager import StateStore
from core.simulator import Simulator
from tests.test_p2 import candidate


def response(text,status="completed"):
    return {"status":status,"output":[{"type":"message","content":[{"type":"output_text","text":text}]}]}

class ScriptedTransport:
    def __init__(self,outputs): self.outputs=list(outputs); self.calls=[]
    def complete(self,prompt,schema,system):
        self.calls.append((prompt,schema,system))
        output=self.outputs.pop(0)
        if isinstance(output,Exception): raise output
        return output


class P3Tests(unittest.TestCase):
    def setUp(self):
        self.state=mock_state(); self.event=candidate(self.state,"OUTFIT_CHOICE"); self.grammar=Grammar()
        self.valid=Decision(decision_id="dec_api",event_id=self.event.event_id,choice="accept",reason_tags=["owned"],actions=[Action(type="use_item",item_id=self.event.payload["item_id"])])

    def test_valid_structured_decision(self):
        t=ScriptedTransport([response(self.valid.model_dump_json())])
        result=MioDecisionAgent(t,self.grammar).decide(self.state,self.event)
        self.assertEqual(result,self.valid); self.assertEqual(len(t.calls),1)

    def test_one_repair_only(self):
        t=ScriptedTransport([response("not json"),response(self.valid.model_dump_json())])
        agent=MioDecisionAgent(t,self.grammar)
        self.assertEqual(agent.decide(self.state,self.event),self.valid); self.assertEqual(agent.repairs,1)
        t=ScriptedTransport([response("{}"),response("{}")]); agent=MioDecisionAgent(t,self.grammar)
        self.assertIsNone(agent.decide(self.state,self.event)); self.assertEqual(len(t.calls),2)

    def test_wrong_event_contract_and_unknown_fields(self):
        bad=self.valid.model_dump(); bad["event_id"]="other"; bad["invented_balance"]=999999
        t=ScriptedTransport([response(json.dumps(bad)),response("{}")])
        self.assertIsNone(MioDecisionAgent(t,self.grammar).decide(self.state,self.event))

    def test_timeout_refusal_and_incomplete_do_not_repair(self):
        for output in [TimeoutError(),response("{}","incomplete"),{"status":"completed","output":[{"type":"message","content":[{"type":"refusal","refusal":"no"}]}]}]:
            t=ScriptedTransport([output]); self.assertIsNone(MioDecisionAgent(t,self.grammar).decide(self.state,self.event))
            self.assertEqual(len(t.calls),1)

    def test_json_schema_all_properties_required_closed_objects(self):
        schema=strict_schema(Decision)
        def check(node):
            if isinstance(node,dict):
                if node.get("type")=="object":
                    self.assertEqual(set(node["required"]),set(node["properties"])); self.assertFalse(node["additionalProperties"])
                for value in node.values(): check(value)
            elif isinstance(node,list):
                for value in node: check(value)
        check(schema)

    def test_scheduler_continues_when_llm_fails(self):
        class FailingAgent:
            def decide(self,state,event): raise RuntimeError("unexpected provider failure")
        store=StateStore(); store.initialize(mock_state()); sim=Simulator(store,decision_agent=FailingAgent())
        sim.run(168); self.assertEqual(len(store.records("ticks")),168); self.assertGreater(sim.skips,0)
        self.assertEqual(store.load().wallet.balance,self.state.wallet.balance)

    def test_budget_is_durable_and_concurrent_admission_is_atomic(self):
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"usage.db"; a=RequestBudget(path,monthly_usd=.00001)
            a.reserve(1,1); b=RequestBudget(path,monthly_usd=.00001)
            with self.assertRaises(BudgetExceeded): b.reserve(10000,1200)

    def test_real_http_request_against_local_api_contract_server(self):
        captured=[]; valid=self.valid.model_dump_json()
        class Handler(BaseHTTPRequestHandler):
            def do_POST(self):
                captured.append(json.loads(self.rfile.read(int(self.headers["Content-Length"]))))
                data=json.dumps(response(valid)).encode(); self.send_response(200); self.end_headers(); self.wfile.write(data)
            def log_message(self,*args): pass
        server=HTTPServer(("127.0.0.1",0),Handler); thread=threading.Thread(target=server.serve_forever,daemon=True); thread.start()
        try:
            t=OpenAITransport(api_key="fixture_not_a_real_key",endpoint=f"http://127.0.0.1:{server.server_port}/v1/responses")
            result=MioDecisionAgent(t,self.grammar).decide(self.state,self.event)
            self.assertEqual(result,self.valid); self.assertEqual(captured[0]["model"],"gpt-5.6-luna")
            self.assertTrue(captured[0]["text"]["format"]["strict"]); self.assertFalse(captured[0]["store"])
        finally: server.shutdown(); server.server_close(); thread.join()

    def test_world_cannot_introduce_unknown_entities(self):
        text=json.dumps({"event_id":self.event.event_id,"no_event":False,"summary":"candidate","referenced_entities":["imaginary_owner"]})
        t=ScriptedTransport([response(text),response(text)])
        self.assertIsNone(WorldRealizer(t).realize(self.event,{"mio","shirt_white"})); self.assertEqual(len(t.calls),2)
