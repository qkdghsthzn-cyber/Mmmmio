import hashlib
import io
import struct
import tarfile
import tempfile
import unittest
import zipfile
from pathlib import Path
from unittest.mock import patch
from tools.build_android_wheels import ABIS, CORE_VERSION, collect_wheels, extract_source, inspect_wheel


class AndroidDependencyTests(unittest.TestCase):
    """Receipt gates only: these synthetic libraries are never executed or shipped."""
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def wheel(self, abi='arm64_v8a', *, machine=None, align=16384, version=CORE_VERSION,
              python='cp313', native=True, metadata_version=None, no_load=False, corrupt_header=False):
        tag = f'{python}-{python}-android_24_{abi}'
        raw = bytearray(120)
        raw[:6] = b'\x7fELF\x02\x01'
        struct.pack_into('<HH', raw, 16, 3, machine if machine is not None else ABIS[abi])
        struct.pack_into('<Q', raw, 32, 64)
        struct.pack_into('<HH', raw, 54, 56, 2 if corrupt_header else 1)
        struct.pack_into('<I', raw, 64, 0 if no_load else 1)
        struct.pack_into('<Q', raw, 112, align)
        path = self.root / f'pydantic_core-{version}-{tag}.whl'
        with zipfile.ZipFile(path, 'w') as z:
            prefix = f'pydantic_core-{version}.dist-info/'
            z.writestr(prefix + 'METADATA', f'Name: pydantic-core\nVersion: {metadata_version or version}\n')
            z.writestr(prefix + 'WHEEL', f'Wheel-Version: 1.0\nRoot-Is-Purelib: false\nTag: {tag}\n')
            if native: z.writestr('pydantic_core/_pydantic_core.cpython-313-android.so', raw)
        return path

    def test_two_abis_require_real_native_headers_and_record_hashes(self):
        for abi in ABIS: self.wheel(abi)
        receipts = collect_wheels(self.root)
        self.assertEqual({r['abi'] for r in receipts}, set(ABIS))
        for r in receipts:
            self.assertEqual(r['sha256'], hashlib.sha256(Path(r['file']).read_bytes()).hexdigest())
            self.assertEqual(r['android_execution'], 'NOT_RUN')

    def test_missing_x86_wheel_blocks_receipt(self):
        self.wheel()
        with self.assertRaises(ValueError): collect_wheels(self.root)

    def test_old_core_cannot_satisfy_locked_contract(self):
        with self.assertRaises(ValueError): inspect_wheel(self.wheel(version='2.41.5'), 'arm64_v8a')

    def test_wrong_python_cannot_be_retagged_as_313(self):
        with self.assertRaises(ValueError): inspect_wheel(self.wheel(python='cp312'), 'arm64_v8a')

    def test_linux_or_x86_binary_cannot_be_labelled_arm64(self):
        with self.assertRaises(ValueError): inspect_wheel(self.wheel(machine=62), 'arm64_v8a')

    def test_four_kib_alignment_blocks_packaging(self):
        with self.assertRaises(ValueError): inspect_wheel(self.wheel(align=4096), 'arm64_v8a')

    def test_missing_extension_blocks_packaging(self):
        with self.assertRaises(ValueError): inspect_wheel(self.wheel(native=False), 'arm64_v8a')

    def test_metadata_mismatch_blocks_packaging(self):
        with self.assertRaises(ValueError): inspect_wheel(self.wheel(metadata_version='2.46.4'), 'arm64_v8a')

    def test_truncated_or_no_load_elf_is_rejected(self):
        for kwargs in [{'no_load': True}, {'corrupt_header': True}]:
            with self.subTest(kwargs=kwargs), self.assertRaises(ValueError):
                inspect_wheel(self.wheel(**kwargs), 'arm64_v8a')

    def test_source_integrity_and_archive_path_guards(self):
        with self.assertRaises(ValueError): extract_source(b'changed source', self.root)
        buffer = io.BytesIO()
        with tarfile.open(fileobj=buffer, mode='w:gz') as z:
            entry = tarfile.TarInfo(f'pydantic_core-{CORE_VERSION}/../../escape')
            entry.size = 1; z.addfile(entry, io.BytesIO(b'x'))
        raw = buffer.getvalue()
        with patch('tools.build_android_wheels.SOURCE_SHA256', hashlib.sha256(raw).hexdigest()):
            with self.assertRaises(ValueError): extract_source(raw, self.root)
        self.assertFalse((self.root.parent / 'escape').exists())
