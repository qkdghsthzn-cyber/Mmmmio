import json
import unittest
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
from core.models import Action, Decision, Provenance
from core.validator import RuleViolation
from connectors.canonical_runtime import RuntimeEvidenceReader, expense_description, CanonicalCacheBridge
from connectors.native_plans import SpendProposal, rich, money_field
from connectors.native_rebase import NativeCacheReconciler
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.write_coordinator import WriteCoordinator, WriteConflict
from connectors.write_models import digest
from connectors.http_json import ConnectorUnavailable
from tests.test_p2 import candidate
from tests import test_p5_runtime as support


class P5EffectsTests(unittest.TestCase):
    setUp=support.P5RuntimeTests.setUp
    tearDown=support.P5RuntimeTests.tearDown

    def expense(self):
        event=candidate(self.bridge.state(),'SMALL_EXPENSE')
        decision=Decision(decision_id='expense.decision',event_id=event.event_id,choice='accept',reason_tags=[],
            actions=[Action(type='spend',amount=event.payload['cost'])])
        proposal=SpendProposal(description=expense_description(event),cost_jpy=250,occurred_at=self.now,evidence='fixture cost proof')
        self.bridge.log_event(event)
        evidence=replace(self.evidence,state_hash=digest(self.bridge.state().model_dump(mode='json')))
        return event,decision,proposal,evidence

    def prepare_expense(self):
        event,decision,proposal,evidence=self.expense()
        return self.bridge.prepare(event,decision,evidence,self.now,proposal)

    def create_calendar(self):
        event,decision=support.P5RuntimeTests.calendar_inputs(self,self.bridge.state())
        self.bridge.log_event(event)
        tx=self.bridge.prepare(event,decision,self.evidence,self.now,calendar_connector=self.calendar)
        self.assertEqual(self.coordinator.run(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        return self.bridge.state().calendar[-1].commitment_id

    def read(self,reconcile=False):
        return RuntimeEvidenceReader(self.notion,self.calendar,lambda:self.now).read(self.bridge,
            'fixture.wallet','fixture.inventory','fixture.continuity','explicit fixture world',reconcile_external=reconcile)

    def cancellation(self):
        evidence=self.read(); state=self.bridge.state(); event=candidate(state,'APPOINTMENT_CANCEL')
        decision=Decision(decision_id='cancel.'+event.event_id,event_id=event.event_id,choice='accept',reason_tags=[],
            actions=[Action(type='calendar_cancel',commitment_id=event.payload['commitment_id'])])
        self.bridge.log_event(event)
        tx=self.bridge.prepare(event,decision,evidence,self.now,calendar_connector=self.calendar)
        return tx,event,decision

    def native_read(self):
        return self.native.model_copy(update={'wallet':self.notion.page('fixture.wallet'),
            'inventory_schema':self.notion.data_source('fixture.inventory'),
            'inventory_rows':self.notion.inventory_rows('fixture.inventory'),
            'continuity_page':self.notion.page('fixture.continuity')})

    def baseline(self):
        self.rebaser=NativeCacheReconciler(self.bridge); self.rebaser.anchor(self.native_read(),self.now)

    def add_external(self,amount,balance,monthly,identifier='external.row',description='native external cause',kind=None):
        cells=[self.now.date().isoformat(),kind or ('EXPENSE' if amount<0 else 'INCOME'),description,
               ('-' if amount<0 else '')+f'¥{abs(amount):,}',f'¥{balance:,}']
        self.server.objects[identifier]={'object':'block','id':identifier,'type':'table_row','last_edited_time':'external-v1',
            'parent':{'type':'block_id','block_id':'fixture.moneylog'},'table_row':{'cells':[rich(c) for c in cells]}}
        self.server.children['fixture.moneylog'].append(identifier); self.server.version(self.server.objects['fixture.moneylog'])
        for key,label,value in [('fixture.balance','残高:',balance),('fixture.monthly','今月の支出:',monthly)]:
            self.server.edit(key,money_field(self.server.objects[key],label,value)[1])

    def owned(self,name='verified native item',status='Owned'):
        key='external.item'
        self.server.objects[key]={'id':key,'object':'page','last_edited_time':'external-item-v1',
            'parent':{'type':'data_source_id','data_source_id':'fixture.inventory'},'properties':{
                'Item':{'title':rich(name)},'Status':{'select':{'name':status}},'Purchase Price':{'number':None},
                'Evidence':{'rich_text':rich('external native ownership record')}}}
        if key not in self.server.children['fixture.inventory']: self.server.children['fixture.inventory'].append(key)
        self.server.version(self.server.objects['fixture.inventory']); return key

    def test_expense_native_fields_annotations_tables_and_no_acquisition(self):
        old_wish=deepcopy(self.server.objects['fixture.wish.row'])
        event,decision,proposal,evidence=self.expense()
        tx=self.bridge.prepare(event,decision,evidence,self.now,proposal)
        self.assertEqual(self.coordinator.run(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        state=self.bridge.state(); self.assertEqual(state.wallet.balance,27600); self.assertEqual(state.inventory,{})
        self.assertEqual(state.wallet.ledger[-1].amount,-250)
        self.assertTrue(self.server.objects['fixture.balance']['bulleted_list_item']['rich_text'][0]['annotations']['bold'])
        self.assertEqual(self.server.objects['fixture.wish.row'],old_wish)
        self.assertEqual(len(self.server.children['fixture.moneylog']),2)
        self.assertEqual(self.bridge.prepare(event,decision,evidence,self.now,proposal),tx)
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(len(self.server.children['fixture.moneylog']),2)

    def test_expense_failure_compensates_wallet_without_cache_commit(self):
        self.server.fault('PATCH','/blocks/fixture.continuity/children',403); tx=self.prepare_expense()
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK'); self.assertEqual(self.bridge.publish(tx),'ROLLED_BACK')
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertIn('27,850',str(self.server.objects['fixture.balance']))
        self.assertTrue(self.bridge.confirmations_allowed())

    def test_expense_lost_append_ack_reconciles_exactly_once(self):
        self.server.fault('PATCH','/blocks/fixture.moneylog/children','after_disconnect'); tx=self.prepare_expense()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.coordinator.reconcile(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(len(self.server.children['fixture.moneylog']),2)

    def test_expense_unknown_patch_ack_does_not_fabricate_receipt(self):
        self.server.fault('PATCH','/blocks/fixture.balance','after_disconnect'); tx=self.prepare_expense()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.coordinator.reconcile(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_expense_proposal_cannot_change_amount_description_or_time(self):
        event,decision,proposal,evidence=self.expense()
        for change in [{'cost_jpy':1},{'description':'LLM invented expense'},{'occurred_at':self.now+timedelta(minutes=1)}]:
            with self.subTest(change=change),self.assertRaises(RuleViolation):
                self.bridge.prepare(event,decision,evidence,self.now,proposal.model_copy(update=change))

    def test_expense_stale_reserved_and_calendar_independence(self):
        event,decision,proposal,evidence=self.expense()
        with self.assertRaises(RuleViolation): self.validator.project(self.state,event,decision,
            replace(evidence,notion=self.native.model_copy(update={'read_at':self.now-timedelta(minutes=6)})),self.now)
        state=self.state.model_copy(deep=True); state.wallet.reserved_amount=27800
        native=self.native.model_copy(update={'reserved_jpy':27800})
        with self.assertRaises(RuleViolation): self.validator.project(state,event,decision,
            replace(evidence,notion=native,state_hash=digest(state.model_dump(mode='json'))),self.now)
        tx=self.bridge.prepare(event,decision,replace(evidence,calendar_stale=True),self.now,proposal)
        self.assertEqual(self.coordinator.run(tx),'COMMITTED')

    def test_live_expense_rejects_unverified_cost_and_projects_only_matching_signal(self):
        event,decision,proposal,_=self.expense()
        state,evidence=support.P5RuntimeTests.synthetic_canonical_context(self)
        with self.assertRaises(RuleViolation): self.validator.plan(state,event,decision,evidence,self.now,proposal)
        signal={'source':'external_verified','ref':'synthetic provider cost evidence','amount':250,
                'description':expense_description(event),'verified_at':self.now.isoformat()}
        evidence=replace(evidence,expense_signals={event.event_id:signal})
        proposal=proposal.model_copy(update={'evidence':signal['ref']})
        plan,projected=self.validator.plan(state,event,decision,evidence,self.now,proposal)
        self.assertEqual(projected.wallet.balance,27600)
        with self.assertRaises(ConnectorUnavailable): self.coordinator.prepare(plan)

    def test_cancel_published_runtime_event_with_if_match_and_provenance(self):
        identifier=self.create_calendar(); original=deepcopy(self.server.objects[identifier]); tx,event,_=self.cancellation()
        self.assertEqual(self.bridge.state().calendar[-1].status,'scheduled')
        self.assertEqual(self.coordinator.run(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        row=self.server.objects[identifier]; self.assertEqual(row['status'],'cancelled')
        self.assertEqual(row['start'],original['start']); self.assertEqual(row['summary'],original['summary'])
        self.assertEqual(row['extendedProperties']['private']['mio_cancel_event'],event.event_id)
        call=next(c for c in self.server.calls if c['method']=='PATCH' and c['path']==self.calendar.path+'/'+identifier)
        self.assertEqual(call['if_match'],original['etag']); self.assertEqual(call['query']['sendUpdates'],['none'])
        self.assertEqual(self.bridge.state().calendar[-1].status,'cancelled')

    def test_cancel_lost_ack_recovers_without_repeating_patch(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.fault('PATCH',self.calendar.path+'/'+identifier,'after_disconnect')
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.coordinator.reconcile(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(len([c for c in self.server.calls if c['method']=='PATCH' and c['path']==self.calendar.path+'/'+identifier]),1)

    def test_cancel_not_applied_lost_ack_retries_conditional_patch_safely(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.fault('PATCH',self.calendar.path+'/'+identifier,'before_disconnect')
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.coordinator.reconcile(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')

    def test_cancel_continuity_failure_restores_exact_event(self):
        identifier=self.create_calendar(); original=deepcopy(self.server.objects[identifier]); tx,_,_=self.cancellation()
        self.server.fault('PATCH','/blocks/fixture.continuity/children',403)
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK'); self.assertEqual(self.bridge.publish(tx),'ROLLED_BACK')
        restored=deepcopy(self.server.objects[identifier]); restored.pop('etag'); original.pop('etag')
        self.assertEqual(restored,original); self.assertEqual(self.bridge.state().calendar[-1].status,'scheduled')

    def test_cancel_external_edit_before_apply_is_never_overwritten(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.edit(identifier,{'summary':'external edit'})
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.bridge.publish(tx),'PENDING')
        self.assertFalse(self.bridge.confirmations_allowed('calendar'))
        self.assertEqual(self.server.objects[identifier]['summary'],'external edit')
        self.assertEqual(self.server.objects[identifier]['status'],'confirmed')

    def test_cancel_external_edit_before_compensation_freezes(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.fault('PATCH',self.calendar.path+'/'+identifier,'external_calendar_edit')
        self.server.fault('PATCH','/blocks/fixture.continuity/children',403)
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.server.objects[identifier]['summary'],'external edit')
        self.assertFalse(self.bridge.confirmations_allowed('calendar'))

    def test_cancel_minimal_tombstone_is_unknown_not_success(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.fault('PATCH',self.calendar.path+'/'+identifier,'after_disconnect')
        self.coordinator.run(tx)
        self.server.objects[identifier]={'kind':'calendar#event','id':identifier,'status':'cancelled','etag':'external-tombstone'}
        self.assertEqual(self.coordinator.reconcile(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.bridge.state().calendar[-1].status,'scheduled')

    def test_cancel_lost_undo_ack_freezes_without_claiming_rollback(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.fault('PATCH','/blocks/fixture.continuity/children',403)
        adapter=self.coordinator.adapters['calendar']; original=adapter.compensate
        def compensate(op,receipt):
            self.server.fault('PATCH',self.calendar.path+'/'+identifier,'after_disconnect')
            return original(op,receipt)
        adapter.compensate=compensate
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.coordinator.reconcile(tx),'RECONCILE_REQUIRED')
        self.assertFalse(self.bridge.confirmations_allowed('calendar'))

    def test_cancel_forged_receipt_from_evidence_is_replaced_by_durable_proof(self):
        identifier=self.create_calendar(); evidence=self.read(); state=self.bridge.state()
        self.coordinator.db.execute("UPDATE cache_bindings SET status='ROLLED_BACK'")
        event=candidate(state,'APPOINTMENT_CANCEL'); self.bridge.log_event(event)
        decision=Decision(decision_id='forged.cancel',event_id=event.event_id,choice='accept',reason_tags=[],
            actions=[Action(type='calendar_cancel',commitment_id=identifier)])
        with self.assertRaises(RuleViolation): self.bridge.prepare(event,decision,evidence,self.now,calendar_connector=self.calendar)

    def test_cancel_modified_attended_or_recurring_event_is_rejected(self):
        identifier=self.create_calendar(); before=deepcopy(self.server.objects[identifier])
        for fields in [{'summary':'human changed title'},{'attendees':[{'email':'fixture.invalid'}]},{'recurrence':['RRULE:FREQ=DAILY']}]:
            self.server.objects[identifier]=deepcopy(before); self.server.edit(identifier,fields)
            with self.subTest(fields=fields),self.assertRaises(RuleViolation): self.cancellation()

    def test_rebase_external_expense_explains_all_yen_and_preserves_world(self):
        self.baseline(); before=self.bridge.state(); self.add_external(-250,27600,250)
        self.assertEqual(self.rebaser.reconcile(self.native_read(),self.now,self.notion),'REBASED')
        after=self.bridge.state(); self.assertEqual(after.world,before.world)
        self.assertEqual(after.wallet.balance,27600); self.assertEqual(after.wallet.ledger[-1].event_id,'native:notion:external.row')
        self.assertEqual(after.wallet.ledger[-1].created_at,self.now)
        self.assertEqual(after.wallet.ledger[-1].amount,-250); self.assertTrue(after.continuity[-1].cause.startswith('native.read:'))
        self.assertEqual(self.rebaser.reconcile(self.native_read(),self.now,self.notion),'UNCHANGED')
        self.assertEqual(len(self.bridge.state().wallet.ledger),1)

    def test_rebase_income_then_expense_preserves_signed_arithmetic(self):
        self.baseline(); self.add_external(1000,28850,0,'income.row'); self.add_external(-500,28350,500,'expense.row')
        self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual([e.amount for e in self.bridge.state().wallet.ledger],[1000,-500])

    def test_rebase_without_rows_cannot_invent_income(self):
        self.baseline(); self.server.edit('fixture.balance',money_field(self.server.objects['fixture.balance'],'残高:',99000)[1])
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertEqual(self.bridge.state().wallet.ledger,[])
        self.assertTrue(self.bridge.state().notion_stale)

    def test_rebase_wrong_monthly_balance_or_kind_is_rejected(self):
        self.baseline(); self.add_external(-250,27600,0)
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.server.edit('fixture.monthly',money_field(self.server.objects['fixture.monthly'],'今月の支出:',250)[1])
        self.server.objects['external.row']['table_row']['cells'][1]=rich('INCOME')
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_rebase_edited_deleted_or_reordered_prefix_is_rejected(self):
        self.baseline(); self.add_external(-250,27600,250); self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        original=deepcopy(self.server.objects['external.row'])
        self.server.edit('external.row',{'table_row':{'cells':[rich('changed')]}})
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.server.objects['external.row']=original; self.server.children['fixture.moneylog'].remove('external.row')
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27600)

    def test_rebase_duplicate_native_row_does_not_double_charge(self):
        self.baseline(); self.add_external(-250,27600,250); self.server.children['fixture.moneylog'].append('external.row')
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_rebase_ownership_and_removal_preserve_raw_history_without_purchase(self):
        self.baseline(); key=self.owned(); self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        item=self.bridge.state().inventory[key]; self.assertIsNone(item.price); self.assertIsNone(item.acquired_at)
        self.assertIsNone(item.source_event); self.assertEqual(item.provenance.source,'mock')
        self.assertEqual(self.bridge.state().wallet.ledger,[])
        self.owned(status='Disposed'); self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().inventory,{})
        proofs=[json.loads(r[0]) for r in self.bridge.db.execute('SELECT body FROM native_rebase_journal')]
        self.assertTrue(any(key in p['inventory_before'] for p in proofs))
        self.assertTrue(any(p['inventory_rows'][0]['properties']['Status']['select']['name']=='Disposed' for p in proofs))
        self.server.objects[key]['properties']['Status']['select']=None
        self.assertEqual(self.rebaser.reconcile(self.native_read(),self.now,self.notion),'UNCHANGED')
        self.assertFalse(self.read().notion.notion_stale)

    def test_rebase_internal_expense_receipt_is_not_imported_twice(self):
        self.baseline(); tx=self.prepare_expense(); self.coordinator.run(tx); self.bridge.publish(tx)
        self.add_external(-100,27500,350)
        self.assertEqual(self.rebaser.reconcile(self.native_read(),self.now,self.notion),'REBASED')
        self.assertEqual([e.amount for e in self.bridge.state().wallet.ledger],[-250,-100])
        self.assertEqual(self.bridge.state().wallet.ledger[0].transaction_id,tx)

    def test_rebase_forged_runtime_marker_is_not_imported_as_external_income(self):
        self.baseline(); self.add_external(100,27950,0,description='forged [ext_'+('0'*24)+':money.log; event=fake; decision=fake]')
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_rebase_pending_native_transaction_blocks_import(self):
        self.baseline(); self.prepare_expense(); self.add_external(100,27950,0)
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_rebase_stale_scope_and_reservation_guards(self):
        self.baseline(); native=self.native_read()
        for change in [{'scope':'canonical'},{'read_at':self.now-timedelta(minutes=6)},{'reserved_jpy':1}]:
            with self.subTest(change=change),self.assertRaises(RuleViolation):
                self.rebaser.reconcile(native.model_copy(update=change),self.now,self.notion)

    def test_rebase_unstable_second_read_does_not_publish(self):
        self.baseline(); self.add_external(-250,27600,250); evidence=self.native_read()
        self.server.edit('fixture.balance',money_field(self.server.objects['fixture.balance'],'残高:',27000)[1])
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(evidence,self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_rebase_cache_revision_guard_preserves_independent_world_update(self):
        self.baseline(); self.add_external(-250,27600,250); evidence=self.native_read(); original=self.notion.page
        def page(key):
            newer=self.bridge.state(); newer.world.mood='independent update'; newer.revision+=1
            self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(newer.model_dump_json(),))
            return original(key)
        self.notion.page=page
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(evidence,self.now,self.notion)
        self.assertEqual(self.bridge.state().world.mood,'independent update'); self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_rebase_restart_and_replay_retain_anchor_and_cause_once(self):
        self.baseline(); self.add_external(-250,27600,250); self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.coordinator.close()
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':NativeHTTPAdapter(self.notion),'calendar':NativeHTTPAdapter(self.calendar)})
        self.bridge=CanonicalCacheBridge(self.coordinator,self.validator); self.rebaser=NativeCacheReconciler(self.bridge)
        self.assertEqual(self.rebaser.reconcile(self.native_read(),self.now,self.notion),'UNCHANGED')
        self.assertEqual(len(self.bridge.state().wallet.ledger),1)
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM native_rebase_journal').fetchone()[0],1)

    def test_reader_opt_in_recovers_verified_external_delta(self):
        self.read(); self.add_external(-250,27600,250)
        evidence=self.read(reconcile=True)
        self.assertFalse(self.bridge.state().notion_stale); self.assertIsNotNone(evidence.notion)
        self.assertEqual(evidence.state_hash,digest(self.bridge.state().model_dump(mode='json')))
        self.assertEqual(self.bridge.state().wallet.balance,27600)

    def test_rebase_month_reset_and_backdated_new_rows_are_explicitly_blocked(self):
        self.baseline(); self.add_external(-250,27600,250)
        self.server.objects['external.row']['table_row']['cells'][0]=rich('2026-09-30')
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now+timedelta(days=31),self.notion)

    def test_cancel_provider_412_between_read_and_write_keeps_external_edit(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        original=self.calendar.http.request
        def request(method,path,body=None,**kwargs):
            if method=='PATCH' and path.startswith(self.calendar.path+'/'+identifier):
                self.server.edit(identifier,{'summary':'racing edit'})
            return original(method,path,body,**kwargs)
        self.calendar.http.request=request
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK'); self.assertEqual(self.bridge.publish(tx),'ROLLED_BACK')
        self.assertEqual(self.server.objects[identifier]['summary'],'racing edit')
        self.assertEqual(self.server.objects[identifier]['status'],'confirmed')

    def test_cancel_committed_native_restart_publishes_once(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation(); self.coordinator.run(tx)
        self.coordinator.close()
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':NativeHTTPAdapter(self.notion),'calendar':NativeHTTPAdapter(self.calendar)})
        self.bridge=CanonicalCacheBridge(self.coordinator,self.validator)
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(self.bridge.state().calendar[-1].status,'cancelled')
        self.assertEqual(len([c for c in self.server.calls if c['method']=='PATCH' and c['path']==self.calendar.path+'/'+identifier]),1)

    def test_cancel_after_verified_rollback_retains_creation_authority(self):
        identifier=self.create_calendar(); tx,_,_=self.cancellation()
        self.server.fault('PATCH','/blocks/fixture.continuity/children',403)
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK'); self.bridge.publish(tx)
        state=self.bridge.state(); state.world.time+=timedelta(minutes=5); self.now=state.world.time
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        tx,_,_=self.cancellation()
        self.assertEqual(self.coordinator.run(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(self.bridge.state().calendar[-1].commitment_id,identifier)

    def test_rebase_transaction_rolls_back_cache_anchor_and_import_journal_together(self):
        self.baseline(); before=self.bridge.state()
        anchor=self.bridge.db.execute('SELECT body FROM native_rebase_anchor').fetchone()[0]
        self.add_external(-250,27600,250)
        self.bridge.db.execute("CREATE TRIGGER refuse_import BEFORE INSERT ON native_rebase_journal BEGIN SELECT RAISE(ABORT,'fixture rejection'); END")
        with self.assertRaises(ConnectorUnavailable): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet,before.wallet); self.assertEqual(self.bridge.state().world,before.world)
        self.assertTrue(self.bridge.state().notion_stale)
        self.assertEqual(self.bridge.db.execute('SELECT body FROM native_rebase_anchor').fetchone()[0],anchor)
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM native_rebase_journal').fetchone()[0],0)
        self.bridge.db.execute('DROP TRIGGER refuse_import')
        self.assertEqual(self.rebaser.reconcile(self.native_read(),self.now,self.notion),'REBASED')

    def test_rebase_reordered_prefix_preserves_cache_without_import(self):
        self.baseline(); self.add_external(100,27950,0,'income'); self.add_external(-50,27900,50,'expense')
        self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.server.children['fixture.moneylog']=['fixture.log.header','expense','income']
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(self.native_read(),self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27900)

    def test_rebase_insufficient_native_balance_preserves_reservation(self):
        self.baseline(); state=self.bridge.state(); state.wallet.reserved_amount=27800
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        self.add_external(-250,27600,250)
        evidence=self.native_read().model_copy(update={'reserved_jpy':27800})
        with self.assertRaises(ValueError): self.rebaser.reconcile(evidence,self.now,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertEqual(self.bridge.state().wallet.reserved_amount,27800)
