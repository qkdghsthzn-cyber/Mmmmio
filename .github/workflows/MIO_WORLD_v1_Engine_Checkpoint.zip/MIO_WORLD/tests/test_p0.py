import json
import tempfile
import unittest
from datetime import datetime
from pathlib import Path
from pydantic import ValidationError
from core.clock import DeterministicClock
from core.mock_state import mock_state
from core.models import State, Wallet, WorldState
from core.state_manager import StateStore


def replay(path, hours=168):
    store=StateStore(path); initial=mock_state(); store.initialize(initial)
    clock=DeterministicClock(initial.world.time)
    for i in range(hours):
        with store.atomic():
            if store.claim_tick(clock.tick_id(i),clock.at(i)):
                state=store.load(); state.world.time=clock.at(i); state.revision+=1
                store.save(state,clock.tick_id(i),"clock"); store.finish_tick(clock.tick_id(i))
    result=store.load().model_dump_json(); count=len(store.records("ticks")); store.close()
    return result,count


class P0Tests(unittest.TestCase):
    def test_seven_days_reproducible(self):
        with tempfile.TemporaryDirectory() as d:
            a,n=replay(Path(d)/"a.db"); b,m=replay(Path(d)/"b.db")
            self.assertEqual(a,b); self.assertEqual(n,168); self.assertEqual(m,168)
            self.assertEqual(json.loads(a)["world"]["time"],"2026-10-12T23:00:00+09:00")

    def test_state_roundtrip_and_restart(self):
        state=mock_state(); self.assertEqual(state,State.model_validate_json(state.model_dump_json()))
        with tempfile.TemporaryDirectory() as d:
            path=Path(d)/"world.db"; a,n=replay(path); b,m=replay(path)
            self.assertEqual(a,b); self.assertEqual(n,m)

    def test_invalid_schema_rejected(self):
        with self.assertRaises(ValidationError): Wallet(balance=-1)
        with self.assertRaises(ValidationError): Wallet(balance=10,reserved_amount=11)
        with self.assertRaises(ValidationError): WorldState(time=datetime(2026,10,6))
        value=mock_state().model_dump(); value["surprise"]=True
        with self.assertRaises(ValidationError): State.model_validate(value)

    def test_atomic_rollback(self):
        store=StateStore(); store.initialize(mock_state()); before=store.load()
        with self.assertRaises(RuntimeError):
            with store.atomic():
                state=store.load(); state.wallet.balance=0; store.save(state,"test","fault")
                raise RuntimeError("injected failure")
        self.assertEqual(before,store.load()); self.assertEqual([],store.records("mutations"))
