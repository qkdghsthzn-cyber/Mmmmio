import json
import tempfile
import unittest
from copy import deepcopy
from dataclasses import replace
from datetime import timedelta
from pathlib import Path
from core.models import Action,Decision,Commitment,Provenance
from core.mock_state import mock_state
from core.event_grammar import Grammar
from core.validator import Validator,RuleViolation
from connectors.mock_native import fixture_purchase
from connectors.canonical_runtime import RuntimeEvidence,CanonicalValidator,CanonicalCacheBridge
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.http_json import HTTPJSON,ConnectorUnavailable
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.write_coordinator import WriteCoordinator
from connectors.write_models import digest
from tests.test_p2 import candidate
from .native_http_server import NativeHTTPFixture


class P5RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.root=Path(self.temp.name)
        self.native,self.proposal,self.now=fixture_purchase()
        self.state=mock_state(); self.state.world.time=self.now; self.state.calendar=[]; self.state.inventory={}
        item=self.state.catalog['catalog_0']; item.name=self.proposal.item_name; item.price=self.proposal.cost_jpy
        self.state.catalog={item.item_id:item}
        self.server=NativeHTTPFixture(self.native)
        http=HTTPJSON(self.server.url,'fixture-only-token',fixture=True)
        self.notion=NotionConnector(http=http); self.calendar=CalendarConnector(calendar_id='fixture.calendar',http=http)
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':NativeHTTPAdapter(self.notion),'calendar':NativeHTTPAdapter(self.calendar)})
        self.validator=CanonicalValidator(Validator(Grammar())); self.bridge=CanonicalCacheBridge(self.coordinator,self.validator)
        self.bridge.initialize(self.state,'fixture')
        self.event=candidate(self.state,'PURCHASE_ITEM')
        self.decision=Decision(decision_id='fixture.runtime.decision',event_id=self.event.event_id,choice='accept',reason_tags=[],
                               actions=[Action(type='purchase',item_id='catalog_0',amount=4800)])
        self.evidence=RuntimeEvidence(notion=self.native,calendar_read_at=self.now,calendar_rows=[],calendar_stale=False,
            world_anchor='fixture explicit world initialization',state_hash=digest(self.state.model_dump(mode='json')),
            calendar_complete=True,calendar_query='',calendar_window=(self.now-timedelta(days=1),self.now+timedelta(days=8)))

    def tearDown(self): self.coordinator.close(); self.server.close(); self.temp.cleanup()

    def prepare(self):
        self.bridge.log_event(self.event)
        return self.bridge.prepare(self.event,self.decision,self.evidence,self.now,self.proposal)

    def test_end_to_end_native_truth_decision_receipts_then_cache_publication(self):
        tx=self.prepare(); self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertFalse(self.bridge.confirmations_allowed('wallet','inventory'))
        with self.assertRaises(ConnectorUnavailable): self.bridge.confirmed_state()
        self.assertEqual(self.bridge.publish(tx),'PENDING')
        self.assertEqual(self.coordinator.run(tx),'COMMITTED')
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        state=self.bridge.confirmed_state(); self.assertEqual(state.wallet.balance,23050)
        self.assertEqual(len(state.inventory),1)
        row=self.notion.inventory_rows('fixture.inventory')[0]
        item=state.inventory[row['id']]
        self.assertEqual(item.item_id,row['id']); self.assertEqual(item.source_event,self.event.event_id)
        self.assertIsNone(item.condition); self.assertIsNone(item.location)
        self.assertEqual(item.provenance.source,'mock')
        self.assertEqual(state.wallet.ledger[-1].transaction_id,tx)
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(self.prepare(),tx)
        calls=[c for c in self.server.calls if c['method']=='POST' and c['path']=='/pages']
        self.assertEqual(len(calls),1)

    def test_event_becomes_committed_only_with_cache_and_survives_replay(self):
        tx=self.prepare(); self.coordinator.run(tx)
        row=self.coordinator.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(self.event.event_id,)).fetchone()
        self.assertEqual(json.loads(row[0])['status'],'pending')
        self.bridge.publish(tx)
        row=self.coordinator.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(self.event.event_id,)).fetchone()
        self.assertEqual(json.loads(row[0])['status'],'committed')
        self.assertEqual(self.prepare(),tx)
        row=self.coordinator.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(self.event.event_id,)).fetchone()
        self.assertEqual(json.loads(row[0])['status'],'committed')

    def synthetic_canonical_context(self):
        # Data-only policy test. No synthetic evidence may pass the production
        # write gate or be published into a live-world cache.
        state=self.state.model_copy(deep=True); state.mode='live'; state.relationships={}
        state.provenance=Provenance(source='canonical',ref='synthetic unit context only',verified_at=self.now)
        state.catalog['catalog_0'].provenance=Provenance(source='external_verified',ref='synthetic signal only',verified_at=self.now)
        evidence=replace(self.evidence,notion=self.native.model_copy(update={'scope':'canonical'}),
            state_hash=digest(state.model_dump(mode='json')))
        return state,evidence

    def test_live_policy_projects_only_verified_fresh_catalog_without_any_write(self):
        state,evidence=self.synthetic_canonical_context(); before=len(self.server.calls)
        plan,projection=self.validator.plan(state,self.event,self.decision,evidence,self.now,self.proposal)
        self.assertEqual(projection.mode,'live'); self.assertEqual(projection.wallet.balance,23050)
        self.assertEqual(state.wallet.balance,27850); self.assertEqual(len(self.server.calls),before)
        with self.assertRaises(ConnectorUnavailable): self.coordinator.prepare(plan)

    def test_live_policy_rejects_unverified_or_old_real_price(self):
        for source,verified in [('mock',self.now),('external_verified',self.now-timedelta(minutes=6)),('external_verified',None)]:
            state,evidence=self.synthetic_canonical_context()
            state.catalog['catalog_0'].provenance=Provenance(source=source,ref='synthetic guard case',verified_at=verified)
            evidence=replace(evidence,state_hash=digest(state.model_dump(mode='json')))
            with self.subTest(source=source,verified=verified),self.assertRaises(RuleViolation):
                self.validator.project(state,self.event,self.decision,evidence,self.now)

    def test_unknown_native_purchase_keeps_cache_and_confirmations_frozen(self):
        self.server.fault('POST','/pages','before_disconnect'); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.bridge.publish(tx),'PENDING')
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertEqual(self.bridge.state().inventory,{})
        self.assertFalse(self.bridge.confirmations_allowed('wallet','inventory'))
        self.assertTrue(self.bridge.confirmations_allowed('calendar'))

    def test_rejected_native_write_restores_external_state_and_releases_cache_binding(self):
        self.server.fault('POST','/pages',403); tx=self.prepare()
        self.assertEqual(self.coordinator.run(tx),'ROLLED_BACK')
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))
        self.assertEqual(self.bridge.publish(tx),'ROLLED_BACK')
        self.assertTrue(self.bridge.confirmations_allowed()); self.assertEqual(self.bridge.confirmed_state(),self.state)

    def test_external_edit_after_commit_but_before_cache_publication_is_detected(self):
        tx=self.prepare(); self.coordinator.run(tx)
        self.server.edit('fixture.balance',{'bulleted_list_item':{'rich_text':[{'type':'text','text':{'content':'残高: ¥99,000'}}]}})
        self.assertEqual(self.bridge.publish(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.bridge.state(),self.state); self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_failed_publication_reread_does_not_stop_or_promote_world(self):
        tx=self.prepare(); self.coordinator.run(tx)
        self.server.fault('GET','/blocks/fixture.balance',503)
        self.assertEqual(self.bridge.publish(tx),'RECONCILE_REQUIRED'); self.assertEqual(self.bridge.state(),self.state)
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED')

    def test_cache_revision_drift_never_overwrites_independent_state(self):
        tx=self.prepare(); self.coordinator.run(tx)
        newer=self.state.model_copy(deep=True); newer.world.mood='new internal mood'; newer.revision+=1
        self.coordinator.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(newer.model_dump_json(),))
        self.assertEqual(self.bridge.publish(tx),'RECONCILE_REQUIRED')
        self.assertEqual(self.bridge.state().world.mood,'new internal mood')
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_outbox_and_cache_binding_rollback_together_on_prepare_failure(self):
        original=self.coordinator.audit
        def audit(tx,action,detail=''):
            if action=='CACHE_INPUT': raise RuntimeError('fixture local failure')
            return original(tx,action,detail)
        self.coordinator.audit=audit
        with self.assertRaises(RuntimeError): self.prepare()
        self.assertEqual(self.coordinator.db.execute('SELECT COUNT(*) FROM external_transactions').fetchone()[0],0)
        self.assertEqual(self.coordinator.db.execute('SELECT COUNT(*) FROM cache_bindings').fetchone()[0],0)
        self.assertTrue(self.bridge.confirmations_allowed())

    def test_restart_after_native_commit_publishes_once_without_new_requests(self):
        tx=self.prepare(); self.coordinator.run(tx); self.coordinator.close()
        http=HTTPJSON(self.server.url,'fixture-only-token',fixture=True)
        n=NotionConnector(http=http)
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':NativeHTTPAdapter(n)})
        self.bridge=CanonicalCacheBridge(self.coordinator,self.validator)
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertEqual(len([c for c in self.server.calls if c['method']=='POST' and c['path']=='/pages']),1)

    def test_forged_unlogged_event_and_changed_replay_cannot_prepare(self):
        with self.assertRaises(RuleViolation): self.bridge.prepare(self.event,self.decision,self.evidence,self.now,self.proposal)
        tx=self.prepare()
        changed=self.decision.model_copy(update={'reason_tags':['changed']})
        with self.assertRaises(RuleViolation): self.bridge.prepare(self.event,changed,self.evidence,self.now,self.proposal)
        self.assertEqual(self.coordinator.status(tx),'PREPARED')

    def test_wallet_ownership_and_reservation_drift_are_rejected(self):
        for change in ['wallet','inventory','reserved']:
            with self.subTest(change=change):
                state=self.state.model_copy(deep=True)
                if change=='wallet': state.wallet.balance=30000
                elif change=='reserved': state.wallet.reserved_amount=20000
                else: state.inventory=mock_state().inventory
                evidence=replace(self.evidence,state_hash=digest(state.model_dump(mode='json')))
                with self.assertRaises(RuleViolation): self.validator.project(state,self.event,self.decision,evidence,self.now)

    def test_stale_missing_anchor_or_scope_mismatch_are_rejected(self):
        cases=[replace(self.evidence,state_hash='wrong'),replace(self.evidence,world_anchor=''),
               replace(self.evidence,notion=self.native.model_copy(update={'scope':'canonical'})),
               replace(self.evidence,notion=self.native.model_copy(update={'read_at':self.now-timedelta(minutes=6)}))]
        for evidence in cases:
            with self.subTest(evidence=evidence),self.assertRaises(RuleViolation):
                self.validator.project(self.state,self.event,self.decision,evidence,self.now)

    def test_purchase_properties_cannot_diverge_from_validated_catalog(self):
        self.bridge.log_event(self.event)
        for changes in [{'item_name':'different'}, {'brand':'guessed brand'}, {'cost_jpy':4700}]:
            with self.subTest(changes=changes), self.assertRaises(RuleViolation):
                self.bridge.prepare(self.event,self.decision,self.evidence,self.now,self.proposal.model_copy(update=changes))

    def test_fixture_receipts_cannot_be_reinterpreted_as_live_cache(self):
        tx=self.prepare(); self.coordinator.run(tx)
        self.coordinator.db.execute("UPDATE runtime_cache SET scope='canonical' WHERE id=1")
        with self.assertRaises(RuleViolation): self.bridge.publish(tx)
        self.assertEqual(self.bridge.state(),self.state)

    def reader(self):
        from connectors.canonical_runtime import RuntimeEvidenceReader
        return RuntimeEvidenceReader(self.notion,self.calendar,lambda:self.now)

    def read_evidence(self):
        return self.reader().read(self.bridge,'fixture.wallet','fixture.inventory','fixture.continuity','explicit fixture initialization')

    def test_reader_fetches_fresh_native_schema_and_unfiltered_calendar(self):
        evidence=self.read_evidence()
        self.assertFalse(evidence.calendar_stale); self.assertTrue(evidence.calendar_complete)
        self.assertEqual(evidence.calendar_query,''); self.assertEqual(evidence.notion.inventory_rows,[])
        calendar_call=next(c for c in self.server.calls if c['path']==self.calendar.path)
        self.assertEqual(calendar_call['query']['q'],[''])
        self.assertEqual(evidence.state_hash,digest(self.bridge.state().model_dump(mode='json')))

    def test_reader_failure_marks_only_affected_domains_stale_then_recovers(self):
        self.server.fault('GET','/pages/fixture.wallet',503)
        evidence=self.read_evidence(); self.assertIsNone(evidence.notion)
        self.assertTrue(self.bridge.state().notion_stale)
        self.assertFalse(self.bridge.confirmations_allowed('inventory'))
        self.assertTrue(self.bridge.confirmations_allowed('calendar'))
        self.read_evidence(); self.assertFalse(self.bridge.state().notion_stale)

    def test_reader_calendar_failure_allows_independent_purchase_validation(self):
        self.server.fault('GET',self.calendar.path,503)
        evidence=self.read_evidence(); self.assertTrue(evidence.calendar_stale)
        self.assertTrue(self.bridge.confirmations_allowed('wallet'))
        self.assertFalse(self.bridge.confirmations_allowed('calendar'))
        self.bridge.log_event(self.event)
        tx=self.bridge.prepare(self.event,self.decision,evidence,self.now,self.proposal)
        self.assertEqual(self.coordinator.status(tx),'PREPARED')

    def test_reader_external_money_change_freezes_without_fabricating_income(self):
        self.server.edit('fixture.balance',{'bulleted_list_item':{'rich_text':[{'type':'text','text':{'content':'残高: ¥99,000'}}]}})
        with self.assertRaises(ConnectorUnavailable): self.read_evidence()
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertEqual(self.bridge.state().wallet.ledger,[])
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_reader_does_not_race_pending_native_writes(self):
        self.prepare(); before=len(self.server.calls)
        with self.assertRaises(ConnectorUnavailable): self.read_evidence()
        self.assertEqual(len(self.server.calls),before)
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_fresh_calendar_can_commit_while_notion_is_unavailable(self):
        from connectors.canonical_runtime import confirmed_domain
        self.server.fault('GET','/pages/fixture.wallet',503)
        evidence=self.read_evidence(); event,decision=self.calendar_inputs(self.bridge.state())
        self.bridge.log_event(event)
        tx=self.bridge.prepare(event,decision,evidence,self.now,calendar_connector=self.calendar)
        self.assertEqual(self.coordinator.run(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        self.assertTrue(self.bridge.confirmations_allowed('calendar'))
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))
        self.assertEqual(len(confirmed_domain(self.bridge,'calendar')),1)
        with self.assertRaises(ConnectorUnavailable): confirmed_domain(self.bridge,'wallet')

    def test_notion_failure_cannot_use_old_wallet_to_prepare_purchase(self):
        self.server.fault('GET','/pages/fixture.wallet',503)
        evidence=self.read_evidence(); self.bridge.log_event(self.event)
        with self.assertRaises(RuleViolation): self.bridge.prepare(self.event,self.decision,evidence,self.now,self.proposal)
        self.assertEqual(self.coordinator.db.execute('SELECT COUNT(*) FROM external_transactions').fetchone()[0],0)

    def calendar_inputs(self,state=None):
        state=state or self.state
        event=candidate(state,'CALENDAR_OPEN_SLOT')
        start=self.now+timedelta(hours=1); end=start+timedelta(minutes=event.payload['duration_minutes'])
        decision=Decision(decision_id='fixture.calendar.decision',event_id=event.event_id,choice='accept',reason_tags=[],
                          actions=[Action(type='calendar_create',start=start,end=end,title='fixture only',location='home')])
        return event,decision

    def test_calendar_cache_binding_promotes_native_id_after_verified_create(self):
        event,decision=self.calendar_inputs(); self.bridge.log_event(event)
        tx=self.bridge.prepare(event,decision,self.evidence,self.now,calendar_connector=self.calendar)
        self.assertEqual(self.coordinator.run(tx),'COMMITTED'); self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        state=self.bridge.confirmed_state(); identifier=state.calendar[-1].commitment_id
        self.assertTrue(identifier.startswith('mio')); self.assertIn(identifier,self.server.objects)
        self.assertEqual(state.calendar[-1].source_event,event.event_id)

    def test_hidden_busy_event_stale_or_filtered_window_prevents_calendar_write(self):
        event,decision=self.calendar_inputs()
        native={'id':'hidden.busy','start':{'dateTime':decision.actions[0].start.isoformat()},
                'end':{'dateTime':decision.actions[0].end.isoformat()},'transparency':'opaque'}
        for changes in [{'calendar_rows':[native]}, {'calendar_stale':True}, {'calendar_query':'MIO'},
                        {'calendar_complete':False}, {'calendar_window':(self.now,self.now+timedelta(minutes=10))}]:
            evidence=replace(self.evidence,**changes)
            with self.subTest(changes=changes),self.assertRaises(RuleViolation):
                self.validator.project(self.state,event,decision,evidence,self.now)

    def test_fixed_calendar_overlap_and_travel_constraints_are_enforced(self):
        event,decision=self.calendar_inputs(); action=decision.actions[0]
        for conflict in ['overlap','travel']:
            state=self.state.model_copy(deep=True)
            start=action.start if conflict=='overlap' else action.end+timedelta(minutes=1)
            state.calendar=[Commitment(commitment_id='native.busy',start=start,end=start+timedelta(hours=1),
                title='confirmed fixture busy',source_event='fixture.only',location='school',
                provenance=Provenance(source='mock',ref='fixture calendar'))]
            row={'id':'native.busy','start':{'dateTime':start.isoformat()},'end':{'dateTime':(start+timedelta(hours=1)).isoformat()},
                 'location':'school','transparency':'opaque'}
            evidence=replace(self.evidence,calendar_rows=[row],state_hash=digest(state.model_dump(mode='json')))
            with self.subTest(conflict=conflict),self.assertRaises(RuleViolation):
                self.validator.project(state,event,decision,evidence,self.now)
