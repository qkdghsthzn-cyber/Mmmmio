import unittest
from datetime import timedelta
from core.event_grammar import Grammar
from core.candidate_generator import CandidateGenerator
from core.probability_engine import ProbabilityEngine
from core.novelty_engine import NoveltyEngine
from core.mock_state import mock_state


def sample(hours,seed=42,enabled=True):
    grammar=Grammar(); generator=CandidateGenerator(grammar); probability=ProbabilityEngine(grammar.rules)
    novelty=NoveltyEngine(grammar.rules,enabled=enabled); state=mock_state(); start=state.world.time
    events=[]; no_event=0; repeated=0; last={}
    for i in range(hours):
        state.world.time=start+timedelta(hours=i)
        candidates=generator.generate(state,seed,novelty)
        selected=probability.select(candidates,seed,state.world.time)
        if not selected: no_event+=1
        for e in selected:
            if not e.routine and e.family in last and state.world.time-last[e.family]<=timedelta(hours=24): repeated+=1
            last[e.family]=state.world.time; events.append(e)
            novelty.record(e)
    denominator=sum(not e.routine for e in events)
    return dict(events=events,no_event_rate=no_event/hours,repeat_rate=repeated/max(1,denominator))


class P1Tests(unittest.TestCase):
    def test_catalog_160_and_slots(self):
        g=Grammar(); self.assertEqual(len(g.families),160)
        candidates=CandidateGenerator(g).generate(mock_state(),42,NoveltyEngine(g.rules))
        self.assertTrue(10<=len(candidates)<=30); self.assertEqual(candidates[-1].family,"NO_EVENT")
        self.assertGreaterEqual(len(candidates[0].slots),17)

    def test_state_constraints(self):
        g=Grammar(); state=mock_state(); state.inventory={}; state.wallet.balance=0; state.relationships={}
        candidates=CandidateGenerator(g).generate(state,9,NoveltyEngine(g.rules))
        for e in candidates:
            self.assertNotIn(e.family,{"PURCHASE_ITEM","OUTFIT_CHOICE","FRIEND_INVITE","SMALL_EXPENSE"})

    def test_reproducible_and_no_empty_hour_forcing(self):
        a=sample(168); b=sample(168)
        self.assertEqual([e.model_dump() for e in a["events"]],[e.model_dump() for e in b["events"]])
        self.assertGreater(a["no_event_rate"],.05); self.assertLess(a["no_event_rate"],.85)

    def test_novelty_reduces_repetition_multiple_seeds(self):
        enabled=[]; disabled=[]
        for seed in [11,42,97]:
            on=sample(720,seed,True); off=sample(720,seed,False)
            enabled.append(on["repeat_rate"]); disabled.append(off["repeat_rate"])
            self.assertGreater(len({e.family for e in on["events"]}),50)
        self.assertLess(sum(enabled)/3,sum(disabled)/3)
