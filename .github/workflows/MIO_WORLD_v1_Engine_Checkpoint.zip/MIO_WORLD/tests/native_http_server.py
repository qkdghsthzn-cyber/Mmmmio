"""Loopback-only native REST fixture. No real credentials or external calls."""
import json
import socket
import threading
from copy import deepcopy
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, unquote, parse_qs
from uuid import uuid4


class NativeHTTPFixture:
    def __init__(self, evidence, page_size=100):
        self.objects={}; self.children={}; self.calls=[]; self.faults={}; self.sequence=1; self.page_size=page_size
        wallet=evidence.wallet
        self.objects[wallet["page"]["id"]]=deepcopy(wallet["page"])
        def seed(blocks,parent,parent_kind):
            self.children.setdefault(parent,[])
            for value in blocks:
                block=deepcopy(value); nested=block.pop("children",[])
                block["parent"]={"type":parent_kind,parent_kind:parent}
                block["has_children"]=bool(nested)
                self.objects[block["id"]]=block; self.children[parent].append(block["id"])
                if nested: seed(nested,block["id"],"block_id")
        seed(wallet["blocks"],wallet["page"]["id"],"page_id")
        source=deepcopy(evidence.inventory_schema); self.objects[source["id"]]=source
        self.children[source["id"]]=[]
        for row in evidence.inventory_rows:
            self.objects[row["id"]]=deepcopy(row); self.children[source["id"]].append(row["id"])
        continuity=deepcopy(evidence.continuity_page["page"]); self.objects[continuity["id"]]=continuity
        self.children[continuity["id"]]=[]
        fixture=self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self,*args): pass
            def do_GET(self): self.dispatch("GET")
            def do_POST(self): self.dispatch("POST")
            def do_PATCH(self): self.dispatch("PATCH")
            def do_DELETE(self): self.dispatch("DELETE")
            def dispatch(self,method):
                parsed=urlsplit(self.path); path=unquote(parsed.path); params=parse_qs(parsed.query,keep_blank_values=True)
                body=json.loads(self.rfile.read(int(self.headers.get("Content-Length",0))) or b"null")
                fixture.calls.append({"method":method,"path":path,"body":body,"if_match":self.headers.get("If-Match"),"query":params})
                action=fixture.faults.pop((method,path),None)
                if action=="before_disconnect": return self.disconnect()
                if isinstance(action,int): return self.respond(action,{"error":"fixture error body contains PRIVATE_ERROR_SENTINEL"})
                status,output=fixture.route(method,path,params,body,self.headers)
                if action=="after_disconnect": return self.disconnect()
                if action=="external_calendar_edit":
                    key=path.split("/")[-1]; fixture.edit(key,{"summary":"external edit"})
                self.respond(status,output)
            def disconnect(self):
                self.connection.shutdown(socket.SHUT_RDWR); self.connection.close(); self.close_connection=True
            def respond(self,status,output):
                raw=json.dumps(output,ensure_ascii=False).encode() if output is not None else b""
                self.send_response(status); self.send_header("Content-Type","application/json")
                self.send_header("Content-Length",str(len(raw))); self.end_headers(); self.wfile.write(raw)
        self.server=ThreadingHTTPServer(("127.0.0.1",0),Handler)
        self.thread=threading.Thread(target=lambda:self.server.serve_forever(poll_interval=.01),daemon=True)
        self.thread.start(); self.url="http://127.0.0.1:"+str(self.server.server_port)

    def close(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)

    def version(self,obj):
        self.sequence+=1
        if obj.get("kind")=="calendar#event": obj["etag"]='"etag-'+str(self.sequence)+'"'
        else: obj["last_edited_time"]="version-"+str(self.sequence)

    def edit(self,identifier,fields):
        self.objects[identifier].update(deepcopy(fields)); self.version(self.objects[identifier])

    def fault(self,method,path,action): self.faults[(method,path)]=action

    def route(self,method,path,params,body,headers):
        segments=path.strip('/').split('/')
        if segments[0]=='calendars':
            if len(segments)==2 and method=='GET':
                return 200,{'id':segments[1],'timeZone':getattr(self,'calendar_timezone','Asia/Tokyo')}
            identifier=segments[3] if len(segments)>3 else None
            if method=='GET':
                if identifier is None:
                    return 200,{'items':[deepcopy(o) for o in self.objects.values() if o.get('kind')=='calendar#event']}
                if identifier not in self.objects: return 404,{"error":"not found"}
                return 200,deepcopy(self.objects[identifier])
            if method=='POST':
                if body['id'] in self.objects: return 409,{}
                obj=deepcopy(body); obj['kind']='calendar#event'; obj['status']='confirmed'; self.version(obj)
                self.objects[obj['id']]=obj; return 200,deepcopy(obj)
            if method=='DELETE':
                obj=self.objects.get(identifier)
                if not obj: return 404,{}
                if headers.get('If-Match')!=obj['etag']: return 412,{}
                del self.objects[identifier]; return 204,None
            if method=='PATCH':
                obj=self.objects.get(identifier)
                if not obj: return 404,{}
                if headers.get('If-Match')!=obj['etag']: return 412,{}
                fields=deepcopy(body); fields.pop('id',None)
                properties=fields.pop('extendedProperties',{})
                obj.update(fields)
                for scope,values in properties.items():
                    saved=obj.setdefault('extendedProperties',{}).setdefault(scope,{})
                    for key,value in values.items():
                        if value is None: saved.pop(key,None)
                        else: saved[key]=value
                self.version(obj); return 200,deepcopy(obj)
        identifier=segments[1] if len(segments)>1 else None
        if method=='GET':
            if len(segments)>2 and segments[2]=='children':
                ids=[k for k in self.children.get(identifier,[]) if not self.objects[k].get('archived')]
                start=int(params.get('start_cursor',['0'])[0]); selected=ids[start:start+self.page_size]
                more=start+self.page_size<len(ids)
                return 200,{'results':[deepcopy(self.objects[k]) for k in selected],'has_more':more,
                            'next_cursor':str(start+self.page_size) if more else None}
            if identifier not in self.objects: return 404,{}
            return 200,deepcopy(self.objects[identifier])
        if segments[0]=='data_sources' and method=='POST':
            ids=[k for k in self.children.get(identifier,[]) if not self.objects[k].get('archived')]
            start=int((body or {}).get('start_cursor',0)); selected=ids[start:start+self.page_size]
            more=start+self.page_size<len(ids)
            return 200,{'results':[deepcopy(self.objects[k]) for k in selected],'has_more':more,
                        'next_cursor':str(start+self.page_size) if more else None}
        if segments[0]=='pages' and method=='POST':
            obj=deepcopy(body); obj['id']=uuid4().hex; obj['object']='page'; obj['archived']=False
            self.version(obj); self.objects[obj['id']]=obj; parent=obj['parent']['data_source_id']
            self.children[parent].append(obj['id']); self.version(self.objects[parent])
            return 200,deepcopy(obj)
        if len(segments)>2 and segments[2]=='children' and method=='PATCH':
            rows=[]
            for child in body['children']:
                obj=deepcopy(child); obj['id']=uuid4().hex; obj['archived']=False
                parent_kind='page_id' if self.objects[identifier].get('object')=='page' or identifier=='fixture.continuity' else 'block_id'
                obj['parent']={'type':parent_kind,parent_kind:identifier}; self.version(obj)
                self.objects[obj['id']]=obj; self.children.setdefault(identifier,[]).append(obj['id']); rows.append(deepcopy(obj))
            self.version(self.objects[identifier]); return 200,{'results':rows,'has_more':False}
        if identifier not in self.objects: return 404,{}
        if method=='PATCH':
            self.edit(identifier,body); return 200,deepcopy(self.objects[identifier])
        if method=='DELETE':
            self.edit(identifier,{'archived':True}); return 200,deepcopy(self.objects[identifier])
        return 400,{}
