import json
import unittest
from copy import deepcopy
from dataclasses import replace
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from core.validator import RuleViolation
from connectors.canonical_runtime import CanonicalCacheBridge
from connectors.native_plans import rich, money_field, purchase_plan
from connectors.native_rebase import NativeCacheReconciler
from connectors.write_coordinator import WriteCoordinator
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.http_json import ConnectorUnavailable
from tests import test_p5_effects as support
from tests import test_p5_hourly as hourly_support


def period(server, month, identifier='fixture.period'):
    if identifier not in server.children['fixture.wallet']:
        server.children['fixture.wallet'].append(identifier)
    server.objects[identifier]={'object':'block','id':identifier,'type':'bulleted_list_item',
        'parent':{'type':'page_id','page_id':'fixture.wallet'},'last_edited_time':'period-v1',
        'bulleted_list_item':{'rich_text':rich('支出対象月: '+month),'color':'default'}}
    server.version(server.objects['fixture.wallet'])


class P5MonthTests(unittest.TestCase):
    setUp=support.P5EffectsTests.setUp
    tearDown=support.P5EffectsTests.tearDown
    native_read=support.P5EffectsTests.native_read
    baseline=support.P5EffectsTests.baseline
    add_external=support.P5EffectsTests.add_external
    read=support.P5EffectsTests.read
    prepare_expense=support.P5EffectsTests.prepare_expense

    def expense(self):
        self.evidence=replace(self.evidence,notion=self.native_read().model_copy(update={'read_at':self.now}))
        return support.P5EffectsTests.expense(self)

    def move_clock(self, when):
        self.now=when
        state=self.bridge.state(); state.world.time=when
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))

    def anchor(self): return json.loads(self.bridge.db.execute('SELECT body FROM native_rebase_anchor').fetchone()[0])
    def proofs(self): return [json.loads(r[0]) for r in self.bridge.db.execute('SELECT body FROM native_rebase_journal ORDER BY rowid')]
    def monthly(self, amount): self.server.edit('fixture.monthly',money_field(self.server.objects['fixture.monthly'],'今月の支出:',amount)[1])
    def dated(self, amount, balance, monthly, when, identifier):
        self.add_external(amount,balance,monthly,identifier)
        self.server.objects[identifier]['table_row']['cells'][0]=rich(when)
    def reconcile(self): return self.rebaser.reconcile(self.native_read().model_copy(update={'read_at':self.now}),self.now,self.notion)
    def start(self): period(self.server,'2026-10'); self.baseline()
    def november(self): self.move_clock(datetime(2026,11,1,0,0,tzinfo=ZoneInfo('Asia/Tokyo'))); period(self.server,'2026-11')

    def test_explicit_rollover_preserves_money_and_records_month_proof_once(self):
        self.start(); self.dated(-100,27750,100,'2026-10-06','october'); self.reconcile()
        self.november(); self.monthly(0); wallet=deepcopy(self.bridge.state().wallet)
        self.assertEqual(self.reconcile(),'REBASED'); self.assertEqual(self.bridge.state().wallet,wallet)
        self.assertEqual(self.anchor()['month_totals'],{'2026-10':100,'2026-11':0})
        proof=self.proofs()[-1]; self.assertEqual(proof['monthly_before']['monthly'],100)
        self.assertEqual(proof['monthly_after']['monthly'],0); self.assertEqual(proof['external_writes'],0)
        count=len(self.proofs()); self.assertEqual(self.reconcile(),'UNCHANGED'); self.assertEqual(len(self.proofs()),count)
        self.assertEqual([c for c in self.server.calls if c['method'] in {'PATCH','POST','DELETE'} and not c['path'].startswith('/data_sources')],[])

    def test_rollover_income_changes_balance_without_spending(self):
        self.start(); self.november(); self.dated(1000,28850,0,'2026-11-01','income')
        self.reconcile(); self.assertEqual(self.bridge.state().wallet.balance,28850)
        self.assertEqual(self.anchor()['month_totals']['2026-11'],0)

    def test_late_previous_month_expense_does_not_charge_current_month(self):
        self.start(); self.dated(-100,27750,100,'2026-10-06','first'); self.reconcile(); self.november()
        self.dated(-250,27500,0,'2026-10-31','late'); self.reconcile()
        self.assertEqual(self.anchor()['month_totals'],{'2026-10':350,'2026-11':0})
        self.assertEqual(self.bridge.state().wallet.ledger[-1].created_at,self.now)
        native=self.proofs()[-1]['native_wallet']['blocks']
        table=next(b for b in native if b['id']=='fixture.moneylog')
        self.assertEqual(table['children'][-1]['table_row']['cells'][0][0]['text']['content'],'2026-10-31')

    def test_append_order_controls_balance_while_dates_partition_expenses(self):
        self.start(); self.november()
        self.dated(-50,27800,0,'2026-10-01','late.first')
        self.dated(-200,27600,200,'2026-11-01','current')
        self.dated(-25,27575,200,'2026-10-05','late.last')
        self.reconcile(); self.assertEqual([e.balance_after for e in self.bridge.state().wallet.ledger],[27800,27600,27575])
        self.assertEqual(self.anchor()['month_totals'],{'2026-10':75,'2026-11':200})

    def test_prebaseline_historical_total_stays_unknown(self):
        self.start(); self.dated(-250,27600,0,'2026-09-30','historical'); self.reconcile()
        self.assertEqual(self.anchor()['historical_expense_deltas'],{'2026-09':250})
        self.assertNotIn('2026-09',self.anchor()['month_totals'])

    def test_current_month_backdated_day_is_counted_without_invented_timestamp(self):
        self.start(); self.dated(-250,27600,250,'2026-10-01','earlier.day'); self.reconcile()
        self.assertEqual(self.anchor()['month_totals']['2026-10'],250)
        self.assertEqual(self.bridge.state().wallet.ledger[-1].created_at,self.now)

    def test_legacy_wallet_requires_explicit_period_for_rollover_even_zero(self):
        self.baseline(); self.move_clock(datetime(2026,11,1,tzinfo=ZoneInfo('Asia/Tokyo')))
        with self.assertRaises(ValueError): self.reconcile()
        self.assertEqual(self.anchor()['month'],'2026-10'); self.assertTrue(self.bridge.state().notion_stale)

    def test_legacy_wallet_requires_explicit_period_for_past_month_row(self):
        self.baseline(); self.dated(-250,27600,0,'2026-09-30','late')
        with self.assertRaises(ValueError): self.reconcile()
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_old_nonzero_summary_cannot_be_carried_as_new_month(self):
        self.start(); self.dated(-250,27600,250,'2026-10-06','old'); self.reconcile(); self.november()
        with self.assertRaises(ValueError): self.reconcile()
        self.assertEqual(self.anchor()['month'],'2026-10')

    def test_current_summary_must_exclude_backdated_expense(self):
        self.start(); self.november(); self.dated(-250,27600,250,'2026-10-31','late')
        with self.assertRaises(ValueError): self.reconcile()
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_period_missing_wrong_duplicate_or_replaced_is_rejected(self):
        self.start(); original=deepcopy(self.server.objects['fixture.period'])
        for kind in ['missing','wrong','duplicate','replaced','malformed']:
            with self.subTest(kind=kind):
                self.server.children['fixture.wallet']=[k for k in self.server.children['fixture.wallet'] if k not in {'fixture.period','other.period'}]
                self.server.children['fixture.wallet'].append('fixture.period'); self.server.objects['fixture.period']=deepcopy(original)
                if kind=='missing': self.server.children['fixture.wallet'].remove('fixture.period')
                if kind=='wrong': period(self.server,'2026-11')
                if kind=='malformed': period(self.server,'2026-13')
                if kind=='duplicate': period(self.server,'2026-10','other.period')
                if kind=='replaced': self.server.children['fixture.wallet'].remove('fixture.period'); period(self.server,'2026-10','other.period')
                with self.assertRaises(ValueError): self.reconcile()
                self.assertEqual(self.anchor()['month'],'2026-10')

    def test_future_and_non_iso_dates_are_not_imported(self):
        self.start()
        for when in ['2026-10-07','20261001','2026-02-30']:
            with self.subTest(when=when):
                if 'row' not in self.server.children['fixture.moneylog']: self.dated(-250,27600,250,when,'row')
                self.server.objects['row']['table_row']['cells'][0]=rich(when)
                with self.assertRaises((RuleViolation,ValueError)): self.reconcile()
                self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_prefix_edit_still_blocks_rollover(self):
        self.start(); self.dated(-250,27600,250,'2026-10-06','old'); self.reconcile()
        self.november(); self.monthly(0); self.server.objects['old']['table_row']['cells'][0]=rich('2026-10-05')
        with self.assertRaises(RuleViolation): self.reconcile()
        self.assertEqual(self.anchor()['month'],'2026-10')

    def test_new_month_label_does_not_explain_balance_without_rows(self):
        self.start(); self.november(); self.server.edit('fixture.balance',money_field(self.server.objects['fixture.balance'],'残高:',27000)[1])
        with self.assertRaises(RuleViolation): self.reconcile()
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_unstable_second_month_read_keeps_anchor_and_money(self):
        self.start(); self.november(); native=self.native_read().model_copy(update={'read_at':self.now})
        period(self.server,'2026-12')
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(native,self.now,self.notion)
        self.assertEqual(self.anchor()['month'],'2026-10')

    def test_http_outage_leaves_month_unpublished_and_confirmations_frozen(self):
        self.start(); self.november(); native=self.native_read().model_copy(update={'read_at':self.now})
        self.server.fault('GET','/pages/fixture.wallet',503)
        with self.assertRaises(ConnectorUnavailable): self.rebaser.reconcile(native,self.now,self.notion)
        self.assertEqual(self.anchor()['month'],'2026-10'); self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_atomic_failure_rolls_back_month_cache_and_proof_then_retries(self):
        self.start(); before=self.bridge.state(); old=self.anchor(); self.november()
        self.bridge.db.execute("CREATE TRIGGER reject_month BEFORE INSERT ON native_rebase_journal BEGIN SELECT RAISE(ABORT,'month proof rejection'); END")
        with self.assertRaises(ConnectorUnavailable): self.reconcile()
        self.assertEqual(self.anchor(),old); self.assertEqual(self.bridge.state().wallet,before.wallet)
        self.assertEqual(self.proofs(),[]); self.bridge.db.execute('DROP TRIGGER reject_month')
        self.assertEqual(self.reconcile(),'REBASED')

    def test_restart_replay_does_not_reset_twice_or_duplicate_expense(self):
        self.start(); self.november(); self.dated(-250,27600,250,'2026-11-01','new'); self.reconcile()
        count=len(self.proofs()); self.coordinator.close()
        self.coordinator=WriteCoordinator(self.root/'outbox.sqlite3',{'notion':NativeHTTPAdapter(self.notion),'calendar':NativeHTTPAdapter(self.calendar)})
        self.bridge=CanonicalCacheBridge(self.coordinator,self.validator); self.rebaser=NativeCacheReconciler(self.bridge)
        self.assertEqual(self.reconcile(),'UNCHANGED'); self.assertEqual(len(self.proofs()),count)
        self.assertEqual(len(self.bridge.state().wallet.ledger),1)

    def test_legacy_anchor_upgrade_preserves_existing_month_and_rows(self):
        self.baseline(); old=self.anchor()
        for key in ['baseline_month','month_totals','historical_expense_deltas','ledger_timezone','period']: old.pop(key)
        self.bridge.db.execute('UPDATE native_rebase_anchor SET body=?',(json.dumps(old),))
        self.november(); self.dated(-250,27600,0,'2026-10-31','late'); self.reconcile()
        self.assertEqual(self.anchor()['baseline_month'],'2026-10'); self.assertEqual(self.anchor()['month_totals']['2026-10'],250)

    def test_year_boundary_skipped_months_and_historical_delta(self):
        self.start(); self.move_clock(datetime(2027,1,1,tzinfo=ZoneInfo('Asia/Tokyo'))); period(self.server,'2027-01')
        self.dated(-100,27750,0,'2026-12-31','december'); self.dated(-25,27725,0,'2026-09-30','unknown')
        self.dated(-200,27525,200,'2027-01-01','january'); self.reconcile()
        self.assertEqual(self.anchor()['month_totals'],{'2026-10':0,'2026-12':100,'2027-01':200})
        self.assertEqual(self.anchor()['historical_expense_deltas'],{'2026-09':25})

    def test_local_midnight_uses_world_timezone_when_read_clock_is_utc(self):
        self.start(); self.move_clock(datetime(2026,10,31,15,tzinfo=timezone.utc)); period(self.server,'2026-11')
        self.dated(-250,27600,250,'2026-11-01','local')
        self.reconcile(); self.assertEqual(self.anchor()['month'],'2026-11')
        self.assertTrue(self.proofs()[-1]['observed_at'].endswith('+09:00'))

    def test_timezone_change_and_month_rewind_are_blocked(self):
        self.start(); self.november(); self.reconcile()
        self.move_clock(datetime(2026,10,31,tzinfo=ZoneInfo('Asia/Tokyo'))); period(self.server,'2026-10')
        with self.assertRaises(ValueError): self.reconcile()
        self.november(); state=self.bridge.state(); state.world.timezone='Asia/Seoul'
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        with self.assertRaises(ValueError): self.reconcile()

    def test_reader_without_reconcile_cannot_confirm_new_month(self):
        self.start(); self.november()
        with self.assertRaises(ConnectorUnavailable): self.read(reconcile=False)
        self.assertEqual(self.anchor()['month'],'2026-10')
        result=self.read(reconcile=True); self.assertIsNotNone(result.notion); self.assertFalse(self.bridge.state().notion_stale)
        self.assertEqual(self.anchor()['month'],'2026-11')

    def test_prepare_cannot_bypass_month_reconciliation(self):
        self.start(); self.november(); self.evidence=replace(self.evidence,notion=self.native_read().model_copy(update={'read_at':self.now}))
        with self.assertRaises(RuleViolation): self.prepare_expense()
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM external_transactions').fetchone()[0],0)
        self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_purchase_planner_rejects_wrong_native_month(self):
        period(self.server,'2026-09'); native=self.native_read()
        with self.assertRaises(ValueError): purchase_plan(native,self.proposal,'event','decision',self.now)

    def test_published_runtime_expense_is_not_reimported_at_rollover(self):
        self.start(); tx=self.prepare_expense(); self.coordinator.run(tx); self.bridge.publish(tx)
        self.november(); self.monthly(0); self.reconcile()
        self.assertEqual([e.transaction_id for e in self.bridge.state().wallet.ledger],[tx])
        self.assertEqual(self.anchor()['month_totals'],{'2026-10':250,'2026-11':0})

    def test_runtime_marker_date_must_match_published_receipt_time(self):
        self.start(); tx=self.prepare_expense(); self.coordinator.run(tx); self.bridge.publish(tx)
        identifier=self.server.children['fixture.moneylog'][-1]
        self.server.objects[identifier]['table_row']['cells'][0]=rich('2026-09-30'); self.monthly(0)
        with self.assertRaises(RuleViolation): self.reconcile()
        self.assertEqual(self.anchor()['month_totals']['2026-10'],0)

    def test_utc_expense_is_written_on_the_local_calendar_date(self):
        self.start(); self.move_clock(datetime(2026,10,31,15,tzinfo=timezone.utc)); period(self.server,'2026-11'); self.reconcile()
        tx=self.prepare_expense(); self.assertEqual(self.coordinator.run(tx),'COMMITTED')
        self.assertEqual(self.bridge.publish(tx),'PUBLISHED')
        identifier=self.server.children['fixture.moneylog'][-1]
        self.assertEqual(self.server.objects[identifier]['table_row']['cells'][0],rich('2026-11-01'))
        self.assertEqual(self.reconcile(),'UNCHANGED')
        self.assertEqual(self.anchor()['month_totals']['2026-11'],250)

    def test_repeated_dst_hour_does_not_make_old_read_fresh(self):
        first=datetime(2026,11,1,1,tzinfo=ZoneInfo('America/New_York'),fold=0)
        later=datetime(2026,11,1,1,tzinfo=ZoneInfo('America/New_York'),fold=1)
        self.move_clock(first); state=self.bridge.state(); state.world.timezone='America/New_York'
        self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        period(self.server,'2026-11'); self.rebaser=NativeCacheReconciler(self.bridge)
        native=self.native_read().model_copy(update={'read_at':first}); self.rebaser.anchor(native,first)
        self.move_clock(later)
        with self.assertRaises(RuleViolation): self.rebaser.reconcile(native,later,self.notion)
        self.assertEqual(self.bridge.state().wallet.balance,27850)


class P5MonthHourlyTests(unittest.TestCase):
    setUp=hourly_support.P5HourlyTests.setUp
    tearDown=hourly_support.P5HourlyTests.tearDown
    connect=hourly_support.P5HourlyTests.connect
    initialize=hourly_support.P5HourlyTests.initialize
    runtime=hourly_support.P5HourlyTests.runtime
    one_event=hourly_support.P5HourlyTests.one_event

    def begin(self):
        self.now=datetime(2026,10,31,23,tzinfo=ZoneInfo('Asia/Tokyo'))
        data=self.request.model_dump(mode='json'); data['world']['time']=self.now.isoformat(); self.request=type(self.request).model_validate(data)
        period(self.server,'2026-10'); self.initialize()
        runtime=self.runtime(); runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        period(self.server,'2026-11'); return runtime

    def test_hourly_crosses_local_midnight_and_can_spend_in_new_month(self):
        runtime=self.begin(); self.one_event(runtime,'SMALL_EXPENSE')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().wallet.balance,27600); self.assertEqual(len(self.agent.calls),1)
        self.assertFalse(self.bridge.state().notion_stale)
        old=json.loads(self.bridge.db.execute('SELECT body FROM native_rebase_anchor').fetchone()[0]); self.assertEqual(old['month'],'2026-11')
        self.assertEqual(self.server.objects['fixture.monthly']['bulleted_list_item']['rich_text'],rich('今月の支出: ¥250'))

    def test_missing_period_rollover_keeps_clock_without_money_confirmation(self):
        runtime=self.begin(); self.server.children['fixture.wallet'].remove('fixture.period'); self.one_event(runtime,'SMALL_EXPENSE')
        select=runtime._selected; runtime._selected=lambda state:[] if state.notion_stale else select(state)
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=1))
        self.assertEqual(self.bridge.state().wallet.balance,27850); self.assertTrue(self.bridge.state().notion_stale)
        self.assertEqual(self.bridge.db.execute('SELECT COUNT(*) FROM cache_bindings').fetchone()[0],0)

    def test_native_checkpoint_restores_after_month_close_without_double_accounting(self):
        from connectors.native_restore import NativeRuntimeRestorer
        runtime=self.begin(); runtime.tick(self.now+timedelta(hours=1)); state=self.bridge.state()
        self.bridge.db.execute('DELETE FROM runtime_cache'); self.bridge.db.execute('DELETE FROM runtime_continuity_archive')
        result=NativeRuntimeRestorer(self.bridge,self.notion,self.calendar,lambda:state.world.time).restore()
        self.assertEqual(result['status'],'RESTORED'); self.assertEqual(self.bridge.state().wallet,state.wallet)
        anchor=json.loads(self.bridge.db.execute('SELECT body FROM native_rebase_anchor').fetchone()[0])
        self.assertEqual(anchor['month_totals'],{'2026-10':0,'2026-11':0})

    def test_restart_between_new_month_clock_and_read_selects_once(self):
        runtime=self.begin(); self.one_event(runtime,'SMALL_EXPENSE')
        runtime._read=lambda:(_ for _ in ()).throw(SystemExit('fixture interrupted before month read'))
        with self.assertRaises(SystemExit): runtime.tick(self.now+timedelta(hours=1))
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=1))
        row=self.bridge.db.execute('SELECT stage FROM hourly_ticks ORDER BY rowid DESC LIMIT 1').fetchone()
        self.assertEqual(row[0],'SELECT'); self.assertEqual(self.agent.calls,[])
        self.coordinator.close(); self.connect(); runtime=self.runtime(); self.one_event(runtime,'SMALL_EXPENSE')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'ALREADY_COMPLETED')
        self.assertEqual(len(self.agent.calls),1); self.assertEqual(self.bridge.state().wallet.balance,27600)

    def test_delayed_native_month_identity_can_recover_on_next_hour(self):
        runtime=self.begin(); period(self.server,'2026-10')
        runtime.tick(self.now+timedelta(hours=1))
        self.assertTrue(self.bridge.state().notion_stale)
        period(self.server,'2026-11'); self.one_event(runtime,'SMALL_EXPENSE')
        runtime.tick(self.now+timedelta(hours=2))
        self.assertFalse(self.bridge.state().notion_stale)
        self.assertEqual(self.bridge.state().wallet.balance,27600)
