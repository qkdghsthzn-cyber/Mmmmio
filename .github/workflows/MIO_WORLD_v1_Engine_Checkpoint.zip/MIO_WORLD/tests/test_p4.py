import unittest
from datetime import timedelta
from core.event_grammar import Grammar
from core.state_manager import StateStore
from core.mock_state import mock_state
from core.chain_engine import ChainEngine
from core.validator import Validator
from core.transaction_manager import TransactionManager
from core.simulator import Simulator
from core.models import Action,Decision
from agents.npc_runtime import NPCRuntime,NPCProposal
from tests.test_p2 import candidate


class P4Tests(unittest.TestCase):
    def setUp(self):
        self.g=Grammar(); self.chain=ChainEngine(self.g); self.store=StateStore(); self.store.initialize(mock_state())

    def contact(self,choice="accept",depth=0):
        state=self.store.load(); e=candidate(state,"FRIEND_CONTACT"); e.depth=depth
        d=Decision(decision_id="dec_chain",event_id=e.event_id,choice=choice,reason_tags=[],
                   actions=[Action(type="relationship_update",npc_id=e.actors[0],delta=1)] if choice=="accept" else [])
        with self.store.atomic():
            self.store.log_event(e); tx=TransactionManager(self.store,Validator(self.g)).commit(e,d,state.revision)
            state=self.store.load(); self.chain.after_commit(state,e,d,tx); self.store.save(state,tx.transaction_id,"chain")
        return e,d,tx

    def test_committed_contact_creates_conditional_future_not_forced_event(self):
        e,d,tx=self.contact(); state=self.store.load()
        self.assertEqual(len(state.hooks),1); h=state.hooks[0]
        self.assertEqual(h.cause_event,e.event_id); self.assertEqual(h.actor,e.actors[0]); self.assertGreater(h.due_at,state.world.time)
        self.assertEqual(len(self.store.records("events")),1)
        self.assertIn(h.hook_id,state.relationships[e.actors[0]].open_threads)

    def test_defer_does_not_generate_followup(self):
        self.contact(choice="defer"); self.assertEqual(self.store.load().hooks,[])

    def test_duplicate_hooks_and_depth_cap(self):
        e,d,tx=self.contact(); state=self.store.load(); self.chain.after_commit(state,e,d,tx)
        self.assertEqual(len(state.hooks),1)
        other=StateStore(); other.initialize(mock_state()); self.store=other
        self.contact(depth=6); self.assertEqual(self.store.load().hooks,[])

    def test_expired_hook_cleans_open_npc_thread(self):
        self.contact(); state=self.store.load(); state.world.time+=timedelta(days=4); self.chain.resolve_due(state)
        self.assertEqual(state.hooks[0].status,"expired")
        self.assertTrue(all(not npc.open_threads for npc in state.relationships.values()))

    def test_npc_cannot_know_private_wallet_or_other_npc_event(self):
        runtime=NPCRuntime(); state=self.store.load(); context=runtime.context(state,"npc_0")
        self.assertNotIn("wallet",context); self.assertNotIn("inventory",context)
        with self.assertRaises(ValueError): runtime.validate(state,NPCProposal(npc_id="npc_0",message="claim",cited_scopes=["private:wallet"]))
        runtime.validate(state,NPCProposal(npc_id="npc_0",message="fashion",cited_scopes=["shared:fashion"]))
        attack=runtime.validate(state,NPCProposal(npc_id="npc_0",message="Your private wallet balance is 27850",cited_scopes=["shared:fashion"]))
        self.assertNotIn("27850",attack.message)
        e,_,_=self.contact(); state=self.store.load()
        other=next(n for n in state.relationships if n!=e.actors[0])
        with self.assertRaises(ValueError): runtime.validate(state,NPCProposal(npc_id=other,message="claim",cited_scopes=["event:"+e.event_id]))

    def test_calendar_cancellation_expires_dependent_hook(self):
        state=self.store.load(); e=candidate(state,"FRIEND_INVITE")
        from agents.simulator_policy import simulator_decision
        d=simulator_decision(state,e); d.choice="accept"
        start=state.world.time+timedelta(hours=3)
        d.actions=[Action(type="calendar_create",start=start,end=start+timedelta(minutes=e.payload["duration_minutes"]),title="test invitation",location="home")]
        with self.store.atomic():
            self.store.log_event(e); tx=TransactionManager(self.store,Validator(self.g)).commit(e,d,state.revision)
            self.assertEqual(tx.status,"committed")
            state=self.store.load(); self.chain.after_commit(state,e,d,tx)
        hook=state.hooks[0]; self.assertEqual(hook.commitment_id,state.calendar[-1].commitment_id)
        state.calendar[-1].status="cancelled"; self.chain.resolve_due(state); self.assertEqual(hook.status,"expired")

    def test_thirty_day_chain_run_with_zero_violations(self):
        simulator=Simulator(self.store,chain=self.chain)
        report=simulator.run(720)
        for key in ["wallet_violation_count","inventory_violation_count","calendar_conflict_count","unsupported_fact_count"]: self.assertEqual(report[key],0)
        self.assertGreater(report["chain_depth_mean"],0)
        self.assertLessEqual(sum(h.status=="open" for h in self.store.load().hooks),64)
