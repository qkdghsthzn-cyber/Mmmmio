"""Synthetic loopback OAuth/API oracle. No credentials are printed or persisted."""
import json
import socket
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import urlsplit, parse_qs


class OAuthHTTPFixture:
    def __init__(self, native=None):
        self.native = native; self.refresh_count = 0; self.api_count = 0; self.write_count = 0
        self.forms = []; self.token_authorizations = []; self.sent_tokens = []
        self.api_errors = []; self.api_requests = []; self.api_faults = {}; self.refresh_errors = []; self.response = {
            'access_token':'fixture.access.new','expires_in':3600,'token_type':'Bearer'}
        self.accepted_token = 'fixture.access.new'; self.before_refresh = None
        fixture = self
        class Handler(BaseHTTPRequestHandler):
            def log_message(self, *args): pass
            def do_GET(self): self.dispatch('GET')
            def do_POST(self): self.dispatch('POST')
            def do_PATCH(self): self.dispatch('PATCH')
            def do_DELETE(self): self.dispatch('DELETE')
            def dispatch(self, method):
                url = urlsplit(self.path); path = url.path
                raw = self.rfile.read(int(self.headers.get('Content-Length', 0)))
                if path == '/token':
                    fixture.refresh_count += 1
                    fixture.forms.append(parse_qs(raw.decode('ascii'), keep_blank_values=True))
                    fixture.token_authorizations.append(self.headers.get('Authorization'))
                    if fixture.before_refresh: fixture.before_refresh()
                    fault = fixture.refresh_errors.pop(0) if fixture.refresh_errors else None
                    if fault == 'disconnect': return self.disconnect()
                    if fault == 'redirect':
                        self.send_response(302); self.send_header('Location', fixture.url+'/redirect.target'); self.end_headers(); return
                    if fault is not None:
                        status, body = fault; return self.respond(status, body)
                    return self.respond(200, fixture.response)
                fixture.api_count += 1; fixture.sent_tokens.append(self.headers.get('Authorization'))
                fixture.api_requests.append({'method':method,'path':path})
                fault=fixture.api_faults.pop((method,path),None)
                if fault is not None: return self.respond(fault, {'error':'PRIVATE_ERROR_SENTINEL'})
                if fixture.api_errors:
                    fault = fixture.api_errors.pop(0)
                    if fault == 'disconnect': return self.disconnect()
                    if fault is not None: return self.respond(fault, {'error':'PRIVATE_ERROR_SENTINEL'})
                if self.headers.get('Authorization') != 'Bearer '+fixture.accepted_token:
                    return self.respond(401, {'error':'unauthorized'})
                body = json.loads(raw) if raw else None
                if method != 'GET': fixture.write_count += 1
                if fixture.native is not None:
                    status, result = fixture.native.route(method, path, parse_qs(url.query,keep_blank_values=True), body, self.headers)
                    return self.respond(status, result)
                return self.respond(200, {'status':'fixture success'})
            def disconnect(self):
                self.connection.shutdown(socket.SHUT_RDWR); self.connection.close(); self.close_connection=True
            def respond(self, status, body):
                raw = body if isinstance(body, bytes) else json.dumps(body).encode()
                self.send_response(status); self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', str(len(raw))); self.end_headers(); self.wfile.write(raw)
        self.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        self.url = 'http://127.0.0.1:'+str(self.server.server_port)
        self.thread = threading.Thread(target=lambda: self.server.serve_forever(poll_interval=.01), daemon=True)
        self.thread.start()

    def close(self):
        self.server.shutdown(); self.server.server_close(); self.thread.join(timeout=2)
