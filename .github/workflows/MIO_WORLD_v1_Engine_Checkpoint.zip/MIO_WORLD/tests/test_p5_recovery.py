import json
import sqlite3
import tempfile
import subprocess
import sys
import unittest
from copy import deepcopy
from datetime import timedelta
from pathlib import Path
from connectors.mock_native import fixture_purchase, seed_plan
from connectors.native_plans import purchase_plan, request_plan, plain, rich
from connectors.write_models import WritePlan, NativeOperation, digest, transaction_id
from connectors.write_coordinator import WriteCoordinator, WriteConflict
from connectors.fixture_adapter import NativeFixtureAdapter, SimulatedProcessDeath
from connectors.http_json import ConnectorUnavailable


class P5RecoveryTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(); self.root = Path(self.temp.name)
        self.evidence, self.proposal, self.now = fixture_purchase()
        self.plan = purchase_plan(self.evidence, self.proposal, "fixture.event", "fixture.decision", self.now)
        self.adapter = NativeFixtureAdapter(self.root/"provider.sqlite3")
        seed_plan(self.adapter, self.plan)
        self.coordinator = WriteCoordinator(self.root/"outbox.sqlite3", {"notion":self.adapter, "calendar":self.adapter})

    def tearDown(self):
        self.coordinator.close(); self.adapter.close(); self.temp.cleanup()

    def prepare(self):
        return self.coordinator.prepare(self.plan)

    def restart(self):
        self.coordinator.close(); self.adapter.close()
        self.adapter = NativeFixtureAdapter(self.root/"provider.sqlite3")
        self.coordinator = WriteCoordinator(self.root/"outbox.sqlite3", {"notion":self.adapter, "calendar":self.adapter})

    def assert_clean_rollback(self, tx):
        self.assertEqual(self.coordinator.status(tx), "ROLLED_BACK")
        self.assertIsNone(self.coordinator.committed(tx))
        self.assertTrue(self.coordinator.confirmations_allowed())
        for op in self.plan.operations:
            if op.kind == "block.patch":
                self.assertEqual(json.loads(self.adapter.get(op.target)["body"]), op.before)
        self.assertEqual(self.adapter.db.execute("SELECT COUNT(*) FROM native_resources WHERE marker IS NOT NULL AND archived=0 AND parent IS NOT NULL").fetchone()[0], 0)

    def test_durable_prepare_then_restart_commits_only_verified_receipts(self):
        tx = self.prepare()
        self.assertFalse(self.coordinator.confirmations_allowed("wallet", "inventory"))
        self.assertTrue(self.coordinator.confirmations_allowed("calendar"))
        self.assertIsNone(self.coordinator.committed(tx)); self.restart()
        self.assertEqual(self.coordinator.run(tx), "COMMITTED")
        row = self.coordinator.committed(tx)
        self.assertEqual(row["evidence_scope"], "fixture")
        self.assertEqual(len(json.loads(row["receipts"])), len(self.plan.operations))
        fields = json.loads(self.adapter.get("fixture.balance")["body"])
        self.assertEqual(plain(fields["bulleted_list_item"]["rich_text"]), "残高: ¥23,050")
        self.assertTrue(self.coordinator.confirmations_allowed())

    def test_real_process_exit_after_remote_write_releases_lock_and_preserves_outbox(self):
        tx = self.prepare()
        script = """
import os, sys
from pathlib import Path
from connectors.fixture_adapter import NativeFixtureAdapter
from connectors.write_coordinator import WriteCoordinator
root=Path(sys.argv[1]); adapter=NativeFixtureAdapter(root/'provider.sqlite3')
coordinator=WriteCoordinator(root/'outbox.sqlite3', {'notion':adapter})
original=adapter.apply
def apply(op):
    receipt=original(op)
    if op.operation_id=='inventory.create': os._exit(71)
    return receipt
adapter.apply=apply
coordinator.run(sys.argv[2])
"""
        process = subprocess.run([sys.executable, "-c", script, str(self.root), tx],
                                 cwd=Path(__file__).resolve().parents[1], timeout=20, capture_output=True, text=True)
        self.assertEqual(process.returncode, 71, process.stderr)
        self.assertIsNone(self.coordinator.committed(tx)); self.restart()
        self.assertEqual(self.coordinator.run(tx), "COMMITTED")
        self.assertEqual(self.adapter.calls("inventory.create"), 1)

    def test_local_commit_failure_does_not_publish_partial_receipts(self):
        tx = self.prepare(); original = self.coordinator.audit
        def audit(transaction, action, detail=""):
            if action == "COMMITTED": raise SimulatedProcessDeath("inside local commit")
            return original(transaction, action, detail)
        self.coordinator.audit = audit
        with self.assertRaises(SimulatedProcessDeath): self.coordinator.run(tx)
        self.assertIsNone(self.coordinator.committed(tx)); self.restart()
        self.assertEqual(self.coordinator.run(tx), "COMMITTED")
        self.assertTrue(all(self.adapter.calls(op.operation_id)==1 for op in self.plan.operations))

    def test_unavailable_read_freezes_without_sending_write(self):
        self.adapter.fault("wallet.balance", "observe", "lost"); tx = self.prepare()
        self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertEqual(self.adapter.calls("wallet.balance"), 0)
        self.assertFalse(self.coordinator.confirmations_allowed("wallet"))
        self.assertEqual(self.coordinator.reconcile(tx), "COMMITTED")

    def test_external_edit_during_compensation_remains_unresolved(self):
        self.adapter.fault("inventory.create", "before_apply", "refuse")
        original = self.adapter.compensate
        def compensate(op, receipt):
            if op.operation_id == "wallet.balance":
                self.adapter.edit(op.target, op.after)
            return original(op, receipt)
        self.adapter.compensate = compensate
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertIsNone(self.coordinator.committed(tx))
        self.assertFalse(self.coordinator.confirmations_allowed("wallet"))
        self.assertEqual(self.adapter.calls("wallet.balance", "undo"), 1)

    def test_only_proposals_with_no_sent_requests_can_be_cancelled(self):
        tx = self.prepare()
        self.assertEqual(self.coordinator.cancel_unwritten(tx), "ROLLED_BACK")
        self.assertTrue(self.coordinator.confirmations_allowed())
        self.assertEqual(self.adapter.calls("wallet.balance"), 0)

    def test_cancel_cannot_clear_unknown_non_idempotent_write(self):
        self.adapter.fault("money.log", "before_apply", "lost"); tx = self.prepare()
        self.coordinator.run(tx)
        with self.assertRaises(WriteConflict): self.coordinator.cancel_unwritten(tx)
        self.assertFalse(self.coordinator.confirmations_allowed("wallet"))

    def test_false_provider_receipt_cannot_publish_canonical_commit(self):
        from connectors.write_coordinator import Observation
        original = self.adapter.observe
        def observe(op, receipt=None, undo=False):
            observation = original(op, receipt, undo)
            if op.operation_id == "inventory.create" and observation.state == "AFTER":
                corrupt = dict(observation.receipt); corrupt["marker"] = "other transaction"
                return Observation("AFTER", corrupt)
            return observation
        self.adapter.observe = observe
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertIsNone(self.coordinator.committed(tx))
        self.assertFalse(self.coordinator.confirmations_allowed("inventory"))

    def test_same_event_replay_never_repeats_provider_writes(self):
        tx = self.prepare(); self.coordinator.run(tx); self.restart()
        self.assertEqual(self.prepare(), tx); self.assertEqual(self.coordinator.run(tx), "COMMITTED")
        self.assertTrue(all(self.adapter.calls(op.operation_id)==1 for op in self.plan.operations))
        self.assertEqual(self.coordinator.db.execute("SELECT COUNT(*) FROM canonical_commits").fetchone()[0], 1)

    def test_same_event_changed_plan_is_rejected(self):
        self.prepare()
        changed = self.plan.model_copy(update={"decision_id":"different"})
        with self.assertRaises(WriteConflict): self.coordinator.prepare(changed)

    def test_decision_cannot_be_reused_for_another_event(self):
        self.prepare()
        changed = purchase_plan(self.evidence, self.proposal, "other.event", "fixture.decision", self.now)
        with self.assertRaises(WriteConflict): self.coordinator.prepare(changed)

    def test_unresolved_resources_block_other_purchase(self):
        self.prepare()
        changed = purchase_plan(self.evidence, self.proposal, "other.event", "other.decision", self.now)
        with self.assertRaises(WriteConflict): self.coordinator.prepare(changed)

    def test_definitive_failure_at_every_position_compensates_all_prior_changes(self):
        for index, op in enumerate(self.plan.operations):
            with self.subTest(operation=op.operation_id):
                self.adapter.fault(op.operation_id, "before_apply", "refuse")
                tx = self.prepare()
                self.assertEqual(self.coordinator.run(tx), "ROLLED_BACK")
                self.assert_clean_rollback(tx)
                if index < len(self.plan.operations)-1:
                    self.coordinator.close(); self.adapter.close()
                    self.root = self.root / str(index); self.root.mkdir()
                    self.adapter = NativeFixtureAdapter(self.root/"provider.sqlite3"); seed_plan(self.adapter, self.plan)
                    self.coordinator = WriteCoordinator(self.root/"outbox.sqlite3", {"notion":self.adapter})

    def test_lost_success_response_reread_recovers_without_duplicate(self):
        self.adapter.fault("inventory.create", "after_apply", "lost")
        tx = self.prepare()
        self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertIsNone(self.coordinator.committed(tx)); self.restart()
        self.assertEqual(self.coordinator.reconcile(tx), "COMMITTED")
        self.assertEqual(self.adapter.calls("inventory.create"), 1)

    def test_non_idempotent_request_lost_before_apply_never_auto_resends(self):
        self.adapter.fault("inventory.create", "before_apply", "lost")
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.restart(); self.assertEqual(self.coordinator.reconcile(tx), "RECONCILE_REQUIRED")
        self.assertEqual(self.adapter.calls("inventory.create"), 1)
        self.assertFalse(self.coordinator.confirmations_allowed("wallet", "inventory"))
        self.assertIsNone(self.coordinator.committed(tx))

    def test_idempotent_patch_response_lost_before_apply_can_resume(self):
        self.adapter.fault("wallet.balance", "before_apply", "lost")
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.restart(); self.assertEqual(self.coordinator.reconcile(tx), "COMMITTED")
        self.assertEqual(self.adapter.calls("wallet.balance"), 2)
        fields = json.loads(self.adapter.get("fixture.balance")["body"])
        self.assertIn("23,050", plain(fields["bulleted_list_item"]["rich_text"]))

    def test_process_death_after_each_provider_write_resumes_without_duplicate(self):
        for index, op in enumerate(self.plan.operations):
            with self.subTest(operation=op.operation_id):
                self.adapter.fault(op.operation_id, "after_apply", "crash"); tx = self.prepare()
                with self.assertRaises(SimulatedProcessDeath): self.coordinator.run(tx)
                self.assertIsNone(self.coordinator.committed(tx)); self.restart()
                self.assertEqual(self.coordinator.run(tx), "COMMITTED")
                self.assertEqual(self.adapter.calls(op.operation_id), 1)
                if index < len(self.plan.operations)-1:
                    self.coordinator.close(); self.adapter.close()
                    self.root = self.root / str(index); self.root.mkdir()
                    self.adapter = NativeFixtureAdapter(self.root/"provider.sqlite3"); seed_plan(self.adapter, self.plan)
                    self.coordinator = WriteCoordinator(self.root/"outbox.sqlite3", {"notion":self.adapter})

    def test_process_death_before_non_idempotent_send_remains_uncertain(self):
        self.adapter.fault("money.log", "before_apply", "crash"); tx = self.prepare()
        with self.assertRaises(SimulatedProcessDeath): self.coordinator.run(tx)
        self.restart(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertEqual(self.adapter.calls("money.log"), 1)

    def test_external_version_conflict_prevents_first_write(self):
        tx = self.prepare()
        before = deepcopy(self.plan.operations[0].before)
        self.adapter.edit("fixture.balance", before)  # same fields, new version
        self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertEqual(self.adapter.calls("wallet.balance"), 0)
        self.assertIsNone(self.coordinator.committed(tx))

    def test_external_edit_after_partial_success_is_never_overwritten(self):
        self.adapter.fault("inventory.create", "after_apply", "lost"); tx = self.prepare()
        self.coordinator.run(tx)
        fields = deepcopy(self.plan.operations[0].after)
        fields["bulleted_list_item"]["rich_text"] = rich("残高: ¥99,000")
        self.adapter.edit("fixture.balance", fields)
        self.assertEqual(self.coordinator.reconcile(tx), "RECONCILE_REQUIRED")
        self.assertEqual(json.loads(self.adapter.get("fixture.balance")["body"]), fields)

    def test_compensation_failure_freezes_then_verified_recovery_rolls_back(self):
        self.adapter.fault("inventory.create", "before_apply", "refuse")
        self.adapter.fault("money.log", "before_undo", "lost")
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertFalse(self.coordinator.confirmations_allowed("wallet", "inventory")); self.restart()
        self.assertEqual(self.coordinator.reconcile(tx), "ROLLED_BACK"); self.assert_clean_rollback(tx)

    def test_compensation_lost_success_response_does_not_undo_twice(self):
        self.adapter.fault("inventory.create", "before_apply", "refuse")
        self.adapter.fault("money.log", "after_undo", "lost")
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.restart(); self.assertEqual(self.coordinator.reconcile(tx), "ROLLED_BACK")
        self.assertEqual(self.adapter.calls("money.log", "undo"), 1)

    def test_process_death_during_compensation_recovers(self):
        self.adapter.fault("inventory.create", "before_apply", "refuse")
        self.adapter.fault("money.log", "after_undo", "crash"); tx = self.prepare()
        with self.assertRaises(SimulatedProcessDeath): self.coordinator.run(tx)
        self.restart(); self.assertEqual(self.coordinator.run(tx), "ROLLED_BACK")
        self.assertEqual(self.adapter.calls("money.log", "undo"), 1)

    def test_final_reread_prevents_publishing_if_earlier_resource_changed(self):
        original = self.adapter.apply
        def apply(op):
            receipt = original(op)
            if op.operation_id == "continuity":
                self.adapter.edit("fixture.balance", self.plan.operations[0].after)
            return receipt
        self.adapter.apply = apply
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertIsNone(self.coordinator.committed(tx))

    def test_two_workers_are_serialized_without_erasing_durable_outbox(self):
        tx = self.prepare()
        second = WriteCoordinator(self.root/"outbox.sqlite3", {"notion":self.adapter})
        try:
            with self.coordinator.worker_lock():
                with self.assertRaises(WriteConflict): second.run(tx)
                with self.assertRaises(WriteConflict): second.reconcile(tx)
            self.assertEqual(second.run(tx), "COMMITTED")
        finally:
            second.close()

    def test_canonical_plan_and_real_adapter_cannot_bypass_gate(self):
        with self.assertRaises(ConnectorUnavailable):
            self.coordinator.prepare(self.plan.model_copy(update={"evidence_scope":"canonical"}))
        self.adapter.evidence_scope = "canonical"
        with self.assertRaises(ConnectorUnavailable): self.prepare()

    def test_resuming_with_real_adapter_is_also_blocked(self):
        tx = self.prepare(); self.adapter.evidence_scope = "canonical"
        with self.assertRaises(ConnectorUnavailable): self.coordinator.run(tx)
        self.assertIsNone(self.coordinator.committed(tx))

    def test_duplicate_creation_marker_is_not_accepted_as_success(self):
        tx = self.prepare(); self.adapter.fault("inventory.create", "after_apply", "lost")
        self.coordinator.run(tx)
        op = next(o for o in self.plan.operations if o.operation_id=="inventory.create")
        row = self.adapter.db.execute("SELECT * FROM native_resources WHERE marker=?", (op.marker,)).fetchone()
        self.adapter.db.execute("INSERT INTO native_resources VALUES(?,?,?,?,?,0)",
            ("duplicate", row["body"], row["version"], row["marker"], row["parent"]))
        self.assertEqual(self.coordinator.reconcile(tx), "RECONCILE_REQUIRED")

    def test_calendar_and_notion_share_one_verified_commit(self):
        tx = self.plan.transaction_id
        op = NativeOperation(operation_id="calendar", connector="calendar", kind="calendar.create",
             target="fixture.calendar", domain="calendar", after={"id":"mio"+digest(tx), "summary":"fixture only",
             "start":{"dateTime":self.now.isoformat()}, "end":{"dateTime":(self.now+timedelta(hours=1)).isoformat()},
             "extendedProperties":{"private":{"mio_transaction":tx, "mio_source_event":self.plan.event_id}}},
             replay_safe=True, marker=tx+":calendar")
        self.plan = self.plan.model_copy(update={"operations":self.plan.operations+[op]})
        seed_plan(self.adapter, self.plan); self.adapter.fault("calendar", "after_apply", "lost")
        tx = self.prepare(); self.assertEqual(self.coordinator.run(tx), "RECONCILE_REQUIRED")
        self.assertFalse(self.coordinator.confirmations_allowed("calendar"))
        self.restart(); self.assertEqual(self.coordinator.reconcile(tx), "COMMITTED")
        self.assertEqual(self.adapter.calls("calendar"), 1)
        self.assertNotIn("attendees", request_plan(op)["body"])


class P5NativePlanTests(unittest.TestCase):
    def setUp(self):
        self.evidence, self.proposal, self.now = fixture_purchase()

    def plan(self, evidence=None, proposal=None):
        return purchase_plan(evidence or self.evidence, proposal or self.proposal, "fixture.event", "fixture.decision", self.now)

    def test_native_structure_unknown_values_and_annotations_preserved(self):
        original = self.evidence.model_dump_json(); plan = self.plan()
        self.assertEqual(self.evidence.model_dump_json(), original)
        props = next(o for o in plan.operations if o.kind=="inventory.create").after["properties"]
        self.assertNotIn("Brand", props); self.assertNotIn("Condition", props); self.assertNotIn("Favorite", props)
        self.assertEqual(props["Purchase Price"]["number"], 4800)
        balance = plan.operations[0].after["bulleted_list_item"]["rich_text"]
        self.assertTrue(balance[0]["annotations"]["bold"])
        self.assertEqual(plain(balance), "残高: ¥23,050")
        wish = next(o for o in plan.operations if o.operation_id=="wishlist")
        self.assertEqual(plain(wish.after["table_row"]["cells"][5]).split(" [")[0], "confirmed fixture only")
        self.assertEqual(plain(wish.after["table_row"]["cells"][4]), "購入済み")
        for op in plan.operations:
            request = request_plan(op)
            self.assertTrue(request["dry_run"]); self.assertIn(plan.transaction_id, op.marker)

    def test_insufficient_money_and_reserved_balance_reject(self):
        with self.assertRaises(ValueError): self.plan(proposal=self.proposal.model_copy(update={"cost_jpy":30000}))
        with self.assertRaises(ValueError): self.plan(evidence=self.evidence.model_copy(update={"reserved_jpy":25000}))

    def test_stale_old_and_future_evidence_cannot_create_money_mutations(self):
        for changes in [{"notion_stale":True}, {"read_at":self.now-timedelta(minutes=6)}, {"read_at":self.now+timedelta(seconds=1)}]:
            with self.subTest(changes=changes), self.assertRaises(ValueError):
                self.plan(evidence=self.evidence.model_copy(update=changes))

    def test_unfamiliar_or_duplicate_wallet_fields_fail_closed(self):
        evidence = self.evidence.model_copy(deep=True)
        evidence.wallet["blocks"].append(deepcopy(evidence.wallet["blocks"][0]))
        with self.assertRaises(ValueError): self.plan(evidence=evidence)
        evidence = self.evidence.model_copy(deep=True)
        evidence.wallet["blocks"][0]["bulleted_list_item"]["rich_text"] = rich("残高: unknown")
        with self.assertRaises(ValueError): self.plan(evidence=evidence)

    def test_unknown_inventory_options_are_not_created(self):
        with self.assertRaises(ValueError): self.plan(proposal=self.proposal.model_copy(update={"category":"guessed"}))
        evidence = self.evidence.model_copy(deep=True)
        evidence.inventory_schema["properties"]["Purchase Price"]["type"] = "formula"
        with self.assertRaises(ValueError): self.plan(evidence=evidence)

    def test_wishlist_wrong_row_or_item_is_rejected(self):
        with self.assertRaises(ValueError): self.plan(proposal=self.proposal.model_copy(update={"wishlist_row_id":"wrong"}))
        with self.assertRaises(ValueError): self.plan(proposal=self.proposal.model_copy(update={"item_name":"wrong item"}))

    def test_future_or_backdated_month_purchase_requires_reconciliation(self):
        for date in [self.now+timedelta(seconds=1), self.now-timedelta(days=30)]:
            with self.subTest(date=date), self.assertRaises(ValueError):
                self.plan(proposal=self.proposal.model_copy(update={"acquired_at":date}))

    def test_native_calendar_operation_checks_times_ids_provenance_and_no_invites(self):
        from connectors.google_calendar import CalendarConnector
        from core.mock_state import mock_state
        class NoNetwork:
            def request(self, *args, **kwargs): raise AssertionError("plan must not use network")
        plan = self.plan()
        commitment = mock_state().calendar[0].model_copy(update={"source_event":plan.event_id})
        connector = CalendarConnector(calendar_id="fixture.calendar", http=NoNetwork())
        operation = connector.create_operation(commitment, plan.transaction_id)
        combined = plan.model_copy(update={"operations":plan.operations+[operation]})
        WritePlan.model_validate_json(combined.model_dump_json())
        self.assertEqual(operation.after["start"]["dateTime"], commitment.start.isoformat())
        for change in [{"attendees":[{"email":"must-not-send@example.invalid"}]},
                       {"end":operation.after["start"]}, {"id":"INVALID!"}]:
            body = deepcopy(operation.after); body.update(change)
            with self.subTest(change=change), self.assertRaises(ValueError):
                NativeOperation.model_validate(operation.model_dump() | {"after":body})
        body = deepcopy(operation.after); body["extendedProperties"]["private"]["mio_source_event"] = "other.event"
        invalid = operation.model_copy(update={"after":body})
        combined = combined.model_copy(update={"operations":plan.operations+[invalid]})
        with self.assertRaises(ValueError): WritePlan.model_validate_json(combined.model_dump_json())

    def test_existing_native_purchase_marker_requires_reconciliation(self):
        plan = self.plan(); operation = next(o for o in plan.operations if o.kind=="inventory.create")
        evidence = self.evidence.model_copy(update={"inventory_rows":[{"id":"confirmed.native", "properties":operation.after["properties"]}]})
        with self.assertRaises(ValueError): self.plan(evidence=evidence)

    def test_replay_safety_and_provenance_contracts_are_enforced(self):
        plan = self.plan()
        data = plan.model_dump(mode="json"); data["operations"][2]["replay_safe"] = True
        with self.assertRaises(ValueError): WritePlan.model_validate(data)
        data = plan.model_dump(mode="json"); data["operations"][0]["marker"] = "other_transaction"
        with self.assertRaises(ValueError): WritePlan.model_validate(data)
        data = plan.model_dump(mode="json"); data["operations"][0]["after"]["number"] = float("nan")
        with self.assertRaises(ValueError): WritePlan.model_validate(data)
