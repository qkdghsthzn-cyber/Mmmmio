import json
import tempfile
import unittest
from datetime import timedelta, timezone
from pathlib import Path
from core.mock_state import mock_state
from core.models import Action
from core.event_grammar import Grammar
from core.validator import Validator, RuleViolation
from connectors.http_json import HTTPJSON, ConnectorUnavailable
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.mock_native import fixture_purchase
from connectors.write_coordinator import WriteCoordinator, WriteConflict
from connectors.write_models import digest
from connectors.canonical_runtime import CanonicalCacheBridge, CanonicalValidator
from connectors.runtime_bootstrap import NativeBootstrapper, InitializationRequest, RuntimeResources
from connectors.calendar_truth import commitments, interval, UNKNOWN_PLACE
from runtime.hourly import NativeHourlyRuntime
from tests.native_http_server import NativeHTTPFixture
from tests.test_p2 import candidate
from agents.simulator_policy import simulator_decision


class FixtureAgent:
    def __init__(self): self.calls=[]; self.fail=False
    def decide(self,state,event):
        self.calls.append(event.event_id)
        if self.fail: raise TimeoutError('synthetic provider failure')
        return simulator_decision(state,event)


class P5HourlyTests(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(); self.path=Path(self.temp.name)/'runtime.sqlite3'
        self.native,_,self.now=fixture_purchase(); self.server=NativeHTTPFixture(self.native)
        for name in ['relationships','taste','memory','world']:
            key='fixture.'+name
            self.server.objects[key]={'object':'page','id':key,'last_edited_time':'v1','archived':False}
            self.server.children[key]=[]
        self.http=HTTPJSON(self.server.url,'fixture-only',fixture=True)
        self.notion=NotionConnector(http=self.http); self.calendar=CalendarConnector('fixture.calendar',http=self.http)
        self.grammar=Grammar(); self.agent=FixtureAgent(); self.connect()
        s=mock_state(); s.world.time=self.now
        item=s.catalog['catalog_0']; item.name='fixture skirt'; item.price=4800
        self.request=InitializationRequest(initialization_ref='fixture confirmed initial world',internal_values_ref='fixture explicit needs',
            world=s.world.model_dump(mode='json'),travel_minutes=s.travel_minutes,feature_flags={'adult_life':False},
            relationships={},npc_age_refs={},npc_metric_refs={},taste={},taste_metric_refs={},catalog={item.item_id:item})
        self.resources=RuntimeResources(wallet_page='fixture.wallet',inventory_source='fixture.inventory',continuity_page='fixture.continuity',
            relationships_page='fixture.relationships',taste_page='fixture.taste',memory_page='fixture.memory',
            world_runtime_page='fixture.world',calendar_id='fixture.calendar')
        self.bootstrap=NativeBootstrapper(self.notion,self.calendar,lambda:self.now)

    def connect(self):
        self.coordinator=WriteCoordinator(self.path,{'notion':NativeHTTPAdapter(self.notion),'calendar':NativeHTTPAdapter(self.calendar)})
        self.bridge=CanonicalCacheBridge(self.coordinator,CanonicalValidator(Validator(self.grammar),allow_internal=True))

    def tearDown(self): self.coordinator.close(); self.server.close(); self.temp.cleanup()
    def initialize(self): return self.bootstrap.initialize(self.bridge,self.request,self.resources)
    def runtime(self): return NativeHourlyRuntime(self.bridge,self.notion,self.calendar,lambda:self.bridge.state().world.time,self.agent)
    def one_event(self,runtime,family):
        runtime._selected=lambda state:[candidate(state,family)]
        def decide(state,event):
            self.agent.calls.append(event.event_id)
            if self.agent.fail: raise TimeoutError('fixture')
            decision=simulator_decision(state,event); decision.choice='accept'
            if not decision.actions:
                effect=self.grammar.families[event.family].effect
                if effect=='observe': decision.actions=[Action(type='observe')]
                elif effect=='purchase': decision.actions=[Action(type='purchase',item_id=event.payload['item_id'],amount=event.payload['cost'])]
                elif effect=='need': decision.actions=[Action(type='need_update',need=event.payload['need'],delta=event.payload['need_delta'])]
                elif effect=='contact': decision.actions=[Action(type='relationship_update',npc_id=event.actors[0],delta=1)]
                elif effect=='move': decision.actions=[Action(type='move',location=event.payload['location'])]
                elif effect=='cancel_calendar': decision.actions=[Action(type='calendar_cancel',commitment_id=event.payload['commitment_id'])]
                elif effect=='spend': decision.actions=[Action(type='spend',amount=event.payload['cost'])]
            return decision
        self.agent.decide=decide

    def test_bootstrap_native_money_empty_inventory_and_raw_sources(self):
        state=self.initialize()
        self.assertEqual(state.wallet.balance,27850); self.assertEqual(state.inventory,{})
        self.assertEqual(state.relationships,{}); self.assertEqual(state.taste,{})
        self.assertEqual(state.wallet.reserved_amount,0); self.assertEqual(state.wallet.ledger,[])
        self.assertIn('fixture.wish.row',state.wishlist)
        proof=json.loads(self.bridge.db.execute('SELECT body FROM runtime_initialization').fetchone()[0])
        self.assertEqual(set(proof['pages']),{'wallet','continuity','relationships','taste','memory','world'})
        self.assertTrue(proof['unmapped_qualitative_sources_preserved'])
        self.assertEqual([c for c in self.server.calls if c['method'] in {'PATCH','DELETE'}],[])

    def test_missing_initial_fields_and_npc_metric_references_are_rejected(self):
        data=self.request.model_dump(mode='json'); del data['world']['place']
        with self.assertRaises(ValueError): InitializationRequest.model_validate(data)
        data=self.request.model_dump(mode='json'); del data['world']['needs']['hunger']
        with self.assertRaises(ValueError): InitializationRequest.model_validate(data)
        data=self.request.model_dump(mode='json'); data['relationships']=mock_state().model_dump(mode='json')['relationships']
        with self.assertRaises(ValueError): InitializationRequest.model_validate(data)

    def test_separate_runtime_page_required(self):
        for field in ['wallet_page','continuity_page','relationships_page','taste_page']:
            data=self.resources.model_dump(); data['world_runtime_page']=data[field]
            with self.subTest(field=field),self.assertRaises(ValueError): RuntimeResources.model_validate(data)

    def test_failed_bootstrap_leaves_no_partial_cache(self):
        self.server.fault('GET','/pages/fixture.taste',503)
        with self.assertRaises(ConnectorUnavailable): self.initialize()
        self.assertIsNone(self.bridge.db.execute('SELECT body FROM runtime_cache').fetchone())

    def test_reseed_rejected(self):
        self.initialize()
        with self.assertRaises(RuleViolation): self.initialize()
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_inventory_unknowns_and_date_only_do_not_become_invented_values(self):
        row={'id':'native.owned','last_edited_time':'v1','properties':{'Item':{'title':[{'type':'text','text':{'content':'Native item'}}]},
             'Status':{'select':{'name':'Owned'}},'Acquired':{'date':{'start':'2026-10-05'}}}}
        self.server.objects[row['id']]=row; self.server.children['fixture.inventory'].append(row['id'])
        item=self.initialize().inventory[row['id']]
        for name in ['price','brand','acquired_at','location','condition']: self.assertIsNone(getattr(item,name))
        self.assertEqual(item.category,'unknown'); self.assertEqual(item.provenance.source,'mock')

    def test_all_day_mapping_uses_timezone_exclusive_end_and_unknown_place(self):
        self.server.objects['day']={'id':'day','kind':'calendar#event','etag':'e1','status':'confirmed',
            'start':{'date':'2026-10-06'},'end':{'date':'2026-10-07'},'summary':'Busy all day'}
        c=self.initialize().calendar[0]
        self.assertEqual(c.start.hour,0); self.assertEqual(c.start.utcoffset(),timedelta(hours=9))
        self.assertEqual(c.end.date().isoformat(),'2026-10-07'); self.assertEqual(c.location,UNKNOWN_PLACE)
        runtime=self.runtime(); runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().world.place,self.request.world.place)

    def test_all_day_dst_span_and_cancelled_rows(self):
        row={'id':'dst','start':{'date':'2026-11-01'},'end':{'date':'2026-11-02'}}
        start,end=interval(row,'America/New_York')
        self.assertEqual((end.astimezone(timezone.utc)-start.astimezone(timezone.utc)).total_seconds(),25*3600)
        with self.assertRaises(RuleViolation): interval(row)
        self.assertEqual(commitments([{**row,'status':'cancelled'}],self.now,'fixture'),[])

    def test_empty_hour_no_llm_and_native_world_snapshot(self):
        self.initialize(); runtime=self.runtime(); runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(self.agent.calls,[]); self.assertEqual(len(self.server.children['fixture.world']),4)
        block=self.server.objects[self.server.children['fixture.world'][-1]]
        self.assertIn('world_snapshot',''.join(x['text']['content'] for x in block['code']['rich_text']))
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=1))

    def test_duplicate_and_wrong_cadence_never_repeat_physics(self):
        self.initialize(); runtime=self.runtime(); runtime._selected=lambda state:[]
        runtime.tick(self.now); state=self.bridge.state(); calls=len(self.server.calls)
        self.assertEqual(runtime.tick(self.now)['status'],'ALREADY_COMPLETED')
        self.assertEqual(self.bridge.state(),state); self.assertEqual(len(self.server.calls),calls)
        with self.assertRaises(RuleViolation): runtime.tick(self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state(),state)

    def test_exclusive_scheduler_worker_lock(self):
        self.initialize(); runtime=self.runtime()
        with runtime.scheduler_lock():
            with self.assertRaises(WriteConflict): runtime.tick(self.now)
        self.assertEqual(self.bridge.db.execute('SELECT count(*) FROM hourly_ticks').fetchone()[0],0)

    def test_llm_failure_skips_only_event_and_later_hour_runs(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK'); self.agent.fail=True
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual([r[0] for r in self.bridge.db.execute('SELECT status FROM hourly_decisions')],['SKIPPED','SKIPPED'])
        self.assertEqual(self.bridge.state().wallet.balance,27850)

    def test_internal_observation_native_continuity_taste_then_consequences(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertTrue(self.server.children['fixture.continuity']); self.assertTrue(self.server.children['fixture.taste'])
        state=self.bridge.state(); self.assertEqual(state.wallet.balance,27850)
        self.assertTrue(state.world.activity.startswith('consider:')); self.assertEqual(len(state.novelty_memory),1)
        self.assertTrue(self.bridge.db.execute('SELECT 1 FROM runtime_continuity_archive').fetchone())
        self.assertEqual(self.bridge.db.execute('SELECT status FROM hourly_decisions').fetchone()[0],'COMMITTED')

    def test_need_delta_is_rule_bound_and_native_backed(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'COOK_MEAL')
        before=self.bridge.state().world.needs.hunger
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertLess(self.bridge.state().world.needs.hunger,before)

    def test_purchase_native_id_and_hook_binding(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'PURCHASE_ITEM')
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        state=self.bridge.state(); self.assertEqual(state.wallet.balance,23050); self.assertEqual(len(state.inventory),1)
        identifier=next(iter(state.inventory)); self.assertNotEqual(identifier,'catalog_0')
        for hook in state.hooks:
            if hook.object_id: self.assertEqual(hook.object_id,identifier)
        self.assertEqual(self.bridge.db.execute('SELECT count(*) FROM canonical_commits').fetchone()[0],2)

    def test_lost_append_recovers_same_tick_without_second_decision(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        self.server.fault('PATCH','/blocks/fixture.continuity/children','after_disconnect')
        self.assertEqual(runtime.tick(self.now)['status'],'BLOCKED_RECOVERY')
        self.assertEqual(self.bridge.state().world.activity,self.request.world.activity)
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(len(self.agent.calls),1); self.assertEqual(len(self.server.children['fixture.continuity']),1)
        self.assertEqual(len(self.bridge.state().novelty_memory),1)

    def test_restart_after_native_commit_without_repeating_decision(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        def crash(tx,on_publish=None): raise KeyboardInterrupt('synthetic stop after native commit')
        self.bridge.publish=crash
        with self.assertRaises(KeyboardInterrupt): runtime.tick(self.now)
        self.coordinator.close(); self.connect(); runtime=self.runtime()
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(len(self.agent.calls),1); self.assertEqual(len(self.server.children['fixture.continuity']),1)
        self.assertEqual(len(self.bridge.state().novelty_memory),1)

    def test_interrupted_decision_skips_without_provider_retry(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        def stop(state,event): self.agent.calls.append(event.event_id); raise KeyboardInterrupt('synthetic stop')
        self.agent.decide=stop
        with self.assertRaises(KeyboardInterrupt): runtime.tick(self.now)
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED'); self.assertEqual(len(self.agent.calls),1)
        self.assertEqual(self.bridge.db.execute('SELECT status FROM hourly_decisions').fetchone()[0],'SKIPPED')

    def test_notion_read_outage_preserves_clock_and_wallet(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        self.server.fault('GET','/pages/fixture.wallet',503)
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().wallet.balance,27850)
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')

    def test_deferred_snapshot_recovery_does_not_rewind_world(self):
        self.initialize(); runtime=self.runtime(); runtime._selected=lambda state:[]
        self.server.fault('PATCH','/blocks/fixture.world/children','after_disconnect')
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED_DEFERRED')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().world.time,self.now+timedelta(hours=1))
        self.assertEqual([r[0] for r in self.bridge.db.execute('SELECT status FROM hourly_snapshots')],['VERIFIED','VERIFIED'])
        self.assertEqual(len(self.server.children['fixture.world']),4)

    def test_external_calendar_refresh_does_not_assert_attendance(self):
        self.initialize(); self.server.objects['outside']={'id':'outside','kind':'calendar#event','etag':'e1',
            'summary':'plan, not attendance','start':{'dateTime':self.now.isoformat()},
            'end':{'dateTime':(self.now+timedelta(hours=1)).isoformat()},'location':'school','status':'confirmed'}
        runtime=self.runtime(); runtime._selected=lambda state:[]
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().calendar[0].commitment_id,'outside')
        self.assertEqual(self.bridge.state().world.place,'home')

    def test_production_runtime_gate_and_initialization_integrity(self):
        self.initialize(); proof=json.loads(self.bridge.db.execute('SELECT body FROM runtime_initialization').fetchone()[0])
        proof['scope']='canonical'
        self.bridge.db.execute('UPDATE runtime_initialization SET body=?,proof_hash=?',(json.dumps(proof),digest(proof)))
        with self.assertRaises(ConnectorUnavailable): self.runtime()
        self.bridge.db.execute("UPDATE runtime_initialization SET proof_hash='changed'")
        with self.assertRaises(RuleViolation): self.runtime()

    def test_world_realization_happens_before_event_log_and_failure_skips_only_candidate(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        def selected(state):
            event=candidate(state,'BUDGET_CHECK'); event.cause='fixture.previous.confirmed'
            return [event]
        runtime._selected=selected
        test=self
        class Realizer:
            def realize(self,event,known):
                test.assertIsNone(test.bridge.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(event.event_id,)).fetchone())
                raise TimeoutError('fixture realization')
        runtime.realizer=Realizer()
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED'); self.assertEqual(self.agent.calls,[])
        self.assertEqual(self.bridge.db.execute('SELECT status FROM hourly_realizations').fetchone()[0],'SKIPPED')

    def test_world_realization_cannot_introduce_unknown_entity(self):
        from agents.world_llm import Realization
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'BUDGET_CHECK')
        def selected(state):
            event=candidate(state,'BUDGET_CHECK'); event.cause='fixture.previous.confirmed'; return [event]
        runtime._selected=selected
        class Realizer:
            def realize(self,event,known): return Realization(event_id=event.event_id,no_event=False,summary='fixture',referenced_entities=['invented-npc'])
        runtime.realizer=Realizer()
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED'); self.assertEqual(self.agent.calls,[])

    def test_relationship_delta_uses_explicit_initial_metrics_and_native_page(self):
        data=self.request.model_dump(mode='json'); npc=next(iter(mock_state().relationships.values()))
        data['relationships']={npc.npc_id:npc.model_dump(mode='json')}
        data['npc_age_refs']={npc.npc_id:'fixture declared age'}; data['npc_metric_refs']={npc.npc_id:'fixture explicitly seeded metrics'}
        self.request=InitializationRequest.model_validate(data); self.initialize()
        runtime=self.runtime(); self.one_event(runtime,'FRIEND_CONTACT')
        before=self.bridge.state().relationships[npc.npc_id].closeness
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().relationships[npc.npc_id].closeness,before+1)
        self.assertTrue(self.server.children['fixture.relationships'])

    def test_general_expense_commits_native_ledger_without_acquisition(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'SMALL_EXPENSE')
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().wallet.balance,27600)
        self.assertEqual(self.bridge.state().inventory,{})
        self.assertEqual(self.bridge.db.execute('SELECT status FROM hourly_decisions').fetchone()[0],'COMMITTED')
        self.assertEqual(len(self.server.children['fixture.moneylog']),2)

    def test_hourly_imports_external_ledger_before_current_decision(self):
        self.initialize(); runtime=self.runtime()
        from connectors.native_plans import rich,money_field
        key='external.expense'
        self.server.objects[key]={'object':'block','id':key,'type':'table_row','last_edited_time':'external-v1',
            'parent':{'type':'block_id','block_id':'fixture.moneylog'},'table_row':{'cells':[rich(c) for c in
                [self.now.date().isoformat(),'EXPENSE','external native cause','-¥500','¥27,350']]}}
        self.server.children['fixture.moneylog'].append(key)
        for identifier,label,value in [('fixture.balance','残高:',27350),('fixture.monthly','今月の支出:',500)]:
            self.server.edit(identifier,money_field(self.server.objects[identifier],label,value)[1])
        self.one_event(runtime,'SMALL_EXPENSE')
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        state=self.bridge.state(); self.assertEqual(state.wallet.balance,27100)
        self.assertEqual([e.amount for e in state.wallet.ledger],[-500,-250])
        self.assertFalse(state.notion_stale); self.assertEqual(state.inventory,{})

    def test_hourly_creates_then_cancels_its_native_calendar_event(self):
        self.initialize(); runtime=self.runtime(); self.one_event(runtime,'CALENDAR_OPEN_SLOT')
        original_decide=self.agent.decide
        def decide(state,event):
            result=original_decide(state,event)
            result.actions[0].start=state.world.time+timedelta(hours=3)
            result.actions[0].end=result.actions[0].start+timedelta(minutes=event.payload['duration_minutes'])
            return result
        self.agent.decide=decide
        self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        identifier=self.bridge.state().calendar[-1].commitment_id
        self.one_event(runtime,'APPOINTMENT_CANCEL')
        self.assertEqual(runtime.tick(self.now+timedelta(hours=1))['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().calendar[-1].status,'cancelled')
        self.assertEqual(self.server.objects[identifier]['status'],'cancelled')
        self.assertEqual(self.bridge.db.execute("SELECT COUNT(*) FROM hourly_decisions WHERE status='COMMITTED'").fetchone()[0],2)

    def test_dst_repeated_hour_has_unique_tick_id_and_one_hour_of_need_change(self):
        from datetime import datetime
        from zoneinfo import ZoneInfo
        self.now=datetime(2026,11,1,1,0,tzinfo=ZoneInfo('America/New_York'),fold=0)
        data=self.request.model_dump(mode='json'); data['world']['time']=self.now.isoformat(); data['world']['timezone']='America/New_York'
        self.request=InitializationRequest.model_validate(data); self.initialize()
        runtime=self.runtime(); runtime._selected=lambda state:[]
        runtime.tick(self.now); hunger=self.bridge.state().world.needs.hunger
        second=self.now.astimezone(timezone.utc)+timedelta(hours=1)
        self.assertEqual(runtime.tick(second)['status'],'COMPLETED')
        self.assertEqual(self.bridge.state().world.needs.hunger,hunger+5)
        self.assertEqual(self.bridge.db.execute('SELECT count(distinct tick_id) FROM hourly_ticks').fetchone()[0],2)

    def test_actual_process_death_after_native_commit_recovers_without_extra_request(self):
        import subprocess,sys,os
        self.initialize()
        script=Path(self.temp.name)/'worker.py'
        script.write_text('''import sys,os
from core.event_grammar import Grammar
from core.validator import Validator
from connectors.http_json import HTTPJSON
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.write_coordinator import WriteCoordinator
from connectors.canonical_runtime import CanonicalCacheBridge,CanonicalValidator
from runtime.hourly import NativeHourlyRuntime
from core.models import Decision,Action
from tests.test_p2 import candidate
h=HTTPJSON(sys.argv[2],'synthetic-fixture-only',fixture=True)
n=NotionConnector(http=h); c=CalendarConnector('fixture.calendar',http=h)
w=WriteCoordinator(sys.argv[1],{'notion':NativeHTTPAdapter(n),'calendar':NativeHTTPAdapter(c)})
b=CanonicalCacheBridge(w,CanonicalValidator(Validator(Grammar()),allow_internal=True))
class Agent:
 def decide(self,state,event): return Decision(decision_id='dec_'+event.event_id,event_id=event.event_id,choice='accept',reason_tags=['fixture'],actions=[Action(type='observe')])
r=NativeHourlyRuntime(b,n,c,lambda:b.state().world.time,Agent())
r._selected=lambda state:[candidate(state,'BUDGET_CHECK')]
def die(tx,on_publish=None): os._exit(71)
b.publish=die
r.tick(b.state().world.time)
''')
        root=Path(__file__).resolve().parents[1]
        env={**os.environ,'PYTHONPATH':str(root)}
        result=subprocess.run([sys.executable,str(script),str(self.path),self.server.url],env=env,capture_output=True,timeout=15)
        self.assertEqual(result.returncode,71,result.stderr.decode())
        runtime=self.runtime(); self.assertEqual(runtime.tick(self.now)['status'],'COMPLETED')
        self.assertEqual(self.agent.calls,[]); self.assertEqual(len(self.server.children['fixture.continuity']),1)
        self.assertEqual(len(self.bridge.state().novelty_memory),1)
