import json
import unittest
import tempfile
from pathlib import Path
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from unittest.mock import patch
from connectors.database_recovery import DatabaseRecoveryVault, RecoveryUnavailable
from connectors.http_json import ConnectorUnavailable
from core.validator import RuleViolation
from runtime.host_resume import pending, resume_after_delay, revalidate_host_resume
from tests import test_p5_hourly as support
from tests import test_p5_clock as clock_support
from tests.test_p2 import candidate


class P5HostResumeTests(unittest.TestCase):
    setUp = support.P5HourlyTests.setUp
    tearDown = support.P5HourlyTests.tearDown
    connect = support.P5HourlyTests.connect
    initialize = support.P5HourlyTests.initialize
    runtime = support.P5HourlyTests.runtime
    one_event = support.P5HourlyTests.one_event
    block = clock_support.P5ClockTests.block
    late_response = clock_support.P5ClockTests.late_response

    def seed(self):
        self.initialize(); runtime = self.runtime(); runtime._selected = lambda state: []
        runtime.tick(self.now)
        return runtime

    def test_gap_is_clock_only_without_historical_writes_or_decisions(self):
        runtime = self.seed(); before = self.bridge.state(); calls = len(self.server.calls)
        wall = self.now + timedelta(hours=3, minutes=37)
        report = resume_after_delay(runtime, wall)
        self.assertEqual(report['processed_hours'], 3)
        self.assertEqual(report['status'], 'AWAITING_FRESH_NATIVE')
        self.assertEqual(self.bridge.state().world.time, self.now + timedelta(hours=3))
        self.assertEqual(self.bridge.state().world.needs.hunger, before.world.needs.hunger + 15)
        self.assertEqual(self.bridge.state().wallet, before.wallet)
        self.assertEqual(self.bridge.state().world.place, before.world.place)
        self.assertEqual(len(self.server.calls), calls); self.assertEqual(self.agent.calls, [])
        self.assertEqual(self.bridge.db.execute("SELECT COUNT(*) FROM hourly_ticks WHERE stage='RECOVERED'").fetchone()[0], 3)
        self.assertTrue(pending(runtime.db)); self.assertFalse(self.bridge.confirmations_allowed())
        with self.assertRaises(ConnectorUnavailable): self.bridge.confirmed_state()
        with self.assertRaises(RecoveryUnavailable): runtime.tick(self.now + timedelta(hours=4))
        with self.assertRaises(RecoveryUnavailable): self.coordinator.prepare(None)

    def test_fresh_read_unlocks_and_next_hour_runs(self):
        runtime = self.seed(); wall = self.now + timedelta(hours=2, minutes=37)
        resume_after_delay(runtime, wall)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        self.assertFalse(pending(runtime.db)); self.assertTrue(self.bridge.confirmations_allowed())
        self.assertEqual(runtime.tick(self.now + timedelta(hours=3))['status'], 'COMPLETED')
        self.assertEqual(self.agent.calls, [])

    def test_initial_unstarted_hour_is_retired_without_fabrication(self):
        self.initialize(); runtime = self.runtime()
        result = resume_after_delay(runtime, self.now + timedelta(hours=2))
        self.assertEqual(result['processed_hours'], 3)
        self.assertEqual(runtime.db.execute('SELECT COUNT(*) FROM hourly_ticks').fetchone()[0], 3)
        self.assertEqual(runtime.db.execute("SELECT COUNT(*) FROM hourly_mutations WHERE kind='host_suspended_clock_only'").fetchone()[0], 2)
        self.assertEqual(self.server.children['fixture.world'], [])
        self.assertEqual(self.agent.calls, [])

    def test_bounded_batches_and_replays_never_duplicate_clock(self):
        runtime = self.seed(); wall = self.now + timedelta(hours=48, minutes=17)
        self.assertEqual(resume_after_delay(runtime, wall)['remaining_hours'], 24)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'MORE_CLOCK_CATCHUP_REQUIRED')
        self.assertEqual(resume_after_delay(runtime, wall)['processed_hours'], 24)
        before = self.bridge.state(); count = runtime.db.execute("SELECT COUNT(*) FROM hourly_ticks WHERE stage='RECOVERED'").fetchone()[0]
        self.assertEqual(resume_after_delay(runtime, wall)['status'], 'NO_MISSED_HOURS')
        self.assertEqual(self.bridge.state(), before); self.assertEqual(count, 48)
        self.assertTrue(pending(runtime.db))

    def test_restart_keeps_gate_and_clock(self):
        runtime = self.seed(); wall = self.now + timedelta(hours=3, minutes=10)
        resume_after_delay(runtime, wall, max_hours=1)
        self.coordinator.close(); self.connect(); runtime = self.runtime()
        with self.assertRaises(RecoveryUnavailable): runtime.tick(self.now + timedelta(hours=2))
        self.assertEqual(resume_after_delay(runtime, wall)['processed_hours'], 2)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        self.assertEqual(runtime.db.execute("SELECT COUNT(*) FROM hourly_ticks WHERE stage='RECOVERED'").fetchone()[0], 3)

    def test_pending_payment_recovers_once_without_resending_decision(self):
        runtime = self.block(); wall = self.now + timedelta(hours=5, minutes=37)
        calls = len(self.agent.calls)
        resume_after_delay(runtime, wall)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'WAITING_NATIVE_RECOVERY')
        self.assertEqual(self.bridge.state().wallet.balance, 27850)
        self.late_response()
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        self.assertEqual(self.bridge.state().wallet.balance, 27600)
        self.assertEqual(len(self.bridge.state().wallet.ledger), 1)
        self.assertEqual(self.bridge.state().world.time, self.now + timedelta(hours=5))
        self.assertEqual(len(self.agent.calls), calls)
        state = self.bridge.state()
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'ALREADY_VERIFIED')
        self.assertEqual(self.bridge.state(), state)
        attempts = [c for c in self.server.calls if c['method'] == 'PATCH' and c['path'] == '/blocks/fixture.continuity/children']
        self.assertEqual(len(attempts), 1)

    def test_unprepared_calling_proposal_is_skipped_without_agent(self):
        runtime = self.seed(); event = candidate(self.bridge.state(), 'COOK_MEAL')
        with self.coordinator.atomic():
            runtime.db.execute("UPDATE hourly_ticks SET stage='REALIZE',events=?", (json.dumps([event.model_dump(mode='json')]),))
            runtime.db.execute("INSERT INTO hourly_decisions VALUES(?,NULL,'CALLING','')", (event.event_id,))
        resume_after_delay(runtime, self.now + timedelta(hours=2))
        row = runtime.db.execute('SELECT status,reason FROM hourly_decisions WHERE event_id=?', (event.event_id,)).fetchone()
        self.assertEqual(tuple(row), ('SKIPPED','host_suspended_no_historical_action'))
        self.assertEqual(self.agent.calls, [])
        self.assertEqual(self.bridge.state().wallet.balance, 27850)

    def test_failed_notion_read_keeps_gate_then_retry_verifies(self):
        runtime = self.seed(); wall = self.now + timedelta(hours=1, minutes=20)
        resume_after_delay(runtime, wall); self.server.fault('GET', '/pages/fixture.wallet', 503)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'WAITING_FRESH_NATIVE_READ')
        self.assertTrue(pending(runtime.db)); self.assertFalse(self.bridge.confirmations_allowed())
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')

    def test_calendar_read_failure_keeps_gate(self):
        runtime = self.seed(); wall = self.now + timedelta(hours=1)
        resume_after_delay(runtime, wall)
        with patch.object(self.calendar, 'events', side_effect=ConnectorUnavailable('fixture')):
            self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'WAITING_FRESH_NATIVE_READ')
        self.assertTrue(pending(runtime.db))
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')

    def test_new_calendar_truth_is_refreshed_before_unlock(self):
        runtime = self.seed(); wall = self.now + timedelta(hours=1, minutes=20)
        resume_after_delay(runtime, wall)
        self.server.objects['new.event'] = {'id':'new.event','kind':'calendar#event','etag':'e1','status':'confirmed',
            'start':{'dateTime':(wall+timedelta(hours=2)).isoformat()}, 'end':{'dateTime':(wall+timedelta(hours=3)).isoformat()},
            'summary':'Native appointment', 'location':'cafe'}
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        self.assertIn('new.event', [c.commitment_id for c in self.bridge.state().calendar])
        self.assertEqual(self.bridge.state().world.place, self.request.world.place)

    def test_invalid_clock_and_budget_do_not_mutate_or_read(self):
        runtime = self.seed(); before = self.bridge.state(); calls = len(self.server.calls)
        for time in [self.now-timedelta(seconds=1), self.now.replace(tzinfo=None)]:
            with self.assertRaises(ValueError): resume_after_delay(runtime, time)
        for budget in [0,25,True,1.2]:
            with self.assertRaises(ValueError): resume_after_delay(runtime, self.now+timedelta(hours=2), budget)
        self.assertEqual(self.bridge.state(), before); self.assertEqual(len(self.server.calls), calls)
        self.assertFalse(pending(runtime.db))

    def test_unchanged_short_gap_does_not_freeze_running_host(self):
        runtime = self.seed(); before = self.bridge.state()
        self.assertEqual(resume_after_delay(runtime, self.now+timedelta(minutes=10))['status'], 'NO_MISSED_HOURS')
        self.assertEqual(self.bridge.state(), before); self.assertFalse(pending(runtime.db))

    def test_failed_clock_record_rolls_back_hour_and_can_resume(self):
        runtime = self.seed(); before = self.bridge.state(); wall = self.now+timedelta(hours=2)
        with patch('runtime.host_resume.record', side_effect=RuntimeError('synthetic crash')):
            with self.assertRaises(RuntimeError): resume_after_delay(runtime, wall)
        self.assertEqual(self.bridge.state(), before); self.assertTrue(pending(runtime.db))
        self.assertEqual(runtime.db.execute('SELECT COUNT(*) FROM cache_clock_steps').fetchone()[0], 0)
        self.assertEqual(resume_after_delay(runtime, wall)['processed_hours'], 2)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')

    def test_dst_repeated_hour_uses_utc_grid(self):
        self.now = datetime(2026,11,1,1,0,tzinfo=ZoneInfo('America/New_York'),fold=0)
        data = self.request.model_dump(mode='json'); data['world']['time'] = self.now.isoformat(); data['world']['timezone'] = 'America/New_York'
        self.request = type(self.request).model_validate(data)
        runtime = self.seed()
        wall = (self.now.astimezone(timezone.utc)+timedelta(hours=2,minutes=20)).astimezone(ZoneInfo('America/New_York'))
        result = resume_after_delay(runtime, wall)
        self.assertEqual(result['processed_hours'], 2)
        self.assertEqual(self.bridge.state().world.time.astimezone(timezone.utc), self.now.astimezone(timezone.utc)+timedelta(hours=2))
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')

    def test_vault_checkpoints_gate_and_catchup_without_dirty_gap(self):
        runtime = self.seed(); offsite = tempfile.TemporaryDirectory(); self.addCleanup(offsite.cleanup); root = Path(offsite.name)
        vault = DatabaseRecoveryVault(root/'images',root/'witness/head.json',b'fixture-disaster-signing-key-0000','fixture.world.recovery')
        self.coordinator.enable_recovery(vault)
        wall = self.now+timedelta(hours=2,minutes=20)
        resume_after_delay(runtime, wall)
        vault.ensure_clean(runtime.db)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        vault.ensure_clean(runtime.db)


    def test_unexplained_native_balance_never_unlocks(self):
        from connectors.native_plans import money_field
        runtime = self.seed(); wall = self.now+timedelta(hours=2,minutes=20)
        resume_after_delay(runtime, wall)
        self.server.edit('fixture.balance', money_field(self.server.objects['fixture.balance'],'残高:',99000)[1])
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'WAITING_FRESH_NATIVE_READ')
        self.assertEqual(self.bridge.state().wallet.balance, 27850)
        self.assertTrue(pending(runtime.db)); self.assertFalse(self.bridge.confirmations_allowed('wallet'))

    def test_late_external_ledger_uses_fresh_wall_observation_not_missed_hour(self):
        from tests.test_p5_effects import P5EffectsTests
        from connectors.native_rebase import NativeCacheReconciler
        runtime = self.seed(); wall = self.now+timedelta(hours=2,minutes=37)
        resume_after_delay(runtime, wall)
        P5EffectsTests.add_external(self, -250,27600,250)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        entry = self.bridge.state().wallet.ledger[-1]
        self.assertEqual(entry.amount, -250)
        proof = json.loads(runtime.db.execute('SELECT body FROM native_rebase_journal ORDER BY rowid DESC LIMIT 1').fetchone()[0])
        self.assertEqual(proof['observed_at'], wall.isoformat())
        self.assertEqual(self.bridge.state().world.time, self.now+timedelta(hours=2))
        self.assertEqual(len(self.bridge.state().wallet.ledger), 1)

    def test_wall_month_crossing_waits_for_logical_hour_boundary(self):
        self.now = datetime(2026,10,31,23,45,tzinfo=ZoneInfo('Asia/Tokyo'))
        data = self.request.model_dump(mode='json'); data['world']['time'] = self.now.isoformat()
        self.request = type(self.request).model_validate(data)
        runtime = self.seed(); wall = self.now+timedelta(minutes=20)
        # A persisted interrupted tick creates the gate even within one hour.
        with self.coordinator.atomic(): runtime.db.execute("UPDATE hourly_ticks SET stage='REALIZE'")
        resume_after_delay(runtime, wall)
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'WAITING_LOGICAL_MONTH_BOUNDARY')
        self.assertTrue(pending(runtime.db))
        from tests.test_p5_month import period
        from connectors.native_plans import money_field
        wall = self.now+timedelta(hours=1,minutes=20)
        resume_after_delay(runtime, wall)
        period(self.server, '2026-11')
        self.server.edit('fixture.monthly',money_field(self.server.objects['fixture.monthly'],'今月の支出:',0)[1])
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')

    def test_retirement_restart_cleans_calling_realization_after_terminal_save(self):
        runtime = self.seed(); event = candidate(self.bridge.state(), 'COOK_MEAL')
        runtime.bridge.log_event(event)
        with self.coordinator.atomic():
            runtime.db.execute("UPDATE hourly_ticks SET stage='REALIZE',events=?", (json.dumps([event.model_dump(mode='json')]),))
            runtime.db.execute("INSERT INTO hourly_realizations VALUES(?,NULL,'CALLING')", (event.event_id,))
        runtime._terminal(event, 'skipped', 'host_suspended_no_historical_action')
        resume_after_delay(runtime,self.now+timedelta(hours=1))
        self.assertEqual(runtime.db.execute('SELECT status FROM hourly_realizations').fetchone()[0], 'SKIPPED')
        self.assertEqual(self.agent.calls, [])


    def test_known_journey_finishes_and_old_hooks_expire_without_new_action(self):
        from core.models import Hook, Journey
        self.initialize(); state = self.bridge.state()
        state.hooks = [Hook(hook_id='known',family='BUDGET_CHECK',due_at=self.now,expires_at=self.now+timedelta(hours=1),cause_event='verified.old',depth=1)]
        state.world.journey = Journey(destination='cafe',departure=self.now,arrival=self.now+timedelta(minutes=10),source_event='verified.old',transaction_id='verified.old.tx')
        with self.coordinator.atomic(): self.bridge.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        runtime = self.runtime(); resume_after_delay(runtime,self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state().world.place, 'cafe')
        self.assertIsNone(self.bridge.state().world.journey)
        self.assertEqual(self.bridge.state().hooks[0].status, 'expired')
        self.assertEqual(self.agent.calls, [])

    def test_scheduler_lock_excludes_second_resume_worker(self):
        from connectors.write_coordinator import WriteConflict
        runtime = self.seed(); before = self.bridge.state()
        with runtime.scheduler_lock():
            with self.assertRaises(WriteConflict): resume_after_delay(runtime,self.now+timedelta(hours=2))
        self.assertEqual(self.bridge.state(), before); self.assertFalse(pending(runtime.db))

    def test_full_db_restore_requires_both_independent_revalidation_gates(self):
        from connectors.database_recovery import revalidate_recovered
        runtime = self.seed(); offsite = tempfile.TemporaryDirectory(); self.addCleanup(offsite.cleanup); root = Path(offsite.name)
        vault = DatabaseRecoveryVault(root/'images',root/'witness/head.json',b'fixture-disaster-signing-key-0000','fixture.world.recovery')
        self.coordinator.enable_recovery(vault)
        wall = self.now+timedelta(hours=2,minutes=20); resume_after_delay(runtime, wall)
        state = self.bridge.state(); self.coordinator.close()
        for suffix in ['', '-wal','-shm','.worker','.scheduler']: Path(str(self.path)+suffix).unlink(missing_ok=True)
        self.assertEqual(vault.restore(self.path)['status'], 'RESTORED_FROZEN')
        self.connect(); self.coordinator.enable_recovery(vault); runtime = self.runtime()
        self.assertEqual(self.bridge.state(), state); self.assertTrue(pending(runtime.db))
        with self.assertRaises(RecoveryUnavailable): resume_after_delay(runtime, wall)
        with self.assertRaises(RecoveryUnavailable): revalidate_host_resume(runtime, wall)
        self.assertEqual(revalidate_recovered(runtime)['status'], 'VERIFIED')
        self.assertTrue(pending(runtime.db)); self.assertFalse(self.bridge.confirmations_allowed())
        self.assertEqual(revalidate_host_resume(runtime, wall)['status'], 'VERIFIED')
        self.assertTrue(self.bridge.confirmations_allowed())


if __name__ == '__main__': unittest.main()
