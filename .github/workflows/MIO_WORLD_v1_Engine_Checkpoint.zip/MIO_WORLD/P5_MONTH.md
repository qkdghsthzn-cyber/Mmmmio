# P5 월 경계·과거 날짜 원장 조정

이 체크포인트는 로컬 HTTP fixture에서 검증했다. 실제 GPT/Notion/Calendar 왕복·native 월 마감 자동화·운영 서버·Android 완료를 뜻하지 않는다. production mutation은 차단되어 있다.

## native 대상 월 계약

기존 Wallet의 구조와 rich text를 보존한다. 아래 계약은 명시적인 월 조정을 위한 선택적인 연동 필드다. reader는 block을 원격으로 만들거나 월 지출을 reset하지 않는다. 실제 연동에서는 이 근거의 설정과 월 마감 절차를 검증해야 한다.

| native 자료 | 검증 |
|---|---|
| `残高: ¥…` | 현재 잔액, 원장 행별 산술의 마지막 값과 일치 |
| `今月の支出: ¥…` | 확인된 대상 월의 지출 합계와 일치 |
| `支出対象月: YYYY-MM` | 유일하고 활성/버전이 있는 block, WORLD_STATE.timezone의 현재 현지 월과 일치 |
| MONEY LOG의 기존 5열 | 日付 / 種類 / 内容 / 金額 / 残高, native ID와 관리 필드 hash 보존 |

대상 월이 없는 기존 Wallet은 같은 월 append 경로를 유지한다. 월이 바뀌거나 과거 월의 새 거래가 들어오면 월을 추정하지 않고 stale로 남긴다. 대상 월 block을 이미 검증한 뒤 삭제·교체하거나 월을 역행하면 조정을 거부한다. WORLD_STATE.timezone을 바꾸는 것도 명시적인 별도 조정이 필요하다.

## 잔액과 월별 지출

잔액 산술은 원장의 append 순서를 따른다. 날짜로 정렬하면 늦게 기록한 거래의 잔액 연결이 달라지므로 재정렬하지 않는다. 새 행은 명시적인 ISO 날짜·종류·내용·부호가 있는 JPY 금액·잔액이 필요하다. 미래 날짜는 거부한다.

지출은 행의 native 거래 날짜가 속한 월에 반영한다. 예를 들어 11월에 추가된 10월 31일의 -¥100 행은 현재 잔액을 ¥100 줄이고, 10월의 확인된 지출 합계를 늘린다. 11월 지출을 늘리지 않는다. INCOME은 잔액에 더하며 gross 지출 합계를 줄이지 않는다.

anchor는 최초 현지 월의 native 지출 합계와 원장 prefix를 보존한다. 기준 이후의 월은 검증된 새 행에서 지출을 누적한다. 기준 이전 월은 전체 합계를 알 수 없으므로 `historical_expense_deltas`에 이후 확인한 추가 지출만 기록하며 `month_totals`에 전체 합계를 만들어 넣지 않는다. 건너뛴 월의 확인되지 않은 별도 summary를 창작하지 않는다.

기존 원장 행 수정·삭제·재정렬은 과거 날짜의 새 append와 다르며 계속 거부한다. cache ledger의 created_at은 관측/반영 시각이고, 실제 native 날짜와 원문은 import proof에 보존한다. 날짜만으로 정확한 거래 시각을 생성하지 않는다.

이미 cache에 게시한 runtime 행은 durable commit의 사건/판단, 금액/잔액, WORLD_STATE.timezone에서의 거래 날짜가 맞아야 한다. 다시 import하지 않는다. runtime marker를 위조하거나 날짜를 바꾸면 거부한다.

## 원자성·시간별 재시작

두 번의 전체 native Wallet/schema/Inventory 조회, 기존 prefix, resource/scope, 현재 cache hash와 예약금을 검증한다. cache·새 원장·월별 합계·anchor·원문 proof·인과를 같은 SQLite transaction으로 반영한다. 월만 넘어간 경우도 proof를 남긴다. 실패하면 anchor와 금전 변화는 rollback되고 외부 사실 확정은 stale 상태로 유지된다. 중복 실행·재시작은 이미 확인한 지출이나 월 마감을 중복 반영하지 않는다.

월 경계 tick은 시계/욕구를 먼저 저장하고 SELECT 단계를 남긴다. 새 현지 월의 native 자료를 읽고 조정한 뒤 Grammar 후보를 선택한다. SELECT 중 종료되면 같은 tick을 재개하며 시계·욕구·판단을 다시 실행하지 않는다. 월 근거가 늦거나 조회에 실패하면 시계는 진행하지만 budget 후보와 금전 확정을 보류한다. 다음 시간에 유효한 native 근거가 제공되면 재조회/조정할 수 있다.

native 거래 날짜는 명시적인 WORLD_STATE.timezone을 따른다. freshness는 UTC 경과 시간으로 검사해 DST 반복 시각에서 1시간 지난 증거를 새 증거로 취급하지 않는다.

월별 anchor와 proof는 보존된 coordinator DB의 일부다. cache/archive 삭제 후 복원에서도 해당 월을 다시 reset하지 않는다. 이 native cache 경로는 전체 DB 유실을 복원하지 않는다. 독립 vault/witness/key가 남은 경우의 별도 fixture 전체 DB 복구는 P5_DISASTER.md를 따른다. 두 번의 native 읽기는 Notion의 원자적 CAS나 조회 후 외부 편집 방지를 뜻하지 않으며 실서비스 동시 편집 검증은 남아 있다.

## 검증

```bash
python3 tools/test_report.py P0 P1 P2 P3 P4 P5_contract P5_recovery P5_http P5_runtime P5_hourly P5_effects P5_clock P5_restore P5_month P5_disaster
python3 mio.py p5-month-demo
python3 mio.py p5-hourly-demo --hours 168
```

월 조정 34개와 전체 회귀 293개 PASS. 월말 자정·연도 경계·늦은 과거 월 지출·알 수 없는 과거 합계·append 순서·부호/잔액/월 합계·native 대상 월 누락/교체·prefix 편집·불안정 조회·503·DB rollback·재시작·UTC 날짜/DST·금전 prepare 우회 방지·SELECT 재시작과 native cache 복원을 검사했다.

월말 48시간 fixture는 snapshot 48개, 사건 18건 commit/7건 skip, 늦은 10월 지출 1회 import, 중간 coordinator 재시작과 cache/archive 삭제 후 복원을 통과했다. 모의 합계는 10월 ¥100, 11월 ¥0이며 실제 미오의 지출이 아니다. native 대상 월과 월 지출 reset은 fixture의 명시적인 provider 편집이고, runtime reader의 원격 쓰기는 0회다. 168시간 fixture의 실행/복원도 통과했다. 원본 core/data/reference와 이전 P2 10,000시간 PASS 보고서는 보존했으며 이번에 10,000시간을 재실행하지 않았다.

증거: `reports/P5_month_tests.json`, `reports/P5_month_demo.json`, `reports/P5_month_summary.json`.

남은 P5 조건은 실제 native 월 마감 근거 설정/검증, 실제 초기화·비용 signal·API/정본 왕복·동시 편집 보호, 안전한 credential 입력·운영 timer/배포, 독립 vault/witness/key 운영 구성·복원 실습이다. 이 조건을 통과한 뒤 P6→P7→P8로 진행한다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.
