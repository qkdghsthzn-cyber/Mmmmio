# P5 일반 지출·일정 취소·원장 근거 cache 복구

검증 범위는 loopback HTTP fixture다. 실제 GPT/Notion/Calendar 쓰기 왕복·운영 서버·Android는 미완료이며 production mutation 차단을 유지한다. 권한 재승인 대기 상태가 아니다.

## 일반 지출

SpendProposal의 금액·설명·시간을 원래 사건/검증된 결정과 바인딩한다. 기존 Wallet의 잔액과 월 지출 bullet에서 숫자만 변경하고 rich text 서식을 유지한다. 기존 MONEY LOG에 EXPENSE 행을 추가하고 Continuity에 사건·결정·transaction·근거를 남긴다. Inventory/Wishlist를 변경하거나 구매를 추정하지 않는다. 예약금을 제외한 잔액을 초과할 수 없다.

실제 지출은 trusted provider read가 제공한 최신 external_verified 비용 signal(금액·설명·시간·ref)이 있어야 한다. LLM의 설명이나 fixture Family의 고정 금액은 live 비용 근거가 아니다. 실제 signal 취득 경로와 실제 왕복은 아직 연결/검증하지 않았다.

## 일정 취소

런타임이 생성하고 cache에 게시한 영수증이 있는 미래의 단발 일정만 취소한다. 원래 생성 내용·source_event·native ID·etag·전체 native hash를 다시 확인한다. 조회 창의 모든 busy 일정을 보존하며 참석자·반복 일정·사람이 편집한 일정은 이 경로에서 거부한다. 기존 routine 일정의 일괄 취소를 지원한다고 선언하지 않는다.

Calendar PATCH는 status=cancelled와 private 취소 출처만 변경한다. If-Match etag와 sendUpdates=none을 사용한다. 취소 marker·필드·resource ID가 모두 맞을 때만 응답 유실 후 영수증을 회수한다. 최소 tombstone 또는 사라진 객체는 작성 주체를 증명하지 못하므로 UNKNOWN/RECONCILE_REQUIRED다.

후속 native 쓰기가 확실히 실패하면 영수증 etag/native hash가 그대로인 경우에만 원래 status와 private metadata로 보상한다. 외부 편집이나 보상 응답 유실은 확정을 보류한다. 검증된 보상 영수증은 기존 생성 근거를 보존하면서 새 native version에 바인딩하므로 이후 tick에서 다시 취소를 제안할 수 있다. SQLite fake adapter는 취소를 흉내 내지 않으며 실제 HTTP fixture adapter에서 검증한다.

## 외부 Wallet/Inventory 변경 복구

NativeCacheReconciler는 외부 쓰기를 하지 않는다. 초기화 때 캐시와 native 사실이 일치하는 경우에만 원장 prefix·잔액·월 지출·월·native resource ID를 durable anchor로 저장한다. hourly reader는 reconcile_external=True로 복구를 사용한다. 일반 reader의 기본값은 이전처럼 drift를 표시한다.

1. 이전 MONEY LOG 행의 ID·순서·관리 필드 hash가 보존되어야 한다.
2. 새 행은 날짜·종류·원인·JPY 부호·행별 잔액을 포함해야 한다. 모든 금액이 산술적으로 연결되고 마지막 잔액 및 월 지출까지 일치해야 한다.
3. 런타임 marker가 있는 행은 실제 committed/published 거래와 캐시 ledger의 금액·잔액·사건·결정이 일치해야 한다. 이미 반영한 지출을 다시 import하지 않는다.
4. 두 번의 full native Wallet/schema/Inventory 읽기가 같고 cache hash도 유지되어야 한다. cache·새 ledger·anchor·import proof를 같은 SQLite transaction에 반영한다.
5. Inventory의 현재 Owned만 활성 cache로 매핑한다. 알려지지 않은 가격·위치·상태·취득 시각은 unknown으로 남긴다. raw native rows와 변경 전 Inventory를 import journal에 보존하므로 제거된 소유권도 이력을 잃지 않는다. native row로 확인한 소유권에서 구매/선물 이야기를 추정하지 않는다.

import ledger의 created_at은 관측/반영 시각이다. native 날짜만으로 거래의 정확한 시각을 만들어내지 않는다. 실제 원래 날짜와 원인 문장은 import proof에 그대로 저장한다. fixture 소유권과 금액은 계속 mock이며 canonical로 승격하지 않는다. 원장과 소유권이 모두 설명된 뒤에만 Notion stale를 해제한다.

설명되지 않은 잔액 차이, 원장 수정/삭제/재정렬/중복, 잘못된 부호·월 지출, reservation 초과, scope/resource 변경, 조회 중 편집, local DB 실패와 미확정 cache binding은 복구를 막는다. 명시적인 native 대상 월이 있으면 P5_MONTH.md에 따라 월 경계와 과거 날짜의 새 append 기록을 읽기 전용으로 조정한다. 대상 월이 없으면 같은 월 append만 처리한다. native 월 지출 reset은 수행하지 않는다. 과거 행 수정과 최초 anchor 이전부터 존재한 drift는 별도 조정 근거가 필요하며 자동 처리하지 않는다. Notion의 두 번 읽기는 원자적 CAS나 여러 외부 자원의 transaction을 뜻하지 않는다.

## 검증과 남은 단계

```bash
python3 tools/test_report.py P0 P1 P2 P3 P4 P5_contract P5_recovery P5_http P5_runtime P5_hourly P5_effects P5_clock P5_restore P5_month P5_disaster
python3 tools/p2_acceptance.py
python3 mio.py p5-hourly-demo --hours 168
```

전체 293개 시험은 지출/취소/rebase 39개, clock 14개, native 복원 19개와 월 조정 34개를 포함해 PASS. 이전 지출/취소 core 변경 후 다시 실행한 10,000시간 시험(4종 위반 0건)을 보존한다. 이번 월 조정 변경은 core/data/reference를 바꾸지 않았다. 168시간 HTTP fixture 실행에서 snapshot 168개·미확정 cache binding 0개를 검증했다. 자연 추첨 demo에는 지출/구매/취소가 발생하지 않았으므로 해당 기능은 별도 통합 시험 결과로 확인한다.

P5의 남은 작업은 실제 native 월 마감 설정/검증, 독립 vault/witness/key 운영 구성·복원 실습, 실제 초기화·비용 signal 취득·서버 인증/실제 왕복, Notion 동시 편집 보호, 안전한 credential 입력과 운영 timer 배포다. 완료 조건을 확인한 뒤 P6→P7→P8로 진행한다.

공식 계약: [Calendar Event status](https://developers.google.com/workspace/calendar/api/v3/reference/events), [PATCH](https://developers.google.com/workspace/calendar/api/v3/reference/events/patch), [conditional modification](https://developers.google.com/workspace/calendar/api/guides/version-resources), [private extended property PATCH/null removal](https://developers.google.com/workspace/calendar/api/guides/extended-properties).

복구 중 clock-only 진행과 native checkpoint cache/인과 복원은 `P5_RESTORE.md`의 제한과 증거를 따른다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.
