"""Responses API via stdlib; credentials stay on the server.
Source: https://developers.openai.com/api/docs/guides/structured-outputs
"""
import json
import os
import sqlite3
import uuid
from datetime import datetime,timezone
from urllib.request import Request,urlopen
from urllib.error import HTTPError,URLError


class ProviderUnavailable(RuntimeError): pass
class BudgetExceeded(ProviderUnavailable): pass


class RequestBudget:
    """Durable conservative reservation, independent of world rollback.
    Uses byte count as an upper bound on input tokens; unknown/failed calls keep
    their reservation. Provider/project spending limits should also be set.
    Prices below are configurable and specific to the documented Luna default.
    """
    def __init__(self,path=":memory:",monthly_usd=5,input_usd_per_million=.2,output_usd_per_million=1.2):
        self.db=sqlite3.connect(str(path),isolation_level=None,timeout=10)
        self.db.execute("CREATE TABLE IF NOT EXISTS budget(call_id TEXT PRIMARY KEY, month TEXT, reserved_micro_usd INTEGER)")
        self.cap=int(monthly_usd*1_000_000); self.input_price=input_usd_per_million; self.output_price=output_usd_per_million

    def reserve(self,input_bytes,max_output_tokens):
        month=datetime.now(timezone.utc).strftime("%Y-%m")
        cost=int(input_bytes*self.input_price+max_output_tokens*self.output_price+1)
        self.db.execute("BEGIN IMMEDIATE")
        try:
            used=self.db.execute("SELECT COALESCE(SUM(reserved_micro_usd),0) FROM budget WHERE month=?",(month,)).fetchone()[0]
            if used+cost>self.cap: raise BudgetExceeded("monthly API budget exhausted")
            self.db.execute("INSERT INTO budget VALUES(?,?,?)",(uuid.uuid4().hex,month,cost))
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK"); raise


class OpenAITransport:
    def __init__(self,api_key=None,model=None,timeout=20,budget=None,endpoint="https://api.openai.com/v1/responses"):
        self._api_key=api_key or os.getenv("OPENAI_API_KEY")
        self.model=model or os.getenv("OPENAI_MODEL","gpt-5.6-luna")
        if not self._api_key: raise ProviderUnavailable("OPENAI_API_KEY is not configured")
        if not endpoint.startswith("https://api.openai.com/") and not endpoint.startswith("http://127.0.0.1:"):
            raise ValueError("unsupported API endpoint")
        if self.model!="gpt-5.6-luna" and budget is None:
            raise ValueError("custom model requires explicitly configured pricing/budget")
        self.timeout=timeout; self.endpoint=endpoint; self.budget=budget or RequestBudget()
        self.requests=0

    def complete(self,prompt,schema,system):
        payload={"model":self.model,"instructions":system,"input":prompt,
                 "text":{"format":{"type":"json_schema","name":"mio_decision","strict":True,"schema":schema}},
                 "max_output_tokens":1200,"reasoning":{"effort":"low"},"store":False}
        body=json.dumps(payload,ensure_ascii=False).encode("utf8")
        if len(body)>60000: raise ProviderUnavailable("input exceeds configured context budget")
        self.budget.reserve(len(body),payload["max_output_tokens"])
        self.requests+=1
        req=Request(self.endpoint,data=body,method="POST",headers={"Content-Type":"application/json","Authorization":"Bearer "+self._api_key})
        try:
            with urlopen(req,timeout=self.timeout) as response:
                return json.loads(response.read(2_000_000))
        except (HTTPError,URLError,TimeoutError,ValueError) as error:
            # Do not log request headers, API keys, or untrusted response bodies.
            raise ProviderUnavailable(type(error).__name__) from None


def output_text(response):
    if response.get("status")!="completed": raise ProviderUnavailable("response not completed")
    texts=[]
    for item in response.get("output",[]):
        if item.get("type")!="message": continue
        for content in item.get("content",[]):
            if content.get("type")=="refusal": raise ProviderUnavailable("provider refusal")
            if content.get("type")=="output_text": texts.append(content.get("text",""))
    if not texts: raise ValueError("no structured output text")
    return "".join(texts)


def strict_schema(model):
    schema=model.model_json_schema()
    def normalize(node):
        if isinstance(node,dict):
            node.pop("default",None)
            if node.get("type")=="object" and "properties" in node:
                node["required"]=list(node["properties"]); node["additionalProperties"]=False
            for value in node.values(): normalize(value)
        elif isinstance(node,list):
            for value in node: normalize(value)
    normalize(schema)
    return schema
