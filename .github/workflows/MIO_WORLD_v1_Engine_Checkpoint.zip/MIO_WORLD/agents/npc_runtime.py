"""Lazy NPC contexts. No separate always-running GPT or private Mio state."""
from pydantic import Field
from typing import Literal
from core.models import Model


class NPCProposal(Model):
    npc_id: str
    message: str = Field(max_length=500)
    cited_scopes: list[str]
    intent: Literal["invite","ask_opinion","share_find","casual_chat","reschedule","followup"] = "casual_chat"
    topic: str | None = None


class GroundedNPCMessage(Model):
    npc_id: str
    message: str
    cited_scopes: list[str]


class NPCRuntime:
    def context(self,state,npc_id):
        npc=state.relationships.get(npc_id)
        if npc is None or not npc.active: raise ValueError("unknown/inactive NPC")
        return {"npc_id":npc.npc_id,"name":npc.name,"traits":npc.traits,"shared_interests":npc.shared_interests,
                "last_contact":npc.last_contact.isoformat() if npc.last_contact else None,
                "knowledge_scope":npc.knowledge_scope,"open_threads":npc.open_threads}

    def validate(self,state,proposal):
        npc=state.relationships.get(proposal.npc_id)
        if npc is None or not npc.active: raise ValueError("unknown/inactive NPC")
        if not set(proposal.cited_scopes)<=set(npc.knowledge_scope): raise ValueError("NPC knowledge violation")
        if not proposal.cited_scopes: raise ValueError("NPC utterance needs scoped evidence")
        if proposal.topic and (proposal.topic not in npc.shared_interests or "shared:"+proposal.topic not in proposal.cited_scopes):
            raise ValueError("topic lacks shared knowledge")
        # Unconstrained model prose never becomes an NPC fact. Render from a
        # small scoped intent vocabulary; proposed private claims are discarded.
        messages={"invite":"時間があるとき、会えたらうれしい。", "ask_opinion":"今度、好きなものの話を聞かせて。",
                  "share_find":"気になるものがあったら、また話そう。", "casual_chat":"少し話せる？",
                  "reschedule":"予定をもう一度相談してもいい？", "followup":"また話したいな。"}
        return GroundedNPCMessage(npc_id=npc.npc_id,message=messages[proposal.intent],cited_scopes=proposal.cited_scopes)
