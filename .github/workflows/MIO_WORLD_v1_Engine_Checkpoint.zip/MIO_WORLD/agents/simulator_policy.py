"""Only for mock simulation. This is deliberately not advertised as GPT thinking."""
from datetime import timedelta
from core.models import Action, Decision
from core.candidate_generator import seeded,busy


def simulator_decision(state,event):
    rng=seeded(17,state.world.time,event.event_id+"policy")
    decision=Decision(decision_id="dec_"+event.event_id,event_id=event.event_id,choice="accept",reason_tags=["mock_policy"],actions=[])
    if rng.random()<.18:
        decision.choice="defer"; return decision
    p=event.payload; effect=p["effect"]; actions=[]
    if effect=="purchase": actions=[Action(type="purchase",item_id=p["item_id"],amount=p["cost"])]
    elif effect=="spend": actions=[Action(type="spend",amount=p["cost"])]
    elif effect=="use_item": actions=[Action(type="use_item",item_id=p["item_id"])]
    elif effect=="need": actions=[Action(type="need_update",need=p["need"],delta=p["need_delta"])]
    elif effect=="contact": actions=[Action(type="relationship_update",npc_id=event.actors[0],delta=1)]
    elif effect in {"calendar","invite"}:
        start=state.world.time+timedelta(hours=2)
        duration=timedelta(minutes=int(p["duration_minutes"]))
        for _ in range(24):
            if not busy(state,start-timedelta(minutes=20),start+duration+timedelta(minutes=20)): break
            start+=timedelta(hours=1)
        actions=[Action(type="calendar_create",start=start,end=start+duration,title="テスト予定: "+event.family,location=p["location"])]
        if effect=="invite": actions.append(Action(type="relationship_update",npc_id=event.actors[0],delta=1))
    elif effect=="cancel_calendar": actions=[Action(type="calendar_cancel",commitment_id=p["commitment_id"])]
    elif effect=="move": actions=[Action(type="move",location=p["location"])]
    else: actions=[Action(type="observe")]
    decision.actions=actions
    return decision
