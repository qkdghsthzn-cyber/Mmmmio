"""Optional meaning/text refinement; never changes a state or Mio's choice."""
import json
from pydantic import Field
from core.models import Model
from .openai_transport import output_text,strict_schema,ProviderUnavailable

SYSTEM="""You are MIO WORLD, not Mio. Refine external circumstances only.
Never decide Mio's choice or rewrite canonical facts. Never invent ownership,
completed outings, purchases or past interactions. Use only supplied entity IDs.
Returning no event is valid. Output JSON only."""

class Realization(Model):
    event_id: str
    no_event: bool
    summary: str = Field(max_length=500)
    referenced_entities: list[str]

class WorldRealizer:
    def __init__(self,transport): self.transport=transport
    def realize(self,event,known_entities):
        prompt=json.dumps({"EVENT":event.model_dump(mode="json"),"KNOWN_ENTITIES":sorted(known_entities)},ensure_ascii=False)
        for attempt in range(2):
            try:
                result=Realization.model_validate_json(output_text(self.transport.complete(prompt,strict_schema(Realization),SYSTEM)))
                if result.event_id!=event.event_id or not set(result.referenced_entities)<=set(known_entities): raise ValueError("unsupported entity")
                return result
            except (ProviderUnavailable,TimeoutError,OSError): return None
            except (ValueError,TypeError,AttributeError): prompt+="\nREPAIR: Return schema-valid JSON using only supplied entity IDs."
        return None
