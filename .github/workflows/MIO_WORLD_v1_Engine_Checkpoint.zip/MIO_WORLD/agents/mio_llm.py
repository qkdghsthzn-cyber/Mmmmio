import json
from pathlib import Path
from core.models import Decision
from core.validator import EFFECT_ACTIONS
from .openai_transport import ProviderUnavailable,output_text,strict_schema

SYSTEM="""You are Mio making a present-tense choice inside a persistent world.
Use only supplied STATE, EVENT, TASTE, RELATIONSHIPS and OPEN_THREADS.
Have your own preferences; accept, decline, defer and ignore are all valid.
Propose intended actions. Never claim an intended action already happened.
Never invent ownership, purchases, past interactions, completed photos or outings.
Use only authorized action types and candidate-bound objects, prices, deltas and durations.
Non-accept choices must have an empty actions array. Respect autonomy, privacy and adult consent.
Output JSON only. The code validator, not you, commits facts.
"""


def context(state,event,grammar):
    f=grammar.families[event.family]
    core_path=Path(__file__).resolve().parents[1]/"reference"/"01_Core_Identity.md"
    core=core_path.read_text().split("## Intimacy Bible")[0]
    return {
        "CORE_IDENTITY":core,
        "STATE":{"mode":state.mode,"revision":state.revision,"world":state.world.model_dump(mode="json"),
                 "wallet":{"currency":state.wallet.currency,"available_balance":state.wallet.available_balance},
                 "owned_items":[x.model_dump(mode="json") for x in state.inventory.values() if x.status=="owned"],
                 "bound_catalog_item":state.catalog[event.payload["item_id"]].model_dump(mode="json") if event.payload.get("item_id") in state.catalog else None,
                 "calendar":[c.model_dump(mode="json") for c in state.calendar if c.status=="scheduled"],
                 "notion_stale":state.notion_stale,"calendar_stale":state.calendar_stale},
        "EVENT":event.model_dump(mode="json"),
        "TASTE":[t.model_dump(mode="json") for t in state.taste.values()],
        "RELATIONSHIPS":[state.relationships[a].model_dump(mode="json") for a in event.actors],
        "OPEN_THREADS":[h.model_dump(mode="json") for h in state.hooks if h.status=="open"],
        "AUTHORIZED_ACTION_TYPES":sorted(EFFECT_ACTIONS[f.effect]),
        "RULES":{"relationship_delta_cap":grammar.rules["relationship_delta_cap"],
                 "need_delta":f.need_delta,"duration_minutes":event.payload["duration_minutes"]},
        "ARCHIVED_CANON_NOTICE":"Past reference scenes do not establish current wallet, ownership or calendar facts.",
    }


class MioDecisionAgent:
    def __init__(self,transport,grammar):
        self.transport=transport; self.grammar=grammar; self.schema=strict_schema(Decision)
        self.failures=[]; self.repairs=0

    def decide(self,state,event):
        original=json.dumps(context(state,event,self.grammar),ensure_ascii=False,sort_keys=True)
        prompt=original
        for attempt in range(2):
            try:
                response=self.transport.complete(prompt,self.schema,SYSTEM)
                text=output_text(response)
                decision=Decision.model_validate_json(text)
                if decision.event_id!=event.event_id: raise ValueError("wrong event_id")
                return decision
            except (ProviderUnavailable,TimeoutError,OSError) as error:
                self.failures.append({"event_id":event.event_id,"kind":type(error).__name__,"attempt":attempt+1})
                return None
            except (ValueError,TypeError,KeyError,AttributeError) as error:
                if attempt==0:
                    self.repairs+=1
                    prompt=original+"\nREPAIR: Your previous output failed the JSON contract ("+type(error).__name__+"). Return the complete corrected JSON, with this exact event_id."
                else:
                    self.failures.append({"event_id":event.event_id,"kind":"invalid_json_after_repair","attempt":2})
        return None
