@echo off
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  set "MIO_PYTHON=python"
) else (
  set "MIO_PYTHON=py -3"
)
%MIO_PYTHON% -m pip install -r requirements.txt
if errorlevel 1 goto failed
%MIO_PYTHON% mio.py simulate --hours 168
if errorlevel 1 goto failed
%MIO_PYTHON% mio.py dump
echo MIO WORLD mock replay completed. Open reports/latest.json and reports/state.json.
pause
exit /b 0
:failed
echo Install Python 3.11 or newer, then retry. Details are in README.md.
pause
exit /b 1
