# P5 초기화·네이티브 시간별 실행

이번 경로는 loopback HTTP 모의 서버에서 실행되는 P5 체크포인트다. 실제 GPT·정본 서버·24시간 서버 배포·APK 완료를 뜻하지 않는다. production 활성화는 계속 차단되어 있다.

## 초기화

`connectors/runtime_bootstrap.py`는 mock_state를 불러오지 않는다. InitializationRequest가 현재 세계 상태·8개 욕구·초기 내부 수치의 근거·이동시간·기능 flag를 명시해야 한다. NPC를 넣을 때 연령 근거와 관계 수치 초기화 근거를 따로 요구한다. 취향 수치도 초기화 근거를 요구한다. 정성적인 기존 문서에서 숫자나 연령을 추정하지 않는다.

NativeBootstrapper가 wallet·Inventory schema/rows·Calendar·관계·취향·Continuity·기억·별도 WORLD_STATE 페이지를 새로 읽는다. 잔액은 기존 잔액 bullet, 소지품은 실제 Owned 행, Wishlist는 기존 native 행 ID를 사용한다. 없거나 모르는 항목은 만들지 않는다. native Acquired가 날짜만 제공하면 취득 시각을 임의로 만들지 않고 원문 날짜를 증거에 보존한다. 원문 페이지·schema·rows와 초기화 입력을 한 SQLite transaction에 보존한다. 실패한 초기화는 반쪽 cache를 만들지 않는다. 기존 cache를 다시 seed하지 않는다.

WORLD_STATE snapshot에는 별도로 설정한 페이지 ID가 필요하다. Wallet·관계·취향·Continuity 페이지를 snapshot 페이지로 치환하지 않는다. 실제 resources.json의 world_runtime_page_id는 아직 미설정이다. 실제 현재 위치·내부 수치 초기화와 native runtime 페이지를 확인한 후 production 초기화를 검증해야 한다.

## 시간별 순서와 재시작

`runtime/hourly.py`의 NativeHourlyRuntime은 다음 순서를 지속 가능한 단계로 기록한다.

1. 이전 미확정 transaction의 영수증·보상을 복구한다.
2. Notion/Calendar를 읽고, 필터 없는 전체 Calendar 창의 변경을 cache에 반영한다.
3. 끝난 시간 구간·도착이 증명된 Journey·만료 hook·욕구를 계산한다.
4. 기존 160 Family 문법과 Probability/Novelty/원인 gate로 후보를 생성·선택한다. NO_EVENT 시간에는 판단 API를 호출하지 않는다.
5. 복잡한 후보만 선택적인 World realization을 거친다. 결과를 검증한 뒤 event log를 기록한다.
6. 명시적으로 주입한 Mio decision agent가 판단한다. 모의 정책은 demo에서만 명시적으로 주입한다. 실세계에서 모의 선택기로 대체하지 않는다.
7. CanonicalValidator → native 계획 → durable outbox → HTTP 쓰기·영수증·재읽기 → cache 게시를 수행한다.
8. 검증된 commit 뒤 같은 cache transaction에서 Novelty·인과·hook을 반영한다. 구매 후 hook은 실제 Inventory native ID에 연결한다.
9. 별도 runtime 페이지에 WORLD_STATE/hook/Novelty snapshot을 추가하고 영수증을 재읽는다. P6 Social output은 아직 실행하지 않는다.

scheduler lock은 별도 SQLite 파일에서 프로세스 간 중복 실행을 막는다. UTC tick ID는 DST의 반복되는 현지 시간을 구분한다. 첫 시간 이후 한 실제 시간 간격을 요구하고 역행·건너뛰기를 거부한다. run(hours)는 제한된 catch-up runner이며 운영 서버의 timer/서비스 배포는 아직 없다.

판단의 CALLING 상태를 응답보다 먼저 저장한다. 판단 중 프로세스가 죽고 응답이 없으면 해당 사건을 skip하며 같은 판단을 무조건 재요청하지 않는다. 응답·계획·native commit이 저장된 경우에는 그 위치부터 이어간다. 외부 commit 이후 cache 게시 중 실패하면 같은 native 영수증을 다시 확인하고, cache·consequences·decision committed를 함께 저장한다. 인과 전체 기록은 별도 archive에 보존하며 hot cache는 최근 256개다.

snapshot 응답 유실은 COMPLETED_DEFERRED로 남긴다. 다음 시간에 과거 snapshot을 검증해도 현재 시계를 과거로 덮어쓰지 않는다. 확실한 snapshot 거부는 FAILED로 남기고 새 transaction ID로 재전송하지 않는다. 일반 읽기 실패와 GPT 실패에서도 내부 시계 처리는 보존한다.

미해결 cache binding이 남아 있으면 새 proposal을 보류하고, 다음 시간의 시계·욕구·이미 확인된 이동·일정·hook 기한을 COMPLETED_CLOCK_ONLY로 진행한다. 이후 거래를 공개할 때 저장된 시간 journal을 원래 projection에 재생해 현재 시각을 보존한다. 임의의 상태 편집은 이 merge에 포함하지 않는다. 독립적인 새 사건 판단은 거래가 해결된 뒤 재개하며, P5 전체 장애 격리 완료로 표시하지 않는다.

## 네이티브 효과와 불확실성

구매와 일정 생성 외에 observe·need_update·use_item·move·relationship_update의 검증·native 인과 기록을 추가했다. 내부 수치의 전후 변화는 기존 Taste/Relationships 페이지에 원인·초기화 근거와 함께 append한다. 원문의 정성적인 서술을 덮어쓰지 않는다. 통화·수량·소유권은 자연어로 확정하지 않는다. 일반 spend와 런타임 소유 단발 calendar_cancel의 native 계획·보상을 추가했다. 실제 지출은 fresh provider 비용 증거가 없으면 거부한다. 새 native full checkpoint에서 cache/인과 기록을 복원하는 경로를 추가했다. 영수증/초기화 DB가 없는 경우 또는 더 새로운 변화가 기록되지 않은 경우에는 복원하지 않는다.

일정은 계획이며 출석 증거가 아니다. 새 실행 경로는 일정의 장소로 미오를 순간 이동시키지 않는다. 검증된 Journey의 도착만 위치를 갱신한다. 완료된 Calendar 상태는 시간 구간이 끝났다는 뜻이며 실제 참석을 생성하지 않는다. 장소가 없는 일정은 unknown 표식으로 보존하고 이동시간을 임의로 0으로 처리하지 않는다.

종일 일정은 Calendar metadata의 IANA timezone에서 자정~exclusive end로 해석한다. DST 종료일은 25시간일 수 있다. 반복 일정은 native singleEvents instance ID를 보존한다. opaque 일정은 fixed busy로 유지한다. Calendar 변화는 전체 조회 창 안에서만 추가·취소를 판단한다. 외부 Wallet/Inventory 변화는 durable 원장 prefix·새 행의 산술·월 지출·안정적인 재조회·cache hash를 검증한 뒤 import journal과 함께 복구한다. 설명되지 않은 잔액, 대상 월이 없는 월 경계/과거 월 기록은 stale로 남긴다. 명시적인 native 대상 월과 월별 누적 증거가 있으면 P5_MONTH.md의 읽기 전용 조정을 수행한다.

## 검증

```bash
python tools/test_report.py P5_hourly
python mio.py p5-hourly-demo --hours 168
```

초기화/hourly 테스트 30개가 초기화 실패·알 수 없는 필드·종일 일정/DST·중복 tick·배타 lock·API 실패·native delta·영수증 유실·강제 프로세스 종료·재시작·snapshot 유실·World realization 순서·production 차단을 검사했다.

168시간 HTTP 모의 실행: 판단 84회, 검증된 사건 69건, skip 15건, 확인된 snapshot 168개, 미해결 cache binding 0개, 규칙 invariant 통과. 실제 정본 쓰기는 0회다. 자연 발생 실행에서 구매가 선택되지 않았으며 구매·관계 변화는 별도 통합 테스트로 확인했다. P2 10,000시간 시험 또는 P8 실연동 장기 시험과 구분한다.

다음 작업은 실제 native 월 마감 설정/검증, 독립 vault/witness/key 운영 구성·복원 실습, 실제 초기화·Notion 동시 편집 보호·왕복 검증, 서버 timer/credential 입력·배포다. 이후 P5 완료를 확인하고 P6으로 진행한다.

공식 API 계약: [Calendar events](https://developers.google.com/workspace/calendar/api/v3/reference/events), [Calendar list](https://developers.google.com/calendar/api/v3/reference/events/list), [Calendar metadata](https://developers.google.com/workspace/calendar/api/v3/reference/calendars/get), [Notion block](https://developers.notion.com/reference/block), [Notion request limits](https://developers.notion.com/reference/request-limits).

이번 체크포인트에서 기존 unsupported expense 시험을 native 지출 commit 시험으로 바꾸고, hourly 외부 원장 복구→지출과 일정 생성→취소의 두 통합 시험을 추가했다. P5_EFFECTS.md에 소유권·불확실성·월 경계 제한을 기록했다.

복구 중 새 시간은 COMPLETED_CLOCK_ONLY로 저장하며 새 LLM 판단이나 금전 확정을 하지 않는다. 거래 공개 시 원래 projection에 journal의 물리 시간 변화를 재생한다. 오래된 미처리 proposal은 skip하고 과거 snapshot을 창작하지 않는다. native full checkpoint는 압축한 cache·인과 기록 조각과 작은 WORLD overview로 구성한다. 168시간 demo는 캐시/인과 기록을 삭제한 뒤 native 복원도 확인한다. 상세 지원 범위는 P5_RESTORE.md다.

월 경계에는 새 시계를 원자적으로 저장한 뒤 SELECT 단계에서 새 월 자료를 조회/조정하고 후보를 생성한다. SELECT 단계에서 종료되면 같은 tick을 재개하며, 시계/욕구를 다시 증가시키거나 판단을 중복 호출하지 않는다. 월 마감 근거가 늦으면 시계는 계속 진행하고 지갑 확정은 보류한다. 34개 월 조정 시험에 새 달 지출·SELECT 재시작·cache/archive 복원이 포함된다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.
