import hashlib
import os
from urllib.parse import urlencode,quote
from core.models import aware
from .http_json import HTTPJSON,ConnectorUnavailable


class CalendarConnector:
    def __init__(self,calendar_id=None,access_token=None,http=None,token_provider=None):
        self.calendar_id=calendar_id or os.getenv("MIO_CALENDAR_ID")
        if not self.calendar_id: raise ConnectorUnavailable("MIO_CALENDAR_ID is not configured")
        if http is not None and (access_token is not None or token_provider is not None):
            raise ValueError("explicit HTTP transport already owns its credential source")
        self.http=http or HTTPJSON("https://www.googleapis.com/calendar/v3",
            access_token if access_token is not None else (None if token_provider is not None else os.getenv("GOOGLE_ACCESS_TOKEN")),
            token_provider=token_provider)

    @property
    def path(self): return "/calendars/"+quote(self.calendar_id,safe="")+"/events"

    def metadata(self):
        return self.http.request("GET", "/calendars/"+quote(self.calendar_id,safe=""))

    def events(self,start,end,query="MIO"):
        aware(start); aware(end)
        if end<=start: raise ValueError("invalid calendar query window")
        result=[]; cursor=None
        while True:
            params={"timeMin":start.isoformat(),"timeMax":end.isoformat(),"singleEvents":"true","orderBy":"startTime","maxResults":250,"q":query}
            if cursor: params["pageToken"]=cursor
            data=self.http.request("GET",self.path+"?"+urlencode(params))
            result.extend(data.get("items",[]))
            cursor=data.get("nextPageToken")
            if not cursor: return result

    @staticmethod
    def create_body(commitment,transaction_id):
        event_id="mio"+hashlib.sha256((transaction_id+"|"+commitment.commitment_id).encode()).hexdigest()
        payload={"id":event_id,"summary":commitment.title,"start":{"dateTime":commitment.start.isoformat()},
                 "end":{"dateTime":commitment.end.isoformat()},"location":commitment.location,"visibility":"private",
                 "extendedProperties":{"private":{"mio_source_event":commitment.source_event,"mio_transaction":transaction_id}},
                 "reminders":{"useDefault":False},"transparency":"opaque" if commitment.flexibility=="fixed" else "transparent"}
        return payload

    def create_plan(self,commitment,transaction_id):
        # Fictional NPCs are world entities, not real calendar invite recipients.
        return self.http.request("POST",self.path+"?sendUpdates=none",self.create_body(commitment,transaction_id),dry_run=True)

    def create_operation(self,commitment,transaction_id):
        from .write_models import NativeOperation
        return NativeOperation(operation_id="calendar."+commitment.commitment_id, connector="calendar",
            kind="calendar.create", target=self.calendar_id, domain="calendar",
            after=self.create_body(commitment,transaction_id), replay_safe=True,
            marker=transaction_id+":calendar."+commitment.commitment_id)

    def apply_live(self,*args,**kwargs):
        raise ConnectorUnavailable("P5 canonical write coordinator is not verified; use dry-run plans")

    def cancel_operation(self,row,transaction_id,event_id):
        from copy import deepcopy
        from .write_models import NativeOperation
        metadata=deepcopy(row.get("extendedProperties",{}).get("private",{}))
        keys={"mio_cancel_marker","mio_cancel_event","mio_cancel_transaction"}
        if keys.intersection(metadata): raise ValueError("event already carries a cancellation record")
        before={"id":row["id"],"status":row.get("status","confirmed"),
                "extendedProperties":{"private":{**metadata,**{key:None for key in keys}}}}
        marker=transaction_id+":calendar.cancel"
        after={"id":row["id"],"status":"cancelled","extendedProperties":{"private":{**metadata,
            "mio_cancel_marker":marker,"mio_cancel_event":event_id,"mio_cancel_transaction":transaction_id}}}
        return NativeOperation(operation_id="calendar.cancel",connector="calendar",kind="calendar.cancel",
            target=self.calendar_id,domain="calendar",before=before,after=after,
            expected_version=row["etag"],replay_safe=True,marker=marker)
