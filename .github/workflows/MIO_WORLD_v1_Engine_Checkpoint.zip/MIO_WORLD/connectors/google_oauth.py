"""Refresh-aware Google Bearer credentials; in-memory store, no login or disk secrets.

Token exchange accepts only Google's HTTPS endpoint (or explicit loopback
fixtures). Authorization consent and Android sealed storage remain separate.
"""
import json
import threading
from contextlib import contextmanager
from dataclasses import dataclass, replace
from datetime import datetime, timedelta, timezone
from http.client import HTTPException
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener
from .http_json import ConnectorUnavailable, NoRedirect


class OAuthRefreshUnavailable(ConnectorUnavailable): pass
class ReauthorizationRequired(ConnectorUnavailable): pass
class OAuthConfigurationRequired(ConnectorUnavailable): pass


def _secret(value, optional=False):
    if optional and value is None: return None
    if not isinstance(value, str) or not value or len(value) > 16384 or any(ord(c) < 33 or ord(c) > 126 for c in value):
        raise ValueError('invalid credential value')
    return value


def _time(value):
    if not isinstance(value, datetime) or value.tzinfo is None or value.utcoffset() is None:
        raise ValueError('timezone-aware credential time required')
    return value.astimezone(timezone.utc)


def _scopes(values):
    if not isinstance(values, (tuple, list)) or len(values) > 64:
        raise ValueError('invalid granted scopes')
    return tuple(sorted(set(_secret(v) for v in values)))


@dataclass(frozen=True, repr=False)
class OAuthGrant:
    client_id: str
    refresh_token: str
    access_token: str | None = None
    expires_at: datetime | None = None
    scopes: tuple[str, ...] = ()
    client_secret: str | None = None
    refresh_expires_at: datetime | None = None
    issued_at: datetime | None = None

    def __post_init__(self):
        _secret(self.client_id); _secret(self.refresh_token)
        _secret(self.access_token, optional=True); _secret(self.client_secret, optional=True)
        object.__setattr__(self, 'scopes', _scopes(self.scopes))
        for key in ('expires_at', 'refresh_expires_at', 'issued_at'):
            value = getattr(self, key)
            if value is not None: object.__setattr__(self, key, _time(value))
        if self.access_token is None and self.expires_at is not None:
            raise ValueError('access expiry without a token')

    def __repr__(self): return '<OAuthGrant redacted>'


class MemoryTokenStore:
    """Process-local only. Never presented as encrypted or restart-persistent."""
    def __init__(self, grant):
        if not isinstance(grant, OAuthGrant): raise TypeError('OAuthGrant required')
        self._grant = grant; self._lock = threading.RLock(); self._revision = 0
        self._reauthorization = False

    @contextmanager
    def locked(self):
        with self._lock: yield

    @property
    def revision(self): return self._revision

    def load(self): return self._grant

    def save(self, grant):
        if not isinstance(grant, OAuthGrant): raise TypeError('OAuthGrant required')
        with self._lock:
            self._grant = grant; self._revision += 1; self._reauthorization = False

    def invalidate(self):
        with self._lock:
            self._grant = None; self._revision += 1; self._reauthorization = True

    def diagnostic(self):
        with self._lock:
            return {'credential_configured': self._grant is not None,
                    'reauthorization_required': self._reauthorization,
                    'storage': 'PROCESS_MEMORY_ONLY', 'encrypted_storage_implemented': False}

    def __repr__(self): return '<MemoryTokenStore redacted>'


class GoogleTokenEndpoint:
    def __init__(self, url='https://oauth2.googleapis.com/token', fixture=False, timeout=20):
        parsed = urlsplit(url)
        if parsed.username or parsed.password or parsed.query or parsed.fragment or parsed.path != '/token':
            raise ValueError('invalid OAuth endpoint')
        if fixture:
            if parsed.scheme not in {'http', 'https'} or parsed.hostname not in {'127.0.0.1', '::1', 'localhost'}:
                raise ValueError('OAuth fixture must stay on loopback')
        elif url != 'https://oauth2.googleapis.com/token':
            raise ValueError('unexpected Google OAuth endpoint')
        if type(timeout) not in {int, float} or not 0 < timeout <= 60:
            raise ValueError('invalid OAuth timeout')
        self.url = url; self.fixture = bool(fixture); self.timeout = timeout
        self.opener = build_opener(NoRedirect())

    @staticmethod
    def _read(stream):
        raw = stream.read(65537)
        if len(raw) > 65536: raise OAuthRefreshUnavailable('OAuth response exceeded read budget')
        value = json.loads(raw)
        if not isinstance(value, dict): raise OAuthRefreshUnavailable('invalid OAuth response')
        return value

    def refresh(self, grant):
        body = {'client_id': grant.client_id, 'refresh_token': grant.refresh_token, 'grant_type': 'refresh_token'}
        if grant.client_secret is not None: body['client_secret'] = grant.client_secret
        request = Request(self.url, data=urlencode(body).encode('ascii'), method='POST',
            headers={'Content-Type': 'application/x-www-form-urlencoded', 'Accept': 'application/json'})
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                return self._read(response)
        except HTTPError as error:
            status = error.code
            try:
                try: payload = self._read(error)
                except (ValueError, OAuthRefreshUnavailable, HTTPException, OSError): payload = {}
            finally: error.close()
            if status == 400 and payload.get('error') == 'invalid_grant':
                raise ReauthorizationRequired('Google authorization must be renewed') from None
            if status in {400, 401} and payload.get('error') in {'invalid_client', 'unauthorized_client', 'unsupported_grant_type', 'invalid_scope'}:
                raise OAuthConfigurationRequired('Google OAuth client configuration requires review') from None
            raise OAuthRefreshUnavailable('OAuth HTTP ' + str(status)) from None
        except (URLError, TimeoutError, ValueError, HTTPException, OSError):
            raise OAuthRefreshUnavailable('OAuth transport or response unavailable') from None

    def __repr__(self): return '<GoogleTokenEndpoint>'


class GoogleAccessTokenProvider:
    """One refresh under the store lock; one bounded HTTP request per attempt."""
    def __init__(self, store, endpoint, clock=None, refresh_margin=60, retry_delay=30, required_scopes=()):
        if not isinstance(store, MemoryTokenStore) or not isinstance(endpoint, GoogleTokenEndpoint):
            raise TypeError('explicit token store and Google endpoint required')
        if type(refresh_margin) is not int or not 0 <= refresh_margin <= 300:
            raise ValueError('invalid refresh margin')
        if type(retry_delay) is not int or not 1 <= retry_delay <= 300:
            raise ValueError('invalid OAuth retry delay')
        self.store = store; self.endpoint = endpoint; self.fixture = endpoint.fixture
        self.clock = clock or (lambda: datetime.now(timezone.utc))
        self.margin = timedelta(seconds=refresh_margin); self.retry_delay = timedelta(seconds=retry_delay)
        self.required_scopes = set(_scopes(required_scopes))
        self._last_time = None; self._hold_until = None; self._held_revision = None
        self._configuration_revision = None

    def _now(self):
        now = _time(self.clock())
        if self._last_time is not None and now < self._last_time:
            raise OAuthRefreshUnavailable('credential clock moved backwards')
        self._last_time = now
        return now

    def _validate_response(self, value, grant, started):
        if not isinstance(value, dict) or value.get('token_type') != 'Bearer':
            raise OAuthRefreshUnavailable('invalid OAuth token response')
        ttl = value.get('expires_in')
        if type(ttl) is not int or not self.margin.total_seconds() < ttl <= 86400:
            raise OAuthRefreshUnavailable('invalid OAuth access lifetime')
        try:
            access = _secret(value.get('access_token'))
            refresh = _secret(value['refresh_token']) if 'refresh_token' in value else grant.refresh_token
            scopes = grant.scopes
            if 'scope' in value:
                if not isinstance(value['scope'], str) or len(value['scope']) > 8192:
                    raise ValueError('invalid scope response')
                scopes = _scopes(value['scope'].split(' '))
            if not self.required_scopes.issubset(scopes):
                raise OAuthConfigurationRequired('required Calendar authorization scopes are absent')
            refresh_expiry = grant.refresh_expires_at
            if 'refresh_token_expires_in' in value:
                refresh_ttl = value['refresh_token_expires_in']
                if type(refresh_ttl) is not int or not 0 < refresh_ttl <= 2147483647:
                    raise ValueError('invalid refresh lifetime')
                refresh_expiry = started + timedelta(seconds=refresh_ttl)
            result = replace(grant, access_token=access, refresh_token=refresh,
                expires_at=started+timedelta(seconds=ttl), scopes=scopes,
                refresh_expires_at=refresh_expiry, issued_at=started)
        except ValueError:
            raise OAuthRefreshUnavailable('invalid OAuth credential response') from None
        if result.expires_at <= self._now()+self.margin:
            raise OAuthRefreshUnavailable('OAuth response arrived too late')
        return result

    def access_token(self):
        with self.store.locked():
            now = self._now(); grant = self.store.load(); revision = self.store.revision
            if grant is None: raise ReauthorizationRequired('Google authorization must be renewed')
            if grant.issued_at is not None and now < grant.issued_at:
                raise OAuthRefreshUnavailable('credential clock precedes issue time')
            if self._configuration_revision == revision:
                raise OAuthConfigurationRequired('Google OAuth client configuration requires review')
            if grant.refresh_expires_at is not None and grant.refresh_expires_at <= now:
                self.store.invalidate()
                raise ReauthorizationRequired('Google authorization must be renewed')
            if grant.access_token and grant.expires_at is not None and grant.expires_at > now+self.margin:
                if not self.required_scopes.issubset(grant.scopes):
                    raise OAuthConfigurationRequired('required Calendar authorization scopes are absent')
                return grant.access_token
            if self._held_revision == revision and self._hold_until is not None and now < self._hold_until:
                raise OAuthRefreshUnavailable('OAuth refresh retry is deferred')
            try:
                fresh = self._validate_response(self.endpoint.refresh(grant), grant, now)
            except ReauthorizationRequired:
                self.store.invalidate()
                raise
            except OAuthConfigurationRequired:
                self._configuration_revision = revision
                raise
            except ConnectorUnavailable:
                self._hold_until = now+self.retry_delay; self._held_revision = revision
                raise
            self.store.save(fresh)
            self._hold_until = None; self._held_revision = None; self._configuration_revision = None
            return fresh.access_token

    def reject(self, sent_token, reauthorize=False):
        """A stale in-flight 401 must not invalidate another worker's new token."""
        with self.store.locked():
            grant = self.store.load()
            if grant is not None and grant.access_token == sent_token:
                if reauthorize: self.store.invalidate()
                elif grant.expires_at is not None: self.store.save(replace(grant, expires_at=None))

    def __repr__(self): return '<GoogleAccessTokenProvider redacted>'
