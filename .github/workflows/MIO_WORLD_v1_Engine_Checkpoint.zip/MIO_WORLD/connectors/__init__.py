"""Canonical adapters. External mutations always expose a dry-run plan."""
