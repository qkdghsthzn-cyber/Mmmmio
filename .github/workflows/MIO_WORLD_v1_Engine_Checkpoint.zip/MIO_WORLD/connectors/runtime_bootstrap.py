"""Explicit world seed + freshly read native truth; never loads mock_state."""
import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from pydantic import Field, field_validator, model_validator
from core.models import Model, WorldState, Needs, NPC, Taste, Item, State, Wallet, Provenance
from core.validator import RuleViolation, Validator
from .write_models import digest
from .native_plans import plain, unique_field, unique_table, money_field
from .canonical_runtime import fresh
from .calendar_truth import commitments


class RuntimeResources(Model):
    wallet_page: str = Field(min_length=1)
    inventory_source: str = Field(min_length=1)
    continuity_page: str = Field(min_length=1)
    relationships_page: str = Field(min_length=1)
    taste_page: str = Field(min_length=1)
    memory_page: str = Field(min_length=1)
    world_runtime_page: str = Field(min_length=1)
    calendar_id: str = Field(min_length=1)

    @model_validator(mode="after")
    def separate_runtime_page(self):
        legacy={self.wallet_page,self.continuity_page,self.relationships_page,self.taste_page,self.memory_page}
        if self.world_runtime_page in legacy:
            raise ValueError("world snapshots need a separate explicitly configured runtime page")
        return self

    @property
    def additional_pages(self):
        return {"relationships":self.relationships_page,"taste":self.taste_page,
                "memory":self.memory_page,"world":self.world_runtime_page}


class InitializationRequest(Model):
    initialization_ref: str = Field(min_length=1)
    internal_values_ref: str = Field(min_length=1)
    world: WorldState
    travel_minutes: dict[str,int]
    feature_flags: dict[str,bool]
    relationships: dict[str,NPC]
    npc_age_refs: dict[str,str]
    npc_metric_refs: dict[str,str]
    taste: dict[str,Taste]
    taste_metric_refs: dict[str,str]
    catalog: dict[str,Item]

    @field_validator("world", mode="before")
    @classmethod
    def explicit_world(cls,value):
        if not isinstance(value,dict):
            value=value.model_dump(mode="json")
        required={"time","timezone","place","activity","mood","privacy","next_commitment","journey","needs"}
        if not required<=set(value) or set(value["needs"])!=set(Needs.model_fields):
            raise ValueError("initialization must explicitly supply all world/need fields")
        ZoneInfo(value["timezone"])
        if not value["place"] or value["journey"] is not None:
            raise ValueError("initial location must be confirmed; an unlogged journey cannot be seeded")
        return value

    @field_validator("travel_minutes")
    @classmethod
    def routes(cls,value):
        if any(not isinstance(v,int) or isinstance(v,bool) or v<0 or '->' not in k for k,v in value.items()):
            raise ValueError("explicit nonnegative travel routes required")
        return value

    @model_validator(mode="after")
    def metric_evidence(self):
        for key in self.relationships:
            if not self.npc_age_refs.get(key) or not self.npc_metric_refs.get(key):
                raise ValueError("NPC age and internal metrics require separate initialization references")
        for key in self.taste:
            if not self.taste_metric_refs.get(key):
                raise ValueError("taste metrics need an explicit initialization reference")
        return self


def inventory_items(rows,scope,now):
    items={}
    for row in rows:
        props=row.get('properties',{})
        if row.get('archived') or row.get('in_trash') or (props.get('Status',{}).get('select') or {}).get('name')!='Owned':
            continue
        identifier=row['id']; name=plain(props['Item']['title'])
        if not name or identifier in items or not row.get('last_edited_time'): raise RuleViolation('invalid/duplicate/unversioned native Inventory identity')
        category=(props.get('Category',{}).get('select') or {}).get('name')
        brand=plain(props.get('Brand',{}).get('rich_text',[])) or None
        location=plain(props.get('Location',{}).get('rich_text',[])) or None
        condition=(props.get('Condition',{}).get('select') or {}).get('name')
        acquired=(props.get('Acquired',{}).get('date') or {}).get('start')
        # A native date without time does not assert a time of acquisition.
        acquired_at=datetime.fromisoformat(acquired) if acquired and 'T' in acquired else None
        if acquired_at is not None and acquired_at.tzinfo is None: raise RuleViolation('native acquisition timestamp needs timezone')
        items[identifier]=Item(item_id=identifier,name=name,status='owned',category=category.lower() if category else 'unknown',
            brand=brand,price=props.get('Purchase Price',{}).get('number'),acquired_at=acquired_at,
            location=location,condition=condition,source_event=None,
            provenance=Provenance(source='mock' if scope=='fixture' else 'canonical',
                ref='notion:'+identifier+':'+str(row.get('last_edited_time','unversioned')),verified_at=now))
    return items


class NativeBootstrapper:
    def __init__(self,notion,calendar,clock):
        self.notion=notion; self.calendar=calendar; self.clock=clock

    def initialize(self,bridge,request,resources):
        request=InitializationRequest.model_validate_json(request.model_dump_json())
        resources=RuntimeResources.model_validate_json(resources.model_dump_json())
        db=bridge.db
        if db.execute('SELECT 1 FROM runtime_cache').fetchone():
            raise RuleViolation('runtime already initialized; resume its durable cache instead of reseeding')
        scope='fixture' if self.notion.http.fixture else 'canonical'
        if bool(self.notion.http.fixture)!=bool(self.calendar.http.fixture): raise RuleViolation('mixed canonical/fixture providers')
        if self.calendar.calendar_id!=resources.calendar_id: raise RuleViolation('Calendar account/resource mismatch')
        now=self.clock()
        if request.world.time.astimezone(timezone.utc)!=now.astimezone(timezone.utc): raise RuleViolation('initialization world clock must match read time')
        if now.astimezone(ZoneInfo(request.world.timezone)).utcoffset()!=request.world.time.utcoffset():
            raise RuleViolation('world time offset differs from its named timezone')
        targets={'wallet':resources.wallet_page,'continuity':resources.continuity_page,**resources.additional_pages}
        pages={role:self.notion.page(identifier) for role,identifier in targets.items()}
        for role,page in pages.items():
            if not page['page'].get('id') or not page['page'].get('last_edited_time') or page['page'].get('archived') or page['page'].get('in_trash'):
                raise RuleViolation('active/versioned native page required: '+role)
            if page['page']['id'].replace('-','')!=targets[role].replace('-',''):
                raise RuleViolation('native page identity differs from configured resource')
        schema=self.notion.data_source(resources.inventory_source)
        if schema.get('id','').replace('-','')!=resources.inventory_source.replace('-','') or not schema.get('last_edited_time'):
            raise RuleViolation('native Inventory schema identity/version mismatch')
        rows=self.notion.inventory_rows(resources.inventory_source)
        metadata=self.calendar.metadata()
        if metadata.get('id')!=resources.calendar_id and resources.calendar_id!='primary': raise RuleViolation('native Calendar identity mismatch')
        ZoneInfo(metadata['timeZone'])
        start=now-timedelta(days=1); end=now+timedelta(days=8)
        calendar_rows=self.calendar.events(start,end,query='')
        completed_at=self.clock(); fresh(now,completed_at)
        balance,_=money_field(unique_field(pages['wallet']['blocks'],'残高:'),'残高:',0)
        wishlist_table=unique_table(pages['wallet']['blocks'],['見つけた日','欲しいもの','だいたいの値段','欲しさ','状態','メモ'])
        wishlist={}
        for row in wishlist_table['children'][1:]:
            status=plain(row['table_row']['cells'][4])
            wishlist[row['id']]='purchased' if status in {'購入済み','Purchased'} else 'deferred' if status in {'保留','Deferred'} else 'wanted'
        state=State(mode='mock' if scope=='fixture' else 'live',world=request.world.model_copy(deep=True),
            wallet=Wallet(balance=balance,reserved_amount=0),inventory=inventory_items(rows,scope,now),
            catalog=request.catalog,relationships=request.relationships,taste=request.taste,wishlist=wishlist,
            calendar=commitments(calendar_rows,now,scope,metadata['timeZone']),
            feature_flags=request.feature_flags,travel_minutes=request.travel_minutes,
            provenance=Provenance(source='mock' if scope=='fixture' else 'canonical',ref=request.initialization_ref,verified_at=now))
        if scope=='canonical':
            for entity in [*state.inventory.values(),*state.relationships.values(),*state.catalog.values()]:
                if entity.provenance.source in {'mock','unverified'}: raise RuleViolation('unverified initialization entity')
        Validator.invariants(state)
        proof={'request':request.model_dump(mode='json'),'resources':resources.model_dump(mode='json'),
               'scope':scope,'read_at':completed_at.isoformat(),'pages':pages,'inventory_schema':schema,'inventory_rows':rows,
               'calendar_metadata':metadata,'calendar_window':[start.isoformat(),end.isoformat()],'calendar_rows':calendar_rows,
               'unmapped_qualitative_sources_preserved':True,'external_writes':0}
        db.execute('CREATE TABLE IF NOT EXISTS runtime_initialization(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL,proof_hash TEXT NOT NULL)')
        from .native_rebase import NativeCacheReconciler
        from .native_plans import CanonicalEvidence
        native=CanonicalEvidence(scope=scope,read_at=completed_at,notion_stale=False,wallet=pages['wallet'],
            inventory_schema=schema,inventory_rows=rows,continuity_page=pages['continuity'],reserved_jpy=0)
        reconciler=NativeCacheReconciler(bridge)
        with bridge.coordinator.atomic():
            db.execute('INSERT INTO runtime_cache VALUES(1,?,?)',(state.model_dump_json(),scope))
            db.execute('INSERT INTO runtime_initialization VALUES(1,?,?)',(json.dumps(proof,ensure_ascii=False),digest(proof)))
            reconciler.anchor(native,completed_at,within_atomic=True)
        return state
