import json
from urllib.request import Request, build_opener, HTTPRedirectHandler
from urllib.error import HTTPError, URLError
from urllib.parse import urlsplit
from http.client import HTTPException


class ConnectorUnavailable(RuntimeError): pass


class HTTPFailure(ConnectorUnavailable):
    def __init__(self, status):
        self.status = status
        # Provider bodies may contain private content or secrets. Never log them.
        super().__init__("provider HTTP " + str(status))


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


class HTTPJSON:
    def __init__(self, base_url, token=None, headers=None, timeout=20, fixture=False, token_provider=None):
        if bool(token) == (token_provider is not None):
            raise ConnectorUnavailable("configure exactly one connector credential source")
        parsed = urlsplit(base_url)
        if parsed.username or parsed.password or parsed.query or parsed.fragment:
            raise ValueError("invalid provider base URL")
        if fixture:
            if parsed.hostname not in {"127.0.0.1", "::1", "localhost"} or parsed.scheme not in {"http", "https"}:
                raise ValueError("fixture transport must stay on loopback")
        elif parsed.scheme != "https" or parsed.hostname not in {"api.notion.com", "www.googleapis.com"}:
            raise ValueError("unexpected native provider host")
        if token_provider is not None:
            from .google_oauth import GoogleAccessTokenProvider
            if not isinstance(token_provider, GoogleAccessTokenProvider) or bool(fixture) != token_provider.fixture:
                raise ValueError("OAuth credential scope differs from API transport")
            if not fixture and parsed.hostname != "www.googleapis.com":
                raise ValueError("Google credentials require a Google API host")
        self.base_url=base_url.rstrip("/"); self._token=token; self.headers=headers or {}; self.timeout=timeout
        self.token_provider=token_provider
        self.fixture=fixture; self.opener=build_opener(NoRedirect())

    def request(self, method, path, body=None, dry_run=False, headers=None):
        if not path.startswith("/") or path.startswith("//") or any(c in path for c in ["\\", "\n", "\r", "://"]):
            raise ValueError("invalid relative provider path")
        if method!="GET" and dry_run:
            return {"dry_run":True,"method":method,"path":path,"body":body}
        data=json.dumps(body,ensure_ascii=False,allow_nan=False).encode() if body is not None else None
        extra={**self.headers, **(headers or {})}
        if any(k.lower() in {"authorization", "host", "content-type"} for k in extra):
            raise ValueError("reserved HTTP header override")
        token=self.token_provider.access_token() if self.token_provider else self._token
        try:
            return self._send(method,path,data,extra,token)
        except HTTPFailure as error:
            if error.status != 401 or self.token_provider is None: raise
            self.token_provider.reject(token)
            # A credential refresh must never replay a possibly mutating request.
            if method != "GET": raise
            fresh=self.token_provider.access_token()
            try:
                return self._send(method,path,data,extra,fresh)
            except HTTPFailure as second:
                if second.status == 401: self.token_provider.reject(fresh,reauthorize=True)
                raise

    def _send(self,method,path,data,extra,token):
        req=Request(self.base_url+path,data=data,method=method,headers={"Authorization":"Bearer "+token,"Content-Type":"application/json",**extra})
        try:
            with self.opener.open(req,timeout=self.timeout) as r:
                raw=r.read(8_000_001)
                if len(raw)>8_000_000: raise ConnectorUnavailable("provider response exceeded read budget")
                return json.loads(raw) if raw else {}
        except HTTPError as error:
            status=error.code; error.close()
            raise HTTPFailure(status) from None
        except (URLError,TimeoutError,ValueError,HTTPException,OSError) as error:
            raise ConnectorUnavailable(type(error).__name__) from None
