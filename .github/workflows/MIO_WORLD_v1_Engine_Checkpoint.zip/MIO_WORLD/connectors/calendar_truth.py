"""Native Calendar intervals. Unknown places never become a home location."""
from datetime import datetime, time, date
from zoneinfo import ZoneInfo
from core.models import Commitment, Provenance, aware
from core.validator import RuleViolation

UNKNOWN_PLACE = "__unknown_calendar_location__"


def interval(row, calendar_timezone=None):
    def endpoint(value):
        if "dateTime" in value:
            result = datetime.fromisoformat(value["dateTime"])
            if result.tzinfo is None:
                if not value.get("timeZone"):
                    raise RuleViolation("native Calendar timestamp has no timezone")
                result = result.replace(tzinfo=ZoneInfo(value["timeZone"]))
            return aware(result)
        if "date" in value and calendar_timezone:
            return datetime.combine(date.fromisoformat(value["date"]), time(), ZoneInfo(calendar_timezone))
        raise RuleViolation("all-day Calendar needs verified calendar timezone")
    start, end = endpoint(row["start"]), endpoint(row["end"])
    if end <= start:
        raise RuleViolation("native Calendar interval is invalid")
    # Google end is exclusive, including all-day events and DST transitions.
    return start, end


def commitments(rows, now, scope, calendar_timezone=None, location_map=None):
    result = []; identifiers = set(); location_map = location_map or {}
    for row in rows:
        if row.get("status") == "cancelled":
            continue
        identifier = row["id"]
        if identifier in identifiers:
            raise RuleViolation("duplicate Calendar instance in read evidence")
        identifiers.add(identifier)
        start, end = interval(row, calendar_timezone)
        native_location = row.get("location")
        location = location_map.get(identifier, native_location or UNKNOWN_PLACE)
        result.append(Commitment(commitment_id=identifier, start=start, end=end,
            title=row.get("summary") or "(untitled Calendar event)",
            flexibility="flexible" if row.get("transparency") == "transparent" else "fixed",
            participants=[], source_event=row.get("extendedProperties", {}).get("private", {}).get("mio_source_event") or "calendar:"+identifier,
            location=location, status="completed" if end <= now else "scheduled",
            provenance=Provenance(source="mock" if scope == "fixture" else "canonical",
                ref="calendar:"+identifier+":"+str(row.get("etag", "unversioned")), verified_at=now)))
    return result
