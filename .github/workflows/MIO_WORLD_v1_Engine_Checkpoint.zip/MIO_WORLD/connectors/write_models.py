"""Validated native mutation plans. No credential or guessed canonical values."""
import hashlib
import json
from datetime import datetime
from typing import Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                    separators=(",", ":"), allow_nan=False).encode()).hexdigest()


class StrictModel(BaseModel):
    model_config = ConfigDict(extra="forbid", frozen=True)


class NativeOperation(StrictModel):
    operation_id: str = Field(min_length=1)
    connector: Literal["notion", "calendar"]
    kind: Literal["block.patch", "table.append", "page.append", "inventory.create", "calendar.create", "calendar.cancel"]
    target: str = Field(min_length=1)
    domain: Literal["wallet", "inventory", "calendar", "wishlist", "continuity", "world", "relationships", "taste"]
    before: dict | None = None  # Only fields managed by this operation.
    after: dict
    expected_version: str | None = None
    # Native POST/append has no documented client idempotency in Notion.
    replay_safe: bool = False
    marker: str = Field(min_length=1)

    @model_validator(mode="after")
    def contract(self):
        notion_kind = not self.kind.startswith("calendar.")
        if notion_kind != (self.connector == "notion"):
            raise ValueError("connector/kind mismatch")
        if self.kind in {"block.patch", "calendar.cancel"} and (self.before is None or not self.expected_version):
            raise ValueError("native field patch requires before image and version")
        if self.kind not in {"block.patch", "calendar.cancel"} and self.before is not None:
            raise ValueError("creation must have no existing before image")
        if self.replay_safe != (self.kind in {"block.patch", "calendar.create", "calendar.cancel"}):
            raise ValueError("Notion creation/append cannot be safely replayed")
        if self.kind == "calendar.create":
            if "attendees" in self.after:
                raise ValueError("fictional NPCs must not invite real calendar recipients")
            start = datetime.fromisoformat(self.after["start"]["dateTime"])
            end = datetime.fromisoformat(self.after["end"]["dateTime"])
            if start.tzinfo is None or end.tzinfo is None or end <= start:
                raise ValueError("invalid timezone-aware calendar interval")
            identifier = self.after["id"]
            if not 5 <= len(identifier) <= 1024 or any(c not in "0123456789abcdefghijklmnopqrstuv" for c in identifier):
                raise ValueError("invalid supplied Google event ID")
        digest(self.before)
        digest(self.after)  # Reject nonfinite JSON.
        if self.kind == "calendar.cancel":
            if set(self.after) != {"id", "status", "extendedProperties"} or set(self.before) != set(self.after):
                raise ValueError("cancellation manages only identity/status/private provenance")
            if self.after["status"] != "cancelled" or self.before["status"] not in {"confirmed", "tentative"}:
                raise ValueError("invalid cancellation before/after status")
            if self.before["id"] != self.after["id"]:
                raise ValueError("cancellation cannot change identity")
            private=self.after["extendedProperties"]["private"]
            if private.get("mio_cancel_marker") != self.marker:
                raise ValueError("cancellation authorship marker required")
            keys={"mio_cancel_marker","mio_cancel_event","mio_cancel_transaction"}
            before_private=self.before["extendedProperties"]["private"]
            if any(before_private.get(key) is not None for key in keys) or {k:v for k,v in private.items() if k not in keys}!={k:v for k,v in before_private.items() if k not in keys}:
                raise ValueError("cancellation must preserve other private metadata")
        return self

    @property
    def resource_key(self):
        return self.connector + ":" + self.target


class WritePlan(StrictModel):
    transaction_id: str
    event_id: str = Field(min_length=1)
    decision_id: str = Field(min_length=1)
    evidence_scope: Literal["fixture", "canonical"]
    source_versions: dict[str, str]
    operations: list[NativeOperation] = Field(min_length=1, max_length=40)

    @model_validator(mode="after")
    def contract(self):
        expected = "ext_" + digest({"event_id": self.event_id})[:24]
        if self.transaction_id != expected:
            raise ValueError("transaction ID must be derived from event ID")
        ids = [o.operation_id for o in self.operations]
        if len(set(ids)) != len(ids):
            raise ValueError("duplicate operation ID")
        patches = [o.resource_key for o in self.operations if o.kind == "block.patch"]
        if len(set(patches)) != len(patches):
            raise ValueError("one field patch per native block per transaction")
        if any(not o.marker.startswith(self.transaction_id + ":") for o in self.operations):
            raise ValueError("operation provenance must include transaction ID")
        for op in self.operations:
            if op.kind == "calendar.create":
                metadata = op.after.get("extendedProperties", {}).get("private", {})
                if metadata.get("mio_transaction") != self.transaction_id or metadata.get("mio_source_event") != self.event_id:
                    raise ValueError("calendar provenance does not match this event/transaction")
            if op.kind == "calendar.cancel":
                metadata=op.after["extendedProperties"]["private"]
                if metadata.get("mio_cancel_event") != self.event_id or metadata.get("mio_cancel_transaction") != self.transaction_id:
                    raise ValueError("cancellation provenance does not match plan")
        return self


def transaction_id(event_id):
    return "ext_" + digest({"event_id": event_id})[:24]
