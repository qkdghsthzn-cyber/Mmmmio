from .http_json import ConnectorUnavailable


class CanonicalReadSync:
    def __init__(self,notion,calendar): self.notion=notion; self.calendar=calendar

    def read(self,state,page_ids,inventory_id,start,end):
        result={}
        try:
            result["pages"]={name:self.notion.page(identifier) for name,identifier in page_ids.items()}
            result["inventory"]=self.notion.inventory_rows(inventory_id)
            state.notion_stale=False
        except ConnectorUnavailable:
            state.notion_stale=True; result["notion_error"]="stale_cache"
        try:
            result["calendar"]=self.calendar.events(start,end)
            state.calendar_stale=False
        except ConnectorUnavailable:
            state.calendar_stale=True; result["calendar_error"]="stale_cache"
        # Faithful native reads are evidence, not permission to guess missing
        # runtime needs, numeric relationship scores, ages or product ownership.
        return result
