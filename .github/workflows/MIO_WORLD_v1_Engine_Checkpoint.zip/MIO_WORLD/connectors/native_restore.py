"""Restore cache/causal archive from receipt-verified native checkpoints.

Requires the durable coordinator and initialization proof. No fixture-to-live
promotion, unverified journal replay, or rollback of a newer usable cache.
"""
import base64
import json
import zlib
from datetime import datetime,timezone
from core.models import State,ContinuityEdge
from core.validator import RuleViolation,Validator
from .write_models import digest
from .native_journals import append_record
from .native_plans import plain
from .http_json import ConnectorUnavailable
from .runtime_bootstrap import RuntimeResources
from .canonical_runtime import RuntimeEvidenceReader


MAX_BYTES=16*1024*1024
PART_SIZE=60000


def checkpoint_payload(runtime,state):
    return {'format':'native-cache-v1','initialization_hash':digest(runtime.initialization),
        'state':state.model_dump(mode='json'),
        'continuity_archive':[json.loads(row[0]) for row in runtime.db.execute('SELECT body FROM runtime_continuity_archive ORDER BY edge_id')],
        'committed_transactions':[row[0] for row in runtime.db.execute('SELECT transaction_id FROM canonical_commits ORDER BY transaction_id')],
        'rebase_proofs':[row[0] for row in runtime.db.execute('SELECT proof_hash FROM native_rebase_journal ORDER BY proof_hash')]}


def checkpoint_operations(page,tx,record):
    """Chunked native blocks keep large states below per-request text limits."""
    payload=record.get('cache_checkpoint')
    if payload is None: return [append_record(page,tx,'world.snapshot','world',record)]
    raw=json.dumps(payload,ensure_ascii=False,sort_keys=True,separators=(',',':'),allow_nan=False).encode()
    if len(raw)>MAX_BYTES: raise RuleViolation('checkpoint exceeds bounded recovery size')
    encoded=base64.b64encode(zlib.compress(raw,9)).decode()
    chunks=[encoded[i:i+PART_SIZE] for i in range(0,len(encoded),PART_SIZE)]
    if len(chunks)>39: raise RuleViolation('checkpoint exceeds native operation budget')
    operations=[]
    for index,part in enumerate(chunks):
        op=append_record(page,tx,'world.checkpoint.'+str(index),'world',
            {'kind':'runtime_checkpoint_part','scope':record['scope'],'tick_id':record['tick_id'],'index':index,'payload':part})
        if index: op=op.model_copy(update={'expected_version':None})
        operations.append(op)
    header={k:v for k,v in record.items() if k!='cache_checkpoint'}
    # Full histories live in the bounded fragments; keep the overview small.
    for key in ['hooks','novelty_memory']:
        if key in header:
            header[key+'_count']=len(header.pop(key))
    header['recovery']={'format':'native-cache-v1','part_count':len(chunks),'payload_hash':digest(payload),'size_bytes':len(raw)}
    operations.append(append_record(page,tx,'world.snapshot','world',header).model_copy(update={'expected_version':None}))
    return operations


def decode_payload(parts,size):
    if not 0<size<=MAX_BYTES: raise RuleViolation('invalid checkpoint size')
    try:
        encoded=''.join(parts); compressed=base64.b64decode(encoded,validate=True)
        decoder=zlib.decompressobj(); raw=decoder.decompress(compressed,MAX_BYTES+1)
        if not decoder.eof or decoder.unused_data or decoder.unconsumed_tail or len(raw)!=size:
            raise ValueError('incomplete/oversized checkpoint')
        return json.loads(raw)
    except (ValueError,zlib.error): raise RuleViolation('native checkpoint payload is invalid') from None


class NativeRuntimeRestorer:
    def __init__(self,bridge,notion,calendar,clock):
        self.bridge=bridge; self.db=bridge.db; self.notion=notion; self.calendar=calendar; self.clock=clock

    def restore(self):
        with self.bridge.coordinator.worker_lock():
            tables={row[0] for row in self.db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
            if not {'runtime_initialization','hourly_snapshots','hourly_ticks','hourly_mutations','native_rebase_journal'}<=tables:
                raise RuleViolation('restore requires the preserved durable runtime/coordinator database')
            proof=self.db.execute('SELECT body,proof_hash FROM runtime_initialization WHERE id=1').fetchone()
            if not proof: raise RuleViolation('restoration requires preserved initialization proof')
            initialization=json.loads(proof['body'])
            if digest(initialization)!=proof['proof_hash']: raise RuleViolation('initialization proof changed')
            if initialization['scope']!='fixture' or not self.notion.http.fixture or not self.calendar.http.fixture:
                raise ConnectorUnavailable('production native restoration gate has not passed')
            resources=RuntimeResources.model_validate(initialization['resources'])
            if self.db.execute("SELECT 1 FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchone():
                raise ConnectorUnavailable('recover native transactions before restoring cache')
            if not self.bridge.coordinator.confirmations_allowed():
                raise ConnectorUnavailable('recover uncertain native snapshots before restoring cache')
            snapshot=self.db.execute("SELECT * FROM hourly_snapshots WHERE status='VERIFIED' ORDER BY rowid DESC LIMIT 1").fetchone()
            if not snapshot: raise RuleViolation('no verified native recovery checkpoint')
            tx=snapshot['transaction_id']
            if self.bridge.coordinator.status(tx)!='COMMITTED': raise RuleViolation('checkpoint transaction is not committed')
            page=self.notion.page(resources.world_runtime_page)
            if page['page']['id']!=resources.world_runtime_page or page['page'].get('archived') or page['page'].get('in_trash'):
                raise RuleViolation('native recovery page identity changed')
            records={}
            for row in self.bridge.coordinator.rows(tx):
                op,adapter=self.bridge.coordinator._operation(row)
                if op.target!=resources.world_runtime_page or op.kind!='page.append' or row['status']!='APPLIED' or not row['receipt']:
                    raise RuleViolation('native checkpoint operation is incomplete')
                receipt=json.loads(row['receipt']); observed=adapter.observe(op,receipt)
                if observed.state!='AFTER' or not self.bridge.coordinator._receipt_valid(op,observed.receipt):
                    raise RuleViolation('native checkpoint receipt/version/content differs')
                matches=[block for block in page['blocks'] if block.get('id')==receipt['resource_id']]
                if len(matches)!=1: raise RuleViolation('native checkpoint part is missing/ambiguous')
                records[op.operation_id]=json.loads(plain(matches[0]['code']['rich_text']))
            header=records.get('world.snapshot',{}); metadata=header.get('recovery')
            if not metadata or metadata.get('format')!='native-cache-v1': raise RuleViolation('legacy WORLD snapshot cannot restore full cache')
            if header.get('tick_id')!=snapshot['tick_id'] or header.get('scope')!='fixture':
                raise RuleViolation('native checkpoint scope/tick differs')
            parts=[]
            if not 1<=metadata['part_count']<=39 or len(records)!=metadata['part_count']+1:
                raise RuleViolation('native checkpoint part count differs')
            for index in range(metadata['part_count']):
                part=records.get('world.checkpoint.'+str(index),{})
                if (part.get('index'),part.get('tick_id'),part.get('scope'))!=(index,header['tick_id'],'fixture'):
                    raise RuleViolation('native checkpoint part identity differs')
                parts.append(part['payload'])
            payload=decode_payload(parts,metadata['size_bytes'])
            if digest(payload)!=metadata['payload_hash'] or payload.get('initialization_hash')!=proof['proof_hash']:
                raise RuleViolation('native checkpoint initialization/content hash differs')
            state=State.model_validate(payload['state']); Validator.invariants(state)
            if state.mode!='mock' or digest(state.model_dump(mode='json'))!=header['state_hash']:
                raise RuleViolation('native state hash/scope differs')
            latest=self.db.execute('SELECT time FROM hourly_ticks ORDER BY rowid DESC LIMIT 1').fetchone()
            if not latest or datetime.fromisoformat(latest[0]).astimezone(timezone.utc)!=state.world.time.astimezone(timezone.utc):
                raise RuleViolation('native checkpoint would rewind the durable clock')
            mutation=self.db.execute('SELECT state_hash FROM hourly_mutations ORDER BY id DESC LIMIT 1').fetchone()
            if not mutation or mutation[0]!=header['state_hash']:
                raise RuleViolation('native checkpoint omits newer runtime mutations')
            commits={r[0] for r in self.db.execute('SELECT transaction_id FROM canonical_commits')}
            rebases={r[0] for r in self.db.execute('SELECT proof_hash FROM native_rebase_journal')}
            if commits!=set(payload['committed_transactions'])|{tx} or rebases!=set(payload['rebase_proofs']):
                raise RuleViolation('native checkpoint omits newer native commits/imports')
            existing=self.db.execute('SELECT body,scope FROM runtime_cache WHERE id=1').fetchone()
            if existing:
                if existing['scope']!='fixture': raise RuleViolation('cannot promote fixture checkpoint into a live cache')
                try: usable=State.model_validate_json(existing['body'])
                except ValueError: usable=None
                if usable is not None:
                    ignored={'revision','notion_stale','calendar_stale'}
                    if usable.model_dump(exclude=ignored)==state.model_dump(exclude=ignored):
                        return {'status':'ALREADY_PRESENT','tick_id':header['tick_id']}
                    raise RuleViolation('a usable differing cache must not be overwritten')
            # Freeze external confirmations until fresh native revalidation.
            state.notion_stale=True; state.calendar_stale=True; state.revision+=1
            archive=[ContinuityEdge.model_validate(e) for e in payload['continuity_archive']]
            with self.bridge.coordinator.atomic():
                current=self.db.execute('SELECT body,scope FROM runtime_cache WHERE id=1').fetchone()
                if (tuple(current) if current else None)!=(tuple(existing) if existing else None):
                    raise RuleViolation('cache changed during native restoration')
                self.db.execute('CREATE TABLE IF NOT EXISTS runtime_continuity_archive(edge_id TEXT PRIMARY KEY,body TEXT NOT NULL)')
                for edge in archive:
                    key='|'.join([edge.cause,edge.consequence,edge.transaction_id])
                    old=self.db.execute('SELECT body FROM runtime_continuity_archive WHERE edge_id=?',(key,)).fetchone()
                    if old and ContinuityEdge.model_validate_json(old[0])!=edge:
                        raise RuleViolation('causal archive conflicts with native checkpoint')
                    self.db.execute('INSERT OR IGNORE INTO runtime_continuity_archive VALUES(?,?)',(key,edge.model_dump_json()))
                self.db.execute("INSERT INTO runtime_cache VALUES(1,?,'fixture') ON CONFLICT(id) DO UPDATE SET body=excluded.body",
                    (state.model_dump_json(),))
                self.bridge.coordinator.audit(tx,'NATIVE_CACHE_RESTORED',header['state_hash'])
        # Fresh reads can explain external changes through the existing ledger
        # rebaser. On failure the recovered cache remains explicitly stale.
        try:
            RuntimeEvidenceReader(self.notion,self.calendar,self.clock).read(self.bridge,resources.wallet_page,
                resources.inventory_source,resources.continuity_page,initialization['request']['initialization_ref'],
                additional_pages=resources.additional_pages,reconcile_external=True)
        except (RuleViolation,ConnectorUnavailable): pass
        return {'status':'RESTORED' if self.bridge.confirmations_allowed() else 'RESTORED_STALE',
                'tick_id':header['tick_id'],'external_writes':0}
