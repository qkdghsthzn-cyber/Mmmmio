"""Native Wallet/MONEY LOG, Inventory DB and Continuity plans.

Input is fresh native block/schema evidence plus a confirmed purchase proposal.
The planner preserves unrelated rich text and database properties. It does not
activate canonical writes or substitute fixture ownership for real inventory.
"""
from copy import deepcopy
from datetime import datetime, timedelta, timezone
import re
from pydantic import Field, model_validator
from .write_models import StrictModel, NativeOperation, WritePlan, transaction_id, digest


def rich(text):
    return [{"type": "text", "text": {"content": text}}]


def plain(parts):
    return "".join(p.get("text", {}).get("content", p.get("plain_text", "")) for p in parts)


def writable_rich(parts):
    # Keep links and annotations; omit server-only plain_text/href fields.
    return [{k: deepcopy(v) for k, v in p.items() if k not in {"plain_text", "href"}} for p in parts]


def block_fields(block):
    kind = block["type"]
    if kind == "table_row":
        return {kind: {"cells": [writable_rich(c) for c in block[kind]["cells"]]}}
    data = deepcopy(block[kind])
    if "rich_text" in data:
        data["rich_text"] = writable_rich(data["rich_text"])
    data.pop("children", None)
    return {kind: data}


def money_field(block, label, value):
    kind = block["type"]
    parts = writable_rich(block[kind]["rich_text"])
    joined = plain(parts)
    match = re.fullmatch(re.escape(label) + r"\s*[¥￥]([0-9][0-9,]*)\s*", joined)
    if not match:
        raise ValueError("wallet field has an unfamiliar native format")
    old = int(match.group(1).replace(",", ""))
    # Change only the number, even when it spans rich-text segments.
    start, end = match.span(1)
    result = []; cursor = 0; inserted = False
    for part in parts:
        if part.get("type", "text") != "text":
            raise ValueError("wallet field contains non-text fragments")
        content = part["text"]["content"]; lo = cursor; hi = cursor + len(content)
        if hi <= start or lo >= end:
            result.append(part)
        else:
            left = content[:max(0, start-lo)]
            right = content[max(0, end-lo):] if hi > end else ""
            number = f"{value:,}" if not inserted else ""
            part["text"]["content"] = left + number + right
            inserted = True
            if part["text"]["content"]:
                result.append(part)
        cursor = hi
    fields = block_fields(block)
    fields[kind]["rich_text"] = result
    return old, fields


def flatten(blocks):
    for block in blocks:
        yield block
        yield from flatten(block.get("children", []))


def unique_field(blocks, label):
    matches = [b for b in flatten(blocks) if "rich_text" in b.get(b.get("type"), {})
               and plain(b[b["type"]]["rich_text"]).startswith(label)]
    if len(matches) != 1:
        raise ValueError("wallet field missing or ambiguous: " + label)
    if not matches[0].get("id") or not matches[0].get("last_edited_time"):
        raise ValueError("native block identity/version is required")
    return matches[0]


def unique_table(blocks, header):
    matches = []
    for block in flatten(blocks):
        if block.get("type") != "table" or not block.get("children"):
            continue
        first = block["children"][0]
        if first.get("type") == "table_row" and [plain(c) for c in first["table_row"]["cells"]] == header:
            matches.append(block)
    if len(matches) != 1:
        raise ValueError("native table missing or ambiguous")
    return matches[0]


class CanonicalEvidence(StrictModel):
    scope: str
    read_at: datetime
    notion_stale: bool
    wallet: dict
    inventory_schema: dict
    inventory_rows: list[dict]
    continuity_page: dict
    reserved_jpy: int = Field(ge=0)

    @model_validator(mode="after")
    def validate_evidence(self):
        if self.scope not in {"fixture", "canonical"}:
            raise ValueError("unknown evidence scope")
        if self.read_at.tzinfo is None:
            raise ValueError("timezone-aware read evidence required")
        if self.notion_stale:
            raise ValueError("stale canon cannot change money or ownership")
        return self


class PurchaseProposal(StrictModel):
    item_name: str = Field(min_length=1, max_length=200)
    cost_jpy: int = Field(gt=0, strict=True)
    acquired_at: datetime
    evidence: str = Field(min_length=1, max_length=1000)
    brand: str | None = None
    category: str | None = None
    location: str | None = None
    wishlist_row_id: str | None = None

    @model_validator(mode="after")
    def validate_time(self):
        if self.acquired_at.tzinfo is None:
            raise ValueError("confirmed acquisition time must be timezone-aware")
        return self


def purchase_plan(evidence, proposal, event_id, decision_id, now, ledger_timezone=None):
    evidence = CanonicalEvidence.model_validate_json(evidence.model_dump_json())
    proposal = PurchaseProposal.model_validate_json(proposal.model_dump_json())
    if now.tzinfo is None or not timedelta(0) <= now.astimezone(timezone.utc) - evidence.read_at.astimezone(timezone.utc) <= timedelta(minutes=5):
        raise ValueError("fresh canonical evidence required (max 5 minutes)")
    if proposal.acquired_at.astimezone(timezone.utc) > now.astimezone(timezone.utc):
        raise ValueError("future acquisition cannot be confirmed")
    from zoneinfo import ZoneInfo
    local_now=now.astimezone(ZoneInfo(ledger_timezone)) if ledger_timezone else now
    if proposal.acquired_at.astimezone(local_now.tzinfo).strftime("%Y-%m") != local_now.strftime("%Y-%m"):
        raise ValueError("backdated purchase requires an explicit monthly ledger reconciliation")
    tx = transaction_id(event_id); operations = []
    wallet = evidence.wallet
    blocks = wallet["blocks"]
    from .wallet_month import native_period
    native_period(blocks, local_now)
    balance_block = unique_field(blocks, "残高:")
    spending_block = unique_field(blocks, "今月の支出:")
    balance, _ = money_field(balance_block, "残高:", 0)
    spending, _ = money_field(spending_block, "今月の支出:", 0)
    if balance - evidence.reserved_jpy < proposal.cost_jpy:
        raise ValueError("insufficient canonical available balance")
    def patch(name, block, after, domain):
        if block_fields(block) == after:
            raise ValueError("empty native mutation")
        operations.append(NativeOperation(operation_id=name, connector="notion", kind="block.patch",
             target=block["id"], domain=domain, before=block_fields(block), after=after,
             expected_version=block["last_edited_time"], replay_safe=True, marker=tx+":"+name))
    patch("wallet.balance", balance_block, money_field(balance_block, "残高:", balance-proposal.cost_jpy)[1], "wallet")
    patch("wallet.monthly", spending_block, money_field(spending_block, "今月の支出:", spending+proposal.cost_jpy)[1], "wallet")
    table = unique_table(blocks, ["日付", "種類", "内容", "金額", "残高"])
    marker = tx + ":money.log"
    description = f"{proposal.item_name} [{marker}; event={event_id}; decision={decision_id}]"
    cells = [proposal.acquired_at.astimezone(local_now.tzinfo).date().isoformat(), "EXPENSE", description,
             f"-¥{proposal.cost_jpy:,}", f"¥{balance-proposal.cost_jpy:,}"]
    child = {"object":"block", "type":"table_row", "table_row":{"cells":[rich(c) for c in cells]}}
    operations.append(NativeOperation(operation_id="money.log", connector="notion", kind="table.append",
          target=table["id"], domain="wallet", after={"children":[child]},
          expected_version=table["last_edited_time"], marker=marker))
    schema = evidence.inventory_schema
    props = schema["properties"]
    required = {"Item":"title", "Purchase Price":"number", "Acquired":"date", "Evidence":"rich_text",
                "Status":"select", "Acquisition":"select"}
    for name, kind in required.items():
        if props.get(name, {}).get("type") != kind:
            raise ValueError("native inventory schema mismatch: " + name)
    def select(name, option):
        spec = props.get(name, {})
        if spec.get("type") != "select" or option not in [o["name"] for o in spec.get("select", {}).get("options", [])]:
            raise ValueError("unsupported native select option: " + name)
        return {"select":{"name":option}}
    marker = tx + ":inventory.create"
    for row in evidence.inventory_rows:
        saved = row.get("properties", {}).get("Evidence", {}).get("rich_text", [])
        if "["+marker+";" in plain(saved):
            raise ValueError("this purchase already exists in native Inventory; reconcile its transaction")
    properties = {"Item":{"title":rich(proposal.item_name)}, "Purchase Price":{"number":proposal.cost_jpy},
        "Acquired":{"date":{"start":proposal.acquired_at.isoformat()}},
        "Evidence":{"rich_text":rich(f"{proposal.evidence}\n[{marker}; event={event_id}; decision={decision_id}]")},
        "Status":select("Status", "Owned"), "Acquisition":select("Acquisition", "Purchased")}
    for name, value in [("Brand", proposal.brand), ("Location", proposal.location)]:
        if value is not None:
            if props.get(name, {}).get("type") != "rich_text":
                raise ValueError("native inventory text field mismatch")
            properties[name] = {"rich_text":rich(value)}
    if proposal.category is not None:
        properties["Category"] = select("Category", proposal.category)
    # Do not insert guessed Condition/Favorite/Description/unknown brand.
    operations.append(NativeOperation(operation_id="inventory.create", connector="notion", kind="inventory.create",
        target=schema["id"], domain="inventory", after={"parent":{"type":"data_source_id", "data_source_id":schema["id"]},
        "properties":properties}, expected_version=schema["last_edited_time"], marker=marker))
    if proposal.wishlist_row_id:
        table = unique_table(blocks, ["見つけた日", "欲しいもの", "だいたいの値段", "欲しさ", "状態", "メモ"])
        rows = [r for r in table["children"][1:] if r["id"] == proposal.wishlist_row_id]
        if len(rows) != 1:
            raise ValueError("requested wishlist row is not in canonical table")
        row = rows[0]; fields = block_fields(row); cells = fields["table_row"]["cells"]
        if plain(cells[1]) != proposal.item_name or plain(cells[4]) in {"購入済み", "Purchased"}:
            raise ValueError("wishlist item mismatch/already purchased")
        cells[4] = rich("購入済み")
        cells[5] = writable_rich(cells[5]) + rich(f" [{tx}:wishlist; event={event_id}]")
        patch("wishlist", row, fields, "wishlist")
    continuity = evidence.continuity_page["page"]
    marker = tx + ":continuity"
    child = {"object":"block", "type":"paragraph", "paragraph":{"rich_text":rich(
        f"{proposal.acquired_at.isoformat()} 購入→所持: {proposal.item_name}, ¥{proposal.cost_jpy:,}. "
        f"[{marker}; event={event_id}; decision={decision_id}]")}}
    operations.append(NativeOperation(operation_id="continuity", connector="notion", kind="page.append",
        target=continuity["id"], domain="continuity", after={"children":[child]},
        expected_version=continuity["last_edited_time"], marker=marker))
    return WritePlan(transaction_id=tx, event_id=event_id, decision_id=decision_id, evidence_scope=evidence.scope,
                     source_versions={"wallet":wallet["page"]["last_edited_time"], "inventory_schema":digest(props),
                                      "continuity":continuity["last_edited_time"]}, operations=operations)


class SpendProposal(StrictModel):
    description: str = Field(min_length=1, max_length=200)
    cost_jpy: int = Field(gt=0, strict=True)
    occurred_at: datetime
    evidence: str = Field(min_length=1, max_length=1000)

    @model_validator(mode="after")
    def time_contract(self):
        if self.occurred_at.tzinfo is None:
            raise ValueError("expense time must be timezone-aware")
        return self


def spend_plan(evidence, proposal, event_id, decision_id, now, ledger_timezone=None):
    """General expense: preserve native Wallet fields and tables; no acquisition."""
    evidence=CanonicalEvidence.model_validate_json(evidence.model_dump_json())
    proposal=SpendProposal.model_validate_json(proposal.model_dump_json())
    if now.tzinfo is None or not timedelta(0)<=now.astimezone(timezone.utc)-evidence.read_at.astimezone(timezone.utc)<=timedelta(minutes=5):
        raise ValueError("fresh native expense evidence required")
    if proposal.occurred_at.astimezone(timezone.utc) != now.astimezone(timezone.utc):
        raise ValueError("expense must belong to this validated tick")
    tx=transaction_id(event_id); blocks=evidence.wallet["blocks"]; operations=[]
    from zoneinfo import ZoneInfo
    local_now=now.astimezone(ZoneInfo(ledger_timezone)) if ledger_timezone else now
    from .wallet_month import native_period
    native_period(blocks, local_now)
    balance_block=unique_field(blocks,"残高:"); spending_block=unique_field(blocks,"今月の支出:")
    balance,_=money_field(balance_block,"残高:",0); spending,_=money_field(spending_block,"今月の支出:",0)
    if balance-evidence.reserved_jpy<proposal.cost_jpy: raise ValueError("insufficient available balance")
    for name,block,label,value in [("wallet.balance",balance_block,"残高:",balance-proposal.cost_jpy),
                                   ("wallet.monthly",spending_block,"今月の支出:",spending+proposal.cost_jpy)]:
        operations.append(NativeOperation(operation_id=name,connector="notion",kind="block.patch",target=block["id"],
            domain="wallet",before=block_fields(block),after=money_field(block,label,value)[1],
            expected_version=block["last_edited_time"],replay_safe=True,marker=tx+":"+name))
    table=unique_table(blocks,["日付","種類","内容","金額","残高"]); marker=tx+":money.log"
    cells=[local_now.date().isoformat(),"EXPENSE",f"{proposal.description} [{marker}; event={event_id}; decision={decision_id}]",
           f"-¥{proposal.cost_jpy:,}",f"¥{balance-proposal.cost_jpy:,}"]
    operations.append(NativeOperation(operation_id="money.log",connector="notion",kind="table.append",target=table["id"],
        domain="wallet",after={"children":[{"object":"block","type":"table_row","table_row":{"cells":[rich(c) for c in cells]}}]},
        expected_version=table["last_edited_time"],marker=marker))
    page=evidence.continuity_page["page"]; marker=tx+":continuity"
    operations.append(NativeOperation(operation_id="continuity",connector="notion",kind="page.append",target=page["id"],
        domain="continuity",after={"children":[{"object":"block","type":"paragraph","paragraph":{"rich_text":rich(
            f"{now.isoformat()} 支出: {proposal.description}, ¥{proposal.cost_jpy:,}. {proposal.evidence} "
            f"[{marker}; event={event_id}; decision={decision_id}]")}}]},expected_version=page["last_edited_time"],marker=marker))
    return WritePlan(transaction_id=tx,event_id=event_id,decision_id=decision_id,evidence_scope=evidence.scope,
        source_versions={"wallet":evidence.wallet["page"]["last_edited_time"],"continuity":page["last_edited_time"]},operations=operations)


def request_plan(operation):
    """Reviewable provider request only. Does not call a transport."""
    from urllib.parse import quote
    target = quote(operation.target, safe="")
    if operation.kind == "block.patch":
        method, path = "PATCH", "/blocks/"+target
    elif operation.kind in {"table.append", "page.append"}:
        method, path = "PATCH", "/blocks/"+target+"/children"
    elif operation.kind == "inventory.create":
        method, path = "POST", "/pages"
    elif operation.kind == "calendar.cancel":
        method, path = "PATCH", "/calendars/"+target+"/events/"+quote(operation.after["id"],safe="")+"?sendUpdates=none"
    else:
        method, path = "POST", "/calendars/"+target+"/events?sendUpdates=none"
    return {"dry_run":True, "connector":operation.connector, "method":method, "path":path,
            "body":deepcopy(operation.after), "expected_version":operation.expected_version,
            "marker":operation.marker}
