"""Native REST apply/observe/compensation, locally HTTP-tested.

Production mutations stay gated. Reads can use the real native connectors;
only explicit loopback HTTP fixtures may execute writes in this checkpoint.
No unsupported Notion If-Match/CAS behavior is invented.
"""
from copy import deepcopy
from datetime import datetime, timezone
from urllib.parse import quote, urlsplit
from .http_json import HTTPFailure, ConnectorUnavailable
from .native_plans import block_fields, plain, request_plan
from .write_models import digest
from .write_coordinator import Observation, DefinitiveWriteFailure, WriteConflict


def normalized(value):
    """Remove server rich-text defaults without losing nondefault formatting."""
    if isinstance(value, list): return [normalized(v) for v in value]
    if not isinstance(value, dict): return value
    output={}
    for key, item in value.items():
        if key in {"plain_text", "href"}: continue
        if key == "annotations":
            item={k:v for k,v in item.items() if v not in {False, "default"}}
            if not item: continue
        if key == "link" and item is None: continue
        output[key]=normalized(item)
    return output


def property_fields(page, expected):
    output={}
    for name, value in expected.items():
        actual=page.get("properties", {}).get(name)
        if not actual: raise ValueError("native property missing")
        kind=next(iter(value))
        if kind == "select":
            output[name]={kind:{"name":actual.get(kind, {}).get("name")}}
        else:
            output[name]={kind:deepcopy(actual.get(kind))}
    return output


def event_fields(event, expected):
    fields={key:deepcopy(event.get(key)) for key in expected}
    for key in ("start", "end"):
        if fields.get(key) and fields[key].get("dateTime"):
            date=datetime.fromisoformat(fields[key]["dateTime"])
            fields[key]={"dateTime":date.astimezone(timezone.utc).isoformat()}
    # Compare private metadata managed by this operation, preserving extras.
    if "extendedProperties" in expected:
        fields["extendedProperties"]={"private":{key:event.get("extendedProperties", {}).get("private", {}).get(key)
            for key in expected["extendedProperties"]["private"]}}
    return fields


class NativeHTTPAdapter:
    def __init__(self, connector):
        self.connector=connector; self.http=connector.http
        self.evidence_scope="fixture" if getattr(self.http, "fixture", False) else "canonical"
        self.provider="calendar" if hasattr(connector, "calendar_id") else "notion"

    def _scope(self, operation, mutation=False):
        if operation.connector != self.provider: raise ValueError("wrong native connector")
        if self.provider == "calendar" and operation.target != self.connector.calendar_id:
            raise ValueError("calendar target mismatch")
        origin=urlsplit(getattr(self.http,"base_url",""))
        loopback=(origin.scheme in {"http","https"} and origin.hostname in {"127.0.0.1","::1","localhost"}
                  and not origin.username and not origin.password)
        if mutation and (not getattr(self.http, "fixture", False) or not loopback):
            raise ConnectorUnavailable("P3/P5 live roundtrip gate has not passed; production writes remain disabled")

    def _get(self, path):
        try: return self.http.request("GET", path)
        except HTTPFailure as error:
            if error.status in {404, 410}: return None
            raise

    def _receipt(self, op, obj, undone=False):
        version=obj.get("etag") if self.provider=="calendar" else obj.get("last_edited_time")
        if not version or not obj.get("id"): raise ConnectorUnavailable("native identity/version missing")
        return {"resource_id":obj["id"], "version":version, "marker":op.marker,
                "fields_hash":digest(op.before if undone and op.kind in {"block.patch","calendar.cancel"} else op.after),
                "fixture":self.evidence_scope=="fixture", "undone":undone,
                # Exact fields protect compensation from edits outside our patch.
                "native_hash":digest(obj)}

    def _matches(self, op, obj):
        if op.kind=="block.patch": actual=block_fields(obj)
        elif op.kind in {"table.append", "page.append"}:
            kind=obj["type"]
            actual={"children":[{"object":"block", "type":kind, **block_fields(obj)}]}
        elif op.kind=="inventory.create":
            actual={"parent":obj.get("parent"), "properties":property_fields(obj, op.after["properties"])}
        else:
            return event_fields(obj, op.after)==event_fields(op.after, op.after)
        return normalized(actual)==normalized(op.after)

    def _object(self, op, identifier):
        identifier=quote(identifier, safe="")
        if op.kind.startswith("calendar."): return self._get(self.connector.path+"/"+identifier)
        return self._get(("/pages/" if op.kind=="inventory.create" else "/blocks/")+identifier)

    def observe(self, op, receipt=None, undo=False):
        self._scope(op)
        if op.kind=="calendar.cancel":
            obj=self._object(op,op.after["id"])
            if obj is None: return Observation("UNKNOWN")
            if event_fields(obj,op.before)==event_fields(op.before,op.before):
                if undo:
                    if receipt and receipt.get("undone") and obj.get("etag")==receipt["version"] and digest(obj)==receipt.get("native_hash"):
                        return Observation("BEFORE",self._receipt(op,obj,undone=True))
                    return Observation("UNKNOWN")
                return Observation("BEFORE" if obj.get("etag")==op.expected_version else "CONFLICT")
            # Cancelled resources may expose only their ID; disappearance is
            # never evidence that this transaction authored the cancellation.
            if obj.get("status")=="cancelled" and not obj.get("extendedProperties"):
                return Observation("UNKNOWN")
        elif op.kind=="calendar.create":
            obj=self._object(op, op.after["id"])
            if obj is None or obj.get("status")=="cancelled":
                if undo and receipt:
                    obj={"id":op.after["id"], "etag":(obj or {}).get("etag") or receipt["version"]}
                    return Observation("BEFORE", self._receipt(op,obj,undone=True))
                return Observation("BEFORE")
        elif op.kind=="block.patch":
            obj=self._object(op, op.target)
            if obj is None or obj.get("archived") or obj.get("in_trash"): return Observation("CONFLICT")
            fields=block_fields(obj)
            if normalized(fields)==normalized(op.before):
                if undo:
                    if receipt and receipt.get("undone") and obj.get("last_edited_time")==receipt["version"]:
                        return Observation("BEFORE",self._receipt(op,obj,undone=True))
                    return Observation("UNKNOWN")  # Lost undo ack is not proof of authorship.
                if obj.get("last_edited_time")==op.expected_version: return Observation("BEFORE")
                return Observation("CONFLICT")
            if self._matches(op,obj) and not receipt:
                return Observation("UNKNOWN")  # No native marker/version receipt on field PATCH.
        else:
            if receipt:
                obj=self._object(op, receipt["resource_id"])
                if obj and (obj.get("archived") or obj.get("in_trash")):
                    if undo and self._matches(op,obj): return Observation("BEFORE",self._receipt(op,obj,undone=True))
                    return Observation("CONFLICT")
                if obj is None: return Observation("UNKNOWN")
                candidates=[obj]
            else:
                if op.kind=="inventory.create": candidates=self.connector.inventory_rows(op.target)
                else: candidates=self.connector.children(op.target)
                candidates=[c for c in candidates if not c.get("archived") and not c.get("in_trash")
                            and op.marker in str(c)]
            if len(candidates)>1: return Observation("CONFLICT")
            if not candidates:
                parent=self.connector.data_source(op.target) if op.kind=="inventory.create" else self._get(
                    ("/pages/" if op.kind=="page.append" else "/blocks/")+quote(op.target,safe=""))
                if not parent or parent.get("archived") or parent.get("in_trash"): return Observation("CONFLICT")
                if op.expected_version and parent.get("last_edited_time")!=op.expected_version: return Observation("CONFLICT")
                return Observation("BEFORE")
            obj=candidates[0]
            # Parent binding is part of ownership, not just a matching marker.
            parent=obj.get("parent", {})
            expected_parent=op.target
            if op.kind=="inventory.create": actual_parent=parent.get("data_source_id")
            elif op.kind=="table.append": actual_parent=parent.get("block_id")
            else: actual_parent=parent.get("page_id") or parent.get("block_id")
            if actual_parent!=expected_parent: return Observation("CONFLICT")
        if not self._matches(op,obj): return Observation("CONFLICT")
        current=self._receipt(op,obj)
        if receipt and (current["version"]!=receipt["version"] or current["native_hash"]!=receipt.get("native_hash")):
            return Observation("CONFLICT")
        return Observation("AFTER",current)

    def apply(self, op):
        self._scope(op,mutation=True)
        observed=self.observe(op)
        if observed.state=="AFTER": return observed.receipt
        if observed.state!="BEFORE": raise WriteConflict("native precondition changed or request already uncertain")
        request=request_plan(op)
        try:
            output=self.http.request(request["method"],request["path"],request["body"],
                headers={"If-Match":op.expected_version} if op.kind=="calendar.cancel" else None)
        except HTTPFailure as error:
            if error.status==409 and op.kind=="calendar.create":
                existing=self.observe(op)
                if existing.state=="AFTER": return existing.receipt
            if error.status in {400,401,403,404,405,409,412,422}:
                raise DefinitiveWriteFailure("provider rejected operation with HTTP "+str(error.status)) from None
            raise
        if op.kind in {"table.append", "page.append"}:
            rows=output.get("results",[])
            if len(rows)!=1: raise ConnectorUnavailable("unexpected native append response")
            output=rows[0]
        return self._receipt(op,output)

    def compensate(self, op, receipt):
        self._scope(op,mutation=True)
        if not receipt or self.observe(op,receipt).state!="AFTER":
            raise WriteConflict("cannot compensate an edited or uncertain native object")
        identifier=quote(receipt["resource_id"],safe="")
        if op.kind=="calendar.create":
            self.http.request("DELETE",self.connector.path+"/"+identifier+"?sendUpdates=none",
                              headers={"If-Match":receipt["version"]})
            return {**receipt,"undone":True}
        if op.kind=="calendar.cancel":
            obj=self.http.request("PATCH",self.connector.path+"/"+identifier+"?sendUpdates=none",op.before,
                                  headers={"If-Match":receipt["version"]})
        elif op.kind=="block.patch":
            obj=self.http.request("PATCH","/blocks/"+identifier,op.before)
        elif op.kind=="inventory.create":
            obj=self.http.request("PATCH","/pages/"+identifier,{"archived":True})
        else:
            obj=self.http.request("DELETE","/blocks/"+identifier)
        return self._receipt(op,obj,undone=True)
