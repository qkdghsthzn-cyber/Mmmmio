"""Authenticated clock replay; arbitrary cache drift never becomes a merge."""
from datetime import datetime
from core.models import State
from core.validator import RuleViolation,Validator
from runtime.physics import advance
from .write_models import digest


def install(db):
    db.executescript('''
    CREATE TABLE IF NOT EXISTS cache_binding_bases(transaction_id TEXT PRIMARY KEY,body TEXT NOT NULL);
    CREATE TABLE IF NOT EXISTS cache_clock_steps(transaction_id TEXT NOT NULL,ordinal INTEGER NOT NULL,
        time TEXT NOT NULL,before_hash TEXT NOT NULL,after_body TEXT NOT NULL,
        PRIMARY KEY(transaction_id,ordinal));
    ''')


def record(bridge,before,after):
    """Caller holds the atomic clock/cache transaction."""
    for binding in bridge.db.execute("SELECT transaction_id,before_hash FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchall():
        tx=binding['transaction_id']
        last=bridge.db.execute('SELECT ordinal,after_body FROM cache_clock_steps WHERE transaction_id=? ORDER BY ordinal DESC LIMIT 1',(tx,)).fetchone()
        expected=digest(State.model_validate_json(last['after_body']).model_dump(mode='json')) if last else binding['before_hash']
        if digest(before.model_dump(mode='json'))!=expected:
            raise RuleViolation('independent cache edit is not an authenticated clock step')
        bridge.db.execute('INSERT INTO cache_clock_steps VALUES(?,?,?,?,?)',(tx,last['ordinal']+1 if last else 0,
            after.world.time.isoformat(),expected,after.model_dump_json()))


def merge(bridge,tx,base,current,projected):
    shadow=State.model_validate_json(base)
    for row in bridge.db.execute('SELECT * FROM cache_clock_steps WHERE transaction_id=? ORDER BY ordinal',(tx,)):
        if digest(shadow.model_dump(mode='json'))!=row['before_hash']:
            raise RuleViolation('clock journal chain changed')
        time=datetime.fromisoformat(row['time'])
        shadow=advance(shadow,time,bridge.validator.rules.grammar)
        saved=State.model_validate_json(row['after_body'])
        if shadow!=saved: raise RuleViolation('clock journal does not reproduce its saved state')
        projected=advance(projected,time,bridge.validator.rules.grammar)
    if shadow!=current: raise RuleViolation('cache drift includes changes outside verified clock evolution')
    projected=State.model_validate_json(projected.model_dump_json()); Validator.invariants(projected)
    return projected
