"""Native pages, block trees and data-source rows. Keeps unknown properties.
Legacy wallet/table pages remain native; they are not replaced by a mock JSON.
Canonical multi-resource writes await the P5 reconciliation gate.
"""
import json
import os
from urllib.parse import urlencode,quote
from .http_json import HTTPJSON,ConnectorUnavailable


class NotionConnector:
    def __init__(self,token=None,http=None):
        self.http=http or HTTPJSON("https://api.notion.com/v1",token or os.getenv("NOTION_TOKEN"),{"Notion-Version":"2025-09-03"})

    def page(self,page_id):
        page=self.http.request("GET","/pages/"+quote(page_id,safe=""))
        blocks=self.children(page_id)
        return {"page":page,"blocks":blocks,"canonical_version":page.get("last_edited_time")}

    def block(self,block_id):
        return self.http.request("GET","/blocks/"+quote(block_id,safe=""))

    def data_source(self,data_source_id):
        # Runtime planning uses raw native schema and version, not the older
        # human-readable connector fetch snapshot in reports/P5_sources.
        return self.http.request("GET","/data_sources/"+quote(data_source_id,safe=""))

    def preview_operation(self,operation):
        from .native_plans import request_plan
        if operation.connector!="notion": raise ValueError("Notion operation required")
        return request_plan(operation)

    def children(self,block_id,depth=0):
        if depth>8: raise ConnectorUnavailable("Notion block tree exceeds read depth budget")
        result=[]; cursor=None
        while True:
            query={"page_size":100}
            if cursor: query["start_cursor"]=cursor
            data=self.http.request("GET","/blocks/"+quote(block_id,safe="")+"/children?"+urlencode(query))
            for block in data["results"]:
                if block.get("has_children"): block["children"]=self.children(block["id"],depth+1)
                result.append(block)
            if not data.get("has_more"): return result
            cursor=data.get("next_cursor")
            if not cursor: raise ConnectorUnavailable("missing Notion pagination cursor")

    def inventory_rows(self,data_source_id):
        rows=[]; cursor=None
        while True:
            body={"page_size":100}
            if cursor: body["start_cursor"]=cursor
            data=self.http.request("POST","/data_sources/"+quote(data_source_id,safe="")+"/query",body)
            rows.extend(data["results"])
            if not data.get("has_more"): return rows
            cursor=data.get("next_cursor")
            if not cursor: raise ConnectorUnavailable("missing inventory pagination cursor")

    def transaction_journal_plan(self,page_id,event_id,decision_id,transaction_id,operations):
        body=json.dumps({"event_id":event_id,"decision_id":decision_id,"transaction_id":transaction_id,"status":"PREPARED","operations":operations},ensure_ascii=False)
        rich=[{"type":"text","text":{"content":body[i:i+1900]}} for i in range(0,len(body),1900)]
        payload={"children":[{"object":"block","type":"code","code":{"language":"json","rich_text":rich}}]}
        return self.http.request("PATCH","/blocks/"+quote(page_id,safe="")+"/children",payload,dry_run=True)

    def apply_live(self,*args,**kwargs):
        raise ConnectorUnavailable("P5 real native write adapter and roundtrip gate have not passed; use dry-run plans")
