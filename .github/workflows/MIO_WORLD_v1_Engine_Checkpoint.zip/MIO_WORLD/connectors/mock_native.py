"""Explicitly fictional native P5 fixture; never import into canonical stores."""
from datetime import datetime
from zoneinfo import ZoneInfo
from .native_plans import CanonicalEvidence, PurchaseProposal, rich, block_fields


def fixture_purchase():
    now = datetime(2026, 10, 6, 12, 0, tzinfo=ZoneInfo("Asia/Tokyo"))
    def block(identifier, kind, body):
        return {"object":"block", "id":identifier, "type":kind, "last_edited_time":"v1", kind:body}
    wallet_blocks = [
        block("fixture.balance", "bulleted_list_item", {"rich_text":[
            {"type":"text", "text":{"content":"残高:"}, "annotations":{"bold":True}},
            {"type":"text", "text":{"content":" ¥27,850"}}], "color":"default"}),
        block("fixture.monthly", "bulleted_list_item", {"rich_text":rich("今月の支出: ¥0"), "color":"default"}),
        block("fixture.moneylog", "table", {"table_width":5, "has_column_header":True, "has_row_header":False}),
        block("fixture.wishlist", "table", {"table_width":6, "has_column_header":True, "has_row_header":False}),
    ]
    wallet_blocks[2]["children"] = [block("fixture.log.header", "table_row", {"cells":[rich(c) for c in ["日付","種類","内容","金額","残高"]]})]
    wallet_blocks[3]["children"] = [
        block("fixture.wish.header", "table_row", {"cells":[rich(c) for c in ["見つけた日","欲しいもの","だいたいの値段","欲しさ","状態","メモ"]]}),
        block("fixture.wish.row", "table_row", {"cells":[rich(c) for c in ["2026-10-05","fixture skirt","¥4,800","high","検討中","confirmed fixture only"]]})]
    schema = {"id":"fixture.inventory", "last_edited_time":"v1", "properties":{}}
    for name, kind in {"Item":"title", "Purchase Price":"number", "Acquired":"date", "Evidence":"rich_text",
                       "Brand":"rich_text", "Location":"rich_text", "Condition":"select", "Favorite":"number"}.items():
        schema["properties"][name] = {"type":kind, kind:{}}
    for name, options in {"Status":["Owned","Sold","Disposed","Gifted"],
                          "Acquisition":["Purchased","Gift","Pre-existing","Unknown"],
                          "Category":["Clothing","Other"]}.items():
        schema["properties"][name] = {"type":"select", "select":{"options":[{"name":option} for option in options]}}
    evidence = CanonicalEvidence(scope="fixture", read_at=now, notion_stale=False, reserved_jpy=0,
         wallet={"page":{"id":"fixture.wallet", "last_edited_time":"v1"}, "blocks":wallet_blocks},
         inventory_schema=schema, inventory_rows=[],
         continuity_page={"page":{"id":"fixture.continuity", "last_edited_time":"v1"}, "blocks":[]})
    proposal = PurchaseProposal(item_name="fixture skirt", cost_jpy=4800, acquired_at=now,
                               evidence="explicit fixture purchase evidence", category="Clothing", wishlist_row_id="fixture.wish.row")
    return evidence, proposal, now


def seed_plan(adapter, plan):
    for op in plan.operations:
        adapter.seed(op.target, op.before if op.before is not None else {"fixture_parent":op.target}, op.expected_version or "v1")
