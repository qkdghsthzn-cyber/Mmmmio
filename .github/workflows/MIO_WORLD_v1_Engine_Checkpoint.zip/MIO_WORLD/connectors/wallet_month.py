"""Native month identity and append-order ledger accounting, without resets.

The optional existing native field is an explicit integration contract. Missing
fields are never created by this reader. Legacy wallets retain same-month use.
"""
import re
from datetime import date
from .native_plans import flatten, plain, block_fields
from .write_models import digest

PERIOD_LABEL = '支出対象月:'


def native_period(blocks, now):
    matches = [b for b in flatten(blocks) if 'rich_text' in b.get(b.get('type'), {})
               and plain(b[b['type']]['rich_text']).startswith(PERIOD_LABEL)]
    if not matches:
        return None
    if len(matches) != 1:
        raise ValueError('native spending month is ambiguous')
    block = matches[0]
    if not block.get('id') or not block.get('last_edited_time') or block.get('archived') or block.get('in_trash'):
        raise ValueError('active versioned native spending month required')
    match = re.fullmatch(re.escape(PERIOD_LABEL) + r'\s*(\d{4}-\d{2})\s*', plain(block[block['type']]['rich_text']))
    if not match:
        raise ValueError('unfamiliar native spending month format')
    month = match[1]
    date.fromisoformat(month + '-01')
    if month != now.strftime('%Y-%m'):
        raise ValueError('native spending month does not identify the current local month')
    return {'month': month, 'id': block['id'], 'hash': digest(block_fields(block))}


def month_accounting(old, current, additions, now, ledger_timezone):
    """Return proved totals and observed deltas for unknown historical totals.

    additions are (row, signed amount), in native append order. Ledger date
    affects spending attribution only; balance arithmetic stays in append order.
    """
    month = now.strftime('%Y-%m')
    if month < old['month']:
        raise ValueError('native monthly anchor cannot move backwards')
    if old.get('ledger_timezone', ledger_timezone) != ledger_timezone:
        raise ValueError('ledger timezone changed; explicit reconciliation required')
    period = current['period']
    if old.get('period') and (period is None or period['id'] != old['period']['id']):
        raise ValueError('native spending month identity was removed/replaced')
    dated = [(row['cells'][0][:7], amount) for row, amount in additions]
    if (month != old['month'] or any(m != month for m, _ in dated)) and period is None:
        raise ValueError('month rollover/backdated rows require an explicit native spending month')
    baseline = old.get('baseline_month', old['month'])
    totals = dict(old.get('month_totals', {old['month']: old['monthly']}))
    historical = dict(old.get('historical_expense_deltas', {}))
    totals.setdefault(month, 0)
    for row_month, amount in dated:
        expense = max(0, -amount)
        if row_month >= baseline:
            totals[row_month] = totals.get(row_month, 0) + expense
        elif expense:
            # Unknown pre-baseline totals stay unknown, even after a late row.
            historical[row_month] = historical.get(row_month, 0) + expense
    if totals[month] != current['monthly']:
        raise ValueError('native current-month spending differs from proved dated expenses')
    return {'month': month, 'baseline_month': baseline, 'month_totals': totals,
            'historical_expense_deltas': historical, 'ledger_timezone': ledger_timezone}
