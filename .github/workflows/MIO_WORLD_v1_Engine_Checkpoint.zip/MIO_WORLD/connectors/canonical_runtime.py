"""Bind fresh native truth to validation, then publish cache only after receipts.

The HTTP/native adapter and coordinator's production gate remain closed. This
bridge can run completely against isolated fixtures, and cannot promote fixture
facts to a live State. It does not initialize unknown canon from defaults.
"""
import json
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from core.models import State, Provenance, Event
from core.validator import RuleViolation
from .native_plans import unique_field, money_field, plain, purchase_plan, spend_plan, SpendProposal
from .write_models import WritePlan, digest, transaction_id
from .http_json import ConnectorUnavailable
from .calendar_truth import interval, UNKNOWN_PLACE


def fresh(read_at, now):
    if read_at.tzinfo is None or now.tzinfo is None or not timedelta(0)<=now.astimezone(timezone.utc)-read_at.astimezone(timezone.utc)<=timedelta(minutes=5):
        raise RuleViolation("fresh timezone-aware canonical evidence required")


def expense_description(event):
    return event.family+": "+event.slots["action"]


@dataclass(frozen=True)
class RuntimeEvidence:
    notion: object  # CanonicalEvidence native wallet/schema/rows
    calendar_read_at: datetime
    calendar_rows: list[dict]
    calendar_stale: bool
    world_anchor: str  # Explicit initialization/confirmed-world evidence reference
    state_hash: str
    calendar_complete: bool = False
    calendar_window: tuple[datetime,datetime] | None = None
    calendar_query: str | None = None
    evidence_scope: str | None = None
    calendar_timezone: str | None = None
    canonical_pages: dict = field(default_factory=dict)
    expense_signals: dict = field(default_factory=dict)  # Trusted provider read evidence, never an LLM declaration.
    calendar_creation_proofs: dict = field(default_factory=dict)


class CanonicalValidator:
    def __init__(self, rules_validator, allow_internal=False):
        self.rules=rules_validator; self.allow_internal=allow_internal

    def project(self,state,event,decision,evidence,now):
        state=State.model_validate_json(state.model_dump_json())
        has_purchase=any(a.type=="purchase" for a in decision.actions)
        has_spend=any(a.type=="spend" for a in decision.actions)
        has_ownership=has_purchase or has_spend or any(a.type=="use_item" for a in decision.actions)
        internal=any(a.type in {"observe","need_update","use_item","move","relationship_update"} for a in decision.actions)
        if has_ownership or (internal and self.allow_internal):
            if evidence.notion is None: raise RuleViolation("native Notion truth unavailable for purchase")
            fresh(evidence.notion.read_at,now)
        if not evidence.world_anchor or evidence.state_hash!=digest(state.model_dump(mode="json")):
            raise RuleViolation("proposal has no authenticated runtime state anchor")
        scope=evidence.evidence_scope or (evidence.notion.scope if evidence.notion else None)
        if scope not in {"fixture","canonical"}: raise RuleViolation("native evidence scope missing")
        if (scope=="fixture") != (state.mode=="mock"):
            raise RuleViolation("fixture/live scope mismatch")
        if state.world.time.astimezone(timezone.utc)!=now.astimezone(timezone.utc): raise RuleViolation("runtime clock differs from validation time")
        if has_ownership:
            if state.notion_stale or evidence.notion.notion_stale:
                raise RuleViolation("Notion truth is stale")
            block=unique_field(evidence.notion.wallet["blocks"],"残高:")
            balance,_=money_field(block,"残高:",0)
            if state.wallet.balance!=balance or state.wallet.reserved_amount!=evidence.notion.reserved_jpy:
                raise RuleViolation("cached wallet or reservations differ from canonical evidence")
            native_owned={row["id"]:row for row in evidence.notion.inventory_rows
                          if not row.get("archived") and not row.get("in_trash") and (row.get("properties",{}).get("Status",{}).get("select") or {}).get("name")=="Owned"}
            owned={key:item for key,item in state.inventory.items() if item.status=="owned"}
            if set(owned)!=set(native_owned): raise RuleViolation("cached ownership differs from native Inventory")
            for key,item in owned.items():
                row=native_owned[key]; properties=row["properties"]
                if item.name!=plain(properties["Item"]["title"]): raise RuleViolation("cached item identity differs")
                if scope=="canonical" and item.provenance.source!="canonical":
                    raise RuleViolation("mock/unverified ownership cannot enter canonical cache")
        has_calendar=any(a.type in {"calendar_create","calendar_cancel"} for a in decision.actions)
        authorized_cancellations=set()
        if has_calendar:
            fresh(evidence.calendar_read_at,now)
            if not evidence.calendar_complete or evidence.calendar_query!="" or evidence.calendar_window is None:
                raise RuleViolation("unfiltered complete Calendar read window required")
            lower,upper=evidence.calendar_window
            for action in decision.actions:
                if action.type=="calendar_create" and (action.start is None or action.end is None or not lower<=action.start<action.end<=upper):
                    raise RuleViolation("proposed calendar interval is outside verified read window")
            if evidence.calendar_stale or state.calendar_stale: raise RuleViolation("Calendar truth is stale")
            # Canonical cache must include every read event, including unrelated
            # busy events. MIO-only search results cannot certify conflicts.
            native={row["id"]:row for row in evidence.calendar_rows if row.get("status")!="cancelled" and interval(row,evidence.calendar_timezone)[1]>now}
            active={c.commitment_id:c for c in state.calendar if c.status=="scheduled" and c.end>now}
            if set(native)!=set(active): raise RuleViolation("calendar cache does not cover native read window")
            for key,commitment in active.items():
                row=native[key]
                start,end=interval(row,evidence.calendar_timezone)
                if start!=commitment.start or end!=commitment.end:
                    raise RuleViolation("calendar time differs from native truth")
                if row.get("location") and row["location"]!=commitment.location:
                    raise RuleViolation("calendar location differs from native truth")
                if row.get("transparency","opaque")=="opaque" and commitment.flexibility!="fixed":
                    raise RuleViolation("busy canonical event cannot be downgraded to flexible")
            for action in decision.actions:
                if action.type!="calendar_cancel": continue
                identifier=action.commitment_id; row=native.get(identifier); proof=evidence.calendar_creation_proofs.get(identifier)
                if not row or not proof: raise RuleViolation("cancellation requires durable runtime creation proof")
                from .write_models import NativeOperation
                from .native_http_adapter import event_fields
                op=NativeOperation.model_validate(proof["operation"]); receipt=proof["receipt"]
                metadata=row.get("extendedProperties",{}).get("private",{})
                if (op.kind!="calendar.create" or op.after["id"]!=identifier or receipt.get("resource_id")!=identifier
                    or receipt.get("fixture")!=(scope=="fixture") or receipt.get("fields_hash")!=digest(op.after)
                    or receipt.get("marker")!=op.marker or receipt.get("version")!=row.get("etag")
                    or receipt.get("native_hash")!=digest(row) or event_fields(row,op.after)!=event_fields(op.after,op.after)
                    or metadata.get("mio_source_event")!=active[identifier].source_event):
                    raise RuleViolation("native cancellation ownership/version differs from creation receipt")
                if row.get("attendees") or row.get("recurrence") or row.get("recurringEventId"):
                    raise RuleViolation("only runtime-owned one-off events without attendees may be cancelled")
                if not lower<=active[identifier].start<active[identifier].end<=upper:
                    raise RuleViolation("cancellation is outside verified read window")
                authorized_cancellations.add(identifier)
        if scope=="canonical":
            if state.provenance.source!="canonical": raise RuleViolation("explicit canonical runtime initialization required")
            for action in decision.actions:
                if action.type=="purchase":
                    catalog=state.catalog.get(action.item_id)
                    if catalog is None or catalog.provenance.source!="external_verified" or catalog.provenance.verified_at is None:
                        raise RuleViolation("real purchase price/availability has no verified signal")
                    fresh(catalog.provenance.verified_at,now)
                elif action.type=="spend":
                    signal=evidence.expense_signals.get(event.event_id)
                    if not signal or signal.get("source")!="external_verified" or not signal.get("ref"):
                        raise RuleViolation("real expense has no verified provider cost signal")
                    fresh(datetime.fromisoformat(signal["verified_at"]),now)
                    if signal.get("amount")!=action.amount or signal.get("description")!=expense_description(event):
                        raise RuleViolation("expense signal differs from this event")
            for entity in [*state.inventory.values(),*state.catalog.values(),*state.relationships.values()]:
                if entity.provenance.source in {"mock","unverified"}: raise RuleViolation("unverified entity in live runtime")
        allowed={"purchase","spend","calendar_create","calendar_cancel"}
        if self.allow_internal: allowed.update({"observe","need_update","use_item","move","relationship_update"})
        if any(a.type not in allowed for a in decision.actions):
            raise RuleViolation("this native bridge supports purchase/calendar_create only; other effects require full native plans")
        projected=self.rules._project(state,event,decision,transaction_id(event.event_id),cancel_authorizations=authorized_cancellations)
        if internal and self.allow_internal:
            if state.notion_stale or evidence.notion.notion_stale:
                raise RuleViolation("native effect journal unavailable")
            if not {"world","relationships","taste"}<=set(evidence.canonical_pages):
                raise RuleViolation("internal effects require explicit native runtime/relationship/taste pages")
        return projected

    def plan(self,state,event,decision,evidence,now,proposal=None,calendar_connector=None):
        projected=self.project(state,event,decision,evidence,now)
        if any(a.type=="purchase" for a in decision.actions):
            if proposal is None: raise RuleViolation("native purchase description/evidence required")
            action=next(a for a in decision.actions if a.type=="purchase")
            item=state.catalog[action.item_id]
            if (proposal.item_name,proposal.cost_jpy,proposal.acquired_at,proposal.brand)!=(item.name,item.price,now,item.brand):
                raise RuleViolation("native purchase properties differ from validated decision/catalog")
            plan=purchase_plan(evidence.notion,proposal,event.event_id,decision.decision_id,now,ledger_timezone=state.world.timezone)
        elif any(a.type=="spend" for a in decision.actions):
            if not isinstance(proposal,SpendProposal): raise RuleViolation("native expense proposal required")
            action=next(a for a in decision.actions if a.type=="spend")
            if (proposal.description,proposal.cost_jpy,proposal.occurred_at)!=(expense_description(event),action.amount,now):
                raise RuleViolation("expense proposal differs from validated event")
            if state.mode=="live" and proposal.evidence!=evidence.expense_signals[event.event_id]["ref"]:
                raise RuleViolation("expense evidence differs from verified provider reference")
            plan=spend_plan(evidence.notion,proposal,event.event_id,decision.decision_id,now,ledger_timezone=state.world.timezone)
        elif any(a.type=="calendar_create" for a in decision.actions):
            if calendar_connector is None: raise RuleViolation("calendar connector required")
            added=[c for c in projected.calendar if c.commitment_id not in {old.commitment_id for old in state.calendar}]
            if len(added)!=1: raise RuleViolation("exactly one validated new commitment required")
            plan=WritePlan(transaction_id=transaction_id(event.event_id),event_id=event.event_id,decision_id=decision.decision_id,
                evidence_scope=evidence.evidence_scope or evidence.notion.scope,source_versions={"calendar":digest(evidence.calendar_rows)},
                operations=[calendar_connector.create_operation(added[0],transaction_id(event.event_id))])
        elif any(a.type=="calendar_cancel" for a in decision.actions):
            if calendar_connector is None: raise RuleViolation("calendar connector required")
            action=next(a for a in decision.actions if a.type=="calendar_cancel")
            row=next(r for r in evidence.calendar_rows if r["id"]==action.commitment_id)
            tx=transaction_id(event.event_id)
            operations=[calendar_connector.cancel_operation(row,tx,event.event_id)]
            if evidence.notion is not None and not state.notion_stale:
                from .native_journals import append_record,state_delta
                fresh(evidence.notion.read_at,now)
                operations.append(append_record(evidence.notion.continuity_page,tx,"effect.continuity","continuity",
                                                state_delta(state,projected,event,decision)))
            plan=WritePlan(transaction_id=tx,event_id=event.event_id,decision_id=decision.decision_id,
                evidence_scope=evidence.evidence_scope or evidence.notion.scope,
                source_versions={"calendar":digest(evidence.calendar_rows)},operations=operations)
        elif self.allow_internal and decision.choice=="accept":
            from .native_journals import append_record,state_delta
            tx=transaction_id(event.event_id)
            record=state_delta(state,projected,event,decision)
            plan=WritePlan(transaction_id=tx,event_id=event.event_id,decision_id=decision.decision_id,
                evidence_scope=evidence.evidence_scope or evidence.notion.scope,
                source_versions={"continuity":evidence.notion.continuity_page["page"]["last_edited_time"]},
                operations=[append_record(evidence.notion.continuity_page,tx,"effect.continuity","continuity",record)])
        else: raise RuleViolation("no accepted native mutation")
        if self.allow_internal:
            from .native_journals import append_record,state_delta
            record=state_delta(state,projected,event,decision); operations=list(plan.operations)
            for domain in ["relationships","taste"]:
                if domain in record["domains"]:
                    if domain not in evidence.canonical_pages or evidence.notion is None or state.notion_stale:
                        raise RuleViolation("native effect domain lacks fresh page evidence: "+domain)
                    fresh(evidence.notion.read_at,now)
                    operations.append(append_record(evidence.canonical_pages[domain],plan.transaction_id,"effect."+domain,domain,
                        {"kind":"internal_metric_delta","event_id":event.event_id,"decision_id":decision.decision_id,
                         "scope":state.mode,"initialization_ref":evidence.world_anchor,"delta":record["domains"][domain]}))
            plan=WritePlan.model_validate({**plan.model_dump(),"operations":operations})
        return plan,projected


class CanonicalCacheBridge:
    def __init__(self,coordinator,validator):
        self.coordinator=coordinator; self.validator=validator; self.db=coordinator.db
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS runtime_cache(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL,scope TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS cache_bindings(transaction_id TEXT PRIMARY KEY,before_hash TEXT NOT NULL,
            after_body TEXT NOT NULL,domains TEXT NOT NULL,status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS canonical_events(event_id TEXT PRIMARY KEY,body TEXT NOT NULL);
        ''')
        from .clock_merge import install
        install(self.db)

    def initialize(self,state,scope):
        if scope not in {"fixture","canonical"} or (scope=="fixture")!=(state.mode=="mock"):
            raise RuleViolation("cache scope mismatch")
        State.model_validate_json(state.model_dump_json())
        with self.coordinator.atomic():
            self.db.execute("INSERT OR IGNORE INTO runtime_cache VALUES(1,?,?)",(state.model_dump_json(),scope))
            existing=self.db.execute("SELECT scope FROM runtime_cache WHERE id=1").fetchone()[0]
            if existing!=scope: raise RuleViolation("cannot reinterpret an existing cache's scope")

    def state(self):
        row=self.db.execute("SELECT body FROM runtime_cache WHERE id=1").fetchone()
        if not row: raise RuntimeError("runtime cache not initialized")
        return State.model_validate_json(row[0])

    def log_event(self,event):
        if event.status!="pending": raise RuleViolation("only engine proposals may be logged")
        with self.coordinator.atomic():
            existing=self.db.execute("SELECT body FROM canonical_events WHERE event_id=?",(event.event_id,)).fetchone()
            if existing:
                saved=Event.model_validate_json(existing[0])
                if saved.model_dump(exclude={"status","resolved_at"})!=event.model_dump(exclude={"status","resolved_at"}):
                    raise RuleViolation("logged event changed")
            self.db.execute("INSERT OR IGNORE INTO canonical_events VALUES(?,?)",(event.event_id,event.model_dump_json()))

    def prepare(self,event,decision,evidence,now,proposal=None,calendar_connector=None):
        authenticated=self.db.execute("SELECT body FROM canonical_events WHERE event_id=?",(event.event_id,)).fetchone()
        if not authenticated:
            raise RuleViolation("event is not authenticated by engine event log")
        logged=Event.model_validate_json(authenticated[0])
        if logged.model_dump(exclude={"status","resolved_at"})!=event.model_dump(exclude={"status","resolved_at"}):
            raise RuleViolation("event differs from authenticated engine log")
        # Idempotent replay returns only the same persisted decision. New proposal
        # content goes through the coordinator's event hash guard.
        existing=self.db.execute("SELECT transaction_id,plan FROM external_transactions WHERE event_id=?",(event.event_id,)).fetchone()
        if existing:
            saved=json.loads(existing["plan"])
            row=self.db.execute("SELECT after_body FROM cache_bindings WHERE transaction_id=?",(existing["transaction_id"],)).fetchone()
            if saved["decision_id"]!=decision.decision_id or not row:
                raise RuleViolation("replayed event decision differs or has no cache binding")
            # Full decision/event/proposal fingerprints are authenticated below.
            saved_fingerprint=self.db.execute("SELECT detail FROM external_audit WHERE transaction_id=? AND action='CACHE_INPUT'",(existing["transaction_id"],)).fetchone()
            if not saved_fingerprint or saved_fingerprint[0]!=self._input_hash(event,decision,proposal):
                raise RuleViolation("replayed input differs from validated proposal")
            return existing["transaction_id"]
        state=self.state()
        if any(a.type in {'purchase','spend'} for a in decision.actions) and evidence.notion is not None:
            from .native_rebase import NativeCacheReconciler
            try: NativeCacheReconciler(self).require_current_month(evidence.notion,now)
            except (RuleViolation,ValueError):
                self.mark_stale('notion'); raise
        from dataclasses import replace
        # Authorship cannot be supplied by a decision or an arbitrary proposal.
        evidence=replace(evidence,calendar_creation_proofs=self.calendar_creation_proofs())
        plan,projected=self.validator.plan(state,event,decision,evidence,now,proposal,calendar_connector)
        def bind(tx):
            current=self.state()
            if digest(current.model_dump(mode="json"))!=evidence.state_hash:
                raise RuleViolation("cache changed during prepare")
            domains=sorted({op.domain for op in plan.operations})
            self.db.execute("INSERT INTO cache_bindings VALUES(?,?,?,?, 'PENDING')",
                (tx,evidence.state_hash,projected.model_dump_json(),json.dumps(domains)))
            self.db.execute('INSERT INTO cache_binding_bases VALUES(?,?)',(tx,current.model_dump_json()))
            self.coordinator.audit(tx,"CACHE_INPUT",self._input_hash(event,decision,proposal))
        # Outbox, locks, projection binding and input proof commit together.
        return self.coordinator.prepare(plan,on_prepare=bind)

    def calendar_creation_proofs(self):
        proofs={}
        for row in self.db.execute("SELECT o.body,o.receipt FROM external_outbox o JOIN cache_bindings b USING(transaction_id) "
                                   "WHERE b.status='PUBLISHED' AND o.status='APPLIED'"):
            op=json.loads(row["body"])
            if op["kind"]=="calendar.create" and row["receipt"]:
                receipt=json.loads(row["receipt"])
                proofs[receipt["resource_id"]]={"operation":op,"receipt":receipt}
        # A verified compensation changes the provider version without changing
        # ownership. Preserve the creation cause and bind its new exact receipt.
        for row in self.db.execute("SELECT o.body,o.undo_receipt FROM external_outbox o "
            "JOIN cache_bindings b USING(transaction_id) JOIN external_audit a USING(transaction_id) "
            "WHERE b.status='ROLLED_BACK' AND o.status='UNDONE' AND a.action='UNDONE' AND a.detail=CAST(o.ordinal AS TEXT) ORDER BY a.id"):
            op=json.loads(row['body'])
            if op['kind']!='calendar.cancel' or not row['undo_receipt']: continue
            receipt=json.loads(row['undo_receipt']); proof=proofs.get(receipt.get('resource_id'))
            if (proof and receipt.get('undone') and receipt.get('fields_hash')==digest(op['before'])
                and receipt.get('marker')==op['marker'] and receipt.get('native_hash')
                and receipt.get('fixture')==proof['receipt'].get('fixture')):
                proof['receipt']={**proof['receipt'],'version':receipt['version'],'native_hash':receipt['native_hash']}
        return proofs

    @staticmethod
    def _input_hash(event,decision,proposal):
        return digest({"event":event.model_dump(mode="json"),"decision":decision.model_dump(mode="json"),
                       "proposal":proposal.model_dump(mode="json") if proposal else None})

    def publish(self,tx,on_publish=None):
        with self.coordinator.worker_lock():
            with self.coordinator.atomic():
                binding=self.db.execute("SELECT * FROM cache_bindings WHERE transaction_id=?",(tx,)).fetchone()
                if binding is None: raise RuleViolation("native transaction has no authenticated cache binding")
                if binding["status"]=="PUBLISHED": return "PUBLISHED"
                status=self.coordinator.status(tx)
                if status=="ROLLED_BACK":
                    self.db.execute("UPDATE cache_bindings SET status='ROLLED_BACK' WHERE transaction_id=?",(tx,))
                    self._resolve_event(tx,"rejected")
                    return "ROLLED_BACK"
                commit=self.coordinator.committed(tx)
                if status!="COMMITTED" or not commit: return "PENDING"
                scope=self.db.execute("SELECT scope FROM runtime_cache WHERE id=1").fetchone()[0]
                if commit["evidence_scope"]!=scope: raise RuleViolation("fixture receipt cannot publish live cache")
                current=self.state()
                base=self.db.execute('SELECT body FROM cache_binding_bases WHERE transaction_id=?',(tx,)).fetchone()
                needs_merge=digest(current.model_dump(mode="json"))!=binding["before_hash"]
                if needs_merge and (not base or digest(State.model_validate_json(base[0]).model_dump(mode='json'))!=binding['before_hash']):
                    self.db.execute("UPDATE cache_bindings SET status='RECONCILE_REQUIRED' WHERE transaction_id=?",(tx,))
                    return "RECONCILE_REQUIRED"
                if needs_merge:
                    from .clock_merge import merge
                    try: merge(self,tx,base[0],current,State.model_validate_json(binding['after_body']))
                    except (RuleViolation,ValueError):
                        self.db.execute("UPDATE cache_bindings SET status='RECONCILE_REQUIRED' WHERE transaction_id=?",(tx,))
                        return 'RECONCILE_REQUIRED'
                # Fresh final provider re-read, including every original receipt,
                # before making the proposed cache observable as confirmed state.
                for row in self.coordinator.rows(tx):
                    op,adapter=self.coordinator._operation(row); receipt=json.loads(row["receipt"])
                    try:
                        observation=adapter.observe(op,receipt)
                    except Exception:
                        from .write_coordinator import Observation
                        observation=Observation("UNKNOWN")
                    if observation.state!="AFTER" or not self.coordinator._receipt_valid(op,observation.receipt):
                        self.db.execute("UPDATE cache_bindings SET status='RECONCILE_REQUIRED' WHERE transaction_id=?",(tx,))
                        return "RECONCILE_REQUIRED"
                projected=State.model_validate_json(binding["after_body"])
                before=State.model_validate_json(base[0]) if needs_merge else current
                plan=WritePlan.model_validate_json(self.db.execute("SELECT plan FROM external_transactions WHERE transaction_id=?",(tx,)).fetchone()[0])
                for row in self.coordinator.rows(tx):
                    op,_=self.coordinator._operation(row); receipt=json.loads(row["receipt"])
                    if op.kind=="inventory.create":
                        added=set(projected.inventory)-set(before.inventory)
                        if len(added)!=1: raise RuleViolation("inventory receipt has no unique validated acquisition")
                        old_id=next(iter(added)); item=projected.inventory.pop(old_id)
                        item.item_id=receipt["resource_id"]
                        item.provenance=Provenance(source="mock" if scope=="fixture" else "canonical",
                            ref=op.marker+":"+receipt["resource_id"],verified_at=projected.world.time)
                        # Keep genuinely unknown canonical fields unknown.
                        props=op.after["properties"]
                        item.location=plain(props["Location"]["rich_text"]) if "Location" in props else None
                        item.condition=None
                        item.category=props["Category"]["select"]["name"].lower() if "Category" in props else "unknown"
                        projected.inventory[item.item_id]=item
                    elif op.kind=="calendar.create":
                        added=[c for c in projected.calendar if c.commitment_id not in {b.commitment_id for b in before.calendar}]
                        if len(added)!=1: raise RuleViolation("calendar receipt has no unique validated commitment")
                        added[0].commitment_id=receipt["resource_id"]
                        added[0].provenance=Provenance(source="mock" if scope=="fixture" else "canonical",
                            ref=op.marker+":"+receipt["resource_id"],verified_at=projected.world.time)
                projected=State.model_validate_json(projected.model_dump_json())
                if on_publish is not None:
                    on_publish(projected,plan)
                    projected=State.model_validate_json(projected.model_dump_json())
                if needs_merge:
                    from .clock_merge import merge
                    # A failed merge also rolls back consequence callbacks.
                    projected=merge(self,tx,base[0],current,projected)
                self.db.execute("UPDATE runtime_cache SET body=? WHERE id=1",(projected.model_dump_json(),))
                self.db.execute("UPDATE cache_bindings SET status='PUBLISHED' WHERE transaction_id=?",(tx,))
                self.coordinator.audit(tx,"CACHE_PUBLISHED")
                self._resolve_event(tx,"committed")
                return "PUBLISHED"

    def _resolve_event(self,tx,status):
        identifier=self.db.execute("SELECT event_id FROM external_transactions WHERE transaction_id=?",(tx,)).fetchone()[0]
        row=self.db.execute("SELECT body FROM canonical_events WHERE event_id=?",(identifier,)).fetchone()
        if not row: raise RuleViolation("cache publication has no source event")
        event=Event.model_validate_json(row[0]); event.status=status; event.resolved_at=self.state().world.time
        self.db.execute("UPDATE canonical_events SET body=? WHERE event_id=?",(event.model_dump_json(),identifier))

    def confirmations_allowed(self,*domains):
        from .database_recovery import recovery_pending
        if recovery_pending(self.db): return False
        from runtime.host_resume import pending
        if pending(self.db): return False
        if not self.coordinator.confirmations_allowed(*domains): return False
        wanted=set(domains or ["wallet","inventory","calendar","wishlist","continuity","world","relationships","taste"])
        state=self.state()
        if state.notion_stale and wanted.intersection({"wallet","inventory","wishlist","continuity","world","relationships","taste"}): return False
        if state.calendar_stale and "calendar" in wanted: return False
        if not self.coordinator.confirmations_allowed(*domains): return False
        wanted=set(domains or ["wallet","inventory","calendar","wishlist","continuity","world","relationships","taste"])
        for row in self.db.execute("SELECT domains FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')"):
            if wanted.intersection(json.loads(row[0])): return False
        return True

    def confirmed_state(self):
        if not self.confirmations_allowed():
            raise ConnectorUnavailable("canonical cache has unresolved domain confirmations")
        return self.state()

    def mark_stale(self,domain,stale=True):
        if domain not in {"notion","calendar"}: raise ValueError("unknown canonical domain")
        with self.coordinator.atomic():
            state=self.state()
            setattr(state,domain+"_stale",stale); state.revision+=1
            self.db.execute("UPDATE runtime_cache SET body=? WHERE id=1",(state.model_dump_json(),))


class RuntimeEvidenceReader:
    """Fetch raw native truth, unfiltered Calendar, schema and ownership rows.

    Caller supplies the explicit runtime-world anchor; unknown location, NPC
    ages and numeric relationship scores are not initialized by this reader.
    """
    def __init__(self,notion,calendar,clock):
        self.notion=notion; self.calendar=calendar; self.clock=clock

    def read(self,bridge,wallet_page,inventory_source,continuity_page,world_anchor,additional_pages=None,reconcile_external=False,validation_time=None):
        from .native_plans import CanonicalEvidence
        if bridge.db.execute("SELECT 1 FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchone():
            raise ConnectorUnavailable("publish/recover pending native receipts before refreshing their cache")
        if bool(getattr(self.notion.http,"fixture",False))!=bool(getattr(self.calendar.http,"fixture",False)):
            raise RuleViolation("cannot combine fixture and canonical read providers")
        before=bridge.state(); scope="fixture" if getattr(self.notion.http,"fixture",False) else "canonical"
        truth_time=validation_time or before.world.time
        if truth_time.tzinfo is None or not timedelta(0)<=truth_time.astimezone(timezone.utc)-before.world.time.astimezone(timezone.utc)<timedelta(hours=1):
            raise RuleViolation('canonical validation time requires completed bounded host catch-up')
        wallet=None; rows=None; schema=None; continuity=None; notion_error=False; pages={}
        try:
            wallet=self.notion.page(wallet_page)
            schema=self.notion.data_source(inventory_source)
            rows=self.notion.inventory_rows(inventory_source)
            continuity=self.notion.page(continuity_page)
            for role,identifier in (additional_pages or {}).items(): pages[role]=self.notion.page(identifier)
            notion_at=self.clock()
        except ConnectorUnavailable:
            notion_error=True
            bridge.mark_stale("notion")
        start=before.world.time-timedelta(days=1); end=before.world.time+timedelta(days=8)
        calendar_rows=[]; calendar_stale=False; calendar_timezone=None; calendar_read_complete=False
        try:
            calendar_rows=self.calendar.events(start,end,query="")
            if any("date" in r.get("start",{}) for r in calendar_rows if r.get("status")!="cancelled"):
                calendar_timezone=self.calendar.metadata()["timeZone"]
            calendar_at=self.clock()
            calendar_read_complete=True
        except ConnectorUnavailable:
            calendar_stale=True; calendar_at=self.clock(); bridge.mark_stale("calendar")
        if notion_error:
            current=bridge.state()
            return RuntimeEvidence(notion=None,calendar_read_at=calendar_at,calendar_rows=calendar_rows,
                calendar_stale=calendar_stale,world_anchor=world_anchor,state_hash=digest(current.model_dump(mode="json")),
                calendar_complete=not calendar_stale,calendar_query="",calendar_window=(start,end),evidence_scope=scope,
                calendar_timezone=calendar_timezone)
        # Do not clear stale merely because HTTP succeeded: changed native money
        # or ownership first require cache/ledger reconciliation.
        current=bridge.state()
        native=CanonicalEvidence(scope=scope,read_at=notion_at,notion_stale=False,wallet=wallet,
            inventory_schema=schema,inventory_rows=rows,continuity_page=continuity,reserved_jpy=current.wallet.reserved_amount)
        from .native_rebase import NativeCacheReconciler
        reconciler=NativeCacheReconciler(bridge)
        if not bridge.db.execute('SELECT 1 FROM native_rebase_anchor').fetchone():
            try: reconciler.anchor(native,truth_time)
            except (RuleViolation,ValueError):
                bridge.mark_stale('notion')
                raise ConnectorUnavailable('native drift lacks a valid initial ledger anchor') from None
        if reconcile_external:
            try: reconciler.reconcile(native,truth_time,self.notion)
            except (RuleViolation,ValueError,ConnectorUnavailable):
                bridge.mark_stale('notion')
                raise ConnectorUnavailable('native ledger/ownership reconciliation is unresolved') from None
            current=bridge.state()
        try: reconciler.require_current_month(native,truth_time)
        except (RuleViolation,ValueError):
            bridge.mark_stale('notion')
            raise ConnectorUnavailable('native spending month is not reconciled') from None
        balance,_=money_field(unique_field(wallet["blocks"],"残高:"),"残高:",0)
        owned={r["id"] for r in rows if not r.get("archived") and not r.get("in_trash") and (r.get("properties",{}).get("Status",{}).get("select") or {}).get("name")=="Owned"}
        row_by_id={r["id"]:r for r in rows}
        details_changed=any(i.item_id in row_by_id and (
            i.name!=plain(row_by_id[i.item_id].get("properties",{}).get("Item",{}).get("title",[])) or
            i.brand!=plain(row_by_id[i.item_id].get("properties",{}).get("Brand",{}).get("rich_text",[])) and
                not (i.brand is None and not row_by_id[i.item_id].get("properties",{}).get("Brand",{}).get("rich_text",[])))
            for i in current.inventory.values() if i.status=="owned")
        if details_changed or balance!=current.wallet.balance or owned!={i.item_id for i in current.inventory.values() if i.status=="owned"}:
            bridge.mark_stale("notion")
            raise ConnectorUnavailable("canonical money/ownership changed; ledger/cache reconciliation required")
        if current.notion_stale: bridge.mark_stale("notion",False)
        if not calendar_stale:
            active={c.commitment_id:c for c in current.calendar if c.status=="scheduled" and c.end>current.world.time}
            native_future={r["id"]:r for r in calendar_rows if r.get("status")!="cancelled" and
                interval(r,calendar_timezone)[1]>current.world.time}
            changed=set(active)!=set(native_future)
            if not changed:
                changed=any(interval(native_future[k],calendar_timezone)!=(c.start,c.end) or
                    native_future[k].get("location",UNKNOWN_PLACE)!=c.location or
                    (native_future[k].get("transparency","opaque")=="opaque" and c.flexibility!="fixed")
                    for k,c in active.items())
            if changed:
                calendar_stale=True; bridge.mark_stale("calendar")
            elif bridge.state().calendar_stale:
                bridge.mark_stale("calendar",False)
        current=bridge.state()
        return RuntimeEvidence(notion=native,calendar_read_at=calendar_at,calendar_rows=calendar_rows,
            calendar_stale=calendar_stale,world_anchor=world_anchor,state_hash=digest(current.model_dump(mode="json")),
            calendar_complete=calendar_read_complete,calendar_query="",calendar_window=(start,end),
            calendar_timezone=calendar_timezone,canonical_pages=pages,calendar_creation_proofs=bridge.calendar_creation_proofs())

# confirmed_state is deliberately strict. Per-domain consumers can expose only
# the verified domain without leaking unrelated stale ownership or money.
def confirmed_domain(bridge,domain):
    if domain not in {"wallet","inventory","calendar","wishlist","continuity"}: raise ValueError("unsupported domain")
    if not bridge.confirmations_allowed(domain): raise ConnectorUnavailable("domain confirmation is unresolved")
    value=getattr(bridge.state(),domain)
    if hasattr(value,"model_dump"): return value.model_dump(mode="json")
    if isinstance(value,list): return [v.model_dump(mode="json") if hasattr(v,"model_dump") else v for v in value]
    return {k:v.model_dump(mode="json") if hasattr(v,"model_dump") else v for k,v in value.items()}
