"""Durable, isolated fake native provider for P5 failure/restart verification.

Native body shapes are retained; versions/CAS are a fixture capability. Notion
has no equivalent documented atomic compare-and-swap: this is not live proof.
"""
import json
import sqlite3
from uuid import uuid4
from .write_models import digest
from .write_coordinator import Observation, DefinitiveWriteFailure, WriteConflict


class SimulatedProcessDeath(BaseException):
    pass


class NativeFixtureAdapter:
    evidence_scope = "fixture"

    def __init__(self, path):
        self.db = sqlite3.connect(str(path), isolation_level=None)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS native_resources(
          id TEXT PRIMARY KEY, body TEXT NOT NULL, version TEXT NOT NULL,
          marker TEXT, parent TEXT, archived INTEGER NOT NULL DEFAULT 0);
        CREATE TABLE IF NOT EXISTS provider_calls(
          id INTEGER PRIMARY KEY, action TEXT NOT NULL, operation_id TEXT NOT NULL);
        ''')
        self.faults = {}

    def seed(self, identifier, body, version="v1"):
        self.db.execute("INSERT OR IGNORE INTO native_resources(id,body,version) VALUES(?,?,?)",
                        (identifier, json.dumps(body, ensure_ascii=False), version))

    def get(self, identifier):
        row = self.db.execute("SELECT * FROM native_resources WHERE id=?", (identifier,)).fetchone()
        return dict(row) if row else None

    def edit(self, identifier, body):
        self.db.execute("UPDATE native_resources SET body=?,version=? WHERE id=?",
                        (json.dumps(body, ensure_ascii=False), "v_"+uuid4().hex, identifier))

    def fault(self, operation_id, stage, value):
        self.faults[(operation_id, stage)] = value

    def _fault(self, op, stage):
        value = self.faults.pop((op.operation_id, stage), None)
        if value == "crash":
            raise SimulatedProcessDeath(stage)
        if value == "lost":
            raise ConnectionError("fixture response unavailable")
        if value == "refuse":
            raise DefinitiveWriteFailure("fixture provider rejected before applying")

    def _receipt(self, row, op, undone=False):
        return {"resource_id":row["id"], "version":row["version"], "marker":op.marker,
                "fields_hash":digest(json.loads(row["body"])), "fixture":True, "undone":undone}

    def observe(self, op, receipt=None, undo=False):
        if op.kind == "calendar.cancel":
            raise ValueError("cancellation requires the native HTTP fixture adapter")
        self._fault(op, "observe")
        if op.kind == "block.patch":
            row = self.get(op.target)
            if row is None or row["archived"]:
                return Observation("CONFLICT")
            fields = json.loads(row["body"])
            if fields == op.after:
                if row["marker"] != op.marker:
                    return Observation("CONFLICT")
                if receipt and row["version"] != receipt["version"]:
                    return Observation("CONFLICT")
                return Observation("AFTER", self._receipt(row, op))
            if fields == op.before:
                if (undo and row["marker"] == op.marker+":undone") or (not undo and row["version"] == op.expected_version):
                    if undo and receipt and receipt.get("undone") and row["version"] != receipt["version"]:
                        return Observation("CONFLICT")
                    return Observation("BEFORE", self._receipt(row, op, undone=undo))
            return Observation("CONFLICT")
        matches = self.db.execute("SELECT * FROM native_resources WHERE marker=? AND archived=0", (op.marker,)).fetchall()
        if len(matches) > 1:
            return Observation("CONFLICT")
        if matches:
            row = matches[0]
            if row["parent"] != op.target or json.loads(row["body"]) != op.after:
                return Observation("CONFLICT")
            if receipt and (row["id"] != receipt["resource_id"] or row["version"] != receipt["version"]):
                return Observation("CONFLICT")
            return Observation("AFTER", self._receipt(row, op))
        if undo and receipt:
            old = self.get(receipt["resource_id"])
            if old and old["archived"] and old["marker"] == op.marker and json.loads(old["body"]) == op.after:
                if receipt.get("undone") and old["version"] != receipt["version"]:
                    return Observation("CONFLICT")
                return Observation("BEFORE", self._receipt(old, op, undone=True))
            return Observation("CONFLICT")
        parent = self.get(op.target)
        if not parent or parent["archived"]:
            return Observation("CONFLICT")
        if op.expected_version and parent["version"] != op.expected_version:
            return Observation("CONFLICT")
        return Observation("BEFORE")

    def apply(self, op):
        self.db.execute("INSERT INTO provider_calls(action,operation_id) VALUES('apply',?)", (op.operation_id,))
        self._fault(op, "before_apply")
        self.db.execute("BEGIN IMMEDIATE")
        try:
            observed = self.observe(op)
            if observed.state == "AFTER":
                self.db.execute("COMMIT")
                return observed.receipt
            if observed.state != "BEFORE":
                raise DefinitiveWriteFailure("fixture CAS precondition changed")
            version = "v_"+uuid4().hex
            if op.kind == "block.patch":
                identifier = op.target
                self.db.execute("UPDATE native_resources SET body=?,version=?,marker=? WHERE id=?",
                                (json.dumps(op.after, ensure_ascii=False), version, op.marker, identifier))
            else:
                # Google supplied IDs are safe to repeat; Notion IDs are server
                # generated. Marker lookup can resolve success but not prove a
                # still-in-flight absent request won't eventually finish.
                identifier = op.after["id"] if op.kind == "calendar.create" else uuid4().hex
                self.db.execute("INSERT INTO native_resources VALUES(?,?,?,?,?,0)",
                                (identifier, json.dumps(op.after, ensure_ascii=False), version, op.marker, op.target))
            self.db.execute("COMMIT")
        except BaseException:
            if self.db.in_transaction:
                self.db.execute("ROLLBACK")
            raise
        self._fault(op, "after_apply")
        return self._receipt(self.get(identifier), op)

    def compensate(self, op, receipt):
        self.db.execute("INSERT INTO provider_calls(action,operation_id) VALUES('undo',?)", (op.operation_id,))
        self._fault(op, "before_undo")
        self.db.execute("BEGIN IMMEDIATE")
        try:
            if self.observe(op, receipt).state != "AFTER":
                raise WriteConflict("fixture CAS prevents overwriting external edit")
            identifier = receipt["resource_id"]; version = "v_"+uuid4().hex
            if op.kind == "block.patch":
                self.db.execute("UPDATE native_resources SET body=?,version=?,marker=? WHERE id=?",
                    (json.dumps(op.before, ensure_ascii=False), version, op.marker+":undone", identifier))
            else:
                # Archive our exact created resource; never delete user content.
                self.db.execute("UPDATE native_resources SET archived=1,version=? WHERE id=?", (version, identifier))
            self.db.execute("COMMIT")
        except BaseException:
            if self.db.in_transaction:
                self.db.execute("ROLLBACK")
            raise
        self._fault(op, "after_undo")
        return self._receipt(self.get(identifier), op, undone=True)

    def calls(self, operation_id, action="apply"):
        return self.db.execute("SELECT COUNT(*) FROM provider_calls WHERE operation_id=? AND action=?", (operation_id, action)).fetchone()[0]

    def close(self):
        self.db.close()
