"""Append causal records to existing pages; never replace their source prose."""
import json
from .native_plans import rich
from .write_models import NativeOperation


def append_record(page,tx,name,domain,record):
    marker=tx+":"+name
    text=json.dumps({"marker":marker,**record},ensure_ascii=False,sort_keys=True,allow_nan=False)
    parts=[]
    for index in range(0,len(text),1900): parts.extend(rich(text[index:index+1900]))
    if len(parts)>100: raise ValueError("native journal exceeds Notion text budget")
    child={"object":"block","type":"code","code":{"language":"json","rich_text":parts}}
    return NativeOperation(operation_id=name,connector="notion",kind="page.append",target=page["page"]["id"],
        domain=domain,after={"children":[child]},expected_version=page["page"]["last_edited_time"],marker=marker)


def state_delta(before,after,event,decision):
    domains={}
    for name in ["world","relationships","taste","continuity","hooks"]:
        left=before.model_dump(mode="json")[name]; right=after.model_dump(mode="json")[name]
        if left!=right:
            domains[name]={"append":right[len(left):]} if name=="continuity" and right[:len(left)]==left else {"before":left,"after":right}
    return {"kind":"validated_effect_delta","event_id":event.event_id,"decision_id":decision.decision_id,
            "time":after.world.time.isoformat(),"actions":[a.model_dump(mode="json") for a in decision.actions],
            "domains":domains,"scope":after.mode}
