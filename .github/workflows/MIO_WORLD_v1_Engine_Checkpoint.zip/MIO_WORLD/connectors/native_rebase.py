"""Read-only, evidence-backed Wallet/Inventory cache reconciliation.

An immutable native ledger prefix anchors the balance. New rows must explain
every yen, including monthly spending. Native ownership rows are preserved in
the import journal, including removals; no purchase story is inferred.
"""
import json
import re
import sqlite3
from contextlib import nullcontext
from datetime import date
from zoneinfo import ZoneInfo
from core.models import State, LedgerEntry, ContinuityEdge
from core.validator import RuleViolation, Validator
from .native_plans import unique_field, unique_table, money_field, block_fields, plain
from .write_models import digest
from .http_json import ConnectorUnavailable
from .canonical_runtime import fresh
from .runtime_bootstrap import inventory_items
from .wallet_month import native_period, month_accounting


def wallet_snapshot(evidence,now):
    blocks=evidence.wallet['blocks']
    balance,_=money_field(unique_field(blocks,'残高:'),'残高:',0)
    monthly,_=money_field(unique_field(blocks,'今月の支出:'),'今月の支出:',0)
    table=unique_table(blocks,['日付','種類','内容','金額','残高'])
    rows=[]; ids=set()
    for row in table['children'][1:]:
        if not row.get('id') or not row.get('last_edited_time') or row['id'] in ids:
            raise RuleViolation('ledger rows must have unique versioned native IDs')
        ids.add(row['id'])
        rows.append({'id':row['id'],'hash':digest(block_fields(row)),
                     'cells':[plain(c) for c in row['table_row']['cells']]})
    return {'scope':evidence.scope,'wallet_id':evidence.wallet['page']['id'],
            'inventory_id':evidence.inventory_schema['id'],'balance':balance,'monthly':monthly,'rows':rows,
            'period':native_period(blocks,now)}


def parsed_row(row,now):
    cells=row['cells']
    if len(cells)!=5: raise RuleViolation('unfamiliar native ledger width')
    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',cells[0]):
        raise RuleViolation('native ledger date must be explicit ISO calendar date')
    when=date.fromisoformat(cells[0])
    if when>now.date():
        raise RuleViolation('future native ledger date cannot be confirmed')
    amount=re.fullmatch(r'([+-]?)[¥￥]([0-9][0-9,]*)',cells[3])
    balance=re.fullmatch(r'[¥￥]([0-9][0-9,]*)',cells[4])
    if not amount or not balance: raise RuleViolation('unfamiliar native ledger money format')
    value=int(amount[2].replace(',',''))*(-1 if amount[1]=='-' else 1)
    if not value or not cells[2].strip(): raise RuleViolation('ledger requires a nonzero amount and cause')
    if (value<0 and cells[1] not in {'EXPENSE','支出'}) or (value>0 and cells[1] not in {'INCOME','収入'}):
        raise RuleViolation('ledger kind disagrees with signed amount')
    marker=re.search(r'\[(ext_[0-9a-f]{24}):money\.log; event=([^;]+); decision=([^\]]+)\]',cells[2])
    return value,int(balance[1].replace(',','')),marker


class NativeCacheReconciler:
    def __init__(self,bridge):
        self.bridge=bridge; self.db=bridge.db
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS native_rebase_anchor(id INTEGER PRIMARY KEY CHECK(id=1),body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS native_rebase_journal(proof_hash TEXT PRIMARY KEY,body TEXT NOT NULL);
        ''')

    def require_current_month(self,evidence,now):
        """A read/prepare cannot bypass an unresolved monthly rollover."""
        state=self.bridge.state(); now=now.astimezone(ZoneInfo(state.world.timezone))
        period=native_period(evidence.wallet['blocks'],now)
        saved=self.db.execute('SELECT body FROM native_rebase_anchor').fetchone()
        if saved:
            old=json.loads(saved[0])
            if old['month']!=now.strftime('%Y-%m'):
                raise RuleViolation('native monthly rollover must be reconciled before confirmation')
            if old.get('ledger_timezone',state.world.timezone)!=state.world.timezone:
                raise RuleViolation('native ledger timezone differs from durable anchor')
            if old.get('period') and (period is None or old['period']['id']!=period['id']):
                raise RuleViolation('native spending month identity differs from durable anchor')

    def _guard(self,evidence,now,state):
        fresh(evidence.read_at,now)
        if evidence.notion_stale or (evidence.scope=='fixture')!=(state.mode=='mock'):
            raise RuleViolation('rebase scope/staleness mismatch')
        if evidence.reserved_jpy!=state.wallet.reserved_amount:
            raise RuleViolation('rebase cannot reinterpret reservations')
        if self.db.execute("SELECT 1 FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchone():
            raise RuleViolation('native reconciliation waits for all unresolved cache bindings')
        if not self.bridge.coordinator.confirmations_allowed('wallet','inventory'):
            raise RuleViolation('native reconciliation waits for ownership/money writes')
        for obj in [evidence.wallet['page'],evidence.inventory_schema]:
            if not obj.get('id') or not obj.get('last_edited_time') or obj.get('archived') or obj.get('in_trash'):
                raise RuleViolation('active versioned native evidence required')

    def anchor(self,evidence,now,within_atomic=False):
        """Baseline only while cache and native truth agree; never repair drift."""
        state=self.bridge.state(); self._guard(evidence,now,state)
        now=now.astimezone(ZoneInfo(state.world.timezone)); snapshot=wallet_snapshot(evidence,now)
        if self.db.execute('SELECT 1 FROM native_rebase_anchor').fetchone(): return
        owned=inventory_items(evidence.inventory_rows,evidence.scope,now)
        if snapshot['balance']!=state.wallet.balance or set(owned)!={k for k,i in state.inventory.items() if i.status=='owned'}:
            raise RuleViolation('cannot anchor unexplained native balance/ownership')
        for key,item in owned.items():
            if any(getattr(item,k)!=getattr(state.inventory[key],k) for k in ['name','brand','price','acquired_at','condition','location']):
                raise RuleViolation('cannot anchor differing native Inventory facts')
        if snapshot['rows']:
            for row in snapshot['rows']:
                if len(row['cells'])!=5 or date.fromisoformat(row['cells'][0])>now.date():
                    raise RuleViolation('initial ledger has an invalid/future date')
            last=snapshot['rows'][-1]['cells']
            if len(last)!=5 or last[4] not in {f"¥{state.wallet.balance:,}",f"¥{state.wallet.balance}",f"￥{state.wallet.balance:,}"}:
                raise RuleViolation('initial ledger endpoint differs from native Wallet')
        snapshot['month']=now.strftime('%Y-%m')
        snapshot.update(baseline_month=snapshot['month'],month_totals={snapshot['month']:snapshot['monthly']},
                        historical_expense_deltas={},ledger_timezone=state.world.timezone)
        with nullcontext() if within_atomic else self.bridge.coordinator.atomic():
            if digest(self.bridge.state().model_dump(mode='json'))!=digest(state.model_dump(mode='json')):
                raise RuleViolation('cache changed during anchor')
            self.db.execute('INSERT OR IGNORE INTO native_rebase_anchor VALUES(1,?)',(json.dumps(snapshot,ensure_ascii=False),))

    def reconcile(self,evidence,now,notion):
        """Require a second stable full native read before atomic cache import."""
        with self.bridge.coordinator.worker_lock():
            try: return self._reconcile(evidence,now,notion)
            except (RuleViolation,ValueError,KeyError,ConnectorUnavailable):
                self.bridge.mark_stale('notion'); raise
            except sqlite3.Error:
                self.bridge.mark_stale('notion')
                raise ConnectorUnavailable('native rebase persistence failed; confirmations frozen') from None

    def _reconcile(self,evidence,now,notion):
        state=self.bridge.state(); self._guard(evidence,now,state)
        now=now.astimezone(ZoneInfo(state.world.timezone))
        if bool(getattr(notion.http,'fixture',False))!=(evidence.scope=='fixture'):
            raise RuleViolation('native read provider and rebase evidence scope differ')
        saved=self.db.execute('SELECT body FROM native_rebase_anchor').fetchone()
        if not saved: raise RuleViolation('external drift has no durable native baseline')
        old=json.loads(saved[0]); current=wallet_snapshot(evidence,now)
        if (current['scope'],current['wallet_id'],current['inventory_id'])!=(old['scope'],old['wallet_id'],old['inventory_id']):
            raise RuleViolation('native rebase target/scope changed')
        if current['rows'][:len(old['rows'])]!=old['rows']:
            raise RuleViolation('native ledger prefix was edited/deleted/reordered')
        # A Notion page timestamp alone cannot prove a stable multi-resource read.
        wallet=notion.page(current['wallet_id']); rows=notion.inventory_rows(current['inventory_id'])
        schema=notion.data_source(current['inventory_id'])
        if digest(wallet)!=digest(evidence.wallet) or digest(schema)!=digest(evidence.inventory_schema) or digest(sorted(rows,key=lambda r:r['id']))!=digest(sorted(evidence.inventory_rows,key=lambda r:r['id'])):
            raise RuleViolation('native truth changed during reconciliation reads')
        running=old['balance']; imports=[]; seen_external=False; additions=[]
        for row in current['rows'][len(old['rows']):]:
            amount,balance,marker=parsed_row(row,now)
            if running+amount!=balance: raise RuleViolation('native ledger arithmetic mismatch')
            running=balance; additions.append((row,amount))
            if marker:
                tx,event_id,decision_id=marker.groups()
                commit=self.db.execute('SELECT event_id,decision_id FROM canonical_commits WHERE transaction_id=?',(tx,)).fetchone()
                existing=[entry for entry in state.wallet.ledger if entry.transaction_id==tx]
                if seen_external or not commit or tuple(commit)!=(event_id,decision_id) or len(existing)!=1 or (existing[0].amount,existing[0].balance_after)!=(amount,balance) or existing[0].created_at.astimezone(ZoneInfo(state.world.timezone)).date().isoformat()!=row['cells'][0]:
                    raise RuleViolation('native runtime marker has no matching published ledger receipt')
            else:
                seen_external=True
                imports.append(LedgerEntry(ledger_id='native:'+row['id'],amount=amount,balance_after=balance,
                    event_id='native:notion:'+row['id'],transaction_id='rebase_'+digest(row)[:24],created_at=now))
        if running!=current['balance']:
            raise RuleViolation('new native rows do not explain balance')
        try: accounting=month_accounting(old,current,additions,now,state.world.timezone)
        except ValueError as error: raise RuleViolation(str(error)) from None
        if state.wallet.balance+sum(e.amount for e in imports)!=current['balance']:
            raise RuleViolation('native delta does not reconcile cached ledger')
        owned=inventory_items(evidence.inventory_rows,evidence.scope,now)
        # Preserve runtime creation causes when managed native facts still agree.
        for key,item in owned.items():
            previous=state.inventory.get(key)
            if previous and all(getattr(previous,k)==getattr(item,k) for k in ['name','brand','category','price','acquired_at','condition','location','status']):
                owned[key]=previous.model_copy(deep=True)
        projected=state.model_copy(deep=True)
        projected.wallet.balance=current['balance']; projected.wallet.ledger.extend(imports)
        projected.inventory={**{k:v for k,v in state.inventory.items() if v.status!='owned'},**owned}
        month_changed=old['month']!=accounting['month'] or old.get('period')!=current['period']
        changed=projected.wallet!=state.wallet or projected.inventory!=state.inventory or month_changed
        proof={'kind':'native_cache_rebase','scope':evidence.scope,'read_at':evidence.read_at.isoformat(),
               'observed_at':now.isoformat(),'before_hash':digest(state.model_dump(mode='json')),
               'native_wallet':evidence.wallet,'inventory_schema':evidence.inventory_schema,'inventory_rows':evidence.inventory_rows,
               'inventory_before':{k:v.model_dump(mode='json') for k,v in state.inventory.items()},
               'imported_ledger_ids':[e.ledger_id for e in imports],'external_writes':0,
               'monthly_before':{k:old.get(k) for k in ['month','monthly','period','baseline_month','month_totals','historical_expense_deltas','ledger_timezone']},
               'monthly_after':{**accounting,'monthly':current['monthly'],'period':current['period']}}
        proof_hash=digest(proof)
        if changed:
            projected.continuity.append(ContinuityEdge(cause='native.read:'+proof_hash,consequence='cache.rebase',
                transaction_id='rebase_'+proof_hash[:24],depth=0))
        projected.notion_stale=False
        if changed or state.notion_stale: projected.revision+=1
        projected=State.model_validate_json(projected.model_dump_json()); Validator.invariants(projected)
        current.update(accounting)
        with self.bridge.coordinator.atomic():
            if digest(self.bridge.state().model_dump(mode='json'))!=proof['before_hash']:
                raise RuleViolation('cache changed during native reconciliation')
            self._guard(evidence,now,self.bridge.state())
            self.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(projected.model_dump_json(),))
            self.db.execute('UPDATE native_rebase_anchor SET body=? WHERE id=1',(json.dumps(current,ensure_ascii=False),))
            if changed:
                self.db.execute('INSERT INTO native_rebase_journal VALUES(?,?)',(proof_hash,json.dumps(proof,ensure_ascii=False)))
        return 'REBASED' if changed else 'UNCHANGED'
