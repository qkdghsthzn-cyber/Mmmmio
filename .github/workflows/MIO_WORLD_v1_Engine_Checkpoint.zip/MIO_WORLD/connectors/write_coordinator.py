"""Durable saga/outbox. Fixture verification only until real P3/P5 gates pass.

No external service offers a cross-service atomic transaction. Canonical writes
may be temporarily partial. Only verified all-success receipts publish a commit.
"""
import json
import sqlite3
from contextlib import contextmanager, nullcontext
from .write_models import WritePlan, NativeOperation, digest
from .http_json import ConnectorUnavailable


class WriteConflict(ValueError):
    pass


class DefinitiveWriteFailure(RuntimeError):
    """Provider confirms that the request did not apply."""


class Observation:
    def __init__(self, state, receipt=None):
        if state not in {"BEFORE", "AFTER", "UNKNOWN", "CONFLICT"}:
            raise ValueError("unknown observation")
        self.state = state
        self.receipt = receipt


class WriteCoordinator:
    def __init__(self, path, adapters):
        if str(path) == ":memory:":
            raise ValueError("external writes require a durable file-backed outbox")
        self.db = sqlite3.connect(str(path), isolation_level=None, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.execute("PRAGMA synchronous=FULL")
        self.adapters = adapters
        self.recovery_vault = None
        self._protected_atomic_active = False
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS external_transactions(
          transaction_id TEXT PRIMARY KEY, event_id TEXT UNIQUE NOT NULL,
          decision_id TEXT UNIQUE NOT NULL, plan_hash TEXT NOT NULL,
          plan TEXT NOT NULL, status TEXT NOT NULL, error TEXT);
        CREATE TABLE IF NOT EXISTS external_outbox(
          transaction_id TEXT NOT NULL, ordinal INTEGER NOT NULL, body TEXT NOT NULL,
          status TEXT NOT NULL, receipt TEXT, undo_receipt TEXT,
          PRIMARY KEY(transaction_id, ordinal));
        CREATE TABLE IF NOT EXISTS external_locks(
          resource_key TEXT PRIMARY KEY, transaction_id TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS canonical_commits(
          transaction_id TEXT PRIMARY KEY, event_id TEXT UNIQUE NOT NULL,
          decision_id TEXT NOT NULL, evidence_scope TEXT NOT NULL, receipts TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS external_audit(
          id INTEGER PRIMARY KEY, transaction_id TEXT NOT NULL, action TEXT NOT NULL, detail TEXT NOT NULL);
        ''')

    @contextmanager
    def atomic(self):
        vault=self.recovery_vault
        if vault is None:
            from .database_recovery import recovery_pending,RecoveryUnavailable
            if recovery_pending(self.db): raise RecoveryUnavailable('reattach recovery vault before mutating the restored database')
        with vault.lock() if vault else nullcontext():
            self.db.execute("BEGIN IMMEDIATE")
            begun=False; previous=None
            try:
                if vault:
                    previous=vault.begin(self.db); begun=True
                    self._protected_atomic_active=True
                yield
                self.db.execute("COMMIT")
            except BaseException:
                self._protected_atomic_active=False
                if self.db.in_transaction: self.db.execute("ROLLBACK")
                if begun: vault.abort(previous)
                raise
            else:
                self._protected_atomic_active=False
                # A checkpoint failure after COMMIT leaves the independent
                # dirty fence intact. Do not claim a rollback or send more I/O.
                if vault: vault.finish(self.db)

    def enable_recovery(self,vault):
        if self.recovery_vault is not None: raise WriteConflict('recovery vault already attached')
        vault.attach(self)

    def _recovery_io_gate(self):
        from .database_recovery import recovery_pending,RecoveryUnavailable
        if self._protected_atomic_active: raise RecoveryUnavailable('provider mutation cannot run inside an uncheckpointed transaction')
        if recovery_pending(self.db) and self.recovery_vault is None:
            raise RecoveryUnavailable('restored database requires the surviving vault before provider I/O')
        if self.recovery_vault: self.recovery_vault.ensure_clean(self.db)

    def audit(self, tx, action, detail=""):
        self.db.execute("INSERT INTO external_audit(transaction_id,action,detail) VALUES(?,?,?)",
                        (tx, action, detail))

    def prepare(self, plan, on_prepare=None):
        from .database_recovery import recovery_pending,RecoveryUnavailable
        if recovery_pending(self.db): raise RecoveryUnavailable('fresh native revalidation required before new proposals')
        from runtime.host_resume import pending
        if pending(self.db): raise RecoveryUnavailable('fresh native revalidation required after host suspension')
        # Revalidate even model_construct/mutable nested input; no unvalidated LLM
        # operations. The native planner is called after code-based validation.
        plan = WritePlan.model_validate_json(plan.model_dump_json())
        if plan.evidence_scope != "fixture":
            raise ConnectorUnavailable("P3/P5 real roundtrip gate has not passed; canonical writes are disabled")
        for op in plan.operations:
            if getattr(self.adapters.get(op.connector), "evidence_scope", None) != "fixture":
                raise ConnectorUnavailable("only isolated fixture adapters may execute this checkpoint")
        tx = plan.transaction_id
        fingerprint = digest(plan.model_dump(mode="json"))
        with self.atomic():
            old = self.db.execute("SELECT * FROM external_transactions WHERE event_id=?", (plan.event_id,)).fetchone()
            if old:
                if old["plan_hash"] != fingerprint:
                    raise WriteConflict("same event ID with changed proposal")
                return tx
            if self.db.execute("SELECT 1 FROM external_transactions WHERE decision_id=?", (plan.decision_id,)).fetchone():
                raise WriteConflict("decision already belongs to another event")
            keys = {o.resource_key for o in plan.operations}
            # Lock by semantic domain as well as resource: wallet/log/inventory
            # confirmations cannot be split while another purchase is unresolved.
            keys.update("domain:" + o.domain for o in plan.operations)
            for key in sorted(keys):
                if self.db.execute("SELECT 1 FROM external_locks WHERE resource_key=?", (key,)).fetchone():
                    raise WriteConflict("resource has an unresolved transaction")
            self.db.execute("INSERT INTO external_transactions VALUES(?,?,?,?,?,'PREPARED',NULL)",
                            (tx, plan.event_id, plan.decision_id, fingerprint, plan.model_dump_json()))
            self.db.executemany("INSERT INTO external_locks VALUES(?,?)", [(key, tx) for key in sorted(keys)])
            self.db.executemany("INSERT INTO external_outbox VALUES(?,?,?,'PENDING',NULL,NULL)",
                               [(tx, i, op.model_dump_json()) for i, op in enumerate(plan.operations)])
            self.audit(tx, "PREPARED", fingerprint)
            if on_prepare is not None:
                on_prepare(tx)
        return tx

    def status(self, tx):
        row = self.db.execute("SELECT status FROM external_transactions WHERE transaction_id=?", (tx,)).fetchone()
        if row is None:
            raise KeyError(tx)
        return row[0]

    def rows(self, tx):
        return self.db.execute("SELECT * FROM external_outbox WHERE transaction_id=? ORDER BY ordinal", (tx,)).fetchall()

    def _operation(self, row):
        op = NativeOperation.model_validate_json(row["body"])
        adapter = self.adapters.get(op.connector)
        if getattr(adapter, "evidence_scope", None) != "fixture":
            raise ConnectorUnavailable("fixture scope required on resume, too")
        return op, adapter

    def _tx_state(self, tx, status, error=None):
        with self.atomic():
            self.db.execute("UPDATE external_transactions SET status=?,error=? WHERE transaction_id=?", (status, error, tx))
            self.audit(tx, status, error or "")
            if status in {"COMMITTED", "ROLLED_BACK"}:
                self.db.execute("DELETE FROM external_locks WHERE transaction_id=?", (tx,))

    def _op_state(self, tx, ordinal, status, receipt=None, undo=False):
        with self.atomic():
            field = "undo_receipt" if undo else "receipt"
            self.db.execute(f"UPDATE external_outbox SET status=?,{field}=COALESCE(?,{field}) WHERE transaction_id=? AND ordinal=?",
                            (status, json.dumps(receipt, ensure_ascii=False) if receipt else None, tx, ordinal))
            self.audit(tx, status, str(ordinal))

    def _receipt_valid(self, op, receipt):
        if not isinstance(receipt, dict):
            return False
        valid = (bool(receipt.get("resource_id")) and bool(receipt.get("version"))
                 and receipt.get("marker") == op.marker and receipt.get("fields_hash") == digest(op.after)
                 and receipt.get("fixture") is True)
        if op.kind == "block.patch":
            valid = valid and receipt.get("resource_id") == op.target
        if op.kind in {"calendar.create", "calendar.cancel"}:
            valid = valid and receipt.get("resource_id") == op.after["id"]
        return valid

    def _applied(self, tx, row, observation):
        op = NativeOperation.model_validate_json(row["body"])
        if not self._receipt_valid(op, observation.receipt):
            return self._tx_state(tx, "RECONCILE_REQUIRED", "provider receipt does not prove the prepared native operation")
        self._op_state(tx, row["ordinal"], "APPLIED", observation.receipt)

    @contextmanager
    def worker_lock(self):
        # Holding this local SQLite write lock over provider I/O serializes workers.
        # Durable transitions use a second worker-lock DB, separate from outbox,
        # so a process death releases the lock without rolling back receipts.
        worker = sqlite3.connect(self.db.execute("PRAGMA database_list").fetchone()[2] + ".worker", isolation_level=None, timeout=0)
        try:
            worker.execute("CREATE TABLE IF NOT EXISTS worker(id INTEGER)")
            worker.execute("BEGIN IMMEDIATE")
        except sqlite3.OperationalError:
            worker.close()
            raise WriteConflict("another recovery worker is running") from None
        try:
            yield
        finally:
            worker.execute("ROLLBACK")
            worker.close()

    def run(self, tx):
        self._recovery_io_gate()
        with self.worker_lock():
            return self._run(tx)

    def _run(self, tx):
        status = self.status(tx)
        if status in {"COMMITTED", "ROLLED_BACK", "RECONCILE_REQUIRED"}:
            return status
        if status == "COMPENSATING":
            return self._compensate(tx)
        self._tx_state(tx, "APPLYING")
        for row in self.rows(tx):
            op, adapter = self._operation(row)
            if row["status"] == "APPLIED":
                continue
            if row["status"] == "FAILED":
                self._tx_state(tx, "COMPENSATING")
                return self._compensate(tx)
            receipt = json.loads(row["receipt"]) if row["receipt"] else None
            try:
                observation = adapter.observe(op, receipt)
            except Exception:
                self._tx_state(tx, "RECONCILE_REQUIRED", "provider read failed before write")
                return self.status(tx)
            if observation.state == "AFTER":
                self._applied(tx, row, observation)
                if self.status(tx) == "RECONCILE_REQUIRED":
                    return self.status(tx)
                continue
            if observation.state in {"UNKNOWN", "CONFLICT"}:
                self._tx_state(tx, "RECONCILE_REQUIRED", "provider truth is uncertain or externally edited")
                return self.status(tx)
            if row["status"] == "APPLYING" and not op.replay_safe:
                # An absence query does not prove that a timed-out Notion create
                # is not still in flight. Never automatically repeat that POST.
                self._tx_state(tx, "RECONCILE_REQUIRED", "ambiguous non-idempotent request; no resend")
                return self.status(tx)
            self._op_state(tx, row["ordinal"], "APPLYING")
            try:
                receipt = adapter.apply(op)
            except DefinitiveWriteFailure:
                self._op_state(tx, row["ordinal"], "FAILED")
                self._tx_state(tx, "COMPENSATING", "provider refused operation")
                return self._compensate(tx)
            except Exception:
                self._tx_state(tx, "RECONCILE_REQUIRED", "write response lost; reread required")
                return self.status(tx)
            # Never treat an HTTP success response alone as canonical truth.
            try:
                observed = adapter.observe(op, receipt)
            except Exception:
                self._tx_state(tx, "RECONCILE_REQUIRED", "post-write reread failed")
                return self.status(tx)
            if observed.state != "AFTER":
                self._tx_state(tx, "RECONCILE_REQUIRED", "post-write fields disagree")
                return self.status(tx)
            self._applied(tx, row, observed)
            if self.status(tx) == "RECONCILE_REQUIRED":
                return self.status(tx)
        # All resources must still match, including earlier writes that could
        # have changed during later provider calls.
        receipts = []
        for row in self.rows(tx):
            op, adapter = self._operation(row)
            receipt = json.loads(row["receipt"])
            try:
                observation = adapter.observe(op, receipt)
            except Exception:
                observation = Observation("UNKNOWN")
            if observation.state != "AFTER" or not self._receipt_valid(op, observation.receipt):
                self._tx_state(tx, "RECONCILE_REQUIRED", "final canonical reread disagrees")
                return self.status(tx)
            receipts.append({"operation_id": op.operation_id, "receipt": observation.receipt})
        with self.atomic():
            plan = WritePlan.model_validate_json(self.db.execute("SELECT plan FROM external_transactions WHERE transaction_id=?", (tx,)).fetchone()[0])
            self.db.execute("INSERT INTO canonical_commits VALUES(?,?,?,?,?)",
                            (tx, plan.event_id, plan.decision_id, plan.evidence_scope, json.dumps(receipts, ensure_ascii=False)))
            self.db.execute("UPDATE external_transactions SET status='COMMITTED',error=NULL WHERE transaction_id=?", (tx,))
            self.db.execute("DELETE FROM external_locks WHERE transaction_id=?", (tx,))
            self.audit(tx, "COMMITTED")
        return "COMMITTED"

    def _compensate(self, tx):
        for row in reversed(self.rows(tx)):
            if row["status"] in {"PENDING", "FAILED", "UNDONE"}:
                continue
            if row["status"] not in {"APPLIED", "UNDOING"}:
                self._tx_state(tx, "RECONCILE_REQUIRED", "unresolved write before compensation")
                return self.status(tx)
            op, adapter = self._operation(row)
            receipt = json.loads(row["receipt"]) if row["receipt"] else None
            try:
                observed = adapter.observe(op, receipt, undo=row["status"] == "UNDOING")
                if row["status"] == "UNDOING" and observed.state == "BEFORE":
                    self._op_state(tx, row["ordinal"], "UNDONE", observed.receipt, undo=True)
                    continue
                if observed.state != "AFTER":
                    raise WriteConflict("compensation would overwrite external edit")
                self._op_state(tx, row["ordinal"], "UNDOING")
                undo_receipt = adapter.compensate(op, receipt)
                if adapter.observe(op, undo_receipt, undo=True).state != "BEFORE":
                    raise WriteConflict("compensation reread disagrees")
                self._op_state(tx, row["ordinal"], "UNDONE", undo_receipt, undo=True)
            except Exception:
                self._tx_state(tx, "RECONCILE_REQUIRED", "compensation uncertain; confirmations frozen")
                return self.status(tx)
        # Earlier undo receipts must still agree before claiming full rollback.
        for row in self.rows(tx):
            if row["status"] != "UNDONE":
                continue
            op, adapter = self._operation(row)
            receipt = json.loads(row["undo_receipt"]) if row["undo_receipt"] else None
            try:
                observed = adapter.observe(op, receipt, undo=True)
            except Exception:
                observed = Observation("UNKNOWN")
            if observed.state != "BEFORE":
                self._tx_state(tx, "RECONCILE_REQUIRED", "final compensation reread disagrees")
                return self.status(tx)
        self._tx_state(tx, "ROLLED_BACK")
        return "ROLLED_BACK"

    def reconcile(self, tx):
        self._recovery_io_gate()
        with self.worker_lock():
            return self._reconcile(tx)

    def _reconcile(self, tx):
        # Reread only; never manually flip an unresolved saga to COMMITTED.
        # run() will again verify every receipt before publishing any fact.
        if self.status(tx) != "RECONCILE_REQUIRED":
            return self._run(tx)
        compensating = any(r["status"] in {"FAILED", "UNDOING", "UNDONE"} for r in self.rows(tx))
        for row in self.rows(tx):
            if row["status"] not in {"APPLYING", "APPLIED", "UNDOING"}:
                continue
            op, adapter = self._operation(row)
            receipt = json.loads(row["receipt"]) if row["receipt"] else None
            try:
                observation = adapter.observe(op, receipt, undo=row["status"] == "UNDOING")
            except Exception:
                return self.status(tx)
            if row["status"] == "UNDOING" and observation.state == "BEFORE":
                self._op_state(tx, row["ordinal"], "UNDONE", observation.receipt, undo=True)
            elif observation.state == "AFTER":
                if row["status"] != "UNDOING":
                    self._applied(tx, row, observation)
            elif row["status"] == "APPLYING" and observation.state == "BEFORE" and op.replay_safe:
                self._op_state(tx, row["ordinal"], "PENDING")
            else:
                return self.status(tx)
        self._tx_state(tx, "COMPENSATING" if compensating else "APPLYING")
        return self._run(tx)

    def cancel_unwritten(self, tx):
        """Release a proposal only when durable outbox proves nothing was sent.

        An APPLYING entry may already have reached a provider and cannot be
        cancelled just because a lookup currently returns no matching object.
        """
        with self.worker_lock():
            if self.status(tx) in {"COMMITTED", "ROLLED_BACK"}:
                return self.status(tx)
            if any(row["status"] != "PENDING" for row in self.rows(tx)):
                raise WriteConflict("sent/uncertain writes require provider reconciliation")
            self._tx_state(tx, "ROLLED_BACK", "cancelled before any provider request")
            return "ROLLED_BACK"

    def confirmations_allowed(self, *domains):
        if self.recovery_vault and not self._protected_atomic_active:
            try: self.recovery_vault.ensure_clean(self.db)
            except ConnectorUnavailable: return False
        if not domains:
            domains = ("wallet", "inventory", "calendar", "wishlist", "continuity", "world", "relationships", "taste")
        return not any(self.db.execute("SELECT 1 FROM external_locks WHERE resource_key=?", ("domain:" + domain,)).fetchone()
                       for domain in domains)

    def committed(self, tx):
        row = self.db.execute("SELECT * FROM canonical_commits WHERE transaction_id=?", (tx,)).fetchone()
        return dict(row) if row else None

    def close(self):
        self.db.close()
