# P5 외부 APK 빌드 준비

현재 상태는 READY_NOT_RUN이다. 사용자 GitHub 웹 로그인/저장소 생성 가능은 확인했으나 원격 job/repository는 아직 생성/실행하지 않았다. 개발 환경은 JRE 17만 있고 javac/Gradle/Python 3.13/Android SDK가 없어 BLOCKED다. APK는 아직 없다.

## 준비한 경로

수동 GitHub Actions workflow는 Ubuntu 24.04에서 Python 3.13·JDK 17·Gradle 8.13·Android platform 36/build-tools 35.0.0을 준비하고, host fixture 회귀를 통과한 뒤 기존 `tools/build_android_probe.py`를 실행한다. 빌드 담당자의 PC를 상시 실행 호스트로 사용하지 않는다. 생성된 APK가 검증을 통과한 경우에만 artifact로 올리고, 실패한 compile/dependency resolve는 실패로 남긴다. Android native wheels를 확보하기 위해 기존 Pydantic 계약을 임의로 낮추지 않는다.

API 키·OAuth 사용자 grant·정본 DB는 이 fixture 빌드에 필요 없다. job 권한은 contents:read이며 자동 push/cron/release 배포는 구성하지 않았다. debug 검사 앱용 APK이며 제품 UI/overlay/실제 credential 입력 앱이 아니다. APK/진단 artifact 보존은 7일로 설정했다.

`deployment/MIO_P5_Build_Sources.zip`는 workflow를 포함한 254개 코드/데이터/시험 파일이다. 기존 엔진·160 Family와 엔진 실행에 필요한 `reference/01_Core_Identity.md`를 원본 그대로 보존한다. 원본 첨부 문서·사진·나머지 reference·native read reports·resources.json·DB·credential은 제외한다. 전체 체크포인트를 repository에 업로드할 필요는 없다.

```bash
python -m tools.package_android_sources
```

전체 소스 checkout 경로는 Actions의 `MIO P5 device probe`에서 실행하는 선택 경로다. 사용자가 GitHub 웹 로그인/저장소 생성은 가능하다고 확인하여 기본 경로를 `P5_GITHUB_PHONE.md`의 source ZIP + `.github/workflows/mio-p5-phone.yml`로 바꿨다. 이 경로는 runner가 ZIP을 추출하므로 휴대폰에서 소스를 풀지 않아도 되고 ChatGPT GitHub 연결도 필요 없다. `P5_COLAB_BUILD.md`는 다른 선택 경로로 유지한다. 어느 경로도 실제 dependency/compile 성공을 보장하지 않는다.

## 확인한 것과 남은 것

| 항목 | 결과 |
|---|---|
| YAML·run shell syntax | PASS |
| code-only export 파일 hash/개인 자료 제외 | PASS |
| 원본 import 경로 없는 export 사본의 전체 회귀 | 368 PASS, 독립 Linux/Python 3.12; 필수 Core Identity 누락 수정 |
| 기존 전체 회귀 | 368 PASS, 개발 Linux/Python 3.12 |
| GitHub 첫 실행/Python 3.13.15 fixture | 368 PASS, 사용자 console ZIP 증거 |
| Android dependency resolution·Java/Gradle compile | BUILD_FAILED, 상세 Gradle log 필요 |
| APK·Z Fold8 설치/절전/실행 | APK 없음, 기기 NOT_RUN |

원격 빌드가 성공해도 실제 Android native loading/16 KiB·화면 전환·저장/복구·네트워크 보안·worker lifecycle을 기기에서 확인해야 한다. P5 live 인증/정본 gate와 P6→P7→P8 순서는 그대로다. 현재 결과: `reports/P5_remote_build.json`.

공식 참고: [Python setup](https://github.com/actions/setup-python), [JDK setup](https://github.com/actions/setup-java), [Gradle setup](https://github.com/gradle/actions/tree/main/setup-gradle), [artifact upload](https://github.com/actions/upload-artifact), [Ubuntu 24.04 runner tools](https://github.com/actions/runner-images/blob/main/images/ubuntu/Ubuntu2404-Readme.md).

## 첫 GitHub 실행 확인 및 오류 표시 보완 (2026-10-06)

사용자가 올린 `logs_101431036398.zip`의 console에서 368개 fixture 전체 PASS를 실제 GitHub/Python 3.13.15 환경에서 확인했다. Java/javac 17·Gradle 8.13·Android SDK 검사도 적합했고 218개 runtime source/160 Family가 staging됐다. 이후 Android build가 Gradle exit 1/helper exit 2로 실패하여 APK는 없다. `reports/P5_github_run1.json`을 최신 상태로 따른다. 이전 NOT_RUN 기록은 해당 준비 체크포인트 당시 상태다.

console에는 helper가 파일로 저장한 실제 Gradle 오류가 없다. 첫 실행의 [MIO_P5_build_diagnostics.zip](https://github.com/qkdghsthzn-cyber/Miooi/actions/runs/37447059977/artifacts/11403891732) 업로드 성공/33,532 bytes를 확인했지만 파일 내용은 아직 받지 못했다. 해당 ZIP을 먼저 받으면 재실행 없이 분석할 수 있다. Download logs의 ZIP과 Summary/Artifacts의 진단 ZIP은 서로 다르다.

phone workflow에 실패한 Android build 뒤 `Show Android build error log`를 추가했다. 마지막 200줄을 표시하며 원래 build 실패/후속 APK 차단은 유지한다. 누락/빈/200줄 제한 로그 3사례, YAML/shell/inline Python·안내 JS/copy 원문을 확인했다. 원본 source ZIP과 core/data/reference 193개 및 기존 회귀/P2 보고서는 변경하지 않았다. **실패 원인은 미확인/미수정이고 새 workflow remote 실행은 NOT_RUN**이다. 진단 ZIP을 받을 수 없는 경우에만 YAML 본문을 교체하여 Commit 후 **새 Run workflow**로 실행한다. P5 live gate와 P6~P8 NOT_STARTED를 유지한다.

## Android 바이너리 의존성 오류 수정 (2026-10-06)

첫 실행의 `MIO_P5_build_diagnostics.zip`(SHA `8eb7e1a…83c80e`)에서 실제 18단계 368 PASS와 Gradle 원인을 확인했다. `:probe:installDebugPythonRequirements`가 Pydantic 2.13 계열의 정확한 `pydantic-core` Android wheel을 찾지 못해 실패했다. Gradle 8.13 안내 경고가 실패 이유는 아니다. 최신 증거는 `reports/P5_android_dependencies_fix.json`이다.

엔진/스키마/requirements 범위를 바꾸지 않고 Android 빌드 constraint에 첫 실행 버전 Pydantic 2.13.5/core 2.46.5를 고정했다. `tools/build_android_wheels.py`는 SHA가 고정된 공식 upstream sdist를 추출하고 Cargo.lock을 유지하여 cibuildwheel 4.3.0/Rust 1.88.0으로 CPython 3.13/API24/arm64-v8a와 x86_64 wheel을 만든다. cibuildwheel이 실제 Android libpython/sysconfig·NDK·Cargo linker/PyO3 환경을 제공한다. version/tag/native ELF architecture/16KiB LOAD alignment와 두 ABI receipt를 확인한 경우에만 Gradle find-links로 공급한다. 새 temp output을 사용해 실패 후 이전 wheel을 재사용하지 않는다. Gradle 실패는 stacktrace와 native-wheel/Gradle 진단 로그로 남긴다. 설치/런타임 적합성은 여전히 실기기 검증 대상이다.

기존 368개와 새 synthetic binary receipt/source guard 10개를 포함한 **378개 회귀가 개발 tree 및 배포 ZIP의 독립 Linux/Python 3.12.14 사본에서 모두 PASS**다. 실제 upstream hash/extraction·cibuildwheel의 두 대상 선택·wheel 실패 시 Gradle/APK 차단·workflow/notebook/guide 문법과 embedded ZIP/copy 원문을 확인했다. synthetic bytes를 실제 wheel/APK로 내보내지 않는다. 원본 engine/data/reference/mobile 227개와 160 Family, P2 10,000시간 보고서 및 live gate를 보존했다.

새 source ZIP은 258개 파일/SHA `feb53d33ffe39372cd88cd7b4c81294e0a40e6ec9c9989205c3501634e6a18fe`이다. **소스 ZIP과 phone YAML 둘 다 교체·Commit하고 새 Run workflow를 실행해야 한다.** 이전 실행의 Re-run jobs는 이전 revision을 사용한다. Colab 노트북에도 새 ZIP/constraint/378개 gate를 반영했으나 선택 경로이며 실행하지 않았다. **수정본의 native wheel compilation·Gradle/APK·Android 실행은 NOT_RUN**이다. P5가 완료된 것으로 표시하지 않으며 P6~P8은 계속 NOT_STARTED다.

공식 빌드 참고: [Chaquopy Android wheel 빌드](https://github.com/chaquo/chaquopy/blob/master/server/pypi/README.md), [cibuildwheel Android](https://cibuildwheel.pypa.io/en/stable/platforms/#android), [PyO3 cross compilation](https://pyo3.rs/main/building-and-distribution.html#cross-compiling).
