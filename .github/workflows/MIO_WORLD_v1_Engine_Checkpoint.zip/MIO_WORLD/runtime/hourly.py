"""Durable native-backed hourly stages. Current executable scope: HTTP fixture.

No simulator-policy fallback in a live world. Native snapshots use a separate
configured page; wallet, Inventory, relationships and source prose stay native.
"""
import json
import sqlite3
from contextlib import contextmanager
from dataclasses import replace
from datetime import timedelta, timezone
from pathlib import Path
from zoneinfo import ZoneInfo
from core.models import State, Event, Decision, TransactionRecord
from core.candidate_generator import CandidateGenerator, seeded
from core.probability_engine import ProbabilityEngine
from core.novelty_engine import NoveltyEngine
from core.chain_engine import ChainEngine
from core.validator import RuleViolation, Validator
from connectors.canonical_runtime import RuntimeEvidenceReader
from connectors.calendar_truth import commitments, UNKNOWN_PLACE
from connectors.native_plans import PurchaseProposal, SpendProposal
from connectors.native_journals import append_record
from connectors.write_models import WritePlan, digest, transaction_id
from connectors.write_coordinator import WriteConflict
from connectors.http_json import ConnectorUnavailable
from connectors.runtime_bootstrap import RuntimeResources


class NativeHourlyRuntime:
    def __init__(self,bridge,notion,calendar,clock,decision_agent,seed=42,world_realizer=None):
        self.bridge=bridge; self.coordinator=bridge.coordinator; self.db=bridge.db
        row=self.db.execute('SELECT body,proof_hash FROM runtime_initialization WHERE id=1').fetchone()
        if not row: raise RuleViolation('durable explicit initialization proof required')
        self.initialization=json.loads(row['body'])
        if digest(self.initialization)!=row['proof_hash']: raise RuleViolation('initialization proof changed')
        self.resources=RuntimeResources.model_validate(self.initialization['resources'])
        if self.initialization['scope']!='fixture' or bridge.state().mode!='mock':
            raise ConnectorUnavailable('P3/P5 production initialization/roundtrip gates have not passed')
        if not notion.http.fixture or not calendar.http.fixture: raise RuleViolation('fixture runtime needs fixture providers')
        if not bridge.validator.allow_internal: raise RuleViolation('hourly runtime requires native internal-effect planner')
        if decision_agent is None: raise RuleViolation('explicit decision agent required; no silent mock fallback')
        self.notion=notion; self.calendar=calendar; self.clock=clock; self.agent=decision_agent
        self.seed=seed; self.realizer=world_realizer; self.grammar=bridge.validator.rules.grammar
        self.generator=CandidateGenerator(self.grammar); self.probability=ProbabilityEngine(self.grammar.rules)
        self.chain=ChainEngine(self.grammar); self.reader=RuntimeEvidenceReader(notion,calendar,clock)
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS hourly_ticks(tick_id TEXT PRIMARY KEY,time TEXT UNIQUE NOT NULL,
            stage TEXT NOT NULL,events TEXT NOT NULL,cursor INTEGER NOT NULL,summary TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hourly_decisions(event_id TEXT PRIMARY KEY,body TEXT,status TEXT NOT NULL,reason TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hourly_realizations(event_id TEXT PRIMARY KEY,body TEXT,status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hourly_snapshots(tick_id TEXT PRIMARY KEY,record TEXT NOT NULL,transaction_id TEXT,status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hourly_mutations(id INTEGER PRIMARY KEY,cause TEXT NOT NULL,kind TEXT NOT NULL,state_hash TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS runtime_continuity_archive(edge_id TEXT PRIMARY KEY,body TEXT NOT NULL);
        ''')

    @contextmanager
    def scheduler_lock(self):
        path=self.db.execute('PRAGMA database_list').fetchone()[2]+'.scheduler'
        lock=sqlite3.connect(path,isolation_level=None,timeout=0)
        try:
            lock.execute('CREATE TABLE IF NOT EXISTS scheduler(id INTEGER)')
            lock.execute('BEGIN IMMEDIATE')
        except sqlite3.OperationalError:
            lock.close(); raise WriteConflict('another hourly scheduler is running') from None
        try: yield
        finally: lock.execute('ROLLBACK'); lock.close()

    def _save(self,state,cause,kind):
        for edge in state.continuity:
            self.db.execute('INSERT OR IGNORE INTO runtime_continuity_archive VALUES(?,?)',
                ('|'.join([edge.cause,edge.consequence,edge.transaction_id]),edge.model_dump_json()))
        state.continuity=state.continuity[-256:]
        State.model_validate_json(state.model_dump_json())
        self.db.execute('UPDATE runtime_cache SET body=? WHERE id=1',(state.model_dump_json(),))
        self.db.execute('INSERT INTO hourly_mutations(cause,kind,state_hash) VALUES(?,?,?)',
                        (cause,kind,digest(state.model_dump(mode='json'))))

    def _read(self):
        r=self.resources
        return self.reader.read(self.bridge,r.wallet_page,r.inventory_source,r.continuity_page,
            self.initialization['request']['initialization_ref'],additional_pages=r.additional_pages,reconcile_external=True)

    def _recover(self):
        for row in self.db.execute("SELECT transaction_id FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchall():
            tx=row[0]; status=self.coordinator.status(tx)
            if status=='RECONCILE_REQUIRED': self.coordinator.reconcile(tx)
            elif status not in {'COMMITTED','ROLLED_BACK'}: self.coordinator.run(tx)
            result=self.bridge.publish(tx,on_publish=self._consequences)
            if result not in {'PUBLISHED','ROLLED_BACK'}: return False
            if result=='ROLLED_BACK':
                row=self.db.execute('SELECT event_id FROM external_transactions WHERE transaction_id=?',(tx,)).fetchone()
                if self.db.execute('SELECT 1 FROM hourly_decisions WHERE event_id=?',(row[0],)).fetchone():
                    event=Event.model_validate_json(self.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(row[0],)).fetchone()[0])
                    self._terminal(event,'rejected','native_write_rolled_back')
            with self.coordinator.atomic():
                self.db.execute('INSERT INTO hourly_mutations(cause,kind,state_hash) VALUES(?,?,?)',
                    (tx,'recovered_publication',digest(self.bridge.state().model_dump(mode='json'))))
        return True

    def _clock_only(self,time,tick_id):
        state=self.bridge.state()
        if time.astimezone(timezone.utc)<=state.world.time.astimezone(timezone.utc):
            return {'status':'BLOCKED_RECOVERY','tick_id':tick_id}
        if time.astimezone(timezone.utc)!=state.world.time.astimezone(timezone.utc)+timedelta(hours=1):
            raise RuleViolation('hourly cadence cannot skip during recovery')
        from connectors.clock_merge import record
        with self.coordinator.atomic():
            before=self.bridge.state(); after=self._physics(before.model_copy(deep=True),time)
            record(self.bridge,before,after); self._save(after,tick_id,'clock_during_recovery')
            summary={'status':'COMPLETED_CLOCK_ONLY','tick_id':tick_id,'selected_events':0,
                     'world_snapshot_verified':False,'recovery_pending':True,'scope':'local_http_fixture'}
            self.db.execute("INSERT INTO hourly_ticks VALUES(?,?,'COMPLETED_CLOCK_ONLY','[]',0,?)",
                (tick_id,time.isoformat(),json.dumps(summary)))
        return summary

    def _finish_older_ticks(self,time):
        # Old unprepared proposals cannot act on a newer world. A committed
        # pending decision is retained; no second LLM call is made.
        for row in self.db.execute("SELECT * FROM hourly_ticks WHERE stage IN ('REALIZE','EVENTS','SNAPSHOT') ORDER BY rowid").fetchall():
            from datetime import datetime
            if datetime.fromisoformat(row['time']).astimezone(timezone.utc)>=time.astimezone(timezone.utc): continue
            for raw in json.loads(row['events']):
                event=Event.model_validate(raw)
                status=self.db.execute('SELECT status FROM hourly_decisions WHERE event_id=?',(event.event_id,)).fetchone()
                if not status or status[0] not in {'COMMITTED','SKIPPED','REJECTED'}:
                    self.bridge.log_event(event); self._terminal(event,'skipped','superseded_tick_after_recovery')
            with self.coordinator.atomic():
                summary={'status':'RECOVERED','tick_id':row['tick_id'],'historical_snapshot_not_fabricated':True}
                self.db.execute("UPDATE hourly_ticks SET stage='RECOVERED',cursor=?,summary=? WHERE tick_id=?",
                    (len(json.loads(row['events'])),json.dumps(summary),row['tick_id']))

    def _consequences(self,state,plan):
        row=self.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(plan.event_id,)).fetchone()
        decision_row=self.db.execute('SELECT body FROM hourly_decisions WHERE event_id=?',(plan.event_id,)).fetchone()
        if not decision_row or not decision_row[0]: return
        event=Event.model_validate_json(row[0]); decision=Decision.model_validate_json(decision_row[0])
        # Hooks bind the actual acquired native ID, while the proposal log keeps
        # its original catalog identity and immutable fingerprint.
        acquisitions=[i for i in state.inventory.values() if i.source_event==event.event_id]
        if acquisitions: event.payload['item_id']=acquisitions[0].item_id
        record=TransactionRecord(transaction_id=plan.transaction_id,idempotency_key='event:'+event.event_id,
            event_id=event.event_id,decision_id=decision.decision_id,expected_revision=state.revision,
            status='committed',created_at=event.created_at)
        state.novelty_memory.append(NoveltyEngine(self.grammar.rules).record(event))
        self.chain.after_commit(state,event,decision,record)
        self.db.execute("UPDATE hourly_decisions SET status='COMMITTED',reason='' WHERE event_id=?",(event.event_id,))
        self.db.execute('INSERT INTO hourly_mutations(cause,kind,state_hash) VALUES(?,?,?)',
            (plan.transaction_id,'verified_consequences',digest(state.model_dump(mode='json'))))
        for edge in state.continuity:
            self.db.execute('INSERT OR IGNORE INTO runtime_continuity_archive VALUES(?,?)',
                ('|'.join([edge.cause,edge.consequence,edge.transaction_id]),edge.model_dump_json()))

        state.continuity=state.continuity[-256:]

    def _refresh_calendar(self,evidence):
        if evidence is None or not evidence.calendar_complete or evidence.calendar_query!='': return
        state=self.bridge.state()
        mapped=commitments(evidence.calendar_rows,state.world.time,'fixture',evidence.calendar_timezone)
        # Keep previously recorded terminal facts; absence in a full window is
        # cancellation only for instances that intersect that same window.
        lower,upper=evidence.calendar_window; new_ids={c.commitment_id for c in mapped}
        retained=[]
        for old in state.calendar:
            if old.commitment_id in new_ids: continue
            if old.status=='scheduled' and old.start<upper and old.end>lower:
                old.status='cancelled'
            retained.append(old)
        state.calendar=retained+mapped; state.calendar_stale=False
        try: Validator.invariants(state)
        except RuleViolation:
            self.bridge.mark_stale('calendar'); return
        with self.coordinator.atomic():
            state.revision+=1; self._save(state,'calendar-native-refresh','sync')

    def _physics(self,state,time):
        from .physics import advance
        return advance(state,time,self.grammar)

    def _selected(self,state):
        due=any(c.status=='scheduled' and state.world.time<=c.start<state.world.time+timedelta(hours=2) for c in state.calendar)
        due=due or any(h.status=='open' and h.due_at<=state.world.time<h.expires_at for h in state.hooks)
        n=state.world.needs
        high=any(v>=self.grammar.rules['need_threshold'] for k,v in n.model_dump().items() if k!='energy') or n.energy<=25
        gate=seeded(self.seed,state.world.time,'gate').random()<self.grammar.rules['random_gate_probability']
        if not (due or high or gate): return []
        novelty=NoveltyEngine(self.grammar.rules,state.novelty_memory)
        return self.probability.select(self.generator.generate(state,self.seed,novelty),self.seed,state.world.time)

    def _terminal(self,event,status,reason):
        with self.coordinator.atomic():
            current=Event.model_validate_json(self.db.execute('SELECT body FROM canonical_events WHERE event_id=?',(event.event_id,)).fetchone()[0])
            if current.status=='pending':
                current.status=status; current.resolved_at=self.bridge.state().world.time
                self.db.execute('UPDATE canonical_events SET body=? WHERE event_id=?',(current.model_dump_json(),event.event_id))
            self.db.execute('INSERT INTO hourly_decisions VALUES(?,NULL,?,?) ON CONFLICT(event_id) DO UPDATE SET status=excluded.status,reason=excluded.reason',
                (event.event_id,status.upper(),reason))

    def _event(self,event):
        saved=self.db.execute('SELECT body,status FROM hourly_decisions WHERE event_id=?',(event.event_id,)).fetchone()
        if saved and saved['status'] in {'COMMITTED','SKIPPED','REJECTED'}: return True
        if not saved:
            # A process may die while provider I/O is in flight. On recovery,
            # never repeat a possibly billed decision without a saved response.
            with self.coordinator.atomic():
                self.db.execute("INSERT INTO hourly_decisions VALUES(?,NULL,'CALLING','')",(event.event_id,))
            try:
                value=self.agent.decide(self.bridge.state(),event)
                decision=Decision.model_validate(value) if value is not None else None
            except Exception: decision=None
            if decision is None:
                self._terminal(event,'skipped','decision_unavailable'); return True
            with self.coordinator.atomic():
                self.db.execute("UPDATE hourly_decisions SET body=?,status='DECIDED' WHERE event_id=?",(decision.model_dump_json(),event.event_id))
        elif saved['status']=='CALLING':
            self._terminal(event,'skipped','interrupted_decision_without_receipt'); return True
        else: decision=Decision.model_validate_json(saved['body'])
        state=self.bridge.state()
        if decision.choice!='accept':
            try: self.bridge.validator.rules._project(state,event,decision,transaction_id(event.event_id))
            except RuleViolation: self._terminal(event,'rejected','invalid_nonaccept_decision'); return True
            self._terminal(event,'skipped','mio_'+decision.choice); return True
        try:
            evidence=self._read(); evidence=replace(evidence,state_hash=digest(self.bridge.state().model_dump(mode='json')))
            proposal=None
            purchase=next((a for a in decision.actions if a.type=='purchase'),None)
            if purchase:
                item=state.catalog.get(purchase.item_id)
                if item is None: raise RuleViolation('unknown purchase catalog')
                proposal=PurchaseProposal(item_name=item.name,cost_jpy=item.price,acquired_at=state.world.time,
                    brand=item.brand,evidence='verified catalog reference: '+item.provenance.ref)
            elif any(a.type=='spend' for a in decision.actions):
                from connectors.canonical_runtime import expense_description
                action=next(a for a in decision.actions if a.type=='spend')
                proposal=SpendProposal(description=expense_description(event),cost_jpy=action.amount,occurred_at=state.world.time,
                    evidence='fixture family fixed cost: '+event.family)
            tx=self.bridge.prepare(event,decision,evidence,state.world.time,proposal,self.calendar)
        except (RuleViolation,ValueError,ConnectorUnavailable,WriteConflict):
            self._terminal(event,'rejected','native_validation_or_evidence_unavailable'); return True
        status=self.coordinator.status(tx)
        if status=='RECONCILE_REQUIRED': self.coordinator.reconcile(tx)
        else: self.coordinator.run(tx)
        published=self.bridge.publish(tx,on_publish=self._consequences)
        if published=='ROLLED_BACK': self._terminal(event,'rejected','native_write_rolled_back')
        return published in {'PUBLISHED','ROLLED_BACK'}

    def _realize(self,event):
        if not self.realizer or not (event.actors or event.cause): return True
        row=self.db.execute('SELECT status FROM hourly_realizations WHERE event_id=?',(event.event_id,)).fetchone()
        if row: return row[0]=='DONE'
        with self.coordinator.atomic(): self.db.execute("INSERT INTO hourly_realizations VALUES(?,NULL,'CALLING')",(event.event_id,))
        state=self.bridge.state()
        known=set(state.relationships)|set(state.inventory)|set(state.catalog)|{c.commitment_id for c in state.calendar}
        from agents.world_llm import Realization
        try:
            value=self.realizer.realize(event,known)
            result=Realization.model_validate(value) if value is not None else None
            valid=result is not None and result.event_id==event.event_id and set(result.referenced_entities)<=known and not result.no_event
        except Exception: result=None; valid=False
        with self.coordinator.atomic():
            self.db.execute('UPDATE hourly_realizations SET body=?,status=? WHERE event_id=?',
                (result.model_dump_json() if result else None,'DONE' if valid else 'SKIPPED',event.event_id))
        return valid

    def _snapshot(self,tick_id):
        row=self.db.execute('SELECT * FROM hourly_snapshots WHERE tick_id=?',(tick_id,)).fetchone()
        if row is None:
            state=self.bridge.state()
            record={'kind':'world_snapshot','tick_id':tick_id,'initialization_ref':self.initialization['request']['initialization_ref'],
                'scope':'fixture','world':state.world.model_dump(mode='json'),
                'hooks':[h.model_dump(mode='json') for h in state.hooks],
                'novelty_memory':[n.model_dump(mode='json') for n in state.novelty_memory],
                'state_hash':digest(state.model_dump(mode='json')),'notion_stale':state.notion_stale,'calendar_stale':state.calendar_stale}
            from connectors.native_restore import checkpoint_payload
            record['cache_checkpoint']=checkpoint_payload(self,state)
            with self.coordinator.atomic():
                self.db.execute("INSERT INTO hourly_snapshots VALUES(?,?,NULL,'QUEUED')",(tick_id,json.dumps(record,ensure_ascii=False)))
            row=self.db.execute('SELECT * FROM hourly_snapshots WHERE tick_id=?',(tick_id,)).fetchone()
        if row['status']=='VERIFIED': return True
        if row['status']=='FAILED': return False
        tx=row['transaction_id']
        if tx is None:
            try:
                from connectors.native_restore import checkpoint_operations
                page=self.notion.page(self.resources.world_runtime_page)
                event_id='snapshot:'+tick_id; tx=transaction_id(event_id)
                plan=WritePlan(transaction_id=tx,event_id=event_id,decision_id='snapshot-decision:'+tick_id,
                    evidence_scope='fixture',source_versions={'world':page['page']['last_edited_time']},
                    operations=checkpoint_operations(page,tx,json.loads(row['record'])))
                def bound(identifier):
                    self.db.execute("UPDATE hourly_snapshots SET transaction_id=?,status='PENDING' WHERE tick_id=?",(identifier,tick_id))
                self.coordinator.prepare(plan,on_prepare=bound)
            except (ConnectorUnavailable,WriteConflict): return False
            except (RuleViolation,ValueError):
                with self.coordinator.atomic(): self.db.execute("UPDATE hourly_snapshots SET status='FAILED' WHERE tick_id=?",(tick_id,))
                return False
        status=self.coordinator.status(tx)
        if status=='RECONCILE_REQUIRED': self.coordinator.reconcile(tx)
        else: self.coordinator.run(tx)
        if self.coordinator.status(tx)=='ROLLED_BACK':
            # Definite rejection is not a saved WORLD_STATE; keep a visible
            # failed snapshot without inventing a new idempotency key.
            with self.coordinator.atomic(): self.db.execute("UPDATE hourly_snapshots SET status='FAILED' WHERE tick_id=?",(tick_id,))
            return False
        if self.coordinator.status(tx)!='COMMITTED': return False
        for op_row in self.coordinator.rows(tx):
            op,adapter=self.coordinator._operation(op_row)
            try: observation=adapter.observe(op,json.loads(op_row['receipt']))
            except Exception: return False
            if observation.state!='AFTER' or not self.coordinator._receipt_valid(op,observation.receipt): return False
        with self.coordinator.atomic():
            self.db.execute("UPDATE hourly_snapshots SET status='VERIFIED' WHERE tick_id=?",(tick_id,))
        return True

    def tick(self,time):
        if time.tzinfo is None: raise ValueError('timezone-aware tick required')
        time=time.astimezone(ZoneInfo(self.bridge.state().world.timezone))
        tick_id='native_tick_'+time.astimezone(timezone.utc).isoformat()
        with self.scheduler_lock():
            from connectors.database_recovery import recovery_pending,RecoveryUnavailable
            if recovery_pending(self.db): raise RecoveryUnavailable('revalidate restored database before advancing or deciding')
            from .host_resume import pending
            if pending(self.db): raise RecoveryUnavailable('revalidate host resume before normal hourly work')
            self.coordinator._recovery_io_gate()
            existing=self.db.execute('SELECT * FROM hourly_ticks WHERE tick_id=?',(tick_id,)).fetchone()
            if not self._recover(): return self._clock_only(time,tick_id)
            self._finish_older_ticks(self.bridge.state().world.time)
            existing=self.db.execute('SELECT * FROM hourly_ticks WHERE tick_id=?',(tick_id,)).fetchone()
            if existing and existing['stage'] in {'COMPLETED','COMPLETED_CLOCK_ONLY','RECOVERED'}:
                if existing['stage']=='COMPLETED_CLOCK_ONLY' and time==self.bridge.state().world.time:
                    self._snapshot(tick_id)
                return {'status':'ALREADY_COMPLETED','tick_id':tick_id}
            unfinished=self.db.execute("SELECT tick_id FROM hourly_ticks WHERE stage NOT IN ('COMPLETED','COMPLETED_DEFERRED','COMPLETED_CLOCK_ONLY','RECOVERED') ORDER BY rowid LIMIT 1").fetchone()
            if unfinished and unfinished[0]!=tick_id:
                return {'status':'RESUME_REQUIRED','tick_id':unfinished[0]}
            if existing is None:
                latest=self.db.execute("SELECT time FROM hourly_ticks ORDER BY rowid DESC LIMIT 1").fetchone()
                expected=self.bridge.state().world.time if latest is None else self.bridge.state().world.time.astimezone(timezone.utc)+timedelta(hours=1)
                if time.astimezone(timezone.utc)!=expected.astimezone(timezone.utc): raise RuleViolation('hourly cadence cannot skip or move backwards')
                month_boundary=time.strftime('%Y-%m')!=self.bridge.state().world.time.astimezone(ZoneInfo(self.bridge.state().world.timezone)).strftime('%Y-%m')
                if not month_boundary:
                    try: evidence=self._read(); self._refresh_calendar(evidence)
                    except (ConnectorUnavailable,RuleViolation): evidence=None
                with self.coordinator.atomic():
                    state=self._physics(self.bridge.state(),time); self._save(state,tick_id,'clock_needs_due')
                    selected=[] if month_boundary else self._selected(state)
                    self.db.execute("INSERT INTO hourly_ticks VALUES(?,?,?,?,0,'{}')",
                        (tick_id,time.isoformat(),'SELECT' if month_boundary else 'REALIZE',json.dumps([e.model_dump(mode='json') for e in selected],ensure_ascii=False)))
                existing=self.db.execute('SELECT * FROM hourly_ticks WHERE tick_id=?',(tick_id,)).fetchone()
            if existing['stage']=='SELECT':
                # The new local month must be read after its durable clock step.
                # SELECT survives a crash without advancing time or deciding twice.
                try: evidence=self._read(); self._refresh_calendar(evidence)
                except (ConnectorUnavailable,RuleViolation): evidence=None
                with self.coordinator.atomic():
                    state=self.bridge.state(); self._save(state,tick_id,'month_read_before_selection')
                    selected=self._selected(state)
                    self.db.execute("UPDATE hourly_ticks SET stage='REALIZE',events=? WHERE tick_id=?",
                        (json.dumps([e.model_dump(mode='json') for e in selected],ensure_ascii=False),tick_id))
                existing=self.db.execute('SELECT * FROM hourly_ticks WHERE tick_id=?',(tick_id,)).fetchone()
            events=[Event.model_validate(e) for e in json.loads(existing['events'])]
            if existing['stage']=='REALIZE':
                for event in events:
                    realized=self._realize(event)
                    self.bridge.log_event(event)
                    if not realized: self._terminal(event,'skipped','world_realization_unavailable_or_no_event')
                with self.coordinator.atomic(): self.db.execute("UPDATE hourly_ticks SET stage='EVENTS' WHERE tick_id=?",(tick_id,))
            for index in range(existing['cursor'],len(events)):
                if not self._event(events[index]): return {'status':'BLOCKED_RECOVERY','tick_id':tick_id}
                with self.coordinator.atomic():
                    self.db.execute('UPDATE hourly_ticks SET cursor=? WHERE tick_id=?',(index+1,tick_id))
            with self.coordinator.atomic(): self.db.execute("UPDATE hourly_ticks SET stage='SNAPSHOT' WHERE tick_id=?",(tick_id,))
            # Older deferred snapshots are immutable historical clock records.
            # Their retry never overwrites the current internal clock/needs.
            for pending in self.db.execute("SELECT tick_id FROM hourly_snapshots WHERE status NOT IN ('VERIFIED','FAILED') ORDER BY rowid").fetchall():
                self._snapshot(pending[0])
            verified=self._snapshot(tick_id)
            status='COMPLETED' if verified else 'COMPLETED_DEFERRED'
            summary={'status':status,'tick_id':tick_id,'selected_events':len(events),
                'world_snapshot_verified':verified,'canonical_writes':0,'scope':'local_http_fixture'}
            with self.coordinator.atomic(): self.db.execute('UPDATE hourly_ticks SET stage=?,summary=? WHERE tick_id=?',(status,json.dumps(summary),tick_id))
            return summary

    def run(self,hours):
        if not 1<=hours<=10000: raise ValueError('hours must be 1..10000')
        results=[]
        for _ in range(hours):
            pending=self.db.execute("SELECT time FROM hourly_ticks WHERE stage NOT IN ('COMPLETED','COMPLETED_DEFERRED','COMPLETED_CLOCK_ONLY','RECOVERED') ORDER BY rowid LIMIT 1").fetchone()
            latest=self.db.execute('SELECT time FROM hourly_ticks ORDER BY rowid DESC LIMIT 1').fetchone()
            from datetime import datetime
            time=datetime.fromisoformat(pending[0]) if pending else self.bridge.state().world.time.astimezone(timezone.utc)+(timedelta(hours=1) if latest else timedelta())
            unresolved=self.db.execute("SELECT 1 FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchone()
            if unresolved and latest: time=self.bridge.state().world.time.astimezone(timezone.utc)+timedelta(hours=1)
            result=self.tick(time); results.append(result)
            if result['status'] not in {'COMPLETED','COMPLETED_DEFERRED','ALREADY_COMPLETED','COMPLETED_CLOCK_ONLY','BLOCKED_RECOVERY'}: break
        return results
