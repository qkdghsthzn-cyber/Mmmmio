"""Deterministic clock-only state evolution, shared by running and recovery."""
from datetime import timedelta,timezone
from core.chain_engine import ChainEngine
from core.validator import RuleViolation


def advance(state,time,grammar):
    previous=state.world.time
    elapsed=(time.astimezone(timezone.utc)-previous.astimezone(timezone.utc)).total_seconds()/3600
    if elapsed not in {0,1}: raise RuleViolation('clock evolution requires adjacent hourly ticks')
    state.world.time=time
    if state.world.journey and state.world.journey.arrival<=time:
        state.world.place=state.world.journey.destination
        state.world.activity='arrived:'+state.world.journey.destination; state.world.journey=None
    for c in state.calendar:
        if c.status=='scheduled' and c.end<=time: c.status='completed'
    upcoming=[c for c in state.calendar if c.status=='scheduled' and c.start>=time]
    state.world.next_commitment=min(upcoming,key=lambda c:c.start).commitment_id if upcoming else None
    changes={'energy':6 if time.hour<7 else -2,'hunger':5,'social_need':2,'novelty_need':1.5,
        'creative_urge':1,'comfort_need':1,'shopping_interest':.4,'privacy_need':.5}
    for name,delta in changes.items():
        setattr(state.world.needs,name,max(0,min(100,getattr(state.world.needs,name)+delta*elapsed)))
    state.novelty_memory=[r for r in state.novelty_memory if time-r.time<=timedelta(days=30)]
    ChainEngine(grammar).resolve_due(state); state.revision+=1
    return state
