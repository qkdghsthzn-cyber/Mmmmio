"""Server runtime; production activation remains behind P3/P5 gates."""
