"""Bounded clock-only catch-up after host suspension, fixture scope only.

Missing hours have no invented decisions, events or native snapshots. Durable
existing intents may recover; fresh native reads are required before new work.
"""
import json
from datetime import datetime, timedelta, timezone
from zoneinfo import ZoneInfo
from core.models import Event
from core.validator import RuleViolation
from connectors.clock_merge import record
from connectors.database_recovery import recovery_pending, RecoveryUnavailable
from connectors.http_json import ConnectorUnavailable

TERMINAL = {'COMPLETED', 'COMPLETED_DEFERRED', 'COMPLETED_CLOCK_ONLY', 'RECOVERED'}


def pending(db):
    if not db.execute("SELECT name FROM sqlite_master WHERE name='host_resume_gate'").fetchone():
        return False
    row = db.execute('SELECT status FROM host_resume_gate WHERE id=1').fetchone()
    return row is not None and row[0] != 'VERIFIED'


def _observed(runtime, time):
    if time.tzinfo is None:
        raise ValueError('timezone-aware observed host time required')
    state_time = runtime.bridge.state().world.time
    if time.astimezone(timezone.utc) < state_time.astimezone(timezone.utc):
        raise RuleViolation('host clock moved backwards; do not rewind or issue new work')
    return time.astimezone(ZoneInfo(runtime.bridge.state().world.timezone))


def _guard(runtime):
    if recovery_pending(runtime.db):
        raise RecoveryUnavailable('revalidate whole database restoration before host resume')
    runtime.coordinator._recovery_io_gate()


def _recover_existing(runtime):
    # This also covers previously prepared native snapshot intents. No prepare
    # or new proposal occurs in this path, even if its original hour is old.
    for row in runtime.db.execute("SELECT transaction_id FROM external_transactions WHERE status NOT IN ('COMMITTED','ROLLED_BACK')").fetchall():
        tx = row[0]
        if runtime.coordinator.status(tx) == 'RECONCILE_REQUIRED':
            runtime.coordinator.reconcile(tx)
        else:
            runtime.coordinator.run(tx)
    return runtime._recover()


def _retire(runtime, row):
    events = [Event.model_validate(raw) for raw in json.loads(row['events'])]
    for event in events:
        bound = runtime.db.execute('SELECT 1 FROM external_transactions WHERE event_id=?', (event.event_id,)).fetchone()
        if bound:
            # Leave an unknown durable intent and its decision intact. Its later
            # publication still uses the original receipt/projection and clock journal.
            continue
        decision = runtime.db.execute('SELECT status FROM hourly_decisions WHERE event_id=?', (event.event_id,)).fetchone()
        if not decision or decision[0] not in {'COMMITTED', 'SKIPPED', 'REJECTED'}:
            runtime.bridge.log_event(event)
            runtime._terminal(event, 'skipped', 'host_suspended_no_historical_action')
        with runtime.coordinator.atomic():
            runtime.db.execute("UPDATE hourly_realizations SET status='SKIPPED' WHERE event_id=? AND status='CALLING'", (event.event_id,))
    summary = {'status': 'RECOVERED', 'reason': 'host_suspended_no_historical_action',
               'tick_id': row['tick_id'], 'historical_snapshot_not_fabricated': True}
    with runtime.coordinator.atomic():
        runtime.db.execute("UPDATE hourly_ticks SET stage='RECOVERED',cursor=?,summary=? WHERE tick_id=?",
                           (len(events), json.dumps(summary), row['tick_id']))


def resume_after_delay(runtime, observed_at, max_hours=24):
    if type(max_hours) is not int or not 1 <= max_hours <= 24:
        raise ValueError('catch-up work budget must be 1..24 hourly records')
    observed_at = _observed(runtime, observed_at)
    with runtime.scheduler_lock():
        _guard(runtime)
        observed_at = _observed(runtime, observed_at)
        state = runtime.bridge.state()
        elapsed = observed_at.astimezone(timezone.utc) - state.world.time.astimezone(timezone.utc)
        active = runtime.db.execute("SELECT * FROM hourly_ticks WHERE stage NOT IN ('COMPLETED','COMPLETED_DEFERRED','COMPLETED_CLOCK_ONLY','RECOVERED') ORDER BY rowid").fetchall()
        unstarted = not runtime.db.execute('SELECT 1 FROM hourly_ticks LIMIT 1').fetchone()
        if elapsed < timedelta(hours=1) and not active and not (unstarted and elapsed > timedelta(minutes=5)):
            return {'status': 'NO_MISSED_HOURS', 'processed_hours': 0, 'decision_calls': 0}
        with runtime.coordinator.atomic():
            runtime.db.execute('CREATE TABLE IF NOT EXISTS host_resume_gate(id INTEGER PRIMARY KEY CHECK(id=1),status TEXT NOT NULL,observed_at TEXT NOT NULL)')
            runtime.db.execute("INSERT INTO host_resume_gate VALUES(1,'NEEDS_FRESH_NATIVE',?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,observed_at=excluded.observed_at", (observed_at.isoformat(),))
        recovered = _recover_existing(runtime)
        # Retire proposals without replaying a decision or realization. Already
        # bound intents retain their original identity and may still be unknown.
        for row in active:
            if datetime.fromisoformat(row['time']).astimezone(timezone.utc) <= observed_at.astimezone(timezone.utc):
                _retire(runtime, row)
        processed = 0
        if unstarted:
            time = runtime.bridge.state().world.time
            with runtime.coordinator.atomic():
                tick_id = 'native_tick_' + time.astimezone(timezone.utc).isoformat()
                runtime.db.execute("INSERT INTO hourly_ticks VALUES(?,?,'RECOVERED','[]',0,?)", (tick_id, time.isoformat(), json.dumps({
                    'status': 'HOST_CLOCK_ONLY', 'reason': 'host_suspended', 'historical_snapshot_not_fabricated': True})))
            processed += 1
        while processed < max_hours:
            before = runtime.bridge.state()
            time = (before.world.time.astimezone(timezone.utc) + timedelta(hours=1)).astimezone(ZoneInfo(before.world.timezone))
            if time.astimezone(timezone.utc) > observed_at.astimezone(timezone.utc):
                break
            tick_id = 'native_tick_' + time.astimezone(timezone.utc).isoformat()
            with runtime.coordinator.atomic():
                after = runtime._physics(before.model_copy(deep=True), time)
                record(runtime.bridge, before, after)
                runtime._save(after, tick_id, 'host_suspended_clock_only')
                summary = {'status': 'HOST_CLOCK_ONLY', 'tick_id': tick_id, 'selected_events': 0,
                           'observed_at': observed_at.isoformat(), 'historical_snapshot_not_fabricated': True}
                runtime.db.execute("INSERT INTO hourly_ticks VALUES(?,?,'RECOVERED','[]',0,?)", (tick_id, time.isoformat(), json.dumps(summary)))
            processed += 1
        remaining = int((observed_at.astimezone(timezone.utc) - runtime.bridge.state().world.time.astimezone(timezone.utc)).total_seconds() // 3600)
        return {'status': 'MORE_CLOCK_CATCHUP_REQUIRED' if remaining else 'AWAITING_FRESH_NATIVE',
                'processed_hours': processed, 'remaining_hours': remaining, 'decision_calls': 0,
                'durable_intents_recovered': recovered, 'historical_snapshots_created': 0,
                'world_time': runtime.bridge.state().world.time.isoformat(), 'production_enabled': False}


def revalidate_host_resume(runtime, observed_at):
    observed_at = _observed(runtime, observed_at)
    with runtime.scheduler_lock():
        _guard(runtime)
        observed_at = _observed(runtime, observed_at)
        if not pending(runtime.db):
            return {'status': 'ALREADY_VERIFIED', 'decision_calls': 0}
        state = runtime.bridge.state()
        lag = observed_at.astimezone(timezone.utc) - state.world.time.astimezone(timezone.utc)
        if lag >= timedelta(hours=1):
            return {'status': 'MORE_CLOCK_CATCHUP_REQUIRED', 'decision_calls': 0}
        if observed_at.strftime('%Y-%m') != state.world.time.strftime('%Y-%m'):
            return {'status': 'WAITING_LOGICAL_MONTH_BOUNDARY', 'decision_calls': 0}
        if not _recover_existing(runtime) or not runtime.coordinator.confirmations_allowed():
            return {'status': 'WAITING_NATIVE_RECOVERY', 'decision_calls': 0}
        from connectors.canonical_runtime import RuntimeEvidenceReader
        reader = RuntimeEvidenceReader(runtime.notion, runtime.calendar, lambda: observed_at)
        resources = runtime.resources
        try:
            evidence = reader.read(runtime.bridge, resources.wallet_page, resources.inventory_source,
                resources.continuity_page, runtime.initialization['request']['initialization_ref'],
                additional_pages=resources.additional_pages, reconcile_external=True, validation_time=observed_at)
            if evidence.notion is None or not evidence.calendar_complete:
                return {'status': 'WAITING_FRESH_NATIVE_READ', 'decision_calls': 0}
            runtime._refresh_calendar(evidence)
        except (ValueError, ConnectorUnavailable):
            return {'status': 'WAITING_FRESH_NATIVE_READ', 'decision_calls': 0}
        state = runtime.bridge.state()
        if state.notion_stale or state.calendar_stale:
            return {'status': 'WAITING_FRESH_NATIVE_READ', 'decision_calls': 0}
        with runtime.coordinator.atomic():
            runtime._save(state, 'host.resume', 'verified_host_resume')
            runtime.db.execute("UPDATE host_resume_gate SET status='VERIFIED',observed_at=? WHERE id=1", (observed_at.isoformat(),))
        return {'status': 'VERIFIED', 'decision_calls': 0, 'observed_at': observed_at.isoformat()}
