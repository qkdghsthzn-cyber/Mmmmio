package world.mio.qualification;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import com.chaquo.python.Python;
import com.chaquo.python.android.AndroidPlatform;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONObject;

/** P5 qualification console. No live writes, credentials or P7 product flows. */
public class ProbeActivity extends Activity {
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private TextView output;
    private Button[] actions;
    private String latestReport = "";
    private boolean busy = false;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        int padding = (int) (16 * getResources().getDisplayMetrics().density);
        layout.setPadding(padding, padding, padding, padding);
        TextView title = new TextView(this);
        title.setText("MIO WORLD 실행 검사\n가상 데이터로만 시험합니다. 실제 미오의 생활·잔액이 아닙니다.");
        title.setTextSize(18);
        layout.addView(title);
        actions = new Button[] {
            addButton(layout, "1. 기기 검사", "diagnose"),
            addButton(layout, "2. 가상 6시간 진행", "mock"),
            addButton(layout, "3. 연동 모의 시험", "native"),
            addButton(layout, "4. DB 유실 복구 시험", "database_loss"),
            addButton(layout, "5. 실행 지연 복구 시험", "host_resume"),
            addButton(layout, "6. 인증 만료 복구 시험", "oauth")
        };
        Button share = new Button(this);
        share.setText("검사 결과 공유");
        share.setOnClickListener(v -> {
            if (latestReport.isEmpty()) return;
            Intent intent = new Intent(Intent.ACTION_SEND);
            intent.setType("text/plain");
            intent.putExtra(Intent.EXTRA_TEXT, latestReport);
            startActivity(Intent.createChooser(intent, "검사 결과 공유"));
        });
        layout.addView(share);
        ScrollView scroll = new ScrollView(this);
        output = new TextView(this);
        output.setTextIsSelectable(true);
        output.setText("기기 검사를 눌러 시작하세요.\n이 검사 앱에는 키 입력·자동 생활·화면 인식 기능이 없습니다.");
        scroll.addView(output);
        layout.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));
        setContentView(layout);
        if (state != null) {
            latestReport = state.getString("report", "");
            if (!latestReport.isEmpty()) showReport(latestReport);
        }
    }

    private Button addButton(LinearLayout layout, String label, String action) {
        Button button = new Button(this);
        button.setText(label);
        button.setOnClickListener(v -> run(action));
        layout.addView(button);
        return button;
    }

    private void run(String action) {
        if (busy) return;
        busy = true;
        for (Button button : actions) button.setEnabled(false);
        output.setText("시험 중입니다. 완료될 때까지 잠시 앱을 열어 두세요.");
        worker.execute(() -> {
            String report;
            try {
                // Start on the worker: missing native wheels are visible as
                // qualification failures rather than a crashing Application.
                synchronized (Python.class) {
                    if (!Python.isStarted()) Python.start(new AndroidPlatform(getApplicationContext()));
                }
                report = Python.getInstance().getModule("mobile_host.probe")
                    .callAttr("entrypoint", getFilesDir().getAbsolutePath(), action).toString();
            } catch (Exception error) {
                report = "{\"status\":\"PYTHON_START_FAILED\",\"error_type\":\""
                    + error.getClass().getSimpleName() + "\",\"production_enabled\":false}";
            }
            final String result = report;
            runOnUiThread(() -> {
                if (isDestroyed()) return;
                latestReport = result;
                busy = false;
                for (Button button : actions) button.setEnabled(true);
                showReport(result);
            });
        });
    }

    private void showReport(String report) {
        try {
            JSONObject data = new JSONObject(report);
            StringBuilder text = new StringBuilder("결과: ").append(data.optString("status", "UNKNOWN"));
            JSONObject runtime = data.optJSONObject("runtime");
            if (runtime != null) {
                text.append("\n기기: ").append(runtime.optString("device_model", "Android 미확인"));
                text.append("\nPython: ").append(runtime.optString("python", "?"));
            }
            JSONArray checks = data.optJSONArray("checks");
            if (checks != null) for (int i = 0; i < checks.length(); i++) {
                JSONObject check = checks.getJSONObject(i);
                text.append("\n").append(check.optString("name")).append(": ").append(check.optString("status"));
            }
            if (data.has("stored_ticks")) text.append("\n저장된 가상 시간: ").append(data.getInt("stored_ticks"));
            text.append("\n\n실제 API 호출·정본 쓰기를 활성화한 결과가 아닙니다.\n\n상세 결과:\n").append(data.toString(2));
            output.setText(text.toString());
        } catch (Exception error) {
            output.setText("검사 결과를 표시하지 못했습니다.");
        }
    }

    @Override public void onSaveInstanceState(Bundle state) {
        state.putString("report", latestReport);
        super.onSaveInstanceState(state);
    }

    @Override public void onDestroy() {
        // Running work holds its storage lock until it finishes. A rotated
        // Activity's new worker cannot mutate the same DB concurrently.
        worker.shutdown();
        super.onDestroy();
    }
}
