# MIO WORLD P5 기기 검사 프로젝트

**현재 APK 빌드는 BLOCKED, Z Fold8 시험은 NOT_RUN이다.** 이 폴더는 실행 호환성을 검증하는 Android 소스이며 설치 가능한 파일이 아니다. P7 제품 UI·미오 overlay·화면 인식·자동 생활·credential 입력은 포함하지 않는다.

## 구현한 검사 경로

앱 전용 디렉터리의 별도 fixture DB로 기존 Python 엔진을 실행한다. 160 Family와 Grammar/Validator/Novelty/Chain 코드를 원본 그대로 staging하며, 별도의 Kotlin 세계 엔진을 만들지 않는다. API 키와 실제 resources.json, 실제 native 읽기 증거·이미지는 APK staging에서 제외한다.

| 버튼 | 수행하는 시험 |
|---|---|
| 기기 검사 | Python native 의존성, 160 Family/State, SQLite WAL online backup, worker/vault lock, fsync/atomic replace, timezone, TLS CA |
| 가상 6시간 진행 | 별도 mock DB에서 기존 엔진을 6시간 진행. 다음 호출은 이전 저장 시점부터 6시간 추가 |
| 연동 모의 시험 | loopback HTTP 서버에서 기존 P5 hourly 6시간과 cache/archive 복원 |
| 인증 만료 복구 시험 | loopback token 교환·invalid_grant 차단·모의 새 동의 뒤 fresh gate 해제·POST 401 재전송 금지 |
| 실행 지연 복구 시험 | 337분 지연 시 clock-only 진행, restart 후 실행 차단, 늦은 지출 영수증 1회 반영·fresh 재확인 |
| DB 유실 복구 시험 | loopback에서 별도 fixture primary DB/저널 삭제 후 독립 이미지 복원·정본 재확인·중복 지출 방지 |

결과는 JSON으로 공유할 수 있다. exception 원문이나 환경변수의 credential 값을 결과에 넣지 않는다. 테스트에는 시험용 값만 사용하며 실제 GPT/Notion/Calendar 쓰기는 활성화하지 않는다. Internet permission은 loopback REST fixture에도 필요하며 명시적 HTTP 허용은 localhost에 한정했다. Python socket/OpenSSL의 보안 동작은 기기에서 추가 검증해야 한다.

Fold의 화면 회전/펼침으로 Activity가 재생성되어도 별도 DB worker lock으로 동시 mutation을 막는다. Python을 UI thread에서 시작하지 않는다. 다만 Java 코드 컴파일·실기기 lifecycle 동작은 아직 검증하지 않았다. 이 앱은 foreground에서 사용자가 누르는 검사 콘솔이며 상시 scheduler가 아니다.

## 개발 환경 검증 결과

mobile host 18개·지연 복구 22개·OAuth 35개를 포함한 전체 368개 회귀를 개발 호스트에서 재실행했다. 168시간·월말 48시간·DB 전체 삭제 복구·337분 지연 fixture 데모도 PASS다. P2 10,000시간은 이전 PASS를 보존했다. staging 사본에서 native hourly와 host resume 시험이 PASS다. 이 결과를 Android의 Python 3.13/arm64 성공으로 표시하지 않는다.

`reports/P5_android_build.json`에는 java 17만 있고 javac/Gradle/Python 3.13/Android SDK가 없는 실제 빌드 준비 상태를 기록했다. SDK와 Gradle 다운로드 연결도 각각 timeout으로 실패했다. Gradle compilation은 시작하지 못했다. pydantic-core의 Android 3.13 wheel 확보·16 KiB page 호환성은 미확인이다. 엔진의 `pydantic>=2.13,<3` 계약을 낮추거나 대체하지 않았다.

## 빌드 담당자용 진입점

사용자에게 상시 PC를 요구하는 안내가 아니다. JDK 17+, Gradle 8.13, Python 3.13, Android SDK platform 36와 build-tools 35.0.0이 있는 빌드 환경에서 다음 명령을 실행한다. Google/Maven/Gradle/Chaquopy/PyPI 의존성 다운로드 접근이 필요하다. 관련 plugin은 공식 문서를 확인한 AGP 8.13.0·Chaquopy 17.0.0을 사용한다. Python 3.13 executable을 별도로 지정할 때는 `MIO_BUILD_PYTHON` 환경변수를 사용한다.

```bash
python3 tools/build_android_probe.py
```

원본 source를 먼저 staging한 뒤 Gradle을 실행한다. 도구 부족은 `BLOCKED`, 의존성/컴파일 실패는 `BUILD_FAILED`, APK 생성은 `APK_BUILT_DEVICE_NOT_RUN`으로 구분한다. 성공한 APK의 ZIP 구조·classes.dex·arm64 runtime을 확인해 프로젝트 상위의 `MIO_P5_Device_Probe.apk`로 복사한다. 실행/설치 검증이나 배포 서명을 완료했다고 표시하지 않는다. debug APK이며 제품 릴리스가 아니다.

기기 설치 후에는 먼저 **기기 검사**, 이어서 **가상 6시간 진행**을 두 번 눌러 저장된 시간이 6→12로 늘어나는지 확인한다. 그 다음 loopback 연동·DB 유실·실행 지연·인증 만료 복구 시험 결과를 확인한다. 실제 credential은 이 검사 앱에 입력할 필요가 없다. 현재는 APK가 없으므로 사용자가 설치할 단계가 아니다.

## 남은 조건

- Android 의존성 resolve·컴파일·설치·16 KiB native loading·실기기 저장/재개.
- 실제 절전·재부팅·force-stop과 scheduler 연결. fixture의 누락 시간 복구는 P5_HOST_RESUME.md를 따르며 strict normal hourly cadence는 그대로다.
- 실제 API/정본 인증, token 갱신, 별도 WORLD_STATE와 초기 상태 근거, native 월 마감/비용 signal.
- 기기 밖 backup/witness/복원 키, 실제 provider 동시 편집·응답 유실·왕복/보상 시험.
- P5 완료 뒤 P6→P7→P8. 이 검사 Activity를 P7 제품 UI 완료로 재분류하지 않는다.

공식 문서: [Chaquopy Android plugin](https://chaquo.com/chaquopy/doc/current/android.html), [AGP 8.13](https://developer.android.com/build/releases/agp-8-13-0-release-notes), [Chaquopy package/wheel FAQ](https://chaquo.com/chaquopy/doc/current/faq.html), [Android network security](https://developer.android.com/privacy-and-security/security-config).

외부 수동 빌드의 준비 상태와 개인 자료 없는 코드 묶음은 `P5_REMOTE_BUILD.md`를 따른다. 원격 빌드/실기기 시험은 아직 NOT_RUN이다. OAuth 계약과 메모리 저장 한계는 `P5_AUTH.md`를 따른다.
