# Fold8의 GitHub 웹에서 직접 빌드

사용자가 GitHub 사이트 로그인과 저장소 생성을 할 수 있다고 확인했다. 현재 기본 경로는 GitHub Actions 직접 실행이다. ChatGPT GitHub 플러그인·PC·PAT 전달·runtime API 키 입력이 필요 없다. 첫 실행은 실제 GitHub에서 진행됐으며 368 fixture PASS 후 Android build가 실패했다. 최신 증거는 `reports/P5_github_run1.json`이다.

## 사용자가 등록할 것

| 파일 | GitHub 위치 |
|---|---|
| `MIO_P5_Build_Sources.zip` | 저장소 root, 파일명 그대로 |
| `mio-p5-phone.yml`의 전체 내용 | `.github/workflows/mio-p5-phone.yml` |

`deployment/MIO_GitHub_Fold8_Guide.html`에는 파일 경로와 전체 설정을 복사하는 버튼 및 수동 전체 선택 대안이 있다. 별도 source 추출/258개 파일 업로드가 필요하지 않다. ZIP과 설정은 한 쌍이며 SHA가 다르면 중단한다. 전체 체크포인트·개인 첨부 자료를 repository에 올리지 않는다.

1. Chrome으로 https://github.com/new 에서 개인 Private 저장소를 만든다. 이름 예: `mio-world`. README를 추가하여 기본 브랜치를 초기화한다.
2. Code → Add file → Upload files로 `MIO_P5_Build_Sources.zip`을 root에 올리고 Commit changes한다.
3. Add file → Create new file에서 `.github/workflows/mio-p5-phone.yml`을 입력하고 제공한 YAML 전체를 붙여 넣어 기본 브랜치에 Commit changes한다.
4. Actions → MIO P5 phone build → Run workflow를 실행한다. 필요하면 계정의 Actions 안내에 따라 활성화한다.
5. 성공하면 Artifacts → MIO_P5_Device_Probe에서 APK를 받는다. v7 single-file `archive:false`를 사용한다. UI가 ZIP으로 내려주는 경우 압축에서 APK를 꺼낸다. 실패하면 MIO_P5_build_diagnostics를 받아 공유한다. artifact가 없으면 실패한 단계의 오류를 복사한다.

GitHub 로그인/MFA·Actions quota/계정 제한은 그대로 적용된다. SDK 설치는 노트북/안내에 링크한 Android SDK 약관 수락을 포함한다. 별도 billing이나 보안 설정을 바꾸는 자동화는 없다.

## Runner 동작과 검증 범위

Ubuntu 24.04에서 root ZIP hash·path·manifest·개별 source hash와 160 Family/Core Identity를 확인한 후 private runner 임시 directory에 추출한다. Python 3.13, JDK 17, Gradle 8.13과 SDK platform 36/build-tools 35.0.0을 준비한다. P0부터 기존 378개 fixture를 순서대로 실행하고 PASS/개수 gate를 확인한 뒤 기존 `tools/build_android_probe.py`만 호출한다. 원본 schema/의존성은 변경하지 않는다. 검증된 APK build report와 file hash가 일치해야 artifact를 만든다. upload 권한은 기존 contents:read의 runner artifact 기능뿐이며 정본 쓰기는 0회다.

확인한 결과는 `reports/P5_github_phone.json`이다. YAML/shell/Python 문법, 실제 extraction shell을 실행한 원본 hash 일치, missing/corrupt ZIP 차단, 불완전 fixture report 및 invalid APK receipt 차단과 안내의 복사 원문 일치를 확인했다. simulated APK gate bytes를 실제 APK로 표시하지 않는다. 변경하지 않은 source ZIP의 이전 독립 368 PASS를 재사용했다. HTML JavaScript 문법과 clipboard 대안을 준비했지만 실제 Fold8 browser clipboard 검사는 NOT_RUN이다.

**첫 GitHub/Python 3.13.15 실행: 368 fixture PASS, 빌드 도구 적합, Android build FAILED, APK 없음/기기 NOT_RUN이다.** 진단 artifact 수신으로 Android pydantic-core 미제공이 원인임을 확인했다. wheel source-build 수정본의 remote 실행은 NOT_RUN이다. 출력 대상은 P5 검사 앱이며 P6~P8과 실제 서비스 gate는 유지한다. Colab 후보도 `P5_COLAB_BUILD.md`에 남아 있다.

재생성 순서: `python -m tools.package_android_sources` → `python -m tools.package_github_phone`. export hash가 바뀌면 등록된 source ZIP과 YAML을 함께 업데이트한다. Colab 노트북도 새 source hash를 쓰려면 `python -m tools.package_colab_notebook`으로 재생성한다.

공식 참고: [파일 생성](https://docs.github.com/en/repositories/working-with-files/managing-files/creating-new-files), [수동 workflow 실행](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow), [artifact 다운로드](https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts), [single-file artifact](https://github.com/actions/upload-artifact).

## 첫 GitHub 실행 확인 및 오류 표시 보완 (2026-10-06)

사용자가 올린 `logs_101431036398.zip`의 console에서 368개 fixture 전체 PASS를 실제 GitHub/Python 3.13.15 환경에서 확인했다. Java/javac 17·Gradle 8.13·Android SDK 검사도 적합했고 218개 runtime source/160 Family가 staging됐다. 이후 Android build가 Gradle exit 1/helper exit 2로 실패하여 APK는 없다. `reports/P5_github_run1.json`을 최신 상태로 따른다. 이전 NOT_RUN 기록은 해당 준비 체크포인트 당시 상태다.

console에는 helper가 파일로 저장한 실제 Gradle 오류가 없다. 첫 실행의 [MIO_P5_build_diagnostics.zip](https://github.com/qkdghsthzn-cyber/Miooi/actions/runs/37447059977/artifacts/11403891732) 업로드 성공/33,532 bytes를 확인했지만 파일 내용은 아직 받지 못했다. 해당 ZIP을 먼저 받으면 재실행 없이 분석할 수 있다. Download logs의 ZIP과 Summary/Artifacts의 진단 ZIP은 서로 다르다.

phone workflow에 실패한 Android build 뒤 `Show Android build error log`를 추가했다. 마지막 200줄을 표시하며 원래 build 실패/후속 APK 차단은 유지한다. 누락/빈/200줄 제한 로그 3사례, YAML/shell/inline Python·안내 JS/copy 원문을 확인했다. 원본 source ZIP과 core/data/reference 193개 및 기존 회귀/P2 보고서는 변경하지 않았다. **실패 원인은 미확인/미수정이고 새 workflow remote 실행은 NOT_RUN**이다. 진단 ZIP을 받을 수 없는 경우에만 YAML 본문을 교체하여 Commit 후 **새 Run workflow**로 실행한다. P5 live gate와 P6~P8 NOT_STARTED를 유지한다.

## Android 바이너리 의존성 오류 수정 (2026-10-06)

첫 실행의 `MIO_P5_build_diagnostics.zip`(SHA `8eb7e1a…83c80e`)에서 실제 18단계 368 PASS와 Gradle 원인을 확인했다. `:probe:installDebugPythonRequirements`가 Pydantic 2.13 계열의 정확한 `pydantic-core` Android wheel을 찾지 못해 실패했다. Gradle 8.13 안내 경고가 실패 이유는 아니다. 최신 증거는 `reports/P5_android_dependencies_fix.json`이다.

엔진/스키마/requirements 범위를 바꾸지 않고 Android 빌드 constraint에 첫 실행 버전 Pydantic 2.13.5/core 2.46.5를 고정했다. `tools/build_android_wheels.py`는 SHA가 고정된 공식 upstream sdist를 추출하고 Cargo.lock을 유지하여 cibuildwheel 4.3.0/Rust 1.88.0으로 CPython 3.13/API24/arm64-v8a와 x86_64 wheel을 만든다. cibuildwheel이 실제 Android libpython/sysconfig·NDK·Cargo linker/PyO3 환경을 제공한다. version/tag/native ELF architecture/16KiB LOAD alignment와 두 ABI receipt를 확인한 경우에만 Gradle find-links로 공급한다. 새 temp output을 사용해 실패 후 이전 wheel을 재사용하지 않는다. Gradle 실패는 stacktrace와 native-wheel/Gradle 진단 로그로 남긴다. 설치/런타임 적합성은 여전히 실기기 검증 대상이다.

기존 368개와 새 synthetic binary receipt/source guard 10개를 포함한 **378개 회귀가 개발 tree 및 배포 ZIP의 독립 Linux/Python 3.12.14 사본에서 모두 PASS**다. 실제 upstream hash/extraction·cibuildwheel의 두 대상 선택·wheel 실패 시 Gradle/APK 차단·workflow/notebook/guide 문법과 embedded ZIP/copy 원문을 확인했다. synthetic bytes를 실제 wheel/APK로 내보내지 않는다. 원본 engine/data/reference/mobile 227개와 160 Family, P2 10,000시간 보고서 및 live gate를 보존했다.

새 source ZIP은 258개 파일/SHA `feb53d33ffe39372cd88cd7b4c81294e0a40e6ec9c9989205c3501634e6a18fe`이다. **소스 ZIP과 phone YAML 둘 다 교체·Commit하고 새 Run workflow를 실행해야 한다.** 이전 실행의 Re-run jobs는 이전 revision을 사용한다. Colab 노트북에도 새 ZIP/constraint/378개 gate를 반영했으나 선택 경로이며 실행하지 않았다. **수정본의 native wheel compilation·Gradle/APK·Android 실행은 NOT_RUN**이다. P5가 완료된 것으로 표시하지 않으며 P6~P8은 계속 NOT_STARTED다.

공식 빌드 참고: [Chaquopy Android wheel 빌드](https://github.com/chaquo/chaquopy/blob/master/server/pypi/README.md), [cibuildwheel Android](https://cibuildwheel.pypa.io/en/stable/platforms/#android), [PyO3 cross compilation](https://pyo3.rs/main/building-and-distribution.html#cross-compiling).
