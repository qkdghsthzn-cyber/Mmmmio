# MIO WORLD v1 구현·검증 결과

이 결과물은 실행 가능한 headless 엔진의 체크포인트다. 실제 GPT·정본 쓰기·배포 서버·Android APK는 완료되지 않았다.

| 단계 | 결과 | 근거 |
|---|---|---|
| P0 | 통과 | 스키마, 168시간 재생, 재현·재시작·롤백 테스트 4개 |
| P1 | 통과 | 160 Family, 17개 슬롯, 확률·Novelty 및 3개 seed의 30일 비교 테스트 4개 |
| P2 | 통과 | 안전성 테스트 17개, 10,000시간 재생 |
| P3 | 로컬 통과 / 실제 GPT 미검증 | JSON·복구·timeout·HTTP 계약·예산 테스트 9개. 실제 호출은 키 미설정으로 BLOCKED |
| P4 | 로컬 통과 | 후속 hook·인과·취소·NPC 지식 범위·30일 시험을 포함한 테스트 7개 |
| P5 | 일부 구현 / 완료 조건 미통과 | 이전 실제 읽기 증거, 읽기 계약 6개·복구 39개·HTTP 14개·정본 검증/cache 26개·초기화/hourly 30개·지출/취소/복구 39개·clock 14개·native 복원 19개·월 조정 34개·전체 DB 복구 31개 통과, 168시간 및 월말 48시간 HTTP fixture 실행. 실제 쓰기 왕복·세계 초기화·native 월 마감 설정/검증·운영 scheduler 등은 미완료 |
| P6 | 미진행 | P5 완료 조건 대기 |
| P7 | 미진행 | Android UI·APK·실기기 테스트 대기 |
| P8 | 미진행 | 실제 연결을 포함한 30~90일 시험 대기 |

누적 테스트 307개 PASS(이전 293개 보고서 보존 + 이번 기기 검사 코드의 개발 호스트 검증 14개). 기존 전체 회귀는 이전 체크포인트에서 통과했고 이번에는 재실행하지 않았다. P3/P4/P5 준비 시험의 모의 응답과 로컬 HTTP 서버는 실제 OpenAI/정본 서버의 통과를 뜻하지 않는다.

## P2 — 최종 10,000시간

| 지표 | 측정값 |
|---|---:|
| 재생 시간 | 10,000시간 |
| 처리된 사건 | 5,479건 |
| 등장한 Family | 153개 |
| 사건 없는 시간 | 48.58% |
| 비루틴의 24시간 내 반복률 | 1.15% |
| 고유 사건 signature 비율 | 97.57% |
| Family entropy | 6.5687 |
| 30일 창 검사 수 | 387개 |
| 30일 창 내 단일 비루틴 Family의 최대 점유율 | 4.68% |
| 잔액 위반 | 0건 |
| 미보유 소지품 위반 | 0건 |
| 고정 일정 충돌 | 0건 |
| 출처/인과 연결 위반 | 0건 |
| 거부된 거래 | 25건 |

거부된 거래는 검증기가 실행을 막은 건수다. 예를 들어 일정이 충돌하거나 취소할 수 없는 고정 약속을 변경하려는 proposal은 상태를 바꾸지 않는다.

원문에 없는 수치 합격선은 테스트 설정으로 명시했다: 30일 비루틴 Family 점유율 상한 15%, 최소 80 Family, 사건 없는 시간 5~90%, 규칙 위반 0건. 30일 창은 하루 간격으로 이동하며 수면·휴식·식사 등의 core routine을 제외한다.

P2는 Chain을 붙이기 전 검증이므로 chain_depth_mean은 0이다. 별도의 P4 시험에서는 후속 사건 발생을 검증했다. 이 사전 시험을 P8 완료로 간주하지 않는다.

## P5에서 실제로 읽은 정본

| 영역 | 관찰 결과 |
|---|---|
| WALLET | ¥32,000. 기존 잔액/로그 표 구조 확인 |
| INVENTORY | native DB 0행. 13개 properties와 기존 select 옵션 확인 |
| RELATIONSHIPS | ひな·玲奈·なつき의 관계 서술 확인. 평범한 자료에 숫자·연령을 임의로 채우지 않음 |
| TASTE / CONTINUITY / 기억 | 기존 native 페이지를 읽고 원문 증거 보존 |
| CALENDAR | 미오 일정 40건, 반복 식사·샤워·수면 루틴 확인 |

이 관찰은 조회 시점의 기록이다. 다음 실제 연동 전에 최신 정본을 다시 읽어야 한다. 실서버 읽기 증거는 reports/P5_sources에 있다.

## 남은 작업

1. 서버 API 키로 실제 GPT 판단 시험.
2. 실제 세계 초기화·native 월 마감 설정/검증·운영 scheduler·독립 vault/witness/key 운영 구성·복원 실습.
3. Notion 동시 편집·응답 유실 보호 설계 및 실제 왕복/보상/재시작 시험. 서버 배포·안전한 credential 입력 경로.
4. P5 통과 후 Social, Android UI/APK, 실제 연결 장기 시험.

서버 인증정보와 실제 왕복 검증이 없고 production 세계 초기화·운영 scheduler 등이 미완료이므로 live commit은 막혀 있다. 권한 재승인을 요청한 상태가 아니다. 현재 범위를 전체 MIO WORLD 완료로 표시하지 않는다.

실행: README.md / 다음 작업: HANDOFF.md / 모든 스키마: schemas/ / 개별 테스트 결과: reports/*_tests.json.

## 이번 P5 추가 구현

`P5_WRITES.md`에 native 구조 보존, outbox/영수증, domain lock, 보상, 응답 유실, 실제 프로세스 종료와 복구 검증을 기록했다. `mio.py p5-demo`의 5개 fixture 시나리오 모두 예상 결과를 통과했다. 실제 정본 쓰기는 0회다. 증거: `reports/P5_recovery_tests.json`, `reports/P5_offline_demo.json`.

이전 지출/취소 변경 후 core 검증과 10,000시간 재생을 다시 통과했다(195.098초, 5,479 사건·153 Family·4종 위반 0건). 이번 독립 DB 복구 변경은 core/data/reference를 바꾸지 않았고, 전체 293개 회귀와 168시간 native HTTP fixture 실행·cache/archive 삭제 후 복원, 월말 48시간 fixture 실행을 통과했다. 이전 10,000시간 보고서를 보존하며 이번에 다시 실행했다고 표시하지 않는다. 실제 외부 서버의 통과와 구분한다.

## 초기화/hourly 추가 검증

NativeBootstrapper와 NativeHourlyRuntime을 연결했다. 초기화 요청에 전체 세계/욕구 값과 근거가 없으면 거부한다. 지갑·Inventory·Calendar는 native 증거에서 가져오며 원문 문서도 보존한다. 종일 일정/DST·중복 실행·LLM 실패·native delta·실제 프로세스 강제 종료·응답 유실·재시작 및 지출/취소 통합을 30개 테스트로 검증했다. 168시간 loopback HTTP 실행에서 사건 69건 commit, 15건 skip, snapshot 168개 확인, 미해결 cache binding 0개였다. 실제 GPT·정본 서버 쓰기는 0회다. 이번에 spend/calendar_cancel과 동일 월 원장/Inventory rebase를 구현했고, clock replay와 native full checkpoint cache/인과 복원을 추가했고, native 대상 월이 있는 월 경계/과거 날짜 조정은 fixture에서 통과했고, 실제 native 월 마감 설정/검증·독립 vault/witness/key 운영 구성·복원 실습·운영 배포는 남아 있다. 증거: reports/P5_hourly_tests.json, reports/P5_hourly_demo.json.

## P5 지출·취소·외부 원장 복구

일반 지출의 Wallet/MONEY LOG/Continuity 반영, 런타임 소유 일정의 If-Match 취소·보상과 응답 유실 복구, immutable 원장 prefix와 산술에 근거한 외부 잔액/Inventory import를 39개 시험으로 검증했다. 재시작·중복 반영·외부 편집·최소 tombstone·보상 응답 유실·로컬 DB 실패에서도 근거 없이 commit/rollback을 확정하지 않는다. 두 hourly 통합 시험은 외부 원장 import 후 새 지출, 일정 생성 후 다음 tick 취소를 검증한다. 지원 범위와 월 경계 제한: P5_EFFECTS.md. 실제 GPT/정본 서버 쓰기는 0회다.

## P5 복구 중 시계 진행·native checkpoint 복원

검증 가능한 clock-only journal에 시간 변화를 기록하고, 뒤늦게 확정된 거래의 원래 projection에 같은 변화를 재생한다. 시계·욕구·기존 이동·hook 기한은 진행하지만 새 사건 판단과 불확실한 금전/소유권 확정은 보류한다. 임의 cache 변경과 손상된 시간 기록은 merge하지 않는다.

새 native checkpoint는 전체 cache와 인과 archive를 압축한 조각으로 저장한다. 영수증/초기화 DB가 보존된 경우 캐시 삭제·손상과 archive 테이블 유실을 복원하며, 이후 fresh native 사실을 읽기 전 해당 영역을 stale로 유지한다. 오래된 기록·편집·조각 누락·미확정 거래·새로운 native commit/import는 복원을 막는다. 14개 clock 시험·19개 복원 시험과 168시간 실행 후 실제 cache/archive 삭제·복원이 통과했다. 지원 범위와 실행 진입점은 P5_RESTORE.md에 기록했다. 이 native cache 복원 경로만으로 DB 전체 유실을 복원하지 않는다. 독립 vault/witness/key가 남은 fixture DB 전체 복원은 P5_DISASTER.md를 따른다. 실제 서비스 통과로 선언하지 않는다.

## P5 월 경계·과거 날짜 원장 조정

기존 원장 prefix와 native 대상 월, 행별 잔액/부호/날짜, 월별 합계, 두 번의 안정적인 조회를 검증한다. 잔액은 append 순서로 계산하고 지출은 native 거래 날짜의 월로 분류한다. 기준 이전 월의 전체 지출은 추정하지 않고 확인된 추가 지출만 보존한다. 원장·월별 증거·cache·anchor·인과를 원자적으로 반영하며 native 쓰기는 하지 않는다. 새 달의 SELECT 단계는 시계 저장 후 native 조정과 후보 선택을 재개할 수 있게 한다. DST freshness는 UTC 경과 시간으로 검사한다.

34개 시험과 월말 48시간 fixture에서 지난달 지출 1회 import, 48개 snapshot, 중간 coordinator 재시작과 캐시/인과 삭제 후 복원을 통과했다. native 대상 월/월 지출 reset은 fixture의 명시적인 source 편집이며, 실제 월 마감 자동화 완료로 표시하지 않는다. 상세 계약과 증거: P5_MONTH.md, reports/P5_month_tests.json, reports/P5_month_demo.json.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.

## P5 기기 검사 소스

`android-probe/README.md`의 진단 Activity는 기존 엔진과 160 Family를 그대로 staging한다. Python 진입점에서 6→12시간 fixture 저장 재개, native hourly·DB 유실·host resume와 원본 import 경로를 제외한 staging 사본 실행을 검증했다. Android 의존성·컴파일·설치 시험은 미진행이며, 기기용 APK는 아직 없다.

## P5 실행 지연 복구

`runtime/host_resume.py`는 휴대폰 절전처럼 실행이 멈춘 뒤, 누락 시간을 기존 physics로 한 시간씩 진행하는 별도 복구 경로다. 한 호출은 최대 24개 시간 기록을 처리하고 UTC 기준으로 중복·역행을 막는다. 해당 시간에는 GPT 판단·새 구매/외출·역사 snapshot을 만들지 않는다. 이미 확정된 이동·욕구·hook 기한과 기존 미완료 거래만 처리한다. 신규 요청 없이 전송 상태/영수증을 먼저 복구하고, fresh Notion/Calendar 재조회 전 새 요청과 확인된 사실의 공개를 차단한다.

지연 복구 체크포인트에서 22개 복구·16개 기기 검사 시험을 포함한 전체 331개 회귀와 해당 데모를 실행했다. 최신 인증 체크포인트의 368개 결과는 아래 항목을 따른다. P2 10,000시간 결과는 원본 core/data/reference가 바뀌지 않아 이전 PASS를 보존하며 재실행하지 않았다. **Android APK 빌드는 계속 BLOCKED, 실제 절전/재부팅·실기기 실행은 NOT_RUN**이다. P5 실제 연동 gate와 P0→P8 순서를 유지한다. 상세 계약과 증거: `P5_HOST_RESUME.md`, `reports/P5_host_resume_tests.json`, `reports/P5_host_resume_demo.json`.

## P5 인증 갱신·외부 빌드 준비

`connectors/google_oauth.py`와 `HTTPJSON/CalendarConnector`를 연결했다. 만료 전 갱신, invalid_grant 재인증 차단, retry 지연, GET 401 1회 재시도와 mutation 401 자동 재전송 금지를 fixture에서 검증했다. store는 메모리뿐이며 실제 로그인·Android 암호화 저장·재시작 credential 보존은 미구현이다. `P5_AUTH.md`를 따른다.

OAuth 35개·mobile 18개를 포함한 전체 368개 회귀와 168시간·월말 48시간·DB 유실 fixture를 이번 체크포인트에서 재실행했다. 개인 자료를 제외한 code-only build source의 독립 사본에서도 53개 mobile/OAuth 시험이 PASS다. 기존 P2 10,000시간 PASS는 byte-for-byte 보존하며 이번에 재실행하지 않았다. `P5_REMOTE_BUILD.md`의 수동 자동빌드 설정과 `deployment/MIO_P5_Build_Sources.zip`를 준비했지만 GitHub 계정/repository/job은 연결·실행하지 않았다. **APK/Android 실기기 시험은 아직 NOT_RUN, 로컬 빌드 준비는 BLOCKED**다. P5 실제 정본 gate와 개발 순서는 유지한다.

## Fold8에서 Colab 빌드 준비

PC를 사용할 수 없고 GitHub MFA 설정이 어려운 사용자 환경을 반영하여 `P5_COLAB_BUILD.md`의 Google Colab CPU 노트북을 준비했다. `deployment/MIO_P5_Fold8_Build.ipynb` 하나에 build source를 내장하므로 별도 source 업로드/GitHub 연결/Drive mount/API 키 입력은 필요 없다. Google 로그인은 필요하다. P0부터 368개 fixture를 순서대로 통과한 경우에만 기존 APK build helper를 실행하며 실패하면 진단 ZIP을 만든다.

이전 export는 agent가 직접 읽는 Core Identity를 누락해 독립 전체 회귀 P3가 실패했다. staging/export에 원본 Core Identity 하나를 추가하고 다른 reference 첨부는 제외했다. 수정한 254개 파일 export의 전체 368개 회귀가 독립 Linux/Python 3.12 환경에서 PASS다. 원본 core/data/reference와 기존 P2 10,000시간 보고서는 바꾸지 않았다. 노트북 JSON/Python 문법·내장 원본 hash·실패 시 빌드 차단을 검증했다. **Colab 실행/Python 3.13/Android 컴파일/APK/실기기 시험은 NOT_RUN**이며 P5 live gate와 P0→P8 순서는 유지한다. 이번 작업에서 168시간·월말 48시간·DB 유실 데모는 재실행하지 않았고 이전 보고서를 보존했다.

## Fold8의 GitHub 사이트에서 직접 빌드

사용자가 GitHub 웹 로그인과 저장소 생성을 할 수 있다고 확인하여 `P5_GITHUB_PHONE.md`의 직접 Actions 경로를 준비했다. source ZIP을 root에 올리고 `.github/workflows/mio-p5-phone.yml`을 기본 브랜치에 등록하면 runner가 hash/manifest를 확인하여 추출한다. ChatGPT GitHub 플러그인·PC·runtime API 키가 필요 없다. `deployment/MIO_GitHub_Fold8_Guide.html`에 파일 경로/전체 설정 복사 버튼과 수동 선택 대안을 포함했다.

변경하지 않은 254개 source ZIP과 이전 독립 전체 368 PASS를 유지했다. workflow 문법·실제 extraction shell의 254개 byte 일치·missing/corrupt ZIP 차단 3개·fixture acceptance gate 4개·APK receipt gate 5개 사례 및 안내 copy 원문/JS 문법을 확인했다. APK receipt gate에는 명시적인 모의 bytes만 사용했다. **실제 GitHub repository/job/Python 3.13/Android 컴파일/APK/실기기 검사는 NOT_RUN**이다. core/data/reference·P2 10,000시간 보고서와 P5 live gate는 보존한다. Colab도 별도 선택 경로로 남아 있다.

## 첫 GitHub 실행 확인 및 오류 표시 보완 (2026-10-06)

사용자가 올린 `logs_101431036398.zip`의 console에서 368개 fixture 전체 PASS를 실제 GitHub/Python 3.13.15 환경에서 확인했다. Java/javac 17·Gradle 8.13·Android SDK 검사도 적합했고 218개 runtime source/160 Family가 staging됐다. 이후 Android build가 Gradle exit 1/helper exit 2로 실패하여 APK는 없다. `reports/P5_github_run1.json`을 최신 상태로 따른다. 이전 NOT_RUN 기록은 해당 준비 체크포인트 당시 상태다.

console에는 helper가 파일로 저장한 실제 Gradle 오류가 없다. 첫 실행의 [MIO_P5_build_diagnostics.zip](https://github.com/qkdghsthzn-cyber/Miooi/actions/runs/37447059977/artifacts/11403891732) 업로드 성공/33,532 bytes를 확인했지만 파일 내용은 아직 받지 못했다. 해당 ZIP을 먼저 받으면 재실행 없이 분석할 수 있다. Download logs의 ZIP과 Summary/Artifacts의 진단 ZIP은 서로 다르다.

phone workflow에 실패한 Android build 뒤 `Show Android build error log`를 추가했다. 마지막 200줄을 표시하며 원래 build 실패/후속 APK 차단은 유지한다. 누락/빈/200줄 제한 로그 3사례, YAML/shell/inline Python·안내 JS/copy 원문을 확인했다. 원본 source ZIP과 core/data/reference 193개 및 기존 회귀/P2 보고서는 변경하지 않았다. **실패 원인은 미확인/미수정이고 새 workflow remote 실행은 NOT_RUN**이다. 진단 ZIP을 받을 수 없는 경우에만 YAML 본문을 교체하여 Commit 후 **새 Run workflow**로 실행한다. P5 live gate와 P6~P8 NOT_STARTED를 유지한다.

## Android 바이너리 의존성 오류 수정 (2026-10-06)

첫 실행의 `MIO_P5_build_diagnostics.zip`(SHA `8eb7e1a…83c80e`)에서 실제 18단계 368 PASS와 Gradle 원인을 확인했다. `:probe:installDebugPythonRequirements`가 Pydantic 2.13 계열의 정확한 `pydantic-core` Android wheel을 찾지 못해 실패했다. Gradle 8.13 안내 경고가 실패 이유는 아니다. 최신 증거는 `reports/P5_android_dependencies_fix.json`이다.

엔진/스키마/requirements 범위를 바꾸지 않고 Android 빌드 constraint에 첫 실행 버전 Pydantic 2.13.5/core 2.46.5를 고정했다. `tools/build_android_wheels.py`는 SHA가 고정된 공식 upstream sdist를 추출하고 Cargo.lock을 유지하여 cibuildwheel 4.3.0/Rust 1.88.0으로 CPython 3.13/API24/arm64-v8a와 x86_64 wheel을 만든다. cibuildwheel이 실제 Android libpython/sysconfig·NDK·Cargo linker/PyO3 환경을 제공한다. version/tag/native ELF architecture/16KiB LOAD alignment와 두 ABI receipt를 확인한 경우에만 Gradle find-links로 공급한다. 새 temp output을 사용해 실패 후 이전 wheel을 재사용하지 않는다. Gradle 실패는 stacktrace와 native-wheel/Gradle 진단 로그로 남긴다. 설치/런타임 적합성은 여전히 실기기 검증 대상이다.

기존 368개와 새 synthetic binary receipt/source guard 10개를 포함한 **378개 회귀가 개발 tree 및 배포 ZIP의 독립 Linux/Python 3.12.14 사본에서 모두 PASS**다. 실제 upstream hash/extraction·cibuildwheel의 두 대상 선택·wheel 실패 시 Gradle/APK 차단·workflow/notebook/guide 문법과 embedded ZIP/copy 원문을 확인했다. synthetic bytes를 실제 wheel/APK로 내보내지 않는다. 원본 engine/data/reference/mobile 227개와 160 Family, P2 10,000시간 보고서 및 live gate를 보존했다.

새 source ZIP은 258개 파일/SHA `feb53d33ffe39372cd88cd7b4c81294e0a40e6ec9c9989205c3501634e6a18fe`이다. **소스 ZIP과 phone YAML 둘 다 교체·Commit하고 새 Run workflow를 실행해야 한다.** 이전 실행의 Re-run jobs는 이전 revision을 사용한다. Colab 노트북에도 새 ZIP/constraint/378개 gate를 반영했으나 선택 경로이며 실행하지 않았다. **수정본의 native wheel compilation·Gradle/APK·Android 실행은 NOT_RUN**이다. P5가 완료된 것으로 표시하지 않으며 P6~P8은 계속 NOT_STARTED다.

공식 빌드 참고: [Chaquopy Android wheel 빌드](https://github.com/chaquo/chaquopy/blob/master/server/pypi/README.md), [cibuildwheel Android](https://cibuildwheel.pypa.io/en/stable/platforms/#android), [PyO3 cross compilation](https://pyo3.rs/main/building-and-distribution.html#cross-compiling).
