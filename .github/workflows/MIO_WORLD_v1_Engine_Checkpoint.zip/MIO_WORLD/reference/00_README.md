# MIO Source Split v1

목적: 기존 MIO 소스를 개발용 7계층으로 정규화하여 Work/구현 단계에서 필요한 문서만 로드할 수 있게 한다.

## 파일
- `01_Core_Identity.md` - 쉽게 변하지 않는 정체성, 말투, 가치, 자율성, 공통 운용 원칙
- `02_Canon_Memory.md` - 500개 고유 사건의 읽기용 정규화본
- `02_Canon_Memory.jsonl` - RAG/벡터 검색용 500개 레코드
- `03_Live_State.md` - 시시각각 변하는 런타임 상태 스키마/상태 의존 규칙
- `04_Learned_Relationship_Memory.md` - 반복 경험이 장기 관계 기억으로 승격되는 규칙
- `05_Connected_World.md` - Calendar/Drive/Notion/Metricool/Web 등 외부 세계 연결 스냅샷
- `06_Action_Layer.md` - 행동 및 장면 운용 규칙
- `07_Presentation_Layer.md` - 현재 확인된 표현/출력 표면과 아직 미정인 UI 영역
- `08_Source_Map.csv` - 원본 → 분할 파일 추적표

## 정규화 방식
- 500 Scenes의 500회 반복 문장 2개는 Core Identity로 1회 이동했다.
- 장면 종료 문장 중 공통 원칙은 Core Identity로 이동하고 장면별 고유 행동만 Canon Memory에 남겼다.
- 각 장면의 고유 서술은 500개 모두 유지했다. 현재 추출된 scene count: **500**.
- Intimacy Bible은 내용의 의미를 새로 만들지 않고 원문 섹션을 역할별 문서로 재배치했다.
- 원문에 없는 Android/API 구체 구현 사양은 Presentation Layer에 임의 추가하지 않았다.

## 우선순위
`Live State / 최신 사용자 명시 설정 > Learned Relationship Memory > Core Identity + Canon Memory > 과거 단발 장면`

이 우선순위는 원본의 “최신 명시 설정 우선, 반복 패턴을 더 강한 근거로 사용” 규칙을 개발용으로 정리한 것이다.
