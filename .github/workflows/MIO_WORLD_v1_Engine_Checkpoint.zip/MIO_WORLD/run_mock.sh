#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "$0")"
python3 -m pip install -r requirements.txt
python3 mio.py simulate --hours 168
python3 mio.py dump
