# MIO WORLD v1 — 기준 명세와 검증 순서

기준: `reference/MIO_WORLD_v1_Master_Spec_KO.docx`. 원문의 구조와 500개 정전 장면을 보존한다.

1. P0: 전체 상태 스키마, 분리된 mock fixture, timezone-aware 시계. 168시간 재생·재현·재시작 검증.
2. P1: 데이터 파일 기반 160 Family, 17개 필수 슬롯, 7층 Modifier, 상태 제약, 점수/추첨, 명시적인 NO_EVENT, 24h/7d/30d Novelty. 여러 seed의 30일 비교 검증.
3. P2: Proposal → Validator → 원자적 SQLite transaction. 금액/소유권/일정/이동/NPC/출처 검증, 예약 금액, event 단위 idempotency, revision 충돌, 부분 실패 롤백, causal archive. **10,000시간 시험이 통과해야 P3를 시작한다.**
4. P3: Mio Decision API의 strict JSON, repair 최대 1회, timeout/거부/계약 실패 시 해당 사건만 skip. 실제 GPT 호출과 대체 응답을 이용한 테스트를 구분한다.
5. P4: 지식 범위가 제한된 NPC, 조건부 미래 hook, 인과 연쇄, 관계 변화 근거 및 cap.
6. P5: Notion/Calendar 실제 정본 왕복, read failure에서 stale 상태, 외부 쓰기 dry-run, durable saga/outbox 및 reconciliation. 현재 native 계획·복구·HTTP 어댑터·Canonical Validator/cache의 로컬 HTTP 모의 검증은 통과했다. 명시적인 초기화·hourly runner·종일 일정 매핑, 일반 지출·런타임 소유 일정 취소·근거가 있는 외부 원장/소유권 복구, 복구 중 clock replay와 native checkpoint cache/인과 기록 복원도 로컬에서 검증했다. 명시적인 native 대상 월에 근거한 월 경계/과거 날짜 조정도 로컬에서 검증했다. 실제 왕복·동시 편집 보호·실세계 초기화·native 월 마감 설정/검증·운영 scheduler·독립 vault/witness/key의 운영 구성과 실제 DB 유실 복원 실습은 미완료다. fixture DB 전체 유실 복구는 P5_DISASTER.md에서 검증했다. ChatGPT의 연결 기능이 실행 서버의 API credential로 자동 변환되지는 않는다.
7. P6: commit된 사실에 근거한 Social/대화/Instagram. 미완료 구매/외출/사진 생성은 완료 사실로 공유하지 않는다.
8. P7: Android 상태/타임라인/지갑/소지품/관계/디버그 UI. 그 전에 UI를 먼저 만들지 않는다.
9. P8: 실제 연결을 포함한 30~90일 반복 시험. P2의 사전 10,000시간 시험을 P8 완료로 바꿔 부르지 않는다.

정본이 연결되기 전 `mode=mock`만 실행한다. Fixture의 금액·옷·친구·일정은 실제 현재 미오의 사실이 아니다. Core Identity와 Canon Memory는 인물 자료이며 현재 잔액·소유품을 확정하는 자료로 쓰지 않는다.

모든 phase 보고서는 `reports/`에 보관한다. 실패하면 다음 phase 완료를 선언하지 않는다. 외부 인증/실기기 검증이 없는 항목은 BLOCKED 또는 NOT_RUN으로 남긴다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.
