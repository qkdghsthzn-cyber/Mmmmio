from datetime import timedelta
from .models import State, Commitment, Provenance, LedgerEntry, Taste, ContinuityEdge, Journey
from .candidate_generator import busy


class RuleViolation(ValueError):
    pass


EFFECT_ACTIONS={
 "observe":{"observe"}, "contact":{"relationship_update"}, "use_item":{"use_item"},
 "purchase":{"purchase"}, "spend":{"spend"}, "need":{"need_update"},
 "calendar":{"calendar_create"}, "cancel_calendar":{"calendar_cancel"},
 "invite":{"calendar_create","relationship_update"}, "move":{"move"},
}


class Validator:
    def __init__(self,grammar): self.grammar=grammar

    def project(self,state,event,decision,transaction_id,fault_after=None):
        if state.mode!="mock":
            raise RuleViolation("live state requires canonical connector coordinator")
        return self._project(state,event,decision,transaction_id,fault_after)

    def _project(self,state,event,decision,transaction_id,fault_after=None,cancel_authorizations=frozenset()):
        # Pure proposed-state calculation, shared only after canonical evidence
        # validation. No connector I/O or state publication occurs here.
        if event.event_id!=decision.event_id: raise RuleViolation("decision event mismatch")
        if event.status!="pending": raise RuleViolation("event not pending")
        if event.source=="unverified": raise RuleViolation("unverified facts cannot change canonical state")
        if event.family not in self.grammar.families: raise RuleViolation("unknown event family")
        if event.created_at!=state.world.time: raise RuleViolation("event is not from this tick")
        if any(actor not in state.relationships or not state.relationships[actor].active for actor in event.actors):
            raise RuleViolation("unknown/inactive actor")
        family=self.grammar.families[event.family]
        if family.adult:
            if not state.feature_flags.get("adult_life") or state.world.privacy!="private": raise RuleViolation("adult life disabled/context invalid")
            if not event.actors or any(not (state.relationships[a].consent and state.relationships[a].mutual_affection and state.relationships[a].age>=18 and state.relationships[a].role=="partner") for a in event.actors):
                raise RuleViolation("mutual adult consent required")
        if decision.choice!="accept" and decision.actions: raise RuleViolation("declined/deferred event has executable actions")
        if decision.choice=="accept" and not decision.actions: raise RuleViolation("accepted event must propose an action")
        if len({a.type for a in decision.actions})!=len(decision.actions): raise RuleViolation("duplicate action type")
        allowed=EFFECT_ACTIONS[family.effect]
        if any(a.type not in allowed for a in decision.actions): raise RuleViolation("action not authorized by family")
        if family.effect!="move" and state.world.place not in family.locations:
            raise RuleViolation("circumstance cannot happen at current location")
        if state.world.journey and any(a.type not in {"observe","relationship_update"} for a in decision.actions):
            raise RuleViolation("another activity cannot preempt travel")
        next_state=State.model_validate_json(state.model_dump_json())
        now=next_state.world.time
        provenance=Provenance(source="internal_world",ref=event.event_id,verified_at=now)
        for index,action in enumerate(decision.actions):
            if action.type in {"purchase","spend","use_item"} and next_state.notion_stale:
                raise RuleViolation("stale canonical ownership/wallet")
            if action.type in {"calendar_create","calendar_cancel","move"} and next_state.calendar_stale:
                raise RuleViolation("calendar unavailable")
            if action.type=="purchase":
                item=next_state.catalog.get(action.item_id)
                if not item or item.status!="available" or item.price is None: raise RuleViolation("item unavailable")
                if action.item_id!=event.payload.get("item_id"): raise RuleViolation("object not bound to candidate")
                if action.amount!=item.price or event.payload.get("cost")!=item.price: raise RuleViolation("price not verified")
                if item.item_id in next_state.inventory: raise RuleViolation("duplicate owned item")
                self._charge(next_state,item.price,event,transaction_id,index)
                acquired=item.model_copy(deep=True); acquired.status="owned"; acquired.acquired_at=now
                acquired.source_event=event.event_id; acquired.provenance=provenance
                next_state.inventory[item.item_id]=acquired
                next_state.wishlist[item.item_id]="purchased"
                item.status="owned"
            elif action.type=="spend":
                if action.amount is None or action.amount<=0 or action.amount!=event.payload.get("cost"):
                    raise RuleViolation("spend must equal authorized positive cost")
                self._charge(next_state,action.amount,event,transaction_id,index)
            elif action.type=="use_item":
                item=next_state.inventory.get(action.item_id)
                if not item or item.status!="owned": raise RuleViolation("unowned item cannot be used/worn")
                if action.item_id!=event.payload.get("item_id"): raise RuleViolation("item not bound to event")
                next_state.world.activity=event.slots["action"]
                next_state.continuity.append(ContinuityEdge(cause=event.event_id,consequence="use:"+item.item_id,transaction_id=transaction_id,depth=event.depth))
            elif action.type=="calendar_create":
                if action.start is None or action.end is None or not action.title: raise RuleViolation("incomplete calendar action")
                if action.start<now or action.start>now+timedelta(days=7) or action.end<=action.start:
                    raise RuleViolation("invalid/far-future calendar interval")
                duration=(action.end-action.start).total_seconds()/60
                if duration!=event.payload.get("duration_minutes"): raise RuleViolation("duration not bound to event")
                if busy(next_state,action.start,action.end): raise RuleViolation("fixed calendar conflict")
                location=action.location or next_state.world.place
                self._calendar_travel(next_state,action.start,action.end,location)
                commitment=Commitment(commitment_id="cal_"+transaction_id,start=action.start,end=action.end,title=action.title,
                         participants=event.actors,source_event=event.event_id,location=location,provenance=provenance)
                next_state.calendar.append(commitment)
            elif action.type=="calendar_cancel":
                if action.commitment_id!=event.payload.get("commitment_id"): raise RuleViolation("calendar id not bound")
                target=next((c for c in next_state.calendar if c.commitment_id==action.commitment_id),None)
                if not target or target.status!="scheduled" or target.start<=now: raise RuleViolation("calendar cancellation not available")
                if target.provenance.source=="mock" and target.commitment_id not in cancel_authorizations:
                    raise RuleViolation("fixture fixed commitments cannot be cancelled")
                target.status="cancelled"
            elif action.type=="relationship_update":
                if action.npc_id not in event.actors: raise RuleViolation("interaction evidence required")
                if action.delta is None or abs(action.delta)>self.grammar.rules["relationship_delta_cap"]:
                    raise RuleViolation("relationship delta cap")
                npc=next_state.relationships[action.npc_id]
                npc.closeness=max(0,min(100,npc.closeness+action.delta))
                npc.trust=max(0,min(100,npc.trust+action.delta*.15)); npc.last_contact=now
            elif action.type=="need_update":
                if action.need!=family.need or action.delta!=family.need_delta:
                    raise RuleViolation("need change must equal rule-bound consequence")
                current=getattr(next_state.world.needs,action.need)
                setattr(next_state.world.needs,action.need,max(0,min(100,current+action.delta)))
                next_state.world.activity=event.slots["action"]
            elif action.type=="move":
                if action.location!=event.payload.get("location"): raise RuleViolation("destination not bound")
                travel=next_state.travel_minutes.get(f"{next_state.world.place}->{action.location}")
                if travel is None or travel>60: raise RuleViolation("unreachable location")
                if busy(next_state,now,now+timedelta(minutes=travel+int(event.payload["duration_minutes"]))):
                    raise RuleViolation("travel exceeds free time")
                if travel:
                    next_state.world.journey=Journey(destination=action.location,departure=now,arrival=now+timedelta(minutes=travel),
                                                    source_event=event.event_id,transaction_id=transaction_id)
                    next_state.world.activity="travel_to:"+action.location
                else:
                    next_state.world.place=action.location; next_state.world.activity=event.slots["action"]
            elif action.type=="observe":
                # A present-tense observation creates no completed trip/photo/purchase.
                next_state.world.activity="consider:"+event.family.lower()
            if fault_after is not None and index==fault_after: raise RuntimeError("injected partial-commit failure")
        if decision.choice=="accept":
            topic=family.topic
            taste=next_state.taste.get(topic)
            if taste:
                taste.evidence_count+=1; taste.last_updated=now; taste.source_event=event.event_id
                taste.confidence=min(1,taste.confidence+.002)
            else:
                next_state.taste[topic]=Taste(topic=topic,affinity=50,confidence=.1,evidence_count=1,last_updated=now,source_event=event.event_id)
            next_state.continuity.append(ContinuityEdge(cause=event.event_id,consequence=decision.decision_id,transaction_id=transaction_id,depth=event.depth))
        next_state.revision+=1
        # Validate the fully staged result, not each independent operation alone.
        next_state=State.model_validate_json(next_state.model_dump_json())
        self.invariants(next_state)
        return next_state

    def _charge(self,state,cost,event,transaction_id,index):
        if state.wallet.available_balance<cost: raise RuleViolation("insufficient available balance")
        state.wallet.balance-=cost
        state.wallet.ledger.append(LedgerEntry(ledger_id=f"ledger_{transaction_id}_{index}",amount=-cost,
             balance_after=state.wallet.balance,event_id=event.event_id,transaction_id=transaction_id,created_at=state.world.time))

    def _calendar_travel(self,state,start,end,location):
        for c in state.calendar:
            if c.status!="scheduled" or c.flexibility!="fixed": continue
            if c.end<=start:
                gap=(start-c.end).total_seconds()/60; travel=state.travel_minutes.get(f"{c.location}->{location}")
            elif c.start>=end:
                gap=(c.start-end).total_seconds()/60; travel=state.travel_minutes.get(f"{location}->{c.location}")
            else: continue
            if travel is None or gap<travel: raise RuleViolation("calendar travel time impossible")

    @staticmethod
    def invariants(state):
        if state.wallet.available_balance<0: raise RuleViolation("negative available balance")
        active=[c for c in state.calendar if c.status=="scheduled" and c.flexibility=="fixed"]
        active.sort(key=lambda c:c.start)
        for a,b in zip(active,active[1:]):
            if a.end>b.start: raise RuleViolation("fixed calendar overlap")
        for entry in state.wallet.ledger:
            if not entry.event_id or not entry.transaction_id: raise RuleViolation("ledger has no provenance")
        for previous,current in zip(state.wallet.ledger,state.wallet.ledger[1:]):
            if previous.balance_after+current.amount!=current.balance_after:
                raise RuleViolation("wallet ledger arithmetic mismatch")
        if state.wallet.ledger and state.wallet.ledger[-1].balance_after!=state.wallet.balance:
            raise RuleViolation("wallet differs from ledger")
        for item in state.inventory.values():
            if item.provenance.source=="internal_world" and not item.source_event: raise RuleViolation("ownership without cause")
