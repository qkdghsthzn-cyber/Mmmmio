import hashlib
import json
from .models import TransactionRecord, Event
from .validator import RuleViolation


class TransactionManager:
    def __init__(self,store,validator): self.store=store; self.validator=validator; self.last_state=None

    def commit(self,event,decision,expected_revision,fault_after=None):
        self.last_state=None
        if not self.store.db.in_transaction:
            raise RuntimeError("commit must execute inside StateStore.atomic()")
        key="event:"+event.event_id
        existing=self.store.db.execute("SELECT body FROM transactions WHERE idempotency_key=?",(key,)).fetchone()
        if existing: return TransactionRecord.model_validate_json(existing[0])
        transaction_id="tx_"+hashlib.sha256(key.encode()).hexdigest()[:24]
        record=TransactionRecord(transaction_id=transaction_id,idempotency_key=key,event_id=event.event_id,
             decision_id=decision.decision_id,expected_revision=expected_revision,status="committed",created_at=event.created_at)
        self.store.db.execute("SAVEPOINT world_action")
        try:
            state=self.store.load()
            saved=self.store.db.execute("SELECT body FROM events WHERE event_id=?",(event.event_id,)).fetchone()
            if saved is None or Event.model_validate_json(saved[0])!=event: raise RuleViolation("event not authenticated by event log")
            if state.revision!=expected_revision: raise RuleViolation("optimistic revision conflict")
            prior_decision=self.store.db.execute("SELECT event_id FROM decisions WHERE decision_id=?",(decision.decision_id,)).fetchone()
            if prior_decision and prior_decision[0]!=event.event_id:
                raise RuleViolation("decision ID already belongs to another event")
            projected=self.validator.project(state,event,decision,transaction_id,fault_after)
            self.store.log_decision(decision)
            self.store.save(projected,transaction_id,"transaction")
            event=event.model_copy(deep=True); event.status="committed"; event.resolved_at=state.world.time
            self.store.log_event(event)
            self.last_state=projected
        except (ValueError,RuntimeError) as error:
            self.store.db.execute("ROLLBACK TO world_action")
            record.status="rejected" if isinstance(error,ValueError) else "rolled_back"
            record.error=str(error)
            failed=event.model_copy(deep=True); failed.status="rejected"; failed.resolved_at=event.created_at
            self.store.log_event(failed); self.store.log_decision(decision)
        finally:
            self.store.db.execute("RELEASE world_action")
        self.store.db.execute("INSERT INTO transactions VALUES(?,?,?,?,?)",(record.transaction_id,key,event.event_id,record.status,record.model_dump_json()))
        return record
