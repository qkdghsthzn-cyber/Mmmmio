from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from .models import aware


class DeterministicClock:
    def __init__(self, start: datetime, timezone: str = "Asia/Tokyo"):
        self.start = aware(start).astimezone(ZoneInfo(timezone))

    def at(self, index: int) -> datetime:
        if index < 0:
            raise ValueError("negative tick index")
        return self.start + timedelta(hours=index)

    def tick_id(self, index: int) -> str:
        return "tick_" + self.at(index).isoformat()
