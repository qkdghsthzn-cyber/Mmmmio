from datetime import datetime, timedelta
from .models import State, WorldState, Wallet, Item, NPC, Taste, Commitment, Provenance


def mock_state(start=None):
    start = start or datetime.fromisoformat("2026-10-06T00:00:00+09:00")
    provenance = Provenance(source="mock", ref="fixture_v1_NOT_REAL_MIO_FACTS")
    inventory = {
        "shirt_white": Item(item_id="shirt_white", name="白いシャツ", status="owned", category="clothing",price=2400,acquired_at=start-timedelta(days=30),provenance=provenance),
        "jeans_blue": Item(item_id="jeans_blue", name="青いジーンズ", status="owned", category="clothing",price=3900,acquired_at=start-timedelta(days=30),provenance=provenance),
        "phone": Item(item_id="phone",name="スマートフォン",status="owned",category="device",provenance=provenance),
        "notebook": Item(item_id="notebook",name="ノート",status="owned",category="study",price=300,provenance=provenance),
        "game": Item(item_id="game",name="ゲーム",status="owned",category="hobby",price=1800,provenance=provenance),
    }
    catalog = {f"catalog_{i}": Item(item_id=f"catalog_{i}",name=f"テスト商品 {i}",status="available",category="clothing" if i%2==0 else "hobby",price=300+i*150,provenance=provenance) for i in range(16)}
    relationships = {}
    for i,name in enumerate(["玲奈", "葵", "凛", "美咲", "楓", "遥", "奈々", "結衣"]):
        npc_id=f"npc_{i}"
        relationships[npc_id]=NPC(npc_id=npc_id,name=name,age=20+i,closeness=45+i*4,trust=50+i*3,
                                  traits=["calm","playful"][i%2:i%2+1],shared_interests=["fashion","game"],
                                  last_contact=start-timedelta(days=i+1),knowledge_scope=["shared:fashion","shared:game","public:profile"],provenance=provenance)
    calendar=[]
    for day in range(7):
        if day%7<5:
            a=start+timedelta(days=day,hours=10)
            calendar.append(Commitment(commitment_id=f"fixture_class_{day}",start=a,end=a+timedelta(hours=2),title="テスト授業",source_event="fixture_v1",location="school",provenance=provenance))
    tastes={topic:Taste(topic=topic,affinity=aff,confidence=.8,evidence_count=3,last_updated=start) for topic,aff in [("fashion",80),("game",75),("cafe",60),("study",50),("creative",70)]}
    travel={f"{a}->{b}":0 if a==b else 20 for a in ["home","school","cafe","shop","park","bookstore"] for b in ["home","school","cafe","shop","park","bookstore"]}
    return State(world=WorldState(time=start),wallet=Wallet(balance=27850),inventory=inventory,catalog=catalog,
                 wishlist={"catalog_0":"wanted","catalog_2":"wanted"},relationships=relationships,calendar=calendar,taste=tastes,travel_minutes=travel,provenance=provenance)
