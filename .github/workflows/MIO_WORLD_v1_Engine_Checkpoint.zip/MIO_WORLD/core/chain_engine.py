import hashlib
import json
from datetime import timedelta
from pathlib import Path
from .models import Hook,ContinuityEdge


class ChainEngine:
    def __init__(self,grammar,path=None):
        self.grammar=grammar
        path=path or Path(__file__).resolve().parents[1]/"data"/"rules"/"chains.json"
        self.chains=json.loads(Path(path).read_text())
        for source,rules in self.chains.items():
            if source not in grammar.families: raise ValueError("unknown chain source")
            for rule in rules:
                if rule["family"] not in grammar.families: raise ValueError("unknown chain target")
                if rule.get("delay_hours",0)<0 or rule.get("expires_hours",0)<=0: raise ValueError("invalid hook lifetime")

    def after_commit(self,state,event,decision,transaction):
        if transaction.status!="committed" or transaction.event_id!=event.event_id or decision.event_id!=event.event_id:
            raise ValueError("hook requires committed evidence")
        for hook in state.hooks:
            if hook.hook_id==event.payload.get("hook_id"): hook.status="resolved"
        # Grant interaction knowledge only to actual conversation participants.
        for action in decision.actions:
            if action.type=="relationship_update" and action.npc_id in state.relationships:
                npc=state.relationships[action.npc_id]
                scope="event:"+event.event_id
                if scope not in npc.knowledge_scope: npc.knowledge_scope.append(scope)
        if decision.choice!="accept" or event.depth>=self.grammar.rules["chain_depth_cap"]: return
        known={h.hook_id for h in state.hooks}
        open_count=sum(h.status=="open" for h in state.hooks)
        for index,rule in enumerate(self.chains.get(event.family,[])):
            if open_count>=self.grammar.rules["max_hooks"]: break
            obj=event.payload.get("item_id")
            if rule.get("if_object_category"):
                item=state.inventory.get(obj)
                if not item or item.category!=rule["if_object_category"]: continue
            commitment=None; due=state.world.time
            if rule.get("due")=="calendar_end":
                commitment=next((c for c in state.calendar if c.source_event==event.event_id and c.status=="scheduled"),None)
                if commitment is None: continue
                due=commitment.end
            due+=timedelta(hours=rule.get("delay_hours",0))
            hook_id="hook_"+hashlib.sha256(f"{event.event_id}|{index}|{rule['family']}".encode()).hexdigest()[:24]
            if hook_id in known: continue
            actor=event.actors[0] if rule.get("preserve_actor") and event.actors else None
            hook=Hook(hook_id=hook_id,family=rule["family"],due_at=due,expires_at=due+timedelta(hours=rule["expires_hours"]),
                      cause_event=event.event_id,actor=actor,object_id=obj if rule.get("preserve_object") else None,
                      commitment_id=commitment.commitment_id if commitment else None,depth=event.depth+1)
            state.hooks.append(hook); known.add(hook_id); open_count+=1
            state.continuity.append(ContinuityEdge(cause=event.event_id,consequence=hook_id,transaction_id=transaction.transaction_id,depth=hook.depth))
            if actor:
                npc=state.relationships[actor]
                npc.open_threads.append(hook_id)
                if "hook:"+hook_id not in npc.knowledge_scope: npc.knowledge_scope.append("hook:"+hook_id)
        self.resolve_due(state)

    def resolve_due(self,state):
        now=state.world.time
        cancelled={c.commitment_id for c in state.calendar if c.status=="cancelled"}
        for hook in state.hooks:
            if hook.status=="open" and (now>=hook.expires_at or hook.commitment_id in cancelled): hook.status="expired"
        open_ids={h.hook_id for h in state.hooks if h.status=="open"}
        for npc in state.relationships.values(): npc.open_threads=[h for h in npc.open_threads if h in open_ids]
