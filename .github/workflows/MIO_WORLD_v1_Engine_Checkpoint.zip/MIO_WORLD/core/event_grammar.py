import json
from pathlib import Path
from pydantic import Field, model_validator
from .models import Model

DATA=Path(__file__).resolve().parents[1]/"data"


class Family(Model):
    id: str
    group: str
    description: str
    base_weight: float = Field(gt=0)
    routine: bool
    cost: int = Field(ge=0)
    cost_band: str
    duration_minutes: list[int]
    intents: list[str]
    novelty_keys: list[str]
    hooks: list[str]
    binds: dict[str,str]
    effects_if_committed: list[str]
    actions: list[str]
    triggers: list[str]
    channels: list[str]
    locations: list[str]
    outcomes: list[str]
    topic: str
    need: str
    effect: str
    actor_types: list[str]
    requires: list[str]
    forbids: list[str]
    cooldown_hours: int = Field(ge=0)
    object_category: str | None = None
    need_delta: int = -10
    hours: list[int] | None = None
    adult: bool = False

    @model_validator(mode="after")
    def known_rules(self):
        allowed={"actor_active","owned_item","available_item","budget","uniqueness","reachable","mutual_consent","private_context","future_commitment"}
        if not set(self.requires)<=allowed or not set(self.forbids)<={"fixed_busy"}:
            raise ValueError("unknown grammar rule; fail closed")
        if self.effect not in {"observe","contact","use_item","purchase","spend","need","calendar","cancel_calendar","invite","move"}:
            raise ValueError("unknown effect")
        if not self.actions or not self.triggers or not self.outcomes:
            raise ValueError("empty required slot")
        if set(self.binds)!={"actor","object","cost","location"}:
            raise ValueError("required binding contract missing")
        return self


class Grammar:
    def __init__(self, path=DATA):
        self.families={}
        for p in sorted((Path(path)/"event_families").glob("*.json")):
            family=Family.model_validate_json(p.read_text())
            if family.id in self.families: raise ValueError("duplicate family")
            self.families[family.id]=family
        self.modifiers=json.loads((Path(path)/"modifiers"/"layers.json").read_text())
        self.slots=json.loads((Path(path)/"slots.json").read_text())
        self.rules=json.loads((Path(path)/"rules"/"world.json").read_text())
        chains_path=Path(path)/"rules"/"chains.json"
        if chains_path.exists():
            for source,rules in json.loads(chains_path.read_text()).items():
                if source in self.families: self.families[source].hooks=[r["family"] for r in rules]
