"""MIO WORLD deterministic rules. UI and language models cannot write state."""
