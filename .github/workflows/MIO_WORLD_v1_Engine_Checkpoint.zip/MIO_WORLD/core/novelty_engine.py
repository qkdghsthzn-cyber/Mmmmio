import math
from collections import defaultdict
from bisect import bisect_left
from datetime import timedelta
from .models import NoveltyRecord


class NoveltyEngine:
    def __init__(self, rules, records=(), enabled=True):
        self.rules=rules; self.enabled=enabled; self.features=defaultdict(list)
        for record in records:
            for k,v in record.features.items(): self.features[(k,v)].append(record.time)

    def last_family(self,family):
        d=self.features[("family",family)]
        return d[-1] if d else None

    def penalty(self,features,now,routine=False):
        if not self.enabled: return 0
        result=0
        for key,value in features.items():
            d=self.features[(key,value)]
            old=bisect_left(d,now-timedelta(days=30))
            if old: del d[:old]
            c24=len(d)-bisect_left(d,now-timedelta(hours=24))
            c7=len(d)-bisect_left(d,now-timedelta(days=7))
            recent=math.exp(-(now-d[-1]).total_seconds()/14400) if d else 0
            # Family/action are stronger than naturally repeated home location.
            scale=1 if key in {"family","actor"} else .06
            result+=scale*(self.rules["novelty_24h"]*c24+self.rules["novelty_7d"]*c7+self.rules["novelty_recent"]*recent)
        return result*(self.rules["routine_penalty_scale"] if routine else 1)

    def record(self,event):
        features=event_features(event)
        for k,v in features.items(): self.features[(k,v)].append(event.created_at)
        return NoveltyRecord(time=event.created_at,features=features,routine=event.routine)


def event_features(event):
    features={"family":event.family,
            "action":event.slots.get("action","none"),"location":event.slots.get("location","home"),
            "topic":str(event.payload.get("topic","none"))}
    if event.actors: features["actor"]=event.actors[0]
    return features
