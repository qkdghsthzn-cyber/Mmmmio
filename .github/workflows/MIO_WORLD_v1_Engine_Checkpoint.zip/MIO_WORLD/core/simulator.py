import math
from collections import Counter,deque
from datetime import timedelta,datetime
from .models import Event, ContinuityEdge, Decision
from .clock import DeterministicClock
from .event_grammar import Grammar
from .candidate_generator import CandidateGenerator,seeded
from .novelty_engine import NoveltyEngine
from .probability_engine import ProbabilityEngine
from .validator import Validator
from .transaction_manager import TransactionManager
from agents.simulator_policy import simulator_decision


class Simulator:
    def __init__(self,store,seed=42,novelty=True,decision_agent=None,chain=None):
        self.store=store; self.seed=seed; self.grammar=Grammar()
        self.generator=CandidateGenerator(self.grammar); self.probability=ProbabilityEngine(self.grammar.rules)
        self.novelty=NoveltyEngine(self.grammar.rules,store.load().novelty_memory,novelty)
        self.validator=Validator(self.grammar); self.transactions=TransactionManager(store,self.validator)
        start=store.load().world.time
        if store.db.execute("SELECT 1 FROM ticks LIMIT 1").fetchone(): start+=timedelta(hours=1)
        self.clock=DeterministicClock(start); self.decision_agent=decision_agent; self.chain=chain
        self.skips=0

    def tick(self,time):
        try:
            return self._tick(time)
        except BaseException:
            # In-memory indexes must agree with SQLite after a tick rollback.
            self.novelty=NoveltyEngine(self.grammar.rules,self.store.load().novelty_memory,self.novelty.enabled)
            raise

    def _tick(self,time):
        tick_id="tick_"+time.isoformat()
        with self.store.atomic():
            if not self.store.claim_tick(tick_id,time): return False
            state=self.store.load()
            if time<state.world.time: raise ValueError("clock cannot move backwards")
            previous_time=state.world.time
            state.world.time=time
            if state.world.journey and state.world.journey.arrival<=time:
                state.world.place=state.world.journey.destination
                state.world.activity="arrived:"+state.world.journey.destination
                state.world.journey=None
            # Resolve real scheduled facts only; routine physics has a tick source.
            for c in state.calendar:
                if c.status=="scheduled" and c.end<=time: c.status="completed"
                if c.status=="scheduled" and c.start<=time<c.end:
                    state.world.place=c.location; state.world.activity="commitment:"+c.commitment_id
            active=[c for c in state.calendar if c.status=="scheduled" and c.start>=time]
            state.world.next_commitment=min(active,key=lambda c:c.start).commitment_id if active else None
            elapsed=min(24,max(0,(time-previous_time).total_seconds()/3600))
            n=state.world.needs
            changes={"energy":6 if time.hour<7 else -2,"hunger":5,"social_need":2,"novelty_need":1.5,
                     "creative_urge":1,"comfort_need":1,"shopping_interest":.4,"privacy_need":.5}
            for k,delta in changes.items(): setattr(n,k,max(0,min(100,getattr(n,k)+delta*elapsed)))
            state.novelty_memory=[r for r in state.novelty_memory if time-r.time<=timedelta(days=30)]
            state.revision+=1; self.store.save(state,tick_id,"clock_needs_due")
            due=any(c.status=="scheduled" and time<=c.start<time+timedelta(hours=2) for c in state.calendar) or any(h.status=="open" and h.due_at<=time<h.expires_at for h in state.hooks)
            need_high=any(v>=self.grammar.rules["need_threshold"] for k,v in n.model_dump().items() if k!="energy") or n.energy<=25
            random_gate=seeded(self.seed,time,"gate").random()<self.grammar.rules["random_gate_probability"]
            selected=[]
            if due or need_high or random_gate:
                candidates=self.generator.generate(state,self.seed,self.novelty)
                selected=self.probability.select(candidates,self.seed,time)
            for event in selected:
                self.store.log_event(event)
                current=state
                if self.decision_agent is None: decision=simulator_decision(current,event)
                else:
                    try:
                        decision=self.decision_agent.decide(current,event)
                        if decision is not None: decision=Decision.model_validate(decision)
                    except Exception as error:
                        # One provider/integration failure must not stop other
                        # events, deterministic physics or later scheduler ticks.
                        event.payload["decision_error"]=type(error).__name__
                        decision=None
                    if decision is None:
                        event.status="skipped"; self.store.log_event(event); self.skips+=1; continue
                result=self.transactions.commit(event,decision,current.revision)
                if result.status=="committed":
                    current=self.transactions.last_state; current.novelty_memory.append(self.novelty.record(event))
                    if self.chain: self.chain.after_commit(current,event,decision,result)
                    current.revision+=1; self.store.save(current,result.transaction_id,"consequences_novelty")
                    state=current
            if self.chain:
                current=self.store.load(); self.chain.resolve_due(current)
                current.revision+=1; self.store.save(current,tick_id,"hook_expiry")
            self.store.finish_tick(tick_id)
        return True

    def run(self,hours,progress=None):
        for i in range(hours):
            self.tick(self.clock.at(i))
            if progress and (i+1)%1000==0: progress(i+1)
        return metrics(self.store)


def gini(values):
    values=sorted(values)
    if not values or not sum(values): return 0
    n=len(values)
    return sum((2*i-n-1)*v for i,v in enumerate(values,1))/(n*sum(values))


def metrics(store):
    state=store.load()
    all_events=[Event.model_validate_json(row["body"]) for row in store.records("events")]
    events=[e for e in all_events if e.status=="committed"]
    events.sort(key=lambda e:(e.created_at,e.event_id))
    family=Counter(e.family for e in events); actors=Counter(a for e in events for a in e.actors)
    for actor in state.relationships: actors.setdefault(actor,0)
    locations=Counter(e.slots.get("location") for e in events)
    signatures={(e.family,tuple(e.actors),e.slots.get("action"),e.slots.get("object"),e.slots.get("location"),e.slots.get("motive"),e.slots.get("modifier_emotional")) for e in events}
    total=len(events); last={}; repeat=0; nonroutine=0
    for e in events:
        if not e.routine:
            nonroutine+=1
            if e.family in last and e.created_at-last[e.family]<=timedelta(hours=24): repeat+=1
        last[e.family]=e.created_at
    event_times={e.created_at.isoformat() for e in all_events}
    ticks=store.records("ticks")
    # Inspect every 30-day window at daily stride, rather than hiding a burst
    # inside a whole-run aggregate. Routine meals/rest/sleep are excluded.
    max_share=0; windows=0; nonroutine_events=[e for e in events if not e.routine]
    if ticks:
        origin=min(datetime.fromisoformat(t["time"]) for t in ticks)
        final=max(datetime.fromisoformat(t["time"]) for t in ticks)+timedelta(hours=1)
        end=origin+timedelta(days=30); index=0; window=deque(); counts=Counter()
        while end<=final:
            while index<len(nonroutine_events) and nonroutine_events[index].created_at<end:
                e=nonroutine_events[index]; window.append(e); counts[e.family]+=1; index+=1
            while window and window[0].created_at<end-timedelta(days=30):
                counts[window.popleft().family]-=1
            if window:
                max_share=max(max_share,max(counts.values())/len(window)); windows+=1
            end+=timedelta(days=1)
    violation=0
    try: Validator.invariants(state)
    except ValueError: violation=1
    txs={r["transaction_id"] for r in store.records("transactions") if r["status"]=="committed"}
    evt_ids={e.event_id for e in events}
    fact_violations=sum(entry.event_id not in evt_ids or entry.transaction_id not in txs for entry in state.wallet.ledger)
    fact_violations+=sum(c.source_event not in evt_ids for c in state.calendar if c.provenance.source=="internal_world")
    edges=[ContinuityEdge.model_validate_json(r["body"]) for r in store.records("continuity_archive")]
    fact_violations+=sum(edge.cause not in evt_ids or edge.transaction_id not in txs for edge in edges)
    return dict(hours=len(ticks),event_count=total,unique_families=len(family),family_counts=dict(family),
        family_entropy=-sum((n/total)*math.log2(n/total) for n in family.values()) if total else 0,
        unique_event_signature_ratio=len(signatures)/max(1,total),actor_gini=gini(list(actors.values())),location_gini=gini(list(locations.values())),
        repeat_within_24h_rate=repeat/max(1,nonroutine),chain_depth_mean=sum(e.depth for e in events)/max(1,total),
        max_30day_nonroutine_family_share=max_share,rolling_30day_windows_checked=windows,
        no_event_rate=sum(t["time"] not in event_times for t in ticks)/max(1,len(ticks)),
        wallet_violation_count=int(state.wallet.available_balance<0),calendar_conflict_count=violation,
        unsupported_fact_count=fact_violations,inventory_violation_count=sum(x.status!="owned" for x in state.inventory.values()),
        rejected_transactions=sum(r["status"]!="committed" for r in store.records("transactions")),
        final_balance=state.wallet.balance,revision=state.revision)
