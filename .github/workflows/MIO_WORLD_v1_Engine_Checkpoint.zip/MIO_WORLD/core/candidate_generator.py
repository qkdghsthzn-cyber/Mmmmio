import hashlib
import json
import math
import random
from datetime import timedelta
from .models import Event
from .novelty_engine import event_features


def seeded(seed, time, stream):
    digest=hashlib.sha256(f"{seed}|{time.isoformat()}|{stream}".encode()).digest()
    return random.Random(int.from_bytes(digest[:8],"big"))


def busy(state,start,end):
    return any(c.status=="scheduled" and c.flexibility=="fixed" and c.start<end and start<c.end for c in state.calendar)


class CandidateGenerator:
    def __init__(self,grammar): self.grammar=grammar

    def generate(self,state,seed,novelty):
        now=state.world.time; rng=seeded(seed,now,"grammar"); candidates=[]
        for f in self.grammar.families.values():
            if f.adult and not state.feature_flags.get("adult_life",False): continue
            if f.hours is not None and now.hour not in f.hours: continue
            last=novelty.last_family(f.id)
            if last and (now-last).total_seconds()<f.cooldown_hours*3600: continue
            duration=rng.choice(f.duration_minutes)
            if "fixed_busy" in f.forbids and busy(state,now,now+timedelta(minutes=duration)): continue
            actors=[n for n in state.relationships.values() if n.active and n.role in f.actor_types]
            if f.actor_types and not actors: continue
            if "mutual_consent" in f.requires:
                actors=[n for n in actors if n.age>=18 and n.mutual_affection and n.consent and n.trust>=70]
                if not actors: continue
            if "private_context" in f.requires and state.world.privacy!="private": continue
            actor=rng.choice(actors).npc_id if actors else None
            obj=None; cost=f.cost
            if "owned_item" in f.requires:
                objects=[x for x in state.inventory.values() if x.status=="owned" and (f.object_category is None or x.category==f.object_category)]
                if not objects: continue
                obj=rng.choice(objects).item_id
            if "available_item" in f.requires:
                objects=[x for x in state.catalog.values() if x.status=="available" and x.price is not None
                         and x.price<=state.wallet.available_balance and x.item_id not in state.inventory]
                if not objects or state.notion_stale: continue
                item=rng.choice(objects); obj=item.item_id; cost=item.price
            if "budget" in f.requires and (cost>state.wallet.available_balance or state.notion_stale): continue
            future=[c for c in state.calendar if c.status=="scheduled" and c.start>now]
            if "future_commitment" in f.requires and not future: continue
            if f.effect!="move" and state.world.place not in f.locations: continue
            location=rng.choice(f.locations) if f.effect=="move" else state.world.place
            if "reachable" in f.requires:
                travel=state.travel_minutes.get(f"{state.world.place}->{location}")
                if travel is None or travel>60 or busy(state,now,now+timedelta(minutes=travel+duration)): continue
            hooks=[h for h in state.hooks if h.status=="open" and h.family==f.id and h.due_at<=now<h.expires_at]
            cause=hooks[0].cause_event if hooks else None
            if hooks and hooks[0].object_id:
                bound=state.inventory.get(hooks[0].object_id) if "owned_item" in f.requires else state.catalog.get(hooks[0].object_id)
                if bound is None or (f.object_category and bound.category!=f.object_category): continue
                if "owned_item" in f.requires and bound.status!="owned": continue
                if "available_item" in f.requires and (bound.status!="available" or bound.price is None or bound.price>state.wallet.available_balance): continue
                obj=bound.item_id
                if "available_item" in f.requires: cost=bound.price
            if hooks and hooks[0].actor:
                if hooks[0].actor not in state.relationships or not state.relationships[hooks[0].actor].active: continue
                actor=hooks[0].actor
            slots={"family":f.id,"actor":actor or "mio","target":"mio","motive":rng.choice(self.grammar.slots["motive"]),
                   "trigger":"open_thread" if hooks else rng.choice(f.triggers),"action":rng.choice(f.actions),"object":obj or "none",
                   "channel":rng.choice(f.channels),"location":location,"time_relation":rng.choice(self.grammar.slots["time_relation"]),
                   "mood":state.world.mood,"intensity":rng.choice(self.grammar.slots["intensity"]),"cost_band":f.cost_band,
                   "duration":str(duration),"uncertainty":rng.choice(self.grammar.slots["uncertainty"]),
                   "outcome_shape":rng.choice(f.outcomes),"followup_hooks":",".join(f.hooks) or "none"}
            for layer,values in self.grammar.modifiers.items(): slots["modifier_"+layer]=rng.choice(values)
            digest=hashlib.sha256(json.dumps([now.isoformat(),slots,cause],sort_keys=True).encode()).hexdigest()[:24]
            payload={"intent":f.id.lower(),"effect":f.effect,"cost":cost,"item_id":obj,"duration_minutes":duration,
                     "topic":f.topic,"need":f.need,"need_delta":f.need_delta,"location":location,
                     "commitment_id":future[0].commitment_id if future else None,"hook_id":hooks[0].hook_id if hooks else None}
            event=Event(event_id="evt_"+digest,family=f.id,actors=[actor] if actor else [],trigger={"type":slots["trigger"],"value":"state_bound"},
                        payload=payload,slots=slots,constraints=f.requires+f.forbids,hooks_on_success=f.hooks,
                        cause=cause,created_at=now,routine=f.routine,depth=hooks[0].depth if hooks else 0)
            taste=state.taste.get(f.topic)
            level=getattr(state.world.needs,f.need)
            pressure=(100-level if f.need=="energy" else level)/100
            relation=(state.relationships[actor].closeness/100*.4) if actor else 0
            calendar_pressure=.3 if any(now<=c.start<now+timedelta(hours=2) and c.status=="scheduled" for c in state.calendar) and f.group=="calendar" else 0
            resource_pressure=(cost/max(1,state.wallet.available_balance))*1.8
            event.score=math.log(f.base_weight*10)+pressure*1.4+(taste.affinity/100*.6 if taste else 0)+relation+calendar_pressure+(1.7 if cause else 0)-resource_pressure-novelty.penalty(event_features(event),now,f.routine)+rng.uniform(-.35,.35)
            candidates.append(event)
        candidates.sort(key=lambda e:(-e.score,e.event_id))
        # Family and actor diversity in the retained shortlist.
        retained=[]; per_group={}
        for event in candidates:
            group=self.grammar.families[event.family].group
            if per_group.get(group,0)>=5: continue
            retained.append(event); per_group[group]=per_group.get(group,0)+1
            if len(retained)>=self.grammar.rules["candidate_limit"]-1: break
        retained.append(Event(event_id="evt_none_"+hashlib.sha256(now.isoformat().encode()).hexdigest()[:16],family="NO_EVENT",
                     trigger={"type":"none","value":"valid_empty_hour"},payload={},slots={},constraints=[],hooks_on_success=[],created_at=now,score=self.grammar.rules["no_event_score"]))
        return retained
