import math
from .candidate_generator import seeded


class ProbabilityEngine:
    def __init__(self,rules): self.rules=rules

    def select(self,candidates,seed,time):
        rng=seeded(seed,time,"selection")
        def draw(pool):
            maximum=max(e.score for e in pool)
            return rng.choices(pool,weights=[math.exp(e.score-maximum) for e in pool],k=1)[0]
        first=draw(candidates)
        if first.family=="NO_EVENT": return []
        selected=[first]
        if rng.random()<self.rules["second_event_chance"]:
            rest=[e for e in candidates if e.event_id!=first.event_id and (not e.actors or e.actors!=first.actors)]
            if rest:
                second=draw(rest)
                if second.family!="NO_EVENT": selected.append(second)
        return selected
