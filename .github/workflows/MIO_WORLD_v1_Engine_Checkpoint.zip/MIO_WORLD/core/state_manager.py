import json
import sqlite3
from contextlib import contextmanager
from .models import State, ContinuityEdge, Hook


class StateStore:
    """Local authoritative store ONLY in mock mode; live uses a verified cache."""
    def __init__(self, path=":memory:"):
        self.db = sqlite3.connect(str(path), isolation_level=None, timeout=30)
        self.db.row_factory = sqlite3.Row
        self.db.execute("PRAGMA foreign_keys=ON")
        self.db.execute("PRAGMA journal_mode=WAL")
        self.db.executescript('''
        CREATE TABLE IF NOT EXISTS state(id INTEGER PRIMARY KEY CHECK(id=1), body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS ticks(tick_id TEXT PRIMARY KEY, time TEXT NOT NULL, status TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS events(event_id TEXT PRIMARY KEY, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS decisions(decision_id TEXT PRIMARY KEY, event_id TEXT NOT NULL, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS transactions(transaction_id TEXT PRIMARY KEY, idempotency_key TEXT UNIQUE NOT NULL,
            event_id TEXT NOT NULL, status TEXT NOT NULL, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS mutations(id INTEGER PRIMARY KEY, revision INTEGER NOT NULL, cause TEXT NOT NULL,
            kind TEXT NOT NULL, time TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS outbox(id INTEGER PRIMARY KEY, transaction_id TEXT NOT NULL, connector TEXT NOT NULL,
            idempotency_key TEXT UNIQUE NOT NULL, status TEXT NOT NULL, payload TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS continuity_archive(edge_id TEXT PRIMARY KEY, body TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS hooks_archive(hook_id TEXT PRIMARY KEY, body TEXT NOT NULL);
        ''')

    @contextmanager
    def atomic(self):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            yield
            self.db.execute("COMMIT")
        except BaseException:
            self.db.execute("ROLLBACK")
            raise

    def initialize(self, state: State):
        self.db.execute("INSERT OR IGNORE INTO state VALUES(1,?)", (state.model_dump_json(),))

    def load(self, history=False) -> State:
        row = self.db.execute("SELECT body FROM state WHERE id=1").fetchone()
        if row is None:
            raise RuntimeError("state not initialized")
        state=State.model_validate_json(row[0])
        if history:
            edges={r[0]:ContinuityEdge.model_validate_json(r[1]) for r in self.db.execute("SELECT edge_id,body FROM continuity_archive ORDER BY rowid")}
            edges.update({"|".join([e.cause,e.consequence,e.transaction_id]):e for e in state.continuity})
            state.continuity=list(edges.values())
            hooks={r[0]:Hook.model_validate_json(r[1]) for r in self.db.execute("SELECT hook_id,body FROM hooks_archive ORDER BY rowid")}
            hooks.update({h.hook_id:h for h in state.hooks}); state.hooks=list(hooks.values())
        return state

    def save(self, state: State, cause: str, kind: str):
        if not self.db.in_transaction:
            with self.atomic(): return self.save(state,cause,kind)
        if not cause:
            raise ValueError("mutation provenance required")
        # Full causal history is immutable in SQLite; the hot snapshot keeps a
        # 256-edge cache. This bounds hourly work without deleting any history.
        rows=[("|".join([e.cause,e.consequence,e.transaction_id]),e.model_dump_json()) for e in state.continuity]
        self.db.executemany("INSERT OR IGNORE INTO continuity_archive VALUES(?,?)",rows)
        state.continuity=state.continuity[-256:]
        closed=[h for h in state.hooks if h.status!="open"]
        self.db.executemany("INSERT OR REPLACE INTO hooks_archive VALUES(?,?)",[(h.hook_id,h.model_dump_json()) for h in closed])
        state.hooks=[h for h in state.hooks if h.status=="open"]+closed[-64:]
        body=state.model_dump_json()
        State.model_validate_json(body)
        self.db.execute("UPDATE state SET body=? WHERE id=1", (body,))
        self.db.execute("INSERT INTO mutations(revision,cause,kind,time) VALUES(?,?,?,?)",
                        (state.revision, cause, kind, state.world.time.isoformat()))

    def claim_tick(self, tick_id, time):
        return self.db.execute("INSERT OR IGNORE INTO ticks VALUES(?,?,'running')", (tick_id,time.isoformat())).rowcount == 1

    def finish_tick(self, tick_id):
        self.db.execute("UPDATE ticks SET status='completed' WHERE tick_id=?", (tick_id,))

    def log_event(self, event):
        # Replay must never turn a terminal committed fact back into a proposal.
        self.db.execute("INSERT INTO events VALUES(?,?) ON CONFLICT(event_id) DO UPDATE SET body=excluded.body WHERE json_extract(events.body,'$.status')='pending'", (event.event_id,event.model_dump_json()))

    def log_decision(self, decision):
        self.db.execute("INSERT OR IGNORE INTO decisions VALUES(?,?,?)", (decision.decision_id,decision.event_id,decision.model_dump_json()))

    def records(self, table):
        if table not in {"events", "decisions", "transactions", "ticks", "mutations", "outbox", "continuity_archive", "hooks_archive"}:
            raise ValueError("unknown table")
        return [dict(r) for r in self.db.execute(f"SELECT * FROM {table}")]

    def close(self):
        self.db.close()
