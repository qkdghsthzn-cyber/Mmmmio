from __future__ import annotations

from datetime import datetime
from typing import Annotated, Literal
from pydantic import BaseModel, ConfigDict, Field, model_validator, field_validator

Level = Annotated[float, Field(ge=0, le=100)]
Money = Annotated[int, Field(ge=0, strict=True)]


class Model(BaseModel):
    model_config = ConfigDict(extra="forbid", validate_assignment=True)


def aware(value: datetime) -> datetime:
    if value.tzinfo is None or value.utcoffset() is None:
        raise ValueError("timezone-aware datetime required")
    return value


class Provenance(Model):
    source: Literal["mock", "canonical", "internal_world", "external_verified", "unverified"]
    ref: str = Field(min_length=1)
    verified_at: datetime | None = None


class Needs(Model):
    energy: Level = 75
    hunger: Level = 20
    social_need: Level = 25
    novelty_need: Level = 25
    creative_urge: Level = 30
    comfort_need: Level = 20
    shopping_interest: Level = 20
    privacy_need: Level = 20


class Journey(Model):
    destination: str
    departure: datetime
    arrival: datetime
    source_event: str
    transaction_id: str

    _aware_departure = field_validator("departure")(aware)
    _aware_arrival = field_validator("arrival")(aware)


class WorldState(Model):
    time: datetime
    timezone: str = "Asia/Tokyo"
    place: str = "home"
    activity: str = "idle"
    mood: str = "calm"
    privacy: Literal["public", "friends", "private"] = "private"
    next_commitment: str | None = None
    journey: Journey | None = None
    needs: Needs = Field(default_factory=Needs)

    _aware_time = field_validator("time")(aware)


class LedgerEntry(Model):
    ledger_id: str
    amount: int
    balance_after: Money
    event_id: str
    transaction_id: str
    created_at: datetime


class Wallet(Model):
    currency: Literal["JPY"] = "JPY"
    balance: Money
    reserved_amount: Money = 0
    ledger: list[LedgerEntry] = Field(default_factory=list)

    @model_validator(mode="after")
    def valid_reservation(self):
        if self.reserved_amount > self.balance:
            raise ValueError("reserved amount exceeds balance")
        return self

    @property
    def available_balance(self):
        return self.balance - self.reserved_amount


class Item(Model):
    item_id: str
    name: str
    status: Literal["owned", "available", "borrowed", "lost", "returned"]
    category: str
    brand: str | None = None
    price: Money | None = None
    acquired_at: datetime | None = None
    location: str | None = "home"
    condition: str | None = "good"
    source_event: str | None = None
    provenance: Provenance


class NPC(Model):
    npc_id: str
    name: str
    age: int = Field(ge=18)
    role: Literal["friend", "partner", "colleague", "family"] = "friend"
    active: bool = True
    traits: list[str] = Field(default_factory=list)
    closeness: Level = 45
    trust: Level = 55
    tension: Level = 0
    shared_interests: list[str] = Field(default_factory=list)
    last_contact: datetime | None = None
    open_threads: list[str] = Field(default_factory=list)
    knowledge_scope: list[str] = Field(default_factory=list)
    mutual_affection: bool = False
    consent: bool = False
    provenance: Provenance


class Taste(Model):
    topic: str
    affinity: Level
    confidence: float = Field(ge=0, le=1)
    evidence_count: int = Field(ge=0)
    last_updated: datetime
    source_event: str | None = None


class Commitment(Model):
    commitment_id: str
    start: datetime
    end: datetime
    title: str
    flexibility: Literal["fixed", "flexible"] = "fixed"
    participants: list[str] = Field(default_factory=list)
    source_event: str
    location: str = "home"
    status: Literal["scheduled", "completed", "cancelled"] = "scheduled"
    provenance: Provenance

    _aware_start = field_validator("start")(aware)
    _aware_end = field_validator("end")(aware)

    @model_validator(mode="after")
    def interval(self):
        if self.end <= self.start:
            raise ValueError("calendar end must be after start")
        return self


class Hook(Model):
    hook_id: str
    family: str
    due_at: datetime
    expires_at: datetime
    cause_event: str
    actor: str | None = None
    object_id: str | None = None
    commitment_id: str | None = None
    depth: int = Field(ge=1, le=6)
    status: Literal["open", "resolved", "expired"] = "open"

    _aware_due = field_validator("due_at")(aware)
    _aware_expires = field_validator("expires_at")(aware)


class ContinuityEdge(Model):
    cause: str
    consequence: str
    transaction_id: str
    depth: int = Field(ge=0, le=6)


class NoveltyRecord(Model):
    time: datetime
    features: dict[str, str]
    routine: bool


class SocialCandidate(Model):
    candidate_id: str
    source_event: str
    transaction_id: str
    status: Literal["draft", "published", "failed"] = "draft"
    channel: Literal["dialogue", "story", "instagram"]
    text: str
    privacy: Literal["public", "friends", "private"]


class State(Model):
    schema_version: Literal[1] = 1
    mode: Literal["mock", "live"] = "mock"
    revision: int = Field(ge=0, default=0)
    world: WorldState
    wallet: Wallet
    inventory: dict[str, Item] = Field(default_factory=dict)
    catalog: dict[str, Item] = Field(default_factory=dict)
    wishlist: dict[str, Literal["wanted", "purchased", "deferred"]] = Field(default_factory=dict)
    relationships: dict[str, NPC] = Field(default_factory=dict)
    taste: dict[str, Taste] = Field(default_factory=dict)
    calendar: list[Commitment] = Field(default_factory=list)
    continuity: list[ContinuityEdge] = Field(default_factory=list)
    hooks: list[Hook] = Field(default_factory=list)
    novelty_memory: list[NoveltyRecord] = Field(default_factory=list)
    social: list[SocialCandidate] = Field(default_factory=list)
    notion_stale: bool = False
    calendar_stale: bool = False
    feature_flags: dict[str, bool] = Field(default_factory=lambda: {"adult_life": False})
    travel_minutes: dict[str, int] = Field(default_factory=dict)
    provenance: Provenance

    @model_validator(mode="after")
    def entity_keys(self):
        for field, key in [("inventory", "item_id"), ("catalog", "item_id"), ("relationships", "npc_id")]:
            for identifier, entity in getattr(self, field).items():
                if identifier != getattr(entity, key):
                    raise ValueError(f"{field} key and entity id differ")
        return self


class Event(Model):
    event_id: str
    family: str
    source: Literal["internal_world", "external_verified", "unverified"] = "internal_world"
    actors: list[str] = Field(default_factory=list)
    target: str = "mio"
    trigger: dict[str, str]
    payload: dict[str, str | int | float | bool | None]
    slots: dict[str, str]
    constraints: list[str]
    hooks_on_success: list[str]
    confidence: float = Field(ge=0, le=1, default=0.8)
    status: Literal["pending", "committed", "rejected", "skipped"] = "pending"
    cause: str | None = None
    created_at: datetime
    resolved_at: datetime | None = None
    score: float = 0
    routine: bool = False
    depth: int = Field(ge=0, le=6, default=0)


class Action(Model):
    type: Literal["observe", "purchase", "spend", "use_item", "calendar_create", "calendar_cancel",
                  "relationship_update", "taste_update", "need_update", "move", "hook_create"]
    item_id: str | None = None
    amount: int | None = None
    npc_id: str | None = None
    delta: float | None = None
    topic: str | None = None
    need: str | None = None
    location: str | None = None
    start: datetime | None = None
    end: datetime | None = None
    title: str | None = None
    commitment_id: str | None = None
    family: str | None = None
    delay_hours: int | None = None

    @field_validator("delta")
    @classmethod
    def finite_delta(cls,value):
        import math
        if value is not None and not math.isfinite(value):
            raise ValueError("delta must be finite")
        return value

    @field_validator("start", "end")
    @classmethod
    def aware_optional(cls, value):
        return aware(value) if value is not None else value


class Decision(Model):
    decision_id: str
    event_id: str
    choice: Literal["accept", "decline", "defer", "ignore"]
    reason_tags: list[str]
    actions: list[Action] = Field(max_length=8)
    share_intent: Literal["none", "dialogue", "story", "instagram"] = "none"


class TransactionRecord(Model):
    transaction_id: str
    idempotency_key: str
    event_id: str
    decision_id: str
    expected_revision: int
    status: Literal["committed", "rejected", "rolled_back"]
    error: str | None = None
    created_at: datetime
