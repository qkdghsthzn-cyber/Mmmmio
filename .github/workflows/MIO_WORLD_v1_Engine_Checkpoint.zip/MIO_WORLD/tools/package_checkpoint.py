import hashlib
import json
import zipfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT.parent/"MIO_WORLD_v1_Engine_Checkpoint.zip"

def main():
    acceptance=json.loads((ROOT/"reports/P2_10000h.json").read_text())
    assert acceptance["status"]=="PASS" and acceptance["hours"]>=10000
    reports=list((ROOT/"reports").glob("*_tests.json"))
    assert all(json.loads(p.read_text())["status"]=="PASS" for p in reports)
    sources=[]
    for p in sorted(ROOT.rglob("*")):
        if not p.is_file() or "__pycache__" in p.parts or p.suffix==".pyc": continue
        if p.is_relative_to(ROOT/"android-probe") and any(part in {"build", ".gradle"} for part in p.relative_to(ROOT/"android-probe").parts): continue
        if p.name in {".env","package_manifest.json"} or p.name.startswith("usage-budget.sqlite3"): continue
        if p.name.endswith((".worker", ".scheduler")): continue
        if p.name.endswith(("-wal","-shm")): continue
        if p.suffix==".sqlite3" and p.name not in {"demo-world.sqlite3","chain-demo.sqlite3"}: continue
        sources.append(p)
    manifest={"files":[{"path":str(p.relative_to(ROOT)),"size_bytes":p.stat().st_size,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],
              "note":"Mock snapshots are examples. P5 canonical live writes and Android are not complete."}
    with zipfile.ZipFile(OUT,"w",zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sources: z.write(p,"MIO_WORLD/"+str(p.relative_to(ROOT)))
        z.writestr("MIO_WORLD/package_manifest.json",json.dumps(manifest,ensure_ascii=False,indent=2)+"\n")
    with zipfile.ZipFile(OUT) as z:
        assert z.testzip() is None
        assert "MIO_WORLD/mio.py" in z.namelist()
        assert len([n for n in z.namelist() if n.startswith("MIO_WORLD/data/event_families/")])==160
        assert "MIO_WORLD/.env" not in z.namelist()
    print(json.dumps({"path":str(OUT),"size_bytes":OUT.stat().st_size,"file_count":len(sources)+1,"sha256":hashlib.sha256(OUT.read_bytes()).hexdigest()},indent=2))

if __name__=="__main__": main()
