"""Run the qualification entrypoint without importing engine dependencies first."""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from mobile_host.probe import entrypoint


def main():
    parser = argparse.ArgumentParser(description="MIO device qualification, fixture only")
    parser.add_argument("action", choices=["diagnose", "mock", "native", "database_loss", "host_resume", "oauth"])
    parser.add_argument("--workspace", required=True, type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    result = entrypoint(str(args.workspace), args.action)
    report = json.loads(result)
    if args.report:
        args.report.parent.mkdir(parents=True, exist_ok=True)
        args.report.write_text(result + "\n")
    print(result)
    return 0 if report['status'] in {"PASS", "HOST_CAPABILITIES_PASS_ANDROID_NOT_RUN", "ANDROID_CAPABILITIES_PASS"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
