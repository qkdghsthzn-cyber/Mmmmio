"""Stage unchanged engine sources and all Family data for the P5 Android probe."""
import hashlib
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DEFAULT = ROOT / "android-probe/probe/build/generated/mioPython"


def sources(root=ROOT):
    files = []
    for folder in ("core", "agents", "connectors", "runtime", "mobile_host"):
        files += sorted((root / folder).glob("*.py"))
    files += sorted(p for p in (root / "data").rglob("*") if p.is_file() and p.suffix in {".json", ".yaml", ".yml"})
    files += [root / "tests/__init__.py", root / "tests/native_http_server.py", root / "tests/oauth_http_server.py",
              root / "tools/p5_hourly_demo.py", root / "tools/p5_disaster_demo.py", root / "tools/p5_host_resume_demo.py", root / "tools/p5_oauth_demo.py"]
    # MioDecisionAgent.context reads this runtime identity file. Keep its
    # original bytes; reference attachments are not needed by the fixture app.
    files += [root / "reference/01_Core_Identity.md"]
    return files


def prepare(destination=DEFAULT):
    destination = Path(destination).resolve()
    # Own only generated children; callers may stage in a private empty directory.
    if destination == ROOT or ROOT.is_relative_to(destination):
        raise ValueError("source tree cannot be a generated destination")
    if destination.exists() and any(destination.iterdir()):
        if any(p.is_symlink() for p in destination.rglob('*')):
            raise ValueError("generated directory contains symlinks")
        marker = destination / "mio_source_manifest.json"
        if not marker.is_file():
            raise ValueError("refusing to replace a directory without our staging manifest")
        owned = json.loads(marker.read_text())
        if owned.get("format") != "mio-android-source-v1":
            raise ValueError("unknown staging directory owner")
        # Do not recursively delete arbitrary user files, or obey paths in a manifest.
        expected = {str(p.relative_to(ROOT)) for p in sources()} | {"tools/__init__.py", "mio_source_manifest.json"}
        found = {str(p.relative_to(destination)) for p in destination.rglob("*") if p.is_file()}
        if found - expected:
            raise ValueError("generated directory contains unowned files")
    destination.mkdir(parents=True, exist_ok=True)
    manifest = {"format": "mio-android-source-v1", "scope": "fixture qualification only", "files": []}
    for source in sources():
        relative = source.relative_to(ROOT)
        target = destination / relative
        if target.is_symlink() or any(p.is_symlink() for p in target.parents if p.is_relative_to(destination)):
            raise ValueError("generated destination must not contain symlinks")
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(source, target)
        manifest["files"].append({"path": str(relative), "sha256": hashlib.sha256(target.read_bytes()).hexdigest()})
    (destination / "tools/__init__.py").write_text('"""Fixture demonstrations bundled for device qualification."""\n')
    assert len(list((destination / "data/event_families").glob("*.json"))) == 160
    (destination / "mio_source_manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
    return manifest


if __name__ == "__main__":
    print(json.dumps({"staged_files": len(prepare()["files"]), "families": 160}, indent=2))
