"""OAuth expiry/revocation and host resume gate, isolated loopback HTTP only."""
import json
import tempfile
from datetime import timedelta
from pathlib import Path
from core.models import Decision,Action
from core.event_grammar import Grammar
from core.candidate_generator import CandidateGenerator
from core.novelty_engine import NoveltyEngine
from core.validator import Validator
from connectors.mock_native import fixture_purchase
from connectors.http_json import HTTPJSON
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.write_coordinator import WriteCoordinator
from connectors.canonical_runtime import CanonicalValidator,CanonicalCacheBridge
from connectors.runtime_bootstrap import InitializationRequest,RuntimeResources,NativeBootstrapper
from runtime.host_resume import resume_after_delay,revalidate_host_resume,pending
from connectors.database_recovery import RecoveryUnavailable
from connectors.google_oauth import OAuthGrant, MemoryTokenStore, GoogleTokenEndpoint, GoogleAccessTokenProvider
from connectors.http_json import HTTPFailure
from tests.oauth_http_server import OAuthHTTPFixture
from runtime.hourly import NativeHourlyRuntime
from tests.native_http_server import NativeHTTPFixture


class NoFixtureDecision:
    def __init__(self):self.calls=0
    def decide(self,state,event):
        self.calls+=1
        raise AssertionError('quiet qualification must not call the decision agent')


def run_demo():
    native,_,now=fixture_purchase(); server=NativeHTTPFixture(native)
    for role in ['relationships','taste','memory','world']:
        identifier='fixture.'+role
        server.objects[identifier]={'object':'page','id':identifier,'last_edited_time':'v1','archived':False}
        server.children[identifier]=[]
    oauth=OAuthHTTPFixture(server)
    try:
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'primary').mkdir(); path=root/'primary/runtime.sqlite3'
            http=HTTPJSON(server.url,'fixture-only-token',fixture=True)
            notion=NotionConnector(http=http); wall=[now]
            store=MemoryTokenStore(OAuthGrant('fixture.oauth.client','fixture.oauth.refresh'))
            provider=GoogleAccessTokenProvider(store,GoogleTokenEndpoint(oauth.url+'/token',fixture=True),lambda:wall[0])
            calendar=CalendarConnector('fixture.calendar',http=HTTPJSON(oauth.url,fixture=True,token_provider=provider))
            def connect():
                coordinator=WriteCoordinator(path,{'notion':NativeHTTPAdapter(notion),'calendar':NativeHTTPAdapter(calendar)})
                bridge=CanonicalCacheBridge(coordinator,CanonicalValidator(Validator(Grammar()),allow_internal=True))
                return coordinator,bridge
            coordinator,bridge=connect()
            try:
                world={'time':now.isoformat(),'timezone':'Asia/Tokyo','place':'home','activity':'idle','mood':'calm',
                    'privacy':'private','next_commitment':None,'journey':None,'needs':{'energy':75,'hunger':20,'social_need':25,
                    'novelty_need':25,'creative_urge':30,'comfort_need':20,'shopping_interest':20,'privacy_need':20}}
                request=InitializationRequest(initialization_ref='explicit OAuth fixture world, not actual Mio',internal_values_ref='declared fixture needs',
                    world=world,travel_minutes={'home->home':0},feature_flags={'adult_life':False},relationships={},npc_age_refs={},npc_metric_refs={},
                    taste={},taste_metric_refs={},catalog={})
                resources=RuntimeResources(wallet_page='fixture.wallet',inventory_source='fixture.inventory',continuity_page='fixture.continuity',
                    relationships_page='fixture.relationships',taste_page='fixture.taste',memory_page='fixture.memory',
                    world_runtime_page='fixture.world',calendar_id='fixture.calendar')
                NativeBootstrapper(notion,calendar,lambda:now).initialize(bridge,request,resources)
                agent=NoFixtureDecision(); runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                runtime._selected=lambda state:[]
                assert oauth.refresh_count==1
                initial=runtime.tick(now); assert initial['status']=='COMPLETED'
                wall[0]=now+timedelta(hours=2,minutes=20)
                caught=resume_after_delay(runtime,wall[0]); assert caught['processed_hours']==2
                oauth.refresh_errors.append((400,{'error':'invalid_grant','error_description':'PRIVATE_ERROR_SENTINEL'}))
                waiting=revalidate_host_resume(runtime,wall[0]); assert waiting['status']=='WAITING_FRESH_NATIVE_READ'
                assert pending(bridge.db) and not bridge.confirmations_allowed()
                second=revalidate_host_resume(runtime,wall[0]); assert second['status']=='WAITING_FRESH_NATIVE_READ'
                assert oauth.refresh_count==2
                try: runtime.tick(now+timedelta(hours=3))
                except RecoveryUnavailable: new_work_blocked=True
                else: raise AssertionError('revoked Calendar credentials escaped the resume gate')
                # Synthetic explicit new consent. No login/account interaction occurs.
                store.save(OAuthGrant('fixture.oauth.client','fixture.oauth.new.consent'))
                verified=revalidate_host_resume(runtime,wall[0]); assert verified['status']=='VERIFIED'
                assert oauth.refresh_count==3
                before_refresh=oauth.refresh_count
                oauth.api_faults[('POST',calendar.path)]=401
                try: calendar.http.request('POST',calendar.path,{'id':'fixture.must.not.exist'})
                except HTTPFailure as error: assert error.status==401
                else: raise AssertionError('fixture rejection missing')
                writes=[r for r in oauth.api_requests if r['method']=='POST']
                assert len(writes)==1 and oauth.write_count==0 and oauth.refresh_count==before_refresh
                assert 'fixture.must.not.exist' not in server.objects
                calendar.metadata(); assert oauth.refresh_count==4 and oauth.write_count==0
                resumed=runtime.tick(now+timedelta(hours=3)); assert resumed['status']=='COMPLETED'
                Validator.invariants(bridge.state()); assert agent.calls==0
                return {'status':'PASS','scope':'OAuth and native loopback fixture only; no real user consent or service authorization',
                    'initial_hour':initial['status'],'clock_only_catchup_hours':caught['processed_hours'],
                    'expired_access_preflight_refresh':'PASS','invalid_grant_revalidation':waiting['status'],
                    'repeated_invalid_grant_exchange_suppressed':True,'new_work_blocked':new_work_blocked,
                    'fresh_revalidation_after_synthetic_new_consent':verified['status'],
                    'mutation_401_attempts':len(writes),'mutation_401_successful_writes':oauth.write_count,
                    'mutation_401_response_triggered_refreshes':0,'token_endpoint_exchanges':oauth.refresh_count,
                    'resumed_hour':resumed['status'],'decision_calls':agent.calls,'fixture_balance_jpy':bridge.state().wallet.balance,
                    'credential_storage':store.diagnostic(),'actual_api_calls':0,'actual_canonical_writes':0,
                    'android_execution':'NOT_RUN','production_enabled':False,'rule_invariants':'PASS'}
            finally: coordinator.close()
    finally: oauth.close(); server.close()
