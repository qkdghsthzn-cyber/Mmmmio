"""Run native-plan/outbox recovery scenarios without keys or network calls."""
import json
import tempfile
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from connectors.mock_native import fixture_purchase, seed_plan
from connectors.native_plans import purchase_plan, request_plan
from connectors.fixture_adapter import NativeFixtureAdapter
from connectors.write_coordinator import WriteCoordinator


def run_demo():
    scenarios = []; plans = []
    settings = [
        ("all_success", None, None, None, "COMMITTED"),
        ("lost_success_response", "inventory.create", "after_apply", "lost", "COMMITTED"),
        ("partial_failure", "inventory.create", "before_apply", "refuse", "ROLLED_BACK"),
        ("ambiguous_absent_create", "inventory.create", "before_apply", "lost", "RECONCILE_REQUIRED"),
        ("compensation_response_lost", "inventory.create", "before_apply", "refuse", "ROLLED_BACK"),
    ]
    with tempfile.TemporaryDirectory(prefix="mio-p5-fixture-") as directory:
        for name, operation, stage, fault, expected in settings:
            root = Path(directory)/name; root.mkdir()
            evidence, proposal, now = fixture_purchase()
            plan = purchase_plan(evidence, proposal, "fixture.event."+name, "fixture.decision."+name, now)
            adapter = NativeFixtureAdapter(root/"provider.sqlite3"); seed_plan(adapter, plan)
            if operation: adapter.fault(operation, stage, fault)
            if name == "compensation_response_lost": adapter.fault("money.log", "after_undo", "lost")
            coordinator = WriteCoordinator(root/"outbox.sqlite3", {"notion":adapter})
            tx = coordinator.prepare(plan); initial = coordinator.run(tx)
            coordinator.close(); adapter.close()
            # Every scenario reopens independent provider/outbox databases.
            adapter = NativeFixtureAdapter(root/"provider.sqlite3")
            coordinator = WriteCoordinator(root/"outbox.sqlite3", {"notion":adapter})
            final = coordinator.reconcile(tx)
            confirmed = coordinator.committed(tx) is not None
            result = {"scenario":name, "initial_status":initial, "status_after_restart_recovery":final,
                      "fixture_committed":confirmed, "confirmations_allowed":coordinator.confirmations_allowed(),
                      "inventory_create_requests":adapter.calls("inventory.create"), "expected_status":expected}
            assert final == expected, result
            assert confirmed == (expected == "COMMITTED"), result
            assert adapter.calls("inventory.create") == 1, result
            assert coordinator.confirmations_allowed() == (expected != "RECONCILE_REQUIRED"), result
            scenarios.append(result)
            if not plans: plans = [request_plan(op) for op in plan.operations]
            coordinator.close(); adapter.close()
    return {"status":"PASS", "scope":"isolated_fixture_only", "live_api_calls":0,
            "canonical_writes":0, "scenarios":scenarios, "native_purchase_requests":plans,
            "note":"Notion compare-and-swap is simulated. Real native write adapter, canonical validator/cache integration and P3/P5 live gates are not complete."}


if __name__ == "__main__":
    report = run_demo(); path = Path("reports/P5_offline_demo.json")
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k != "native_purchase_requests"}, ensure_ascii=False, indent=2))
