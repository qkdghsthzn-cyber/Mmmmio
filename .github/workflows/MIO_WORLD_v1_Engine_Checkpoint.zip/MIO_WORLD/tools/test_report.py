import json
import sys
import time
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))


class RecordedResult(unittest.TextTestResult):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs); self.cases=[]
    def addSuccess(self,test):
        super().addSuccess(test); self.cases.append({"test":test.id(),"status":"PASS"})
    def addFailure(self,test,error):
        super().addFailure(test,error); self.cases.append({"test":test.id(),"status":"FAIL","detail":str(error[1])})
    def addError(self,test,error):
        super().addError(test,error); self.cases.append({"test":test.id(),"status":"ERROR","detail":str(error[1])})


def run_phase(phase):
    start=time.monotonic()
    suite=unittest.defaultTestLoader.loadTestsFromName("tests.test_"+phase.lower())
    result=unittest.TextTestRunner(verbosity=2,resultclass=RecordedResult).run(suite)
    report={"phase":phase,"status":"PASS" if result.wasSuccessful() else "FAIL","test_count":result.testsRun,
            "elapsed_seconds":round(time.monotonic()-start,3),"cases":result.cases}
    if phase in {"P3","P4","P5_contract","P5_recovery","P5_http","P5_runtime","P5_hourly","P5_effects","P5_clock","P5_restore","P5_month","P5_disaster","P5_mobile","P5_host_resume","P5_oauth"}: report["scope"]="local_contract_and_mock_verification"
    if phase == 'P5_android_dependencies': report['scope'] = 'host-only binary receipt and source-integrity gates; synthetic ELF bytes are not compiled wheels or Android execution'
    Path("reports").mkdir(exist_ok=True)
    Path(f"reports/{phase}_tests.json").write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
    return result.wasSuccessful()

if __name__=="__main__":
    for phase in sys.argv[1:] or ["P0","P1","P2"]:
        if not run_phase(phase): sys.exit(1)
