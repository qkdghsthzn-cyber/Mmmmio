"""Export code-only fixture build sources; excludes user documents/native evidence."""
import argparse
import hashlib
import json
import os
import tempfile
import zipfile
from pathlib import Path
from tools.prepare_mobile_sources import ROOT, sources

MARKER = b'mio-code-only-build-v1'


def build_bundle(destination=None):
    destination = Path(destination or ROOT/'deployment/MIO_P5_Build_Sources.zip')
    if destination.is_symlink(): raise ValueError('build archive destination is a symlink')
    if destination.exists():
        with zipfile.ZipFile(destination) as old:
            if old.comment != MARKER: raise ValueError('existing archive is not owned by this exporter')
    files = set(sources())
    files.update((ROOT/'tests').glob('*.py'))
    files.update(ROOT/n for n in ['mio.py','requirements.txt','tools/build_android_probe.py','tools/build_android_wheels.py',
        'tools/prepare_mobile_sources.py','tools/package_android_sources.py','tools/test_report.py',
        '.github/workflows/mio-p5-probe.yml'])
    files.update(p for p in (ROOT/'android-probe').rglob('*') if p.is_file()
        and not any(n in {'build','.gradle','__pycache__'} for n in p.relative_to(ROOT/'android-probe').parts))
    content = {}
    for source in sorted(files):
        if source.is_symlink() or not source.is_file(): raise ValueError('invalid source for build export')
        content[str(source.relative_to(ROOT))] = source.read_bytes()
    assert len([n for n in content if n.startswith('data/event_families/')]) == 160
    assert not any(n.startswith(('reports/','project_sources/')) or n.endswith(('.sqlite3','.env')) or n=='connectors/resources.json' for n in content)
    assert {n for n in content if n.startswith('reference/')} == {'reference/01_Core_Identity.md'}
    content['tools/__init__.py'] = b'"""Source export tools."""\n'
    content['README.md'] = b'''# MIO P5 code-only qualification build

This repository export includes the unchanged engine, 160 Family files,
fixture tests and the manual GitHub Actions workflow. The unchanged runtime
Core Identity required by MioDecisionAgent is included. Original uploaded
documents/photos, native read evidence, resources.json, credentials and DB
are not included.

Use a private repository. Run Actions -> MIO P5 device probe -> Run workflow.
The job tests Python fixtures, installs the required Android SDK packages,
builds the debug APK and retains APK/diagnostics for seven days. No runtime API
keys are required. Missing binary wheels or failed compilation must fail the
job. This archive is build source, not an APK or successful build report.

APK success still requires installation and qualification on the actual phone.
Credential entry/login, encrypted storage and an Android scheduler remain
unimplemented. P5 live writes stay disabled, and P6-P8 have not started.
'''
    manifest = {'format':MARKER.decode(),'scope':'code-only fixture build source; not an APK',
        'files':[{'path':n,'sha256':hashlib.sha256(raw).hexdigest()} for n,raw in sorted(content.items())]}
    content['build_source_manifest.json'] = (json.dumps(manifest,indent=2)+'\n').encode()
    destination.parent.mkdir(parents=True, exist_ok=True)
    fd, temporary = tempfile.mkstemp(prefix='mio-build-',suffix='.zip',dir=destination.parent); os.close(fd)
    try:
        with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=9) as bundle:
            bundle.comment = MARKER
            for name, raw in sorted(content.items()): bundle.writestr(name,raw)
        with zipfile.ZipFile(temporary) as bundle:
            if bundle.testzip() is not None: raise ValueError('build export ZIP failed integrity check')
        os.replace(temporary,destination)
    finally: Path(temporary).unlink(missing_ok=True)
    return {'path':str(destination),'files':len(content),'families':160,'size_bytes':destination.stat().st_size,
        'sha256':hashlib.sha256(destination.read_bytes()).hexdigest(),'user_documents_exported':False,
        'native_evidence_exported':False,'credentials_exported':False,'runtime_core_identity_included':True,'apk_built':False}


if __name__ == '__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path)
    print(json.dumps(build_bundle(parser.parse_args().output),indent=2))
