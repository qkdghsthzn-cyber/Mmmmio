"""Build the P5 fixture probe when a real Android toolchain is available."""
import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from tools.prepare_mobile_sources import prepare
from tools.build_android_wheels import build_wheels


def inspect_tools():
    checks = {}
    for name in ("java", "javac", "gradle"):
        executable = shutil.which(name)
        version = ""
        if executable:
            args = [executable, "--version"] if name == "gradle" else [executable, "-version"]
            try:
                run = subprocess.run(args, capture_output=True, text=True, timeout=30)
                output = run.stdout + run.stderr
                match = re.search(r"Gradle (\d+\.\d+)", output) if name == "gradle" else re.search(r'(?:version\s+"?|javac\s+)(\d+)', output)
                version = match[1] if match else ""
            except (OSError, subprocess.TimeoutExpired):
                pass
        suitable = bool(version)
        if suitable:
            suitable = tuple(map(int, version.split('.'))) == (8, 13) if name == "gradle" else int(version) >= 17
        checks[name] = {"configured": bool(executable), "version": version or None, "suitable": suitable}
    python = shutil.which(os.environ.get("MIO_BUILD_PYTHON", "python3.13"))
    version = None
    if python:
        try:
            run = subprocess.run([python, "-c", "import sys; print('.'.join(map(str,sys.version_info[:2])))"],
                                 capture_output=True, text=True, timeout=10)
            version = run.stdout.strip()
        except (OSError, subprocess.TimeoutExpired):
            pass
    checks["python_3_13"] = {"configured": bool(python), "suitable": version == "3.13", "version": version}
    sdk = Path(os.environ.get("ANDROID_SDK_ROOT") or os.environ.get("ANDROID_HOME") or "/nonexistent-sdk")
    checks["android_sdk"] = {"configured": sdk.is_dir(), "suitable":
                            (sdk / "platforms/android-36/android.jar").is_file() and
                            (sdk / "build-tools/35.0.0").is_dir()}
    return checks, python


def build(report_path):
    sources = prepare()
    checks, python = inspect_tools()
    report = {"scope": "P5 fixture Android qualification APK only", "toolchain": checks,
              "staged_source_count": len(sources["files"]), "families": 160,
              "status": "BLOCKED", "apk_built": False, "android_execution": "NOT_RUN",
              "production_enabled": False, "canonical_writes": 0,
              "dependency_wheels_verified": False}
    if not all(value["suitable"] for value in checks.values()):
        report["reason"] = "Required JDK/Gradle/Python 3.13/Android SDK toolchain is incomplete"
    else:
        print('Building exact upstream Pydantic core Android wheels; see P5_android_wheels.log', flush=True)
        wheels = build_wheels(python)
        report['native_wheel_build_status'] = wheels['status']
        if wheels['status'] != 'WHEELS_BUILT_STATIC_CHECKS_PASS_DEVICE_NOT_RUN':
            report.update(status='BUILD_FAILED', reason=wheels.get('reason', 'Android native wheel build failed'))
            report_path.parent.mkdir(parents=True, exist_ok=True)
            report_path.write_text(json.dumps(report, indent=2) + '\n')
            return report
        report['native_wheel_receipts'] = wheels['wheels']
        log = ROOT / "reports/P5_android_build.log"
        log.parent.mkdir(parents=True, exist_ok=True)
        with log.open('w') as output:
            result = subprocess.run([shutil.which("gradle"), "--no-daemon", "--stacktrace",
                "-PmioBuildPython=" + python, "-PmioWheelDir=" + wheels['wheel_dir'], ":probe:assembleDebug"], cwd=ROOT / "android-probe",
                stdout=output, stderr=subprocess.STDOUT)
        apk = ROOT / "android-probe/probe/build/outputs/apk/debug/probe-debug.apk"
        report["gradle_exit_code"] = result.returncode
        if result.returncode == 0 and apk.is_file():
            with zipfile.ZipFile(apk) as package:
                names = package.namelist()
                if package.testzip() is not None or not {'AndroidManifest.xml', 'classes.dex'} <= set(names):
                    raise RuntimeError("invalid APK output")
                if not any(n.startswith('lib/arm64-v8a/') for n in names):
                    raise RuntimeError("APK has no arm64 runtime")
            report.update(status="APK_BUILT_DEVICE_NOT_RUN", apk_built=True, dependency_wheels_verified=True,
                          apk_sha256=hashlib.sha256(apk.read_bytes()).hexdigest())
            shutil.copy2(apk, ROOT.parent / "MIO_P5_Device_Probe.apk")
        else:
            report.update(status="BUILD_FAILED", reason="Android compilation or dependency resolution failed")
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n")
    return report


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--report", type=Path, default=ROOT / "reports/P5_android_build.json")
    result = build(parser.parse_args().report)
    print(json.dumps(result, indent=2))
    raise SystemExit(0 if result["apk_built"] else 2)
