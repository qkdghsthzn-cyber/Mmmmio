"""Host suspension and late receipt catch-up, loopback HTTP fixtures only."""
import json
import tempfile
from datetime import timedelta
from pathlib import Path
from core.models import Decision,Action
from core.event_grammar import Grammar
from core.candidate_generator import CandidateGenerator
from core.novelty_engine import NoveltyEngine
from core.validator import Validator
from connectors.mock_native import fixture_purchase
from connectors.http_json import HTTPJSON
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.write_coordinator import WriteCoordinator
from connectors.canonical_runtime import CanonicalValidator,CanonicalCacheBridge
from connectors.runtime_bootstrap import InitializationRequest,RuntimeResources,NativeBootstrapper
from runtime.host_resume import resume_after_delay,revalidate_host_resume,pending
from connectors.database_recovery import RecoveryUnavailable
from runtime.hourly import NativeHourlyRuntime
from tests.native_http_server import NativeHTTPFixture


class ResumeFixtureExpense:
    def __init__(self):self.calls=0
    def decide(self,state,event):
        self.calls+=1
        return Decision(decision_id='fixture.host.resume.'+event.event_id,event_id=event.event_id,choice='accept',
            reason_tags=[],actions=[Action(type='spend',amount=event.payload['cost'])])


def run_demo():
    native,_,now=fixture_purchase(); server=NativeHTTPFixture(native)
    for role in ['relationships','taste','memory','world']:
        identifier='fixture.'+role
        server.objects[identifier]={'object':'page','id':identifier,'last_edited_time':'v1','archived':False}
        server.children[identifier]=[]
    try:
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'primary').mkdir(); path=root/'primary/runtime.sqlite3'
            http=HTTPJSON(server.url,'fixture-only-token',fixture=True)
            notion=NotionConnector(http=http); calendar=CalendarConnector('fixture.calendar',http=http)
            def connect():
                coordinator=WriteCoordinator(path,{'notion':NativeHTTPAdapter(notion),'calendar':NativeHTTPAdapter(calendar)})
                bridge=CanonicalCacheBridge(coordinator,CanonicalValidator(Validator(Grammar()),allow_internal=True))
                return coordinator,bridge
            coordinator,bridge=connect()
            try:
                world={'time':now.isoformat(),'timezone':'Asia/Tokyo','place':'home','activity':'idle','mood':'calm',
                    'privacy':'private','next_commitment':None,'journey':None,'needs':{'energy':75,'hunger':20,'social_need':25,
                    'novelty_need':25,'creative_urge':30,'comfort_need':20,'shopping_interest':20,'privacy_need':20}}
                request=InitializationRequest(initialization_ref='explicit host resume fixture world, not actual Mio',internal_values_ref='declared fixture needs',
                    world=world,travel_minutes={'home->home':0},feature_flags={'adult_life':False},relationships={},npc_age_refs={},npc_metric_refs={},
                    taste={},taste_metric_refs={},catalog={})
                resources=RuntimeResources(wallet_page='fixture.wallet',inventory_source='fixture.inventory',continuity_page='fixture.continuity',
                    relationships_page='fixture.relationships',taste_page='fixture.taste',memory_page='fixture.memory',
                    world_runtime_page='fixture.world',calendar_id='fixture.calendar')
                NativeBootstrapper(notion,calendar,lambda:now).initialize(bridge,request,resources)
                agent=ResumeFixtureExpense(); runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                grammar=Grammar(); grammar.families={'SMALL_EXPENSE':grammar.families['SMALL_EXPENSE']}
                runtime._selected=lambda state:[e for e in CandidateGenerator(grammar).generate(state,42,NoveltyEngine(grammar.rules)) if e.family=='SMALL_EXPENSE']
                server.fault('PATCH','/blocks/fixture.continuity/children','before_disconnect')
                initial=runtime.tick(now); assert initial['status']=='BLOCKED_RECOVERY'
                wall=now+timedelta(hours=5,minutes=37)
                caught=resume_after_delay(runtime,wall)
                assert caught['processed_hours']==5 and caught['decision_calls']==0
                assert bridge.state().wallet.balance==27850 and not bridge.confirmations_allowed()
                tx=bridge.db.execute("SELECT transaction_id FROM cache_bindings WHERE status='PENDING'").fetchone()[0]
                journal_steps=bridge.db.execute('SELECT COUNT(*) FROM cache_clock_steps WHERE transaction_id=?',(tx,)).fetchone()[0]
                snapshots_before_fresh=bridge.db.execute('SELECT COUNT(*) FROM hourly_snapshots').fetchone()[0]
                coordinator.close(); coordinator,bridge=connect()
                runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                frozen_after_restart=pending(bridge.db) and not bridge.confirmations_allowed()
                assert frozen_after_restart
                waiting=revalidate_host_resume(runtime,wall); assert waiting['status']=='WAITING_NATIVE_RECOVERY'
                try: runtime.tick(now+timedelta(hours=6))
                except RecoveryUnavailable: normal_tick_blocked=True
                else: raise AssertionError('new hourly work escaped the resume gate')
                row=next(r for r in coordinator.rows(tx) if r['status']=='APPLYING'); operation=json.loads(row['body'])
                assert server.route('PATCH','/blocks/'+operation['target']+'/children',{},operation['after'],{})[0]==200
                verified=revalidate_host_resume(runtime,wall); assert verified['status']=='VERIFIED'
                state=bridge.state(); assert state.world.time==now+timedelta(hours=5)
                assert state.wallet.balance==27600 and len(state.wallet.ledger)==1 and agent.calls==1
                replay=revalidate_host_resume(runtime,wall); assert replay['status']=='ALREADY_VERIFIED' and bridge.state()==state
                runtime._selected=lambda state:[]; resumed=runtime.tick(now+timedelta(hours=6))
                assert resumed['status']=='COMPLETED'
                Validator.invariants(bridge.state())
                attempts=[c for c in server.calls if c['method']=='PATCH' and c['path']=='/blocks/fixture.continuity/children']
                assert len(attempts)==1
                return {'status':'PASS','scope':'loopback HTTP fixture; no actual Mio facts or Android execution',
                    'initial':initial['status'],'observed_delay_minutes':337,'catchup':caught,
                    'clock_journal_steps':journal_steps,'historical_snapshots_created':snapshots_before_fresh,
                    'frozen_after_process_restart':frozen_after_restart,'new_hourly_work_blocked':normal_tick_blocked,
                    'waiting':waiting['status'],'fresh_revalidation':verified['status'],'replay':replay['status'],
                    'resumed_hour':resumed['status'],'decision_calls_total':agent.calls,
                    'original_ambiguous_append_attempts':len(attempts),'fixture_balance_jpy':bridge.state().wallet.balance,
                    'fixture_ledger_entries':len(bridge.state().wallet.ledger),'fixture_clock':bridge.state().world.time.isoformat(),
                    'actual_api_calls':0,'actual_canonical_writes':0,'android_execution':'NOT_RUN',
                    'rule_invariants':'PASS','production_enabled':False}
            finally: coordinator.close()
    finally: server.close()
