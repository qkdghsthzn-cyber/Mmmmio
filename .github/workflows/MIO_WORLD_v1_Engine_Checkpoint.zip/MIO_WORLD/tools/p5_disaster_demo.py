"""Full primary DB deletion after an ambiguous native expense, fixture only."""
import json
import tempfile
from datetime import timedelta
from pathlib import Path
from core.models import Decision,Action
from core.event_grammar import Grammar
from core.candidate_generator import CandidateGenerator
from core.novelty_engine import NoveltyEngine
from core.validator import Validator
from connectors.mock_native import fixture_purchase
from connectors.http_json import HTTPJSON
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.write_coordinator import WriteCoordinator
from connectors.canonical_runtime import CanonicalValidator,CanonicalCacheBridge
from connectors.runtime_bootstrap import InitializationRequest,RuntimeResources,NativeBootstrapper
from connectors.database_recovery import DatabaseRecoveryVault,revalidate_recovered
from runtime.hourly import NativeHourlyRuntime
from tests.native_http_server import NativeHTTPFixture


class DeclaredFixtureExpense:
    def __init__(self):self.calls=0
    def decide(self,state,event):
        self.calls+=1
        return Decision(decision_id='fixture.disaster.'+event.event_id,event_id=event.event_id,choice='accept',
            reason_tags=[],actions=[Action(type='spend',amount=event.payload['cost'])])


def run_demo():
    native,_,now=fixture_purchase(); server=NativeHTTPFixture(native)
    for role in ['relationships','taste','memory','world']:
        identifier='fixture.'+role
        server.objects[identifier]={'object':'page','id':identifier,'last_edited_time':'v1','archived':False}
        server.children[identifier]=[]
    try:
        with tempfile.TemporaryDirectory() as tmp:
            root=Path(tmp); (root/'primary').mkdir(); path=root/'primary/runtime.sqlite3'
            http=HTTPJSON(server.url,'fixture-only-token',fixture=True)
            notion=NotionConnector(http=http); calendar=CalendarConnector('fixture.calendar',http=http)
            def connect():
                coordinator=WriteCoordinator(path,{'notion':NativeHTTPAdapter(notion),'calendar':NativeHTTPAdapter(calendar)})
                bridge=CanonicalCacheBridge(coordinator,CanonicalValidator(Validator(Grammar()),allow_internal=True))
                return coordinator,bridge
            coordinator,bridge=connect()
            try:
                world={'time':now.isoformat(),'timezone':'Asia/Tokyo','place':'home','activity':'idle','mood':'calm',
                    'privacy':'private','next_commitment':None,'journey':None,'needs':{'energy':75,'hunger':20,'social_need':25,
                    'novelty_need':25,'creative_urge':30,'comfort_need':20,'shopping_interest':20,'privacy_need':20}}
                request=InitializationRequest(initialization_ref='explicit disaster fixture world, not actual Mio',internal_values_ref='declared fixture needs',
                    world=world,travel_minutes={'home->home':0},feature_flags={'adult_life':False},relationships={},npc_age_refs={},npc_metric_refs={},
                    taste={},taste_metric_refs={},catalog={})
                resources=RuntimeResources(wallet_page='fixture.wallet',inventory_source='fixture.inventory',continuity_page='fixture.continuity',
                    relationships_page='fixture.relationships',taste_page='fixture.taste',memory_page='fixture.memory',
                    world_runtime_page='fixture.world',calendar_id='fixture.calendar')
                NativeBootstrapper(notion,calendar,lambda:now).initialize(bridge,request,resources)
                agent=DeclaredFixtureExpense(); runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                vault=DatabaseRecoveryVault(root/'surviving_images',root/'protected_witness/latest.json',b'fixture-disaster-signing-key-0000','fixture.disaster.demo')
                coordinator.enable_recovery(vault)
                grammar=Grammar(); grammar.families={'SMALL_EXPENSE':grammar.families['SMALL_EXPENSE']}
                runtime._selected=lambda state:[e for e in CandidateGenerator(grammar).generate(state,42,NoveltyEngine(grammar.rules)) if e.family=='SMALL_EXPENSE']
                server.fault('PATCH','/blocks/fixture.continuity/children','before_disconnect')
                initial=runtime.tick(now); during=runtime.tick(now+timedelta(hours=1)); state=bridge.state()
                assert initial['status']=='BLOCKED_RECOVERY' and during['status']=='COMPLETED_CLOCK_ONLY'
                checkpoint_sequence=vault.latest()['sequence']; coordinator.close()
                for suffix in ['', '-wal','-shm','.worker','.scheduler']:Path(str(path)+suffix).unlink(missing_ok=True)
                restored=vault.restore(path,expected_sequence=checkpoint_sequence)
                coordinator,bridge=connect(); coordinator.enable_recovery(vault)
                runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                assert bridge.state()==state and not bridge.confirmations_allowed()
                waiting=revalidate_recovered(runtime); assert waiting['status']=='WAITING_NATIVE_RECOVERY'
                tx=bridge.db.execute("SELECT transaction_id FROM cache_bindings WHERE status='PENDING'").fetchone()[0]
                row=next(r for r in coordinator.rows(tx) if r['status']=='APPLYING'); operation=json.loads(row['body'])
                assert server.route('PATCH','/blocks/'+operation['target']+'/children',{},operation['after'],{})[0]==200
                verified=revalidate_recovered(runtime); assert verified['status']=='VERIFIED'
                assert bridge.state().world.time==now+timedelta(hours=1) and bridge.state().wallet.balance==27600
                runtime._selected=lambda state:[]; resumed=runtime.tick(now+timedelta(hours=2))
                assert resumed['status']=='COMPLETED' and agent.calls==1
                Validator.invariants(bridge.state()); vault.ensure_clean(bridge.db)
                return {'status':'PASS','scope':'loopback HTTP fixture; surviving authenticated backup/witness/key required',
                    'actual_canonical_writes':0,'primary_db_and_journals_deleted':True,'checkpoint_sequence_at_loss':checkpoint_sequence,
                    'restore_status':restored['status'],'initial_revalidation':waiting['status'],'final_revalidation':verified['status'],
                    'decision_calls':agent.calls,'fixture_final_balance_jpy':bridge.state().wallet.balance,
                    'fixture_ledger_entries':len(bridge.state().wallet.ledger),'clock_preserved_during_recovery':True,
                    'resumed_hour_status':resumed['status'],'continuity_append_request_attempts':len([c for c in server.calls if c['method']=='PATCH' and c['path']=='/blocks/fixture.continuity/children']),
                    'backup_images_retained':len(list(vault.directory.glob('checkpoint-*.sqlite3'))),
                    'unresolved_cache_bindings':bridge.db.execute("SELECT COUNT(*) FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchone()[0],
                    'rule_invariants':'PASS','signing_key_is_synthetic':True,'host_or_backup_witness_loss_supported':False}
            finally:coordinator.close()
    finally:server.close()
