import sys
import json
import time
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from core.state_manager import StateStore
from core.mock_state import mock_state
from core.simulator import Simulator

if __name__=="__main__":
    store=StateStore(); store.initialize(mock_state())
    start=time.monotonic()
    result=Simulator(store,seed=42).run(10000,progress=lambda n:print(f"{n}/10000 hours elapsed={time.monotonic()-start:.1f}s",flush=True))
    result["elapsed_seconds"]=round(time.monotonic()-start,3)
    for key in ["wallet_violation_count","inventory_violation_count","calendar_conflict_count","unsupported_fact_count"]:
        assert result[key]==0,(key,result[key])
    assert result["hours"]>=10000
    assert .05<result["no_event_rate"]<.9
    assert result["unique_families"]>=80
    assert result["rolling_30day_windows_checked"]>0
    assert result["max_30day_nonroutine_family_share"]<=.15
    result["thresholds"]={"unique_families_min":80,"no_event_rate_range":[.05,.9],"max_30day_nonroutine_family_share_max":.15,"rule_violations_max":0}
    result["status"]="PASS"
    Path("reports/P2_10000h.json").write_text(json.dumps(result,ensure_ascii=False,indent=2)+"\n")
    print(json.dumps({k:v for k,v in result.items() if k!="family_counts"},ensure_ascii=False,indent=2),flush=True)
