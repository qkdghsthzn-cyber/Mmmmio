"""Package the existing P5 source archive in one phone-friendly Colab notebook."""
import ast
import base64
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
archive = ROOT / 'deployment/MIO_P5_Build_Sources.zip'
payload = base64.b64encode(archive.read_bytes()).decode('ascii')
digest = hashlib.sha256(archive.read_bytes()).hexdigest()

code = r'''#@title 테스트 후 P5 검사 APK 빌드하기 ▶
import base64, hashlib, io, json, os, platform, shutil, stat, subprocess, sys, time, urllib.request, zipfile
from pathlib import Path, PurePosixPath
from google.colab import files

SOURCE_B64 = __PAYLOAD__
SOURCE_SHA256 = __DIGEST__
PHASES = ['P0', 'P1', 'P2', 'P3', 'P4', 'P5_contract', 'P5_recovery',
          'P5_http', 'P5_runtime', 'P5_hourly', 'P5_effects', 'P5_clock',
          'P5_restore', 'P5_month', 'P5_disaster', 'P5_mobile', 'P5_host_resume', 'P5_oauth', 'P5_android_dependencies']
SDK_URL = 'https://dl.google.com/android/repository/commandlinetools-linux-15859902_latest.zip'
SDK_SHA256 = '4e4c464f145a7512b57d088ac6c278c03c9eea610886b35a5e0804e74eedf583'
GRADLE_URL = 'https://services.gradle.org/distributions/gradle-8.13-bin.zip'
GRADLE_SHA256 = '20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78'

def safe_extract(raw, destination):
    destination.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(io.BytesIO(raw)) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError('ZIP integrity failure')
        for entry in bundle.infolist():
            name = PurePosixPath(entry.filename)
            if name.is_absolute() or '..' in name.parts or '\\' in entry.filename:
                raise RuntimeError('Unsafe archive path')
            if stat.S_ISLNK(entry.external_attr >> 16):
                raise RuntimeError('Archive symlink rejected')
            target = destination.joinpath(*name.parts)
            if not target.resolve().is_relative_to(destination.resolve()):
                raise RuntimeError('Archive path escapes workspace')
        bundle.extractall(destination)

def fetch(url, expected_sha256, destination):
    if destination.is_file() and hashlib.sha256(destination.read_bytes()).hexdigest() == expected_sha256:
        return destination.read_bytes()
    partial = destination.with_suffix('.partial')
    with urllib.request.urlopen(url, timeout=120) as response, partial.open('wb') as output:
        shutil.copyfileobj(response, output)
    raw = partial.read_bytes()
    if hashlib.sha256(raw).hexdigest() != expected_sha256:
        partial.unlink(missing_ok=True)
        raise RuntimeError('Downloaded tool checksum mismatch')
    partial.replace(destination)
    return raw

def run(arguments, label, *, env=None, cwd=None, input_text=None, timeout=1800, capture=False):
    print(label, flush=True)
    with (logs / (label.split(':', 1)[0] + '.log')).open('w') as output:
        result = subprocess.run(arguments, cwd=cwd, env=env, input=input_text,
                                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                                text=True, timeout=timeout)
        output.write(result.stdout or '')
    if result.returncode:
        print((result.stdout or '')[-7000:], flush=True)
        raise RuntimeError(f'{label}: exit {result.returncode}')
    if not capture:
        print((result.stdout or '')[-1000:], flush=True)
    return (result.stdout or '').strip()

def provision():
    if platform.system() != 'Linux' or platform.machine() != 'x86_64':
        raise RuntimeError('Select a hosted Colab CPU Linux x86_64 runtime')
    env = os.environ.copy()
    uv_site = tools / 'uv-site'
    if not (uv_site / 'uv').is_dir():
        run([sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check',
             '--target', str(uv_site), 'uv==0.12.20'], '01_uv: Python 준비')
    env['PYTHONPATH'] = str(uv_site)
    env['UV_PYTHON_INSTALL_DIR'] = str(tools / 'python')
    env['UV_PYTHON_BIN_DIR'] = str(tools / 'python-bin')
    uv = [sys.executable, '-m', 'uv']
    run(uv + ['python', 'install', '3.13'], '02_python: Python 3.13 설치', env=env)
    managed = run(uv + ['python', 'find', '3.13'], '03_python_path: 버전 확인', env=env, capture=True)
    venv = tools / 'host-env'
    if not (venv / 'bin/python').is_file():
        run(uv + ['venv', '--python', managed, str(venv)], '04_environment: 시험 환경 준비', env=env)
    host_python = venv / 'bin/python'
    run(uv + ['pip', 'install', '--python', str(host_python), '-r', str(project / 'requirements.txt'), '-c', str(project / 'android-probe/constraints.txt')],
        '05_dependencies: 원본 의존성 설치', env=env)
    env.pop('PYTHONPATH', None)
    env['MIO_BUILD_PYTHON'] = str(host_python)
    # Use the same JDK 17 configuration as the existing manual CI job.
    java_home = Path('/usr/lib/jvm/java-17-openjdk-amd64')
    if not (java_home / 'bin/javac').is_file():
        run(['apt-get', 'update', '-qq'], '06_apt: JDK 설치 준비')
        run(['apt-get', 'install', '-y', '-qq', 'openjdk-17-jdk-headless'], '07_jdk: JDK 17 설치')
    if not (java_home / 'bin/javac').is_file():
        raise RuntimeError('JDK 17 installation was not found')
    env['JAVA_HOME'] = str(java_home)
    gradle_home = tools / 'gradle-8.13'
    if not (gradle_home / 'bin/gradle').is_file():
        safe_extract(fetch(GRADLE_URL, GRADLE_SHA256, tools / 'gradle.zip'), tools)
    (gradle_home / 'bin/gradle').chmod(0o755)
    sdk = tools / 'android-sdk'
    sdkmanager = sdk / 'cmdline-tools/latest/bin/sdkmanager'
    if not sdkmanager.is_file():
        stage = tools / 'sdk-unpacked'
        safe_extract(fetch(SDK_URL, SDK_SHA256, tools / 'sdk-tools.zip'), stage)
        sdkmanager.parent.parent.parent.mkdir(parents=True, exist_ok=True)
        shutil.move(str(stage / 'cmdline-tools'), str(sdk / 'cmdline-tools/latest'))
    for executable in sdkmanager.parent.iterdir():
        if executable.is_file(): executable.chmod(0o755)
    env['ANDROID_HOME'] = env['ANDROID_SDK_ROOT'] = str(sdk)
    env['PATH'] = os.pathsep.join([str(java_home / 'bin'), str(gradle_home / 'bin'),
                                str(venv / 'bin'), str(sdkmanager.parent), env.get('PATH', '')])
    env['GRADLE_USER_HOME'] = str(tools / 'gradle-cache')
    run([str(sdkmanager), '--sdk_root=' + str(sdk), '--licenses'],
        '08_sdk_licenses: 노트북에 안내된 Android SDK 약관 수락', env=env, input_text='y\n' * 100)
    run([str(sdkmanager), '--sdk_root=' + str(sdk), 'platforms;android-36', 'build-tools;35.0.0'],
        '09_sdk: Android SDK 36 설치', env=env, input_text='y\n' * 100)
    return str(host_python), env

def main():
    raw = base64.b64decode(SOURCE_B64, validate=True)
    if hashlib.sha256(raw).hexdigest() != SOURCE_SHA256:
        raise RuntimeError('Embedded source checksum mismatch')
    safe_extract(raw, project)
    manifest = json.loads((project / 'build_source_manifest.json').read_text())
    for entry in manifest['files']:
        if hashlib.sha256((project / entry['path']).read_bytes()).hexdigest() != entry['sha256']:
            raise RuntimeError('Original source manifest mismatch')
    families = list((project / 'data/event_families').glob('*'))
    if len([p for p in families if p.is_file()]) != 160:
        raise RuntimeError('Expected exactly 160 original Family files')
    print('원본 소스 검증 완료. API 키 입력은 필요하지 않습니다.', flush=True)
    host_python, env = provision()
    status['stage'] = 'FIXTURE_TESTS'
    run([host_python, 'tools/test_report.py', *PHASES], '10_tests: P0부터 순서대로 회귀 시험',
        env=env, cwd=project, timeout=1800)
    reports = [json.loads((project / f'reports/{phase}_tests.json').read_text()) for phase in PHASES]
    if any(r['status'] != 'PASS' for r in reports) or sum(r['test_count'] for r in reports) != 378:
        raise RuntimeError('Expected all 378 fixture tests to pass before APK build')
    status.update(fixture_tests='PASS', fixture_test_count=378, stage='ANDROID_BUILD')
    print('378개 로컬 fixture 시험 통과. 실제 Android 컴파일을 시작합니다.', flush=True)
    run([host_python, 'tools/build_android_probe.py'], '11_build: P5 APK 컴파일',
        env=env, cwd=project, timeout=2700)
    report = json.loads((project / 'reports/P5_android_build.json').read_text())
    apk = root / 'MIO_P5_Device_Probe.apk'
    if report.get('status') != 'APK_BUILT_DEVICE_NOT_RUN' or not apk.is_file():
        raise RuntimeError('No validated APK was produced')
    if hashlib.sha256(apk.read_bytes()).hexdigest() != report['apk_sha256']:
        raise RuntimeError('APK checksum mismatch')
    status.update(stage='APK_BUILT_DEVICE_NOT_RUN', apk_built=True, apk_sha256=report['apk_sha256'])
    print('APK 빌드 완료. Fold8 설치와 기기 검사는 아직 진행하지 않았습니다.', flush=True)
    return apk

# Each run uses a new directory so failed/rerun builds cannot download an old APK.
root = Path('/content') / ('mio-p5-' + str(time.time_ns()))
project, tools, logs = root / 'MIO_WORLD', root / 'tools', root / 'logs'
for directory in (project, tools, logs): directory.mkdir(parents=True, exist_ok=True)
status = {'stage': 'PREPARING', 'apk_built': False, 'fixture_tests': 'NOT_RUN',
          'android_execution': 'NOT_RUN', 'production_enabled': False,
          'source_sha256': SOURCE_SHA256}
apk = None
error = None
try:
    apk = main()
except Exception as exc:
    error = exc
    status.update(stage='FAILED', error=str(exc))
    print('빌드가 중단되었습니다. 아래 진단 ZIP을 이 대화에 첨부해 주세요.', flush=True)
finally:
    (logs / 'colab_status.json').write_text(json.dumps(status, ensure_ascii=False, indent=2))
    diagnostics = root / 'MIO_P5_Build_Diagnostics.zip'
    with zipfile.ZipFile(diagnostics, 'w', zipfile.ZIP_DEFLATED) as bundle:
        for log in sorted(logs.glob('*')):
            if log.is_file(): bundle.write(log, 'logs/' + log.name)
        for report in sorted((project / 'reports').glob('*')):
            if report.is_file() and (report.name.endswith('_tests.json') or report.name.startswith(('P5_android_build', 'P5_android_wheels'))):
                bundle.write(report, 'reports/' + report.name)
    print('진단 파일:', str(diagnostics), flush=True)

download = apk if apk is not None and error is None else diagnostics
try:
    files.download(str(download))
except Exception:
    print('자동 다운로드가 열리지 않으면 왼쪽 파일 메뉴에서 아래 파일을 길게 누르고 다운로드하세요:')
    print(str(download))
if error is not None:
    raise RuntimeError('P5 빌드 실패: 진단 ZIP을 첨부하면 이어서 수정할 수 있습니다.') from error
'''
code = code.replace('__PAYLOAD__', repr(payload)).replace('__DIGEST__', repr(digest))
ast.parse(code)
intro = '''# Fold8에서 MIO P5 검사 APK 빌드하기

이 노트북에는 기존 MIO WORLD P5 코드가 포함되어 있습니다. 소스 ZIP을 따로 업로드하지 않아도 됩니다.

1. Fold8의 Chrome에서 https://colab.research.google.com/ 를 엽니다. 필요하면 **데스크톱 사이트**를 켭니다.
2. **파일 → 노트북 업로드**에서 이 `.ipynb` 파일을 선택합니다. Google 로그인은 필요하지만 GitHub 계정/연결은 사용하지 않습니다. Google 계정의 로그인 정책은 그대로 적용됩니다.
3. 런타임은 기본 **CPU**로 두고 **런타임 → 모두 실행**을 누릅니다. 실행 확인 창이 뜨면 코드를 확인한 뒤 실행합니다.
4. 성공하면 `MIO_P5_Device_Probe.apk`가 다운로드됩니다. 실패하면 `MIO_P5_Build_Diagnostics.zip`을 이 대화에 첨부합니다.

실행하는 동안 Colab 페이지를 열어 두세요. 도구/SDK 다운로드는 Colab 서버에서 진행하며, 휴대폰은 노트북과 결과 파일을 내려받습니다. 다운로드가 안 뜨면 왼쪽 **파일** 메뉴에서 출력에 표시된 파일을 선택해 내려받습니다. GPU/유료 플랜은 이 빌드의 필수 조건이 아닙니다. 무료 런타임 제공 여부/연결 지속 시간은 보장되지 않습니다.

**실행 범위와 현재 상태**

- 원본 엔진, 실행에 필요한 Core Identity, 160 Family, 의존성 요구사항을 유지합니다. 원본 첨부 문서/사진/API 키/정본 DB는 포함하지 않습니다.
- P0부터 기존 378개 fixture 시험을 순서대로 실행합니다. 모두 통과해야 Android APK 빌드로 넘어갑니다. P3~P5 fixture 통과가 실제 서비스/기기 검사 통과를 뜻하지 않습니다.
- 출력 APK는 **P5 검사 앱**입니다. 완성된 오버레이·로그인·상시 실행 제품 앱은 아직 아닙니다. 실제 Fold8 검사가 끝나야 다음 단계로 진행합니다.
- 준비 시점에 노트북 소스 검증은 완료했지만, **Colab 실행/Android 의존성 해결/컴파일/APK 설치는 NOT_RUN**입니다. Android용 Python 바이너리 의존성이 없으면 빌드는 실패로 남깁니다.
- 실행 시 [Android SDK 약관](https://developer.android.com/studio/terms)을 수락하고 SDK를 설치합니다. API 키 입력, Drive 마운트, GitHub 연결은 없습니다.

공식 참고: [Colab FAQ](https://research.google.com/colaboratory/faq.html), [Colab 파일 다운로드](https://colab.research.google.com/notebooks/io.ipynb), [Android SDK 도구](https://developer.android.com/studio), [Gradle 배포 체크섬](https://gradle.org/release-checksums/), [uv Python 설치](https://docs.astral.sh/uv/guides/install-python/).
'''
notebook = {
    'nbformat': 4, 'nbformat_minor': 5,
    'metadata': {'colab': {'name': 'MIO_P5_Fold8_Build.ipynb', 'provenance': []},
                 'kernelspec': {'name': 'python3', 'display_name': 'Python 3'},
                 'language_info': {'name': 'python'},
                 'mio': {'base_checkpoint_version': 14, 'source_sha256': digest,
                         'colab_execution': 'NOT_RUN', 'apk_built': False}},
    'cells': [
        {'cell_type': 'markdown', 'id': 'fold8-guide', 'metadata': {}, 'source': intro.splitlines(keepends=True)},
        {'cell_type': 'code', 'id': 'p5-build', 'metadata': {'cellView': 'form'},
         'execution_count': None, 'outputs': [], 'source': code.splitlines(keepends=True)}
    ]
}
output = ROOT / 'deployment/MIO_P5_Fold8_Build.ipynb'
output.write_text(json.dumps(notebook, ensure_ascii=False, indent=1) + '\n')
print(json.dumps({'path': str(output), 'size_bytes': output.stat().st_size,
                  'source_sha256': digest, 'colab_execution': 'NOT_RUN', 'apk_built': False}))
