"""Authoring helper. Generated JSON is the runtime source, editable without code changes.
160 distinct circumstances, not 160 copies of a sentence. No generated past facts.
"""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]/"data"
GROUPS={
 "social": "FRIEND_CONTACT REPLY_DELAY FRIEND_INVITE FRIEND_ADVICE FRIEND_RECOMMEND PHOTO_SHARE RESCHEDULE_REQUEST LONG_GAP_CONTACT SMALL_MISUNDERSTANDING THANK_YOU CELEBRATION FRIEND_CHECKIN SHARED_INTEREST FRIEND_SUPPORT GROUP_PLAN BOUNDARY_TALK ROMANTIC_DATE AFFECTION_MOMENT PRIVATE_NIGHT MORNING_AFTER_SOCIAL FRIEND_OPINION FRIEND_FOLLOWUP FRIEND_REUNION SHARED_MEMORY".split(),
 "home": "CLEAN_ROOM LAUNDRY ORGANIZE_DESK COOK_MEAL FOOD_DELIVERY FIND_ITEM ROOM_DECOR REST SHOWER_PREP BEDTIME_ROUTINE MORNING_ROUTINE MEAL_PREP DISHES HOUSEHOLD_SUPPLY WINDOW_AIRING QUIET_HOME HOME_REPAIR HOME_MUSIC".split(),
 "fashion": "OUTFIT_CHOICE ITEM_REDISCOVERY REPAIR_NEEDED COORDINATE_EXPERIMENT WISHLIST_REVIEW SALE_DISCOVERY PURCHASE_ITEM ITEM_STORAGE SEASONAL_OUTFIT COLOR_IDEA ACCESSORY_CHOICE CLOTHING_CARE FIT_CHECK WARDROBE_SORT STYLE_INSPIRATION BORROW_REQUEST RETURN_ITEM OUTFIT_REVIEW".split(),
 "money": "BUDGET_CHECK SMALL_EXPENSE REFUND_REVIEW DISCOUNT_CHECK PRICE_CHANGE PURCHASE_DEFER SAVING_CHOICE SPENDING_REVIEW RESERVED_BUDGET PRICE_COMPARE FREE_ALTERNATIVE WISHLIST_BUDGET".split(),
 "calendar": "CALENDAR_OPEN_SLOT APPOINTMENT_REVIEW APPOINTMENT_CHANGE APPOINTMENT_CANCEL LATE_RISK FREE_TIME PREP_TIME_SHORT SCHEDULE_CONFLICT WEEK_PLAN DAY_PLAN COMMITMENT_REMINDER CALENDAR_FOLLOWUP".split(),
 "hobby": "GAME_URGE NEW_GAME_DISCOVERY DECK_IDEA FRIEND_GAME_RECOMMEND COLLECTION_INTEREST CONTENT_WATCH GAME_PRACTICE GAME_BREAK CARD_ORGANIZE GAME_STRATEGY HOBBY_SEARCH GAME_SESSION GAME_REVIEW HOBBY_FOLLOWUP".split(),
 "creative": "PHOTO_IDEA PHOTO_CAPTURE PHOTO_SELECT POST_CONSIDER COMMENT_REVIEW ARCHIVE_SORT STYLE_CHANGE PHOTO_LIGHT PHOTO_COMPOSITION STORY_IDEA EDIT_IDEA CREATIVE_BLOCK CREATIVE_SESSION CREATIVE_REVIEW".split(),
 "study": "FOCUS_START ASSIGNMENT_REVIEW SMALL_ACHIEVEMENT STUDY_BLOCK STUDY_BREAK SUPPLY_PREP STUDY_RESCHEDULE WORK_PREP NOTE_REVIEW STUDY_PLAN".split(),
 "outing": "OUTING_CAFE VINTAGE_SHOP WALK BOOKSTORE CONVENIENCE_STORE EVENT_DISCOVERY STREET_FIND RETURN_HOME NEARBY_PLACE OUTING_PREP SHORT_TRIP PLACE_REVISIT".split(),
 "digital": "BATTERY_CHECK STORAGE_CHECK APP_NOTICE UPDATE_REVIEW PHOTO_CLEANUP DEVICE_ISSUE ONLINE_DISCOVERY SCREEN_BREAK FILE_ORGANIZE DEVICE_CARE".split(),
 "environment": "WEATHER_REVIEW HEAT_RESPONSE COLD_RESPONSE SEASON_NOTICE SUNSET RAIN_RESPONSE DAYLIGHT_ADJUST VENTILATION".split(),
 "personal": "BOREDOM LONELINESS CURIOSITY FATIGUE DRESS_UP THINK_OF_FRIEND SOLITUDE SELF_REFLECTION".split(),
}
PROFILES={
 "social":dict(actions=["contact","reply","ask_opinion","defer_contact"],triggers=["time_since_contact","shared_interest","open_thread"],channels=["message","dm","call"],locations=["home","cafe"],outcomes=["replied","deferred","followup"],topic="fashion",need="social_need",effect="contact",actor_types=["friend","colleague","family"],requires=["actor_active"],forbids=["fixed_busy"],cooldown_hours=4),
 "home":dict(actions=["prepare","organize","rest","consider"],triggers=["need_pressure","free_time","routine_time"],channels=["internal"],locations=["home"],outcomes=["completed","deferred"],topic="comfort",need="comfort_need",effect="observe",actor_types=[],requires=[],forbids=["fixed_busy"],cooldown_hours=4),
 "fashion":dict(actions=["inspect_owned","coordinate","review","defer"],triggers=["wardrobe_memory","taste_signal","free_time"],channels=["internal","app"],locations=["home"],outcomes=["used_owned","idea_saved","deferred"],topic="fashion",need="shopping_interest",effect="use_item",actor_types=[],requires=["owned_item"],forbids=["fixed_busy"],cooldown_hours=6,object_category="clothing"),
 "money":dict(actions=["review_budget","compare","defer","consider"],triggers=["budget_pressure","wishlist","free_time"],channels=["internal","app"],locations=["home"],outcomes=["reviewed","deferred"],topic="saving",need="shopping_interest",effect="observe",actor_types=[],requires=[],forbids=["fixed_busy"],cooldown_hours=6),
 "calendar":dict(actions=["review_schedule","plan","defer_plan"],triggers=["calendar_due","open_slot","open_thread"],channels=["calendar"],locations=["home"],outcomes=["plan_created","deferred"],topic="study",need="novelty_need",effect="observe",actor_types=[],requires=[],forbids=[],cooldown_hours=4),
 "hobby":dict(actions=["play","practice","review","defer_play"],triggers=["hobby_memory","shared_interest","free_time"],channels=["internal","app"],locations=["home"],outcomes=["played","idea_saved","deferred"],topic="game",need="novelty_need",effect="use_item",actor_types=[],requires=["owned_item"],forbids=["fixed_busy"],cooldown_hours=4,object_category="hobby"),
 "creative":dict(actions=["consider_photo","compose","review","archive"],triggers=["creative_pressure","light_change","past_event"],channels=["internal","app"],locations=["home","cafe","park"],outcomes=["idea_saved","reviewed","deferred"],topic="creative",need="creative_urge",effect="observe",actor_types=[],requires=[],forbids=["fixed_busy"],cooldown_hours=4),
 "study":dict(actions=["prepare_notes","focus","review","take_break"],triggers=["calendar_due","study_task","free_time"],channels=["internal"],locations=["home","school"],outcomes=["reviewed","prepared","deferred"],topic="study",need="comfort_need",effect="use_item",actor_types=[],requires=["owned_item"],forbids=[],cooldown_hours=4,object_category="study"),
 "outing":dict(actions=["consider_visit","plan_visit","consider_return","defer_visit"],triggers=["free_time","curiosity","open_thread"],channels=["internal"],locations=["cafe","shop","park","bookstore"],outcomes=["arrived","deferred"],topic="cafe",need="novelty_need",effect="move",actor_types=[],requires=["reachable"],forbids=["fixed_busy"],cooldown_hours=6),
 "digital":dict(actions=["inspect_device","organize_files","consider_update","take_break"],triggers=["device_check","free_time","routine_time"],channels=["app","internal"],locations=["home"],outcomes=["inspected","reviewed","deferred"],topic="device",need="comfort_need",effect="use_item",actor_types=[],requires=["owned_item"],forbids=["fixed_busy"],cooldown_hours=6,object_category="device"),
 "environment":dict(actions=["notice_environment","consider_adjustment","reflect"],triggers=["seasonal_context","light_change","internal_observation"],channels=["internal"],locations=["home","park"],outcomes=["noticed","deferred"],topic="environment",need="comfort_need",effect="observe",actor_types=[],requires=[],forbids=[],cooldown_hours=8),
 "personal":dict(actions=["reflect","rest","consider_contact","consider_new_activity"],triggers=["need_pressure","mood_change","free_time"],channels=["internal"],locations=["home"],outcomes=["reflected","rested","deferred"],topic="self",need="novelty_need",effect="observe",actor_types=[],requires=[],forbids=["fixed_busy"],cooldown_hours=6),
}
OVERRIDES={
 "PURCHASE_ITEM":dict(actions=["buy","defer_purchase"],effect="purchase",requires=["available_item","budget","uniqueness"],object_category=None,outcomes=["acquired","deferred"],cost_band="item_price"),
 "SMALL_EXPENSE":dict(actions=["spend","defer_expense"],effect="spend",requires=["budget"],cost=250,outcomes=["paid","deferred"],cost_band="small"),
 "OUTFIT_CHOICE":dict(actions=["wear_item","defer_outfit"],effect="use_item"),
 "COORDINATE_EXPERIMENT":dict(actions=["coordinate","defer_outfit"]),
 "REST":dict(actions=["rest","defer_rest"],effect="need",need="energy",need_delta=24,routine=True,cooldown_hours=2),
 "BEDTIME_ROUTINE":dict(actions=["sleep","defer_sleep"],effect="need",need="energy",need_delta=35,routine=True,hours=[22,23,0,1,2,3,4,5],cooldown_hours=4),
 "COOK_MEAL":dict(actions=["cook","defer_meal"],effect="need",need="hunger",need_delta=-45,routine=True,cooldown_hours=3),
 "MEAL_PREP":dict(actions=["prepare_meal","defer_meal"],effect="need",need="hunger",need_delta=-30,routine=True,cooldown_hours=3),
 "LONELINESS":dict(effect="need",need="social_need",need_delta=-12),
 "FATIGUE":dict(effect="need",need="energy",need_delta=16),
 "SOLITUDE":dict(effect="need",need="privacy_need",need_delta=-18),
 "CREATIVE_SESSION":dict(effect="need",need="creative_urge",need_delta=-20),
 "STUDY_BREAK":dict(effect="need",need="energy",need_delta=12),
 "CALENDAR_OPEN_SLOT":dict(actions=["make_plan","defer_plan"],effect="calendar",outcomes=["plan_created","deferred"],forbids=["fixed_busy"]),
 "APPOINTMENT_CANCEL":dict(effect="cancel_calendar",requires=["future_commitment"],actions=["cancel_plan","keep_plan"]),
 "FRIEND_INVITE":dict(effect="invite",actions=["accept_invitation","defer_invitation"],outcomes=["plan_created","deferred"]),
 "FRIEND_REUNION":dict(effect="invite",actions=["plan_reunion","defer_reunion"]),
 "RETURN_HOME":dict(locations=["home"]),
}
ADULT={"ROMANTIC_DATE","AFFECTION_MOMENT","PRIVATE_NIGHT","MORNING_AFTER_SOCIAL"}

def write(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,ensure_ascii=False,indent=2)+"\n",encoding="utf8")

def main():
    for group,names in GROUPS.items():
        for name in names:
            f=dict(id=name,group=group,description=f"{group}: {name.lower().replace('_',' ')} circumstance",
                   base_weight=.08,routine=False,cost=0,cost_band="free",duration_minutes=[15,30,60],
                   intents=[name.lower(),"consider","defer"],novelty_keys=["family","actor","action","location","topic"],
                   hooks=[],**PROFILES[group])
            f.update(OVERRIDES.get(name,{}))
            if name in ADULT:
                f.update(adult=True,base_weight=.006,actor_types=["partner"],requires=["actor_active","mutual_consent","private_context"],hours=[20,21,22,23],effect="contact")
            f["binds"]={"actor":"active_relationship_by_role", "object":"owned_item_by_category" if "owned_item" in f["requires"] else "available_catalog_item" if "available_item" in f["requires"] else "none",
                        "cost":"catalog_price" if f["effect"]=="purchase" else "family_fixed_cost", "location":"reachable_destination" if f["effect"]=="move" else "current_place"}
            f["effects_if_committed"]={"purchase":["wallet_ledger","inventory_owned","wishlist_purchased","continuity"],
                "contact":["relationship_evidence","continuity"],"use_item":["activity","continuity"],"spend":["wallet_ledger","continuity"],
                "calendar":["calendar_create","continuity"],"invite":["calendar_create","relationship_evidence","continuity"],
                "cancel_calendar":["calendar_cancel","continuity"],"move":["journey","continuity"],"need":["needs","continuity"],"observe":["present_intention","continuity"]}[f["effect"]]
            write(ROOT/"event_families"/(name+".json"),f)
    modifiers={
      "temporal":["sudden","after_reflection","between_plans","late_evening"],
      "emotional":["playful","cautious","excited","calm"],
      "contextual":["budget_aware","free_hour","recent_interest","quiet_day"],
      "relationship":["close","slightly_awkward","long_gap","familiar"],
      "resource":["free","small_cost","owned_resource"],
      "consequence":["immediate","tomorrow","followup","state_change"],
      "narrative_echo":["none","recent_echo","deferred_choice"],
    }
    write(ROOT/"modifiers"/"layers.json",modifiers)
    write(ROOT/"rules"/"world.json",dict(candidate_limit=30,relationship_delta_cap=3,
          no_event_score=3.5,second_event_chance=.12,random_gate_probability=.7,
          need_threshold=75,chain_depth_cap=6,max_hooks=64,adult_life=False,
          novelty_24h=.45,novelty_7d=.08,novelty_recent=1.2,routine_penalty_scale=.12))
    slots={"motive":"curiosity comfort saving fun duty connection creativity rest self_expression preparation nostalgia convenience care gratitude belonging anticipation balance privacy order discovery reassurance autonomy attention routine learning improvement exploration simplicity flexibility patience appreciation confidence reflection freshness warmth calmness kindness inspiration completion wellbeing".split(),
           "time_relation":["now","after_commitment","tomorrow","next_free_slot","late_evening","morning","after_reply","weekend"],
           "mood":"calm playful excited cautious tired focused curious bored reflective warm hopeful hesitant grateful neutral relieved restless shy confident cheerful quiet wistful patient uncertain content".split(),
           "intensity":["very_low","low","medium","high","very_high"],
           "uncertainty":["low","medium","high"],
           "duration":["5m","10m","15m","20m","30m","45m","60m","90m","120m","150m","180m","240m"]}
    write(ROOT/"slots.json",slots)
    print("Wrote",sum(map(len,GROUPS.values())),"event families")

if __name__=="__main__": main()
