"""Generate a two-file GitHub browser setup for the frozen P5 source archive."""
import hashlib
import html
import json
import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / 'deployment/MIO_P5_Build_Sources.zip'
WORKFLOW_PATH = '.github/workflows/mio-p5-phone.yml'

EXTRACT = '''import hashlib, json, os, stat, zipfile
from pathlib import Path, PurePosixPath

archive = Path("MIO_P5_Build_Sources.zip")
expected = "__SOURCE_SHA__"
if not archive.is_file():
    raise RuntimeError("Upload MIO_P5_Build_Sources.zip to the repository root first")
if hashlib.sha256(archive.read_bytes()).hexdigest() != expected:
    raise RuntimeError("Source ZIP checksum mismatch: upload the matching provided source ZIP")
destination = Path(os.environ["RUNNER_TEMP"]) / "mio-p5-source"
destination.mkdir()
with zipfile.ZipFile(archive) as bundle:
    if bundle.testzip() is not None:
        raise RuntimeError("Source ZIP integrity failed")
    names = bundle.namelist()
    if len(names) != len(set(names)):
        raise RuntimeError("Duplicate ZIP paths")
    for member in bundle.infolist():
        name = PurePosixPath(member.filename)
        if name.is_absolute() or ".." in name.parts or chr(92) in member.filename:
            raise RuntimeError("Unsafe ZIP path")
        if stat.S_ISLNK(member.external_attr >> 16):
            raise RuntimeError("ZIP symlinks are not allowed")
        if not destination.joinpath(*name.parts).resolve().is_relative_to(destination.resolve()):
            raise RuntimeError("ZIP path escapes destination")
    manifest = json.loads(bundle.read("build_source_manifest.json"))
    if manifest.get("format") != "mio-code-only-build-v1":
        raise RuntimeError("Unknown build source format")
    listed = [entry["path"] for entry in manifest["files"]]
    if len(listed) != len(set(listed)) or set(names) != set(listed) | {"build_source_manifest.json"}:
        raise RuntimeError("Incomplete source manifest")
    for entry in manifest["files"]:
        if hashlib.sha256(bundle.read(entry["path"])).hexdigest() != entry["sha256"]:
            raise RuntimeError("Source file checksum mismatch")
    if len([name for name in names if name.startswith("data/event_families/")]) != 160:
        raise RuntimeError("All 160 original Family files must be included")
    if "reference/01_Core_Identity.md" not in names:
        raise RuntimeError("Required runtime Core Identity is missing")
    bundle.extractall(destination)
with open(os.environ["GITHUB_OUTPUT"], "a") as output:
    output.write("root=" + str(destination) + "\\n")
print(f"Verified and extracted {len(names)} source files; Android build has not run yet")
'''

TEST_GATE = '''import json
from pathlib import Path
phases = "P0 P1 P2 P3 P4 P5_contract P5_recovery P5_http P5_runtime P5_hourly P5_effects P5_clock P5_restore P5_month P5_disaster P5_mobile P5_host_resume P5_oauth P5_android_dependencies".split()
reports = [json.loads(Path(f"reports/{phase}_tests.json").read_text()) for phase in phases]
if any(report["status"] != "PASS" for report in reports) or sum(report["test_count"] for report in reports) != 378:
    raise RuntimeError("All 378 fixture tests must pass before building the APK")
print("378 fixture tests PASS; these are not Android device tests")
'''

APK_GATE = '''import hashlib, json, os, shutil
from pathlib import Path
report = json.loads(Path("reports/P5_android_build.json").read_text())
apk = Path("android-probe/probe/build/outputs/apk/debug/probe-debug.apk")
if report.get("status") != "APK_BUILT_DEVICE_NOT_RUN" or not report.get("apk_built") or not apk.is_file():
    raise RuntimeError("No validated APK was produced")
if hashlib.sha256(apk.read_bytes()).hexdigest() != report["apk_sha256"]:
    raise RuntimeError("APK checksum mismatch")
destination = Path(os.environ["RUNNER_TEMP"]) / "mio-p5-apk"
destination.mkdir()
shutil.copy2(apk, destination / "MIO_P5_Device_Probe.apk")
print("P5 qualification APK built; real phone execution NOT_RUN")
'''

def heredoc(code):
    return '\n'.join('          ' + line for line in ('python3 - <<\'PY\'\n' + code.rstrip() + '\nPY').splitlines()) + '\n'

def generate():
    sha = hashlib.sha256(ARCHIVE.read_bytes()).hexdigest()
    workflow = '''name: MIO P5 phone build

on:
  workflow_dispatch:

permissions:
  contents: read

concurrency:
  group: mio-p5-phone-${{ github.ref }}
  cancel-in-progress: false

jobs:
  qualify-and-build:
    runs-on: ubuntu-24.04
    timeout-minutes: 60
    steps:
      - name: Checkout source ZIP
        uses: actions/checkout@v7
        with:
          persist-credentials: false
      - name: Verify and extract provided source ZIP
        id: source
        shell: bash
        run: |
'''
    workflow += heredoc(EXTRACT.replace('__SOURCE_SHA__', sha))
    workflow += '''      - name: Python 3.13
        uses: actions/setup-python@v7
        with:
          python-version: '3.13'
      - name: JDK 17
        uses: actions/setup-java@v6
        with:
          distribution: temurin
          java-version: '17'
      - name: Gradle 8.13
        uses: gradle/actions/setup-gradle@v6
        with:
          gradle-version: '8.13'
          cache-provider: basic
          cache-disabled: true
          build-scan-publish: false
      - name: Android SDK packages
        shell: bash
        run: |
          mio_sdkmanager="$(command -v sdkmanager || true)"
          if [[ -z "$mio_sdkmanager" ]]; then
            mio_sdkmanager="${ANDROID_HOME:?Android SDK is missing}/cmdline-tools/latest/bin/sdkmanager"
          fi
          (yes || true) | "$mio_sdkmanager" --licenses > "$RUNNER_TEMP/mio-sdk-licenses.log"
          "$mio_sdkmanager" 'platforms;android-36' 'build-tools;35.0.0'
      - name: Full fixture regression in phase order
        working-directory: ${{ steps.source.outputs.root }}
        run: |
          python -m pip install -r requirements.txt -c android-probe/constraints.txt
          python tools/test_report.py P0 P1 P2 P3 P4 P5_contract P5_recovery P5_http P5_runtime P5_hourly P5_effects P5_clock P5_restore P5_month P5_disaster P5_mobile P5_host_resume P5_oauth P5_android_dependencies
      - name: Verify fixture acceptance before APK build
        working-directory: ${{ steps.source.outputs.root }}
        shell: bash
        run: |
'''
    workflow += heredoc(TEST_GATE)
    workflow += '''      - name: Build original P5 Android probe
        id: android_build
        working-directory: ${{ steps.source.outputs.root }}
        run: python tools/build_android_probe.py
      - name: Show Android build error log
        if: ${{ always() && steps.android_build.outcome == 'failure' }}
        shell: bash
        run: |
          for mio_build_log in "$RUNNER_TEMP/mio-p5-source/reports/P5_android_wheels.log" "$RUNNER_TEMP/mio-p5-source/reports/P5_android_build.log"; do
            if [[ -f "$mio_build_log" ]]; then
              echo "Last 200 lines: $mio_build_log"
              tail -n 200 -- "$mio_build_log"
            else
              echo "Log not created: $mio_build_log"
            fi
          done
      - name: Verify and collect APK
        working-directory: ${{ steps.source.outputs.root }}
        shell: bash
        run: |
'''
    workflow += heredoc(APK_GATE)
    workflow += '''      - name: Downloadable APK
        uses: actions/upload-artifact@v7
        with:
          name: MIO_P5_Device_Probe
          path: ${{ runner.temp }}/mio-p5-apk/MIO_P5_Device_Probe.apk
          archive: false
          if-no-files-found: error
          retention-days: 7
      - name: Build diagnostics even on failure
        if: always()
        uses: actions/upload-artifact@v7
        with:
          name: MIO_P5_build_diagnostics
          path: |
            ${{ runner.temp }}/mio-p5-source/reports/*_tests.json
            ${{ runner.temp }}/mio-p5-source/reports/P5_android_build.json
            ${{ runner.temp }}/mio-p5-source/reports/P5_android_build.log
            ${{ runner.temp }}/mio-p5-source/reports/P5_android_wheels.json
            ${{ runner.temp }}/mio-p5-source/reports/P5_android_wheels.log
            ${{ runner.temp }}/mio-sdk-licenses.log
          if-no-files-found: warn
          retention-days: 7
'''
    output = ROOT / WORKFLOW_PATH
    output.write_text(workflow)
    deployment = ROOT / 'deployment'
    shutil.copy2(output, deployment / 'mio-p5-phone.yml')
    guide = '''<!doctype html>
<html lang="ko"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Fold8에서 MIO GitHub 빌드</title>
<style>
body{font:17px/1.65 system-ui,sans-serif;color:#172531;background:#f5f7fa;margin:0;padding:24px 18px}main{max-width:760px;margin:auto}h1{font-size:27px;line-height:1.3}h2{font-size:20px}section{background:white;border-radius:14px;padding:20px;margin:18px 0;border:1px solid #d9e0e8}button,a.action{display:inline-block;background:#145d46;color:white;border:0;border-radius:10px;padding:12px 16px;font-size:16px;text-decoration:none;margin:5px 5px 5px 0}code{overflow-wrap:anywhere;background:#edf1f5;padding:3px 5px}textarea{box-sizing:border-box;width:100%;min-height:210px;font:13px/1.5 monospace;padding:12px;border:1px solid #aab6c2;border-radius:8px;white-space:pre;overflow:auto}small{color:#55616d}.status{font-weight:600;color:#145d46;min-height:1.6em}li{margin:9px 0}a{color:#135b9c}</style>
<main><h1>Fold8에서 MIO P5 APK 빌드</h1>
<section><h2>첫 빌드 오류 수정본 등록</h2><p>첫 실행에서 <b>368개 fixture PASS</b>를 확인했습니다. 실패 원인은 <code>pydantic-core</code> Android 바이너리가 없는 것입니다. 수정본은 동일한 Pydantic 2.13.5/core 2.46.5를 고정하고 공식 upstream 소스로 Android wheel 두 개를 먼저 빌드합니다. 엔진 구조를 바꾸지 않습니다.</p><ol><li>아래 수정본 <code>MIO_P5_Build_Sources.zip</code>을 내려받아 GitHub 저장소의 기존 같은 이름 파일을 교체하고 Commit changes하세요.</li><li>기존 <code>.github/workflows/mio-p5-phone.yml</code>을 열어 편집 버튼을 누르고, 아래 <b>빌드 설정 전체 복사</b>로 본문 전체를 교체하여 Commit changes하세요.</li><li><b>Actions → MIO P5 phone build → Run workflow</b>에서 <b>새 실행</b>을 시작하세요. 기존 첫 실행의 Re-run jobs는 이전 설정을 사용합니다.</li></ol><a class="action" href="https://github.com/qkdghsthzn-cyber/Miooi/upload/main" target="_blank" rel="noopener noreferrer">소스 ZIP 교체</a><a class="action" href="https://github.com/qkdghsthzn-cyber/Miooi/edit/main/.github/workflows/mio-p5-phone.yml" target="_blank" rel="noopener noreferrer">빌드 설정 편집</a><a class="action" href="https://github.com/qkdghsthzn-cyber/Miooi/actions/workflows/mio-p5-phone.yml" target="_blank" rel="noopener noreferrer">새 빌드 실행</a><p>소스 ZIP과 설정을 둘 다 바꿔야 합니다. PC·플러그인·API 키는 필요 없습니다. wheel/Android 컴파일은 GitHub 서버에서 진행합니다. 실패하면 <b>Summary → Artifacts → MIO_P5_build_diagnostics</b>의 ZIP을 보내세요.</p><p>수정본의 전체 fixture와 패키지 검사 <b>378개가 로컬에서 PASS</b>입니다. 아직 수정본의 원격 빌드·APK·Fold8 실행은 확인되지 않았습니다.</p></section><p>소스 ZIP 한 개를 올리고 빌드 설정을 붙여 넣습니다. 휴대폰에서 압축을 풀 필요 없습니다. GitHub 플러그인 연결과 API 키 입력도 필요 없습니다.</p>
<section><h2>1. 비공개 저장소 만들기</h2><p>Chrome으로 GitHub에 로그인합니다. 메뉴가 좁으면 <b>데스크톱 사이트</b>를 켭니다.</p><a class="action" href="https://github.com/new" target="_blank" rel="noopener noreferrer">저장소 만들기</a><p>이름 예: <code>mio-world</code> · <b>Private</b> 선택 · README 추가를 켠 뒤 <b>Create repository</b>를 누릅니다.</p></section>
<section><h2>2. 소스 ZIP 그대로 올리기</h2><p>이 대화에서 받은 <code>MIO_P5_Build_Sources.zip</code>을 저장소의 <b>Code → Add file → Upload files</b>로 올립니다. <b>Commit changes</b>로 기본 브랜치에 저장하세요.</p><p>ZIP 내부 파일을 따로 올리지 않습니다. 이름은 <code>MIO_P5_Build_Sources.zip</code> 그대로이고, 저장소 맨 위에 있어야 합니다.</p></section>
<section><h2>3. 빌드 설정 붙여 넣기</h2><ol><li><b>Code → Add file → Create new file</b>을 선택합니다.</li><li>아래 <b>파일 경로 복사</b>를 누르고 이름 칸에 붙여 넣습니다.</li><li><b>빌드 설정 전체 복사</b>를 누르고 본문 편집기에 붙여 넣습니다.</li><li><b>Commit changes</b>를 눌러 기본 브랜치에 저장합니다. 보통 <code>main</code>입니다.</li></ol>
<button id="copy-path" type="button">파일 경로 복사</button><p><code id="workflow-path">__PATH__</code></p><button id="copy-workflow" type="button">빌드 설정 전체 복사</button><p id="copy-status" class="status" role="status" aria-live="polite"></p>
<details><summary>복사가 안 될 때: 설정 펼치기</summary><p>아래 칸을 눌러 전체 선택 → 복사하세요. 파일 경로도 직접 입력할 수 있습니다.</p><textarea id="workflow" readonly spellcheck="false" aria-label="GitHub 빌드 설정">__WORKFLOW__</textarea></details></section>
<section><h2>4. 실행하고 APK 받기</h2><p><b>Actions → MIO P5 phone build → Run workflow</b>를 누릅니다. 브랜치는 기본 브랜치로 두고 한 번 더 <b>Run workflow</b>를 누릅니다.</p><p>Actions 사용 안내가 나오면 내용을 확인하고 활성화합니다. 설정 변경은 별도로 필요하지 않습니다.</p><p>빌드 페이지가 초록색 성공으로 바뀌면 아래 <b>Artifacts → MIO_P5_Device_Probe</b>에서 APK를 받습니다. 압축 ZIP으로 제공되는 화면이라면 압축을 풀고 <code>MIO_P5_Device_Probe.apk</code>를 꺼냅니다.</p><p>빨간색 실패라면 실행의 <b>Summary → Artifacts → MIO_P5_build_diagnostics</b>를 눌러 ZIP을 받아 이 대화에 첨부해 주세요. <b>Download logs</b>에서 받는 <code>logs_…zip</code>과는 다른 파일입니다. 진단 파일이 없으면 <b>Show Android build error log</b>의 오류 문구를 복사해 보내세요.</p></section>
<section><h2>현재 확인한 범위</h2><p>기존 엔진·Core Identity·160 Family를 보존합니다. 첫 원격 소스 회귀는 368개 PASS이며 수정본은 새 binary receipt 검사 10개를 포함해 378개를 P0부터 순서대로 시험합니다. 모두 통과해야 APK를 만들고, 검증한 APK만 제공합니다.</p><p><b>첫 GitHub 실행: Python 3.13의 368개 테스트 PASS, Android 빌드 FAILED, APK 없음, Fold8 실행 NOT_RUN입니다. Android native wheel 공급 수정본의 원격 실행도 NOT_RUN입니다.</b> 결과 APK는 P5 검사 앱입니다. 완성된 overlay·로그인·상시 실행 앱은 다음 검증/개발 단계가 남아 있습니다.</p><p>실행 시 <a href="https://developer.android.com/studio/terms" target="_blank" rel="noopener noreferrer">Android SDK 약관</a>을 수락하고 SDK를 설치합니다. 저장소와 실행 결과에는 사용자의 원본 첨부 문서/사진·정본 DB·API 키가 포함되지 않습니다. GitHub 계정의 로그인/MFA 및 Actions 이용 한도는 그대로 적용됩니다.</p><small>소스 SHA-256: __SHA__<br>공식 안내: <a href="https://docs.github.com/en/repositories/working-with-files/managing-files/creating-new-files">파일 생성</a> · <a href="https://docs.github.com/en/actions/how-tos/manage-workflow-runs/manually-run-a-workflow">수동 실행</a> · <a href="https://docs.github.com/en/actions/how-tos/manage-workflow-runs/download-workflow-artifacts">결과 다운로드</a></small></section></main>
<script>
async function copyValue(value){
  const status=document.getElementById('copy-status');
  try{if(navigator.clipboard&&window.isSecureContext){await navigator.clipboard.writeText(value);status.textContent='복사했어요. GitHub에 붙여 넣으세요.';return;}}catch(e){}
  const field=document.createElement('textarea');field.value=value;field.style.position='fixed';field.style.left='-9999px';document.body.appendChild(field);field.focus();field.select();field.setSelectionRange(0,field.value.length);
  let copied=false;try{copied=document.execCommand('copy');}catch(e){}field.remove();status.textContent=copied?'복사했어요. GitHub에 붙여 넣으세요.':'자동 복사가 안 열렸어요. 아래 설정을 펼쳐 전체 선택 → 복사하세요.';
}
document.getElementById('copy-path').addEventListener('click',()=>copyValue(document.getElementById('workflow-path').textContent));
document.getElementById('copy-workflow').addEventListener('click',()=>copyValue(document.getElementById('workflow').value));
</script></html>
'''
    guide = guide.replace('__PATH__', WORKFLOW_PATH).replace('__WORKFLOW__', html.escape(workflow)).replace('__SHA__', sha)
    guide_path = deployment / 'MIO_GitHub_Fold8_Guide.html'
    guide_path.write_text(guide)
    return {'workflow': str(output), 'guide': str(guide_path), 'source_sha256': sha,
            'workflow_revision_remote_execution': 'NOT_RUN', 'apk_built_by_generator': False}

if __name__ == '__main__':
    print(json.dumps(generate(), indent=2))
