"""Run the actual native hourly stages against loopback fixtures, without keys."""
import json
import tempfile
from datetime import datetime,timedelta
from zoneinfo import ZoneInfo
from pathlib import Path
from core.models import WorldState,Item,Provenance
from core.event_grammar import Grammar
from core.validator import Validator
from agents.simulator_policy import simulator_decision
from connectors.mock_native import fixture_purchase
from connectors.http_json import HTTPJSON
from connectors.notion import NotionConnector
from connectors.google_calendar import CalendarConnector
from connectors.native_http_adapter import NativeHTTPAdapter
from connectors.write_coordinator import WriteCoordinator
from connectors.canonical_runtime import CanonicalValidator,CanonicalCacheBridge
from connectors.runtime_bootstrap import InitializationRequest,RuntimeResources,NativeBootstrapper
from runtime.hourly import NativeHourlyRuntime
from tests.native_http_server import NativeHTTPFixture


class DeclaredFixturePolicy:
    def __init__(self): self.calls=0
    def decide(self,state,event):
        self.calls+=1
        return simulator_decision(state,event)


def run_demo(hours=168,month_boundary=False):
    native,_,now=fixture_purchase(); server=NativeHTTPFixture(native)
    if month_boundary:
        now=datetime(2026,10,31,12,tzinfo=ZoneInfo('Asia/Tokyo'))
        from connectors.native_plans import rich,money_field
        def set_period(month):
            key='fixture.period'
            if key not in server.children['fixture.wallet']: server.children['fixture.wallet'].append(key)
            server.objects[key]={'object':'block','id':key,'type':'bulleted_list_item','last_edited_time':'month-v1',
                'parent':{'type':'page_id','page_id':'fixture.wallet'},'bulleted_list_item':{'rich_text':rich('支出対象月: '+month)}}
            server.version(server.objects['fixture.wallet'])
        set_period('2026-10')
    for role in ['relationships','taste','memory','world']:
        identifier='fixture.'+role
        server.objects[identifier]={'object':'page','id':identifier,'last_edited_time':'v1','archived':False}
        server.children[identifier]=[]
    try:
        with tempfile.TemporaryDirectory() as tmp:
            h=HTTPJSON(server.url,'synthetic-fixture-only',fixture=True)
            notion=NotionConnector(http=h); calendar=CalendarConnector('fixture.calendar',http=h)
            coordinator=WriteCoordinator(Path(tmp)/'runtime.sqlite3',{'notion':NativeHTTPAdapter(notion),'calendar':NativeHTTPAdapter(calendar)})
            try:
                bridge=CanonicalCacheBridge(coordinator,CanonicalValidator(Validator(Grammar()),allow_internal=True))
                world={'time':now.isoformat(),'timezone':'Asia/Tokyo','place':'home','activity':'idle','mood':'calm',
                    'privacy':'private','next_commitment':None,'journey':None,
                    'needs':{'energy':75,'hunger':20,'social_need':25,'novelty_need':25,'creative_urge':30,
                             'comfort_need':20,'shopping_interest':20,'privacy_need':20}}
                catalog={'fixture.catalog':Item(item_id='fixture.catalog',name='fixture skirt',status='available',category='clothing',
                    price=4800,brand=None,location=None,condition=None,provenance=Provenance(source='mock',ref='declared fixture catalog'))}
                request=InitializationRequest(initialization_ref='explicit demo world seed, not actual Mio',internal_values_ref='declared fixture needs',
                    world=world,travel_minutes={'home->home':0,'home->cafe':15,'cafe->home':15,'home->school':25,'school->home':25},
                    feature_flags={'adult_life':False},relationships={},npc_age_refs={},npc_metric_refs={},taste={},taste_metric_refs={},catalog=catalog)
                resources=RuntimeResources(wallet_page='fixture.wallet',inventory_source='fixture.inventory',continuity_page='fixture.continuity',
                    relationships_page='fixture.relationships',taste_page='fixture.taste',memory_page='fixture.memory',
                    world_runtime_page='fixture.world',calendar_id='fixture.calendar')
                NativeBootstrapper(notion,calendar,lambda:now).initialize(bridge,request,resources)
                agent=DeclaredFixturePolicy()
                runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                if month_boundary:
                    ticks=[]; restarted=False
                    for index in range(hours):
                        tick_time=now+timedelta(hours=index)
                        if index==12:
                            # Explicit synthetic provider month close, not a live
                            # reset performed or inferred by the runtime reader.
                            set_period('2026-11')
                            server.edit('fixture.monthly',money_field(server.objects['fixture.monthly'],'今月の支出:',0)[1])
                        if index==24:
                            balance=money_field(server.objects['fixture.balance'],'残高:',0)[0]-100
                            key='fixture.late_october_expense'
                            server.objects[key]={'object':'block','id':key,'type':'table_row','last_edited_time':'late-v1',
                                'parent':{'type':'block_id','block_id':'fixture.moneylog'},'table_row':{'cells':[rich(c) for c in
                                    ['2026-10-31','EXPENSE','declared synthetic late October expense','-¥100',f'¥{balance:,}']]}}
                            server.children['fixture.moneylog'].append(key); server.version(server.objects['fixture.moneylog'])
                            server.edit('fixture.balance',money_field(server.objects['fixture.balance'],'残高:',balance)[1])
                        if index==30:
                            coordinator.close()
                            coordinator=WriteCoordinator(Path(tmp)/'runtime.sqlite3',{'notion':NativeHTTPAdapter(notion),'calendar':NativeHTTPAdapter(calendar)})
                            bridge=CanonicalCacheBridge(coordinator,CanonicalValidator(Validator(Grammar()),allow_internal=True))
                            runtime=NativeHourlyRuntime(bridge,notion,calendar,lambda:bridge.state().world.time,agent)
                            restarted=True
                        ticks.append(runtime.tick(tick_time))
                else: ticks=runtime.run(hours)
                state=bridge.state()
                Validator.invariants(state)
                from connectors.native_restore import NativeRuntimeRestorer
                bridge.db.execute('DELETE FROM runtime_cache')
                bridge.db.execute('DELETE FROM runtime_continuity_archive')
                restored=NativeRuntimeRestorer(bridge,notion,calendar,lambda:state.world.time).restore()
                recovered=bridge.state()
                assert state.model_dump(exclude={'revision','notion_stale','calendar_stale'})==recovered.model_dump(exclude={'revision','notion_stale','calendar_stale'})
                counts={r[0]:r[1] for r in coordinator.db.execute('SELECT status,count(*) FROM hourly_decisions GROUP BY status')}
                snapshots=coordinator.db.execute("SELECT count(*) FROM hourly_snapshots WHERE status='VERIFIED'").fetchone()[0]
                unresolved=coordinator.db.execute("SELECT count(*) FROM cache_bindings WHERE status NOT IN ('PUBLISHED','ROLLED_BACK')").fetchone()[0]
                all_finished=len(ticks)==hours and all(t['status']=='COMPLETED' for t in ticks)
                report={'status':'PASS' if all_finished and snapshots==hours and unresolved==0 else 'FAIL',
                    'scope':'loopback HTTP fixture only; no live GPT or canonical server writes',
                    'requested_hours':hours,'completed_hours':len(ticks),'decision_calls':agent.calls,'decision_status_counts':counts,
                    'verified_world_snapshots':snapshots,'unresolved_cache_bindings':unresolved,'actual_canonical_writes':0,
                    'http_requests':len(server.calls),'final_time':state.world.time.isoformat(),'fixture_final_balance_jpy':state.wallet.balance,
                    'fixture_owned_items':len(state.inventory),'causal_archive_count':coordinator.db.execute('SELECT count(*) FROM runtime_continuity_archive').fetchone()[0],
                    'rule_invariants':'PASS','native_effects_not_implemented':[],
                    'native_cache_and_archive_restoration':restored['status'],
                    'unmapped_raw_relationship_taste_sources_preserved':True}
                if month_boundary:
                    anchor=json.loads(bridge.db.execute('SELECT body FROM native_rebase_anchor').fetchone()[0])
                    imports=[entry for entry in recovered.wallet.ledger if entry.ledger_id=='native:fixture.late_october_expense']
                    assert hours>=31 and restarted and len(imports)==1 and imports[0].amount==-100
                    assert anchor['month']=='2026-11' and anchor['month_totals']['2026-10']>=100
                    report.update(native_month=anchor['month'],proved_month_totals=anchor['month_totals'],
                        historical_expense_deltas=anchor['historical_expense_deltas'],
                        synthetic_late_expense_imports=len(imports),coordinator_restarted=restarted,
                        native_month_reset='explicit fixture provider edit; runtime reconciliation is read-only')
                return report
            finally: coordinator.close()
    finally: server.close()
