"""Build the exact upstream Pydantic core for Android, without changing schemas."""
import hashlib
import io
import json
import os
import platform
import re
import shutil
import struct
import subprocess
import tarfile
import tempfile
import urllib.request
import zipfile
from email.parser import Parser
from pathlib import Path, PurePosixPath

ROOT = Path(__file__).resolve().parents[1]
CORE_VERSION = '2.46.5'
SOURCE_SHA256 = '10416c15b8839ecc4ef4d0885da76da6fd0f67333a0eb8aff6d93c4b8f2910fc'
CIBW_VERSION = '4.3.0'
ABIS = {'arm64_v8a': 183, 'x86_64': 62}


def extract_source(raw, destination):
    if hashlib.sha256(raw).hexdigest() != SOURCE_SHA256:
        raise ValueError('Upstream pydantic-core source checksum mismatch')
    with tarfile.open(fileobj=io.BytesIO(raw), mode='r:gz') as archive:
        prefix = 'pydantic_core-' + CORE_VERSION
        names = set()
        for member in archive.getmembers():
            path = PurePosixPath(member.name)
            if (path.is_absolute() or '..' in path.parts or '\\' in member.name
                    or not path.parts or path.parts[0] != prefix
                    or not (member.isfile() or member.isdir()) or member.name in names):
                raise ValueError('Unsafe upstream source archive')
            names.add(member.name)
        archive.extractall(destination, filter='data')
    source = destination / prefix
    if not all((source / name).is_file() for name in ['Cargo.toml', 'Cargo.lock', 'pyproject.toml']):
        raise ValueError('Incomplete upstream source archive')
    return source


def inspect_elf(raw, machine):
    if len(raw) < 64 or raw[:6] != b'\x7fELF\x02\x01':
        raise ValueError('Expected a little-endian ELF64 Android library')
    if struct.unpack_from('<H', raw, 16)[0] != 3 or struct.unpack_from('<H', raw, 18)[0] != machine:
        raise ValueError('Android library architecture/type mismatch')
    offset = struct.unpack_from('<Q', raw, 32)[0]
    size, count = struct.unpack_from('<HH', raw, 54)
    if size < 56 or not count or offset + size * count > len(raw):
        raise ValueError('Invalid ELF program headers')
    alignments = []
    for index in range(count):
        entry = offset + index * size
        if struct.unpack_from('<I', raw, entry)[0] == 1:
            alignment = struct.unpack_from('<Q', raw, entry + 48)[0]
            file_offset, address = struct.unpack_from('<QQ', raw, entry + 8)
            if alignment < 16384 or alignment & (alignment - 1) or file_offset % 16384 != address % 16384:
                raise ValueError('Android library fails 16 KiB LOAD alignment check')
            alignments.append(alignment)
    if not alignments:
        raise ValueError('Android library has no LOAD segments')
    return alignments


def inspect_wheel(path, abi):
    path = Path(path)
    tag = 'cp313-cp313-android_24_' + abi
    if abi not in ABIS or path.name != f'pydantic_core-{CORE_VERSION}-{tag}.whl':
        raise ValueError('Wrong package/version/Python/Android wheel tag')
    with zipfile.ZipFile(path) as wheel:
        names = wheel.namelist()
        if len(names) != len(set(names)) or wheel.testzip() is not None:
            raise ValueError('Invalid wheel ZIP')
        metadata_root = f'pydantic_core-{CORE_VERSION}.dist-info/'
        metadata = Parser().parsestr(wheel.read(metadata_root + 'METADATA').decode())
        wheel_metadata = Parser().parsestr(wheel.read(metadata_root + 'WHEEL').decode())
        if (re.sub(r'[-_.]+', '-', metadata['Name'] or '').lower() != 'pydantic-core'
                or metadata['Version'] != CORE_VERSION or tag not in wheel_metadata.get_all('Tag', [])):
            raise ValueError('Wheel metadata/version/tag mismatch')
        libraries = [name for name in names if name.endswith('.so')]
        if not any(name.startswith('pydantic_core/_pydantic_core.') for name in libraries):
            raise ValueError('Native Pydantic core extension is absent')
        alignment = {name: inspect_elf(wheel.read(name), ABIS[abi]) for name in libraries}
    return {'file': str(path.resolve()), 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
            'abi': abi, 'elf_load_alignments': alignment, 'android_execution': 'NOT_RUN'}


def collect_wheels(directory):
    found = list(Path(directory).glob('*.whl'))
    expected = {f'pydantic_core-{CORE_VERSION}-cp313-cp313-android_24_{abi}.whl' for abi in ABIS}
    if {path.name for path in found} != expected:
        raise ValueError('Both exact arm64-v8a and x86_64 Android wheels are required')
    return [inspect_wheel(Path(directory) / name, abi) for abi, name in
            ((abi, f'pydantic_core-{CORE_VERSION}-cp313-cp313-android_24_{abi}.whl') for abi in ABIS)]


def download(url):
    with urllib.request.urlopen(url, timeout=120) as response:
        return response.read()


def build_wheels(python):
    report_path = ROOT / 'reports/P5_android_wheels.json'
    log_path = ROOT / 'reports/P5_android_wheels.log'
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report = {'status': 'BUILD_FAILED', 'upstream_version': CORE_VERSION,
              'source_sha256': SOURCE_SHA256, 'cibuildwheel': CIBW_VERSION,
              'android_execution': 'NOT_RUN', 'production_enabled': False, 'wheels': []}
    try:
        if platform.system() != 'Linux' or platform.machine() != 'x86_64':
            raise RuntimeError('This build recipe requires Linux x86_64')
        parent = ROOT / 'android-probe/build'
        parent.mkdir(parents=True, exist_ok=True)
        work = Path(tempfile.mkdtemp(prefix='mio-native-', dir=parent))
        output = work / 'wheels'
        output.mkdir()
        # Work/output are fresh on every attempt; a failed build cannot reuse old wheels.
        with log_path.open('w') as log:
            def run(args, env=None):
                log.write('Command: ' + json.dumps([str(arg) for arg in args]) + '\n'); log.flush()
                result = subprocess.run(args, env=env, stdout=log, stderr=subprocess.STDOUT,
                                        timeout=2700)
                if result.returncode:
                    raise RuntimeError(f'Android wheel command failed with exit {result.returncode}; see P5_android_wheels.log')
            env = dict(os.environ, RUSTUP_TOOLCHAIN='1.88.0')
            rustup = shutil.which('rustup')
            if not rustup:
                url = 'https://static.rust-lang.org/rustup/archive/1.28.2/x86_64-unknown-linux-gnu/rustup-init'
                checksum = download(url + '.sha256').decode().split()[0]
                installer = download(url)
                if not re.fullmatch('[0-9a-f]{64}', checksum) or hashlib.sha256(installer).hexdigest() != checksum:
                    raise RuntimeError('Rustup installer checksum mismatch')
                init = work / 'rustup-init'
                init.write_bytes(installer); init.chmod(0o755)
                env.update(RUSTUP_HOME=str(work / 'rustup'), CARGO_HOME=str(work / 'cargo'))
                env['PATH'] = str(work / 'cargo/bin') + os.pathsep + env.get('PATH', '')
                run([str(init), '-y', '--no-modify-path', '--default-toolchain', 'none'], env)
                rustup = str(work / 'cargo/bin/rustup')
            run([rustup, 'toolchain', 'install', '1.88.0', '--profile', 'minimal'], env)
            run([python, '-m', 'pip', 'install', f'cibuildwheel=={CIBW_VERSION}'], env)
            metadata = json.loads(download(f'https://pypi.org/pypi/pydantic-core/{CORE_VERSION}/json'))
            sources = [f for f in metadata['urls'] if f['packagetype'] == 'sdist' and
                       f['filename'] == f'pydantic_core-{CORE_VERSION}.tar.gz']
            if len(sources) != 1 or sources[0]['digests']['sha256'] != SOURCE_SHA256:
                raise RuntimeError('Unexpected upstream Pydantic core release')
            source = extract_source(download(sources[0]['url']), work)
            # cibuildwheel supplies the actual target CPython libpython/sysconfig,
            # NDK compiler, Cargo linker, target and PyO3 cross-library directory.
            run([python, '-m', 'cibuildwheel', str(source), '--platform', 'android',
                 '--config-file', str(ROOT / 'android-probe/android-wheels.toml'),
                 '--output-dir', str(output)], env)
        receipt = collect_wheels(output)
        report.update(status='WHEELS_BUILT_STATIC_CHECKS_PASS_DEVICE_NOT_RUN',
                      wheel_dir=str(output.resolve()), wheels=receipt)
    except Exception as exc:
        report.update(error_type=type(exc).__name__, reason=str(exc))
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    return report
