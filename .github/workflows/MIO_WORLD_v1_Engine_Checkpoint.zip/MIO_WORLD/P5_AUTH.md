# P5 Calendar 인증 갱신 계약

기존 Notion/Calendar native 구조와 MASTER SPEC의 실패 복구·정본 gate를 보존한다. 이번 범위는 access token의 갱신, 인증 취소 시 차단, HTTP 중복 요청 방지와 loopback fixture 검증이다. 실제 계정 로그인/동의, Android 암호화 저장, production 연동 합격을 완료했다고 표시하지 않는다.

## 구현

`OAuthGrant`는 client ID·refresh/access token·만료 시각·기존 scope를 검증한다. repr은 비밀 값을 출력하지 않는다. `MemoryTokenStore`는 잠금 아래 grant를 교체하며 프로세스 메모리만 사용한다. 파일/환경변수/세계 DB에 credential을 쓰지 않고, 재시작 보존이나 암호화를 제공한다고 주장하지 않는다.

`GoogleTokenEndpoint`는 Google HTTPS `/token` 또는 명시적인 loopback fixture만 허용한다. form-urlencoded POST에 refresh_token/client_id/grant_type와 필요한 경우 client_secret을 담고, Bearer Authorization을 보내지 않는다. redirect를 따르지 않고 응답은 64 KiB 이내로 제한한다. 오류 본문·설명·token을 예외/보고서에 출력하지 않는다. 실제 OAuth 동의에서 얻은 grant가 전제이며 권한/refresh token을 임의 생성하지 않는다. Android/iOS 유형에 적용되지 않는 client_secret을 필수로 강제하지 않는다.

`GoogleAccessTokenProvider`는 유효기간이 기본 60초 이하 남았을 때 갱신한다. 저장소 lock을 공유하는 동시 호출은 새 credential을 재사용한다. 응답 lifetime/type/scope를 확인하고 refresh token이 생략되면 이전 값을 유지하며 회전 값이 있으면 메모리에 저장한다. 만료 기준은 요청 시작 시각으로 계산하고 너무 늦게 도착한 응답을 거부한다. 시계 역행/naive 시각도 거부한다.

| 조건 | 처리 | 요청·사실 확정에 미치는 영향 |
|---|---|---|
| 충분히 유효한 access token | 그대로 사용 | 불필요한 교환 없음 |
| 만료/임박/만료 시각 미확인 | preflight refresh 1회 | 실패하면 API 요청 전 중단 |
| invalid_grant / refresh grant 만료 | 저장소 무효화, 재인증 필요 | 새 grant를 명시적으로 넣기 전 자동 교환 반복 금지 |
| OAuth client/scope 오류 | 해당 revision 보류 | 구성 변경 전 재시도 금지 |
| 일시 장애/단절/잘못된 응답 | 기본 30초 retry 지연 | 기존 grant 유지, token·정본 사실 확정 금지 |
| API GET 401 | credential을 만료 표시한 뒤 갱신·GET 1회 재시도 | 두 번째 401이면 재인증 필요 |
| API POST/PATCH/DELETE 401 | 원래 HTTPFailure 전달 | 오류 응답 때문에 쓰기 요청을 자동으로 재전송하지 않음 |
| API 403/429/5xx/단절 | 기존 실패 경로 유지 | transport 자동 재시도 없음; coordinator가 원래 intent로 복구 |
| 늦은 worker의 이전 token 401 | 현재 token과 비교 | 이미 교체된 token/진행 중 retry 지연을 지우지 않음 |

`HTTPJSON(token_provider=...)`는 static token과 동시에 설정할 수 없고 Google credential을 Notion host에 보내지 않는다. fixture/canonical transport가 섞이지 않아야 한다. 기존 static Notion credential 경로는 그대로다. dry-run에는 credential 조회·갱신·HTTP 호출이 없다. `CalendarConnector(token_provider=...)`를 쓸 때 무관한 GOOGLE_ACCESS_TOKEN 환경변수를 대신 읽지 않는다. 실제 제공된 http에는 credential source를 추가하지 않는다.

재인증은 `store.save(new_grant)`로 명시적으로 공급한다. 이 호출은 실제 로그인/계정 동의 UI의 구현을 대신하지 않는다. 현재 지원되는 store는 메모리뿐이며 Android Keystore sealed store는 다음 host 연결 작업이다. 토큰 회전을 재시작 후 보존했다고 표시하지 않는다. 필요 scope는 caller가 기존 granted scope에 대해 검증하며 자동으로 확대하지 않는다.

## 세계·거래 gate

token 획득 자체는 영수증/정본 검증이 아니다. NativeHTTPAdapter와 coordinator의 prepare→apply/observe→receipt→commit/rollback 및 cache publication을 그대로 거친다. fixture의 Calendar POST 401은 1회 전송 후 ROLLED_BACK이며 native event·canonical commit이 없다. token 갱신 후 실제 fixture 쓰기를 실행한 경우에도 native 재읽기 영수증을 통해 1회 commit을 확인한다. production 쓰기 차단을 제거하지 않았다.

호스트 지연 뒤 Calendar grant가 취소되면 `revalidate_host_resume`는 WAITING_FRESH_NATIVE_READ와 durable gate를 유지한다. 새 grant를 공급한 뒤에도 최신 Notion/Calendar 읽기를 통과해야 VERIFIED가 된다. wallet/세계 시계는 fixture 값으로 보존되며 새 판단이나 과거 행동을 만들지 않는다.

## 시험·실행

35개 OAuth 시험과 mobile 18개를 포함한 전체 368개 회귀를 개발 Linux/Python 3.12 환경에서 재실행했다. 168시간·월말 48시간·DB 유실 fixture도 PASS다. P2 10,000시간은 이전 PASS를 보존하며 core/data/reference는 byte-for-byte 동일하다.

```bash
python tools/test_report.py P5_oauth
python mio.py p5-oauth-demo
python tools/mobile_probe.py oauth --workspace /tmp/mio-qualification
```

데모는 만료 토큰 갱신→2시간 clock-only→invalid_grant로 fresh gate 유지→모의 새 동의→fresh 확인→POST 401 1회 전송·성공 쓰기 0회→다음 시간 진행을 검증한다. 실제 사용자 동의나 Google 서비스 왕복을 수행하지 않는다. `android-probe/`에 인증 만료 복구 버튼 소스를 추가했으나 APK 컴파일/기기 실행은 NOT_RUN이다. 증거: `reports/P5_oauth_tests.json`, `reports/P5_oauth_demo.json`, `reports/P5_mobile_oauth.json`, `reports/P5_auth_summary.json`.

## 미완료

Android 계정 로그인과 동의/클라이언트 등록, 안전한 입력·암호화/원자적 persistent token store, 재시작 후 token 회전 보존, 키 폐기·기기 밖 복원, 실제 grant lifetime와 권한 확인, 실제 서비스 왕복/오류 복구, Android scheduler/lifecycle·실기기 시험이 남았다. DPoP-bound token은 지원하지 않으며 Bearer만 수용한다. 인증 기능 추가가 P5 완료나 P6/P7 제품 기능 합격을 의미하지 않는다.

공식 참고: [Google native OAuth refresh](https://developers.google.com/identity/protocols/oauth2/native-app#offline), [Google Calendar scopes](https://developers.google.com/workspace/calendar/api/auth), [Google token response/errors](https://developers.google.com/identity/openid-connect/reference).
