"""P5 device qualification only; this is not a live world or P7 product UI."""
