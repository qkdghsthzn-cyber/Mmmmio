"""Standard-library entrypoint which survives missing Android binary wheels.

Only dedicated fixture storage and loopback HTTP may be used. Never load .env,
read credentials, change cwd, or upgrade a fixture into canonical reality.
"""
import importlib
import json
import os
import platform
import sqlite3
import ssl
import sys
import tempfile
from contextlib import contextmanager
from pathlib import Path


def _json(value):
    return json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False)


def runtime_info():
    result = {"python": platform.python_version(), "machine": platform.machine(),
              "platform": sys.platform, "android_verified": False,
              "page_size": os.sysconf("SC_PAGE_SIZE") if hasattr(os, "sysconf") else None}
    try:
        from java import jclass
        build = jclass("android.os.Build")
        result.update(android_verified=True, android_sdk=int(jclass("android.os.Build$VERSION").SDK_INT),
                      device_model=str(build.MODEL), supported_abis=[str(x) for x in build.SUPPORTED_ABIS])
    except (ImportError, AttributeError, RuntimeError):
        # A Linux success must never be shown as a Z Fold8 execution success.
        pass
    return result


def _home(directory):
    home = Path(directory).resolve() / "mio-qualification-v1"
    home.mkdir(parents=True, exist_ok=True)
    return home


@contextmanager
def _worker(home):
    db = sqlite3.connect(home / "fixture.worker", isolation_level=None, timeout=0)
    try:
        db.execute("CREATE TABLE IF NOT EXISTS worker(id INTEGER)")
        db.execute("BEGIN IMMEDIATE")
        yield
    finally:
        if db.in_transaction:
            db.execute("ROLLBACK")
        db.close()


def _storage(directory):
    # No primary state DB is touched by capability tests.
    with tempfile.TemporaryDirectory(prefix="capabilities-", dir=directory) as tmp:
        tmp = Path(tmp)
        source = sqlite3.connect(tmp / "wal.sqlite3", isolation_level=None)
        destination = sqlite3.connect(tmp / "copy.sqlite3", isolation_level=None)
        try:
            if source.execute("PRAGMA journal_mode=WAL").fetchone()[0] != "wal":
                raise RuntimeError("WAL unavailable")
            source.execute("CREATE TABLE proof(value TEXT)")
            source.execute("INSERT INTO proof VALUES('committed')")
            source.backup(destination)
            assert destination.execute("SELECT value FROM proof").fetchone()[0] == "committed"
            second = sqlite3.connect(tmp / "wal.sqlite3", isolation_level=None, timeout=0)
            try:
                source.execute("BEGIN IMMEDIATE")
                try:
                    second.execute("BEGIN IMMEDIATE")
                except sqlite3.OperationalError:
                    pass
                else:
                    raise RuntimeError("worker lock is not exclusive")
                source.execute("ROLLBACK")
            finally:
                second.close()
        finally:
            destination.close(); source.close()
        from connectors.database_recovery import _write
        _write(tmp / "atomic.json", b'{"complete":true}')
        assert json.loads((tmp / "atomic.json").read_text())["complete"]
        import fcntl
        first = os.open(tmp / "file.lock", os.O_CREAT | os.O_RDWR, 0o600)
        second = os.open(tmp / "file.lock", os.O_RDWR)
        try:
            fcntl.flock(first, fcntl.LOCK_EX | fcntl.LOCK_NB)
            try:
                fcntl.flock(second, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError:
                pass
            else:
                raise RuntimeError("vault lock is not exclusive")
        finally:
            os.close(second); os.close(first)
    return {"wal_online_backup": True, "sqlite_worker_lock": True,
            "fsync_atomic_replace": True, "vault_file_lock": True}


def diagnose(directory):
    info = runtime_info()
    report = {"scope": "device qualification; isolated fixture only", "runtime": info,
              "actual_api_calls": 0, "actual_canonical_writes": 0,
              "production_enabled": False, "checks": []}
    home = _home(directory)
    def check(name, function):
        try:
            detail = function()
            report["checks"].append({"name": name, "status": "PASS", "detail": detail})
        except Exception as error:
            # Exception text may contain private paths or secrets. Return type only.
            report["checks"].append({"name": name, "status": "FAIL", "error_type": type(error).__name__})
    def dependencies():
        versions = {}
        for name in ("pydantic", "pydantic_core", "yaml", "tzdata"):
            module = importlib.import_module(name)
            versions[name] = module.__version__
        version = tuple(int(x) for x in versions["pydantic"].split('.')[:2])
        if not (2, 13) <= version < (3, 0):
            raise RuntimeError("existing pydantic contract not supported")
        return versions
    def engine():
        from core.event_grammar import Grammar
        from core.mock_state import mock_state
        from core.models import State
        from core.validator import Validator
        grammar = Grammar()
        if len(grammar.families) != 160:
            raise RuntimeError("full Family data required")
        state = State.model_validate_json(mock_state().model_dump_json())
        Validator.invariants(state)
        return {"families": len(grammar.families), "mode": state.mode}
    def timezone():
        from zoneinfo import ZoneInfo
        from datetime import datetime
        return {"asia_seoul_offset_seconds": int(datetime(2026, 10, 6, tzinfo=ZoneInfo("Asia/Seoul")).utcoffset().total_seconds())}
    def tls():
        context = ssl.create_default_context()
        if not context.get_ca_certs():
            raise RuntimeError("CA certificates missing")
        return {"certificate_validation": context.verify_mode == ssl.CERT_REQUIRED,
                "external_request_performed": False}
    with _worker(home):
        check("python_dependencies", dependencies)
        check("full_engine_schema_and_data", engine)
        check("sqlite_and_filesystem", lambda: _storage(home))
        check("timezone", timezone)
        check("tls_certificate_store", tls)
    passed = all(c["status"] == "PASS" for c in report["checks"])
    report["status"] = ("ANDROID_CAPABILITIES_PASS" if info["android_verified"] else "HOST_CAPABILITIES_PASS_ANDROID_NOT_RUN") if passed else "CAPABILITY_FAILURE"
    return report


def run_mock(directory, hours=6):
    """Persist real existing simulator ticks, reopening on every invocation."""
    if type(hours) is not int or not 1 <= hours <= 24:
        raise ValueError("fixture hours must be an integer in 1..24")
    home = _home(directory)
    from core.state_manager import StateStore
    from core.mock_state import mock_state
    from core.simulator import Simulator
    from core.chain_engine import ChainEngine
    from core.event_grammar import Grammar
    from core.validator import Validator
    with _worker(home):
        store = StateStore(home / "fixture-world.sqlite3")
        try:
            existing = store.db.execute("SELECT body FROM state WHERE id=1").fetchone()
            if existing is not None and store.load().mode != "mock":
                raise ValueError("qualification storage contains a non-fixture world")
            store.initialize(mock_state())
            before = len(store.records("ticks"))
            simulator = Simulator(store, seed=42, chain=ChainEngine(Grammar()))
            result = simulator.run(hours)
            after = len(store.records("ticks"))
            state = store.load()
            Validator.invariants(state)
            if after - before != hours:
                raise RuntimeError("fixture tick count differs")
            return {"status": "PASS", "scope": "artificial hours; not actual Mio facts", "mode": state.mode,
                    "runtime": runtime_info(), "requested_hours": hours, "previous_ticks": before,
                    "stored_ticks": after, "fixture_time": state.world.time.isoformat(),
                    "fixture_balance_jpy": state.wallet.balance, "rule_invariants": "PASS",
                    "actual_api_calls": 0, "actual_canonical_writes": 0,
                    "production_enabled": False, "metrics": result}
        finally:
            store.close()


def run_native_fixture(directory):
    home = _home(directory)
    with _worker(home):
        from tools.p5_hourly_demo import run_demo
        report = run_demo(6)
    report["runtime"] = runtime_info()
    report["qualification_hours"] = 6
    return report


def run_database_loss_fixture(directory):
    home = _home(directory)
    with _worker(home):
        from tools.p5_disaster_demo import run_demo
        report = run_demo()
    report["runtime"] = runtime_info()
    return report


def run_host_resume_fixture(directory):
    home = _home(directory)
    with _worker(home):
        from tools.p5_host_resume_demo import run_demo
        report = run_demo()
    report['runtime'] = runtime_info()
    # Desktop NOT_RUN marker is retained until a genuine Android invocation.
    report['android_execution'] = 'EXECUTED_ON_ANDROID' if report['runtime']['android_verified'] else 'NOT_RUN'
    return report


def run_oauth_fixture(directory):
    home = _home(directory)
    with _worker(home):
        from tools.p5_oauth_demo import run_demo
        report = run_demo()
    report['runtime'] = runtime_info()
    report['android_execution'] = 'EXECUTED_ON_ANDROID' if report['runtime']['android_verified'] else 'NOT_RUN'
    return report


def entrypoint(directory, action):
    functions = {"diagnose": diagnose, "mock": run_mock, "native": run_native_fixture,
                 "database_loss": run_database_loss_fixture, "host_resume": run_host_resume_fixture, "oauth": run_oauth_fixture}
    try:
        if action not in functions:
            raise ValueError("unknown qualification action")
        return _json(functions[action](directory))
    except Exception as error:
        return _json({"status": "FAILED", "scope": "isolated fixture qualification",
                      "error_type": type(error).__name__, "actual_canonical_writes": 0,
                      "production_enabled": False})
