# P5 — Z Fold8 실행 환경 계획

사용자가 상시 온라인 기기는 Samsung Z Fold8이라고 확인했다. **휴대폰을 우선 실행 호스트로 검토한다.** 이 문서는 실행 환경 계획이며 Android 포팅·APK·실기기 검증 완료를 뜻하지 않는다. MASTER SPEC 원문과 P0→P8 순서는 유지한다. P5 호스트 검증을 위한 최소 launcher/worker와 P7 제품 UI·overlay·화면 인식은 별도 단계다.

## 유지할 구조

Grammar, 160 Family, Probability/Novelty, Validator, Chain, 월별 근거, durable saga/outbox와 영수증은 기존 Python 엔진을 유지한다. Kotlin으로 규칙을 축약해 다시 구현하지 않는다. 앱이 Wallet/Inventory/Calendar를 직접 변경하지 않는다. Python 엔진을 Android에 내장하는 경로를 우선 조사하되, 선택·동작은 검증 후 확정한다. Chaquopy는 후보이며 현재 의존성의 Android 설치 가능성을 아직 확인하지 않았다.

| 역할 | 계획 | 현재 결과 |
|---|---|---|
| 실행 호스트 | 사용자 Z Fold8 | 사용자 지정, 실기기 접근/검증 없음 |
| Python 런타임 | 기존 모듈을 내장하여 실행 | NOT_RUN |
| 상태·거래 DB | 앱 전용 SQLite, 기존 journal과 proof 유지 | Android NOT_RUN |
| 호출 | 기기에서 HTTPS로 GPT/Notion/Calendar 연결 | 인증·Android NOT_RUN |
| 자동 실행 | Android가 허용하는 제한된 작업, 재개/지연 처리 포함 | NOT_IMPLEMENTED |
| 제품 UI·overlay·화면 인식 | P7에서 엔진 read/proposal API 연결 | NOT_STARTED |

PC 상시 가동을 사용자에게 필수로 요구하지 않는다. APK 빌드 환경은 실행 호스트와 별개다. 별도 중계/호스트는 장래 선택지로 남겨 두며 현재 준비됐다고 표시하지 않는다.

## 절전·지연·재개 계약

공식 Android 문서에 따르면 Doze는 background CPU·network·job을 지연한다. WorkManager periodic work도 정확한 시각 실행을 보장하지 않는다. Android 15 이상을 target하는 dataSync foreground service에는 background 실행 시간 제한이 있으므로 24시간 dataSync service를 전제로 하지 않는다. 올바른 service type·background 시작 요건과 제조사 설정은 실제 빌드/기기에서 확인한다. 배터리 제한을 해제한 것만으로 매시 정각 실행을 보장하지 않는다.

매시 세계 루프의 논리적 순서는 유지한다. 실제 wall clock과 마지막 완료 tick의 지연을 구분하여 표시하는 호스트가 필요하다. 재개 시 기존 미완료 tick/transaction을 먼저 복구하며, 결정된 GPT 판단·구매 요청·월별 import를 중복 실행하지 않는다. GPT를 매시간 무조건 호출하지 않는 원문 규칙을 유지한다.

**현재 `NativeHourlyRuntime.tick`은 연속 1시간 cadence를 유지한다.** 새 `resume_after_delay` 경로는 누락된 시간을 한 시간씩 처리하며 과거 판단/구매/외출/snapshot을 만들지 않는다. `revalidate_host_resume`가 기존 영수증과 최신 정본 읽기를 통과하기 전까지 normal tick·prepare·confirmed state는 durable gate로 차단된다. 세부 계약은 `P5_HOST_RESUME.md`를 따른다. fixture 검증만 완료했으며 Android scheduler/lifecycle 연결·실제 절전/재부팅 시험 전까지 휴대폰 자율 운영은 BLOCKED다.

사용자 force-stop, 재부팅, 앱 삭제/데이터 삭제는 별개로 시험한다. force-stop 뒤에는 사용자가 앱을 다시 여는 재개 경로를 제공하는 방향으로 검증한다. 종료 후 무조건 자동 부활을 보장하지 않는다.

## 인증과 저장

MASTER SPEC의 작은 중계 서버 권장은 보존한다. 사용자의 휴대폰 호스트 조건에 맞춘 직접 호출 경로는 별도 deployment 선택으로 검토한다. 개인용 APK에 비밀 값을 하드코딩하지 않는다. 앱 설정에서 입력하는 API credential은 Android Keystore로 보호한 암호화 키를 이용해 앱 전용 저장소에 암호화하고, HTTPS 요청 시에만 필요한 값을 사용하도록 설계한다. API 토큰 문자열 자체를 Keystore의 비추출 암호화 키라고 부르지 않는다. 키 폐기·교체·월 예산, Google 토큰 만료/갱신과 재인증 보류는 P5_AUTH.md의 메모리/fixture 경로에서 구현·시험했다. 실제 동의/login·암호화 persistent store 연결과 기기 시험은 남아 있다. 현재 secret 입력 화면·Keystore 연결은 미구현이다.

Notion 기존 페이지/Inventory resource ID는 확보돼 있지만 실서버 credential과 별도 WORLD_STATE 페이지, 초기 세계 수치의 근거, native 월 마감 기준은 아직 필요하다. 파일에 시험 fixture 금액을 실제 사실로 넣지 않는다.

휴대폰 안에서 디렉터리만 나눈 DB/vault/witness는 휴대폰 분실·초기화·앱 데이터 삭제의 독립 장애 도메인이 아니다. `P5_DISASTER.md`의 키는 bytes를 받는 현재 Python 인터페이스다. device-bound Keystore 키와의 연결·내보내기/복원 정책은 아직 구현하지 않았다. 독립 최신 witness/이미지/복원 키를 기기 밖에 보존하는 경로를 검증해야 host 유실 복구 범위를 확장할 수 있다. 같은 휴대폰 안의 백업을 휴대폰 분실 대비라고 표시하지 않는다.

## 순서와 합격 근거

1. Python 내장 호환성: pydantic/pydantic-core, PyYAML, tzdata, SQLite backup/WAL, `fcntl`, fsync/atomic replace, HTTPS 인증서, timezone, 앱 내부 asset 경로를 확인한다. ABI·Python·Android/One UI·page size는 실제 빌드/기기에서 기록한다.
2. 기존 fixture 회귀를 Android에서도 실행한다. 현재 368개 PASS는 개발 호스트 결과이며 Android 통과로 옮겨 쓰지 않는다. subprocess 강제 종료 시험은 실제 앱 프로세스 중단 검증과 구분한다.
3. 지연 tick 계약·중복 worker·절전/단절·재부팅·중단된 요청·토큰 만료를 시험한다. 화면 꺼짐/충전 여부별 실행 지연·배터리·발열·API 비용을 기록한다. 최신 native 증거 없이 사실을 확정하지 않는다.
4. 인증·명시적 초기화 후 실제 GPT 및 Notion/Calendar 왕복·보상·재시작 시험을 통과한다. existing live gate 차단은 시험 없이 해제하지 않는다.
5. P5 완료 후 P6 Social → P7 제품 UI/APK·overlay → P8 실제 연결 장기 시험으로 진행한다.

사용자는 우선 휴대폰을 실행 대상으로 지정했다. 추가 secret이나 임의 초기 수치를 요구하기 전에 호스트·입력 경로와 테스트 가능한 패키지를 준비한다. 현재 APK는 없다. 기기 검사 소스와 지연 시간 복구는 개발 호스트 fixture에서 검증했으며 Android 시험은 새로 실행하지 않았다.

## 공식 참고

- [Doze / App Standby](https://developer.android.com/training/monitoring-device-state/doze-standby)
- [PeriodicWorkRequest](https://developer.android.com/reference/androidx/work/PeriodicWorkRequest)
- [Foreground service timeouts](https://developer.android.com/develop/background-work/services/fgs/timeout)
- [Foreground service background 시작 제한](https://developer.android.com/develop/background-work/services/fgs/restrictions-bg-start)
- [Android Keystore](https://developer.android.com/privacy-and-security/keystore)
- [Chaquopy Android plugin](https://chaquo.com/chaquopy/doc/current/android.html)
- [Chaquopy 지원 버전](https://chaquo.com/chaquopy/doc/current/versions.html)

## P5 기기 검사 소스

기존 Python source를 staging하는 `android-probe/`에 dependency 진단·mock 6시간 재개·native loopback·DB 유실·host resume 버튼을 준비했다. host resume 버튼은 337분 지연, restart 후 gate 유지, 늦은 영수증 1회 반영과 fresh 재확인을 검사한다. 18개 mobile host·22개 지연 복구·35개 OAuth 시험을 포함한 전체 368개 회귀가 개발 호스트에서 PASS다. 실제 Android execution은 NOT_RUN, 빌드 준비 점검은 BLOCKED다. Python 3.13 Android native wheels·16 KiB·화면 전환/lifecycle·절전은 미검증이다. APK를 설치했다고 표시하지 않는다.

## P5 인증 갱신·외부 빌드 준비

`connectors/google_oauth.py`와 `HTTPJSON/CalendarConnector`를 연결했다. 만료 전 갱신, invalid_grant 재인증 차단, retry 지연, GET 401 1회 재시도와 mutation 401 자동 재전송 금지를 fixture에서 검증했다. store는 메모리뿐이며 실제 로그인·Android 암호화 저장·재시작 credential 보존은 미구현이다. `P5_AUTH.md`를 따른다.

OAuth 35개·mobile 18개를 포함한 전체 368개 회귀와 168시간·월말 48시간·DB 유실 fixture를 이번 체크포인트에서 재실행했다. 개인 자료를 제외한 code-only build source의 독립 사본에서도 53개 mobile/OAuth 시험이 PASS다. 기존 P2 10,000시간 PASS는 byte-for-byte 보존하며 이번에 재실행하지 않았다. `P5_REMOTE_BUILD.md`의 수동 자동빌드 설정과 `deployment/MIO_P5_Build_Sources.zip`를 준비했지만 GitHub 계정/repository/job은 연결·실행하지 않았다. **APK/Android 실기기 시험은 아직 NOT_RUN, 로컬 빌드 준비는 BLOCKED**다. P5 실제 정본 gate와 개발 순서는 유지한다.
