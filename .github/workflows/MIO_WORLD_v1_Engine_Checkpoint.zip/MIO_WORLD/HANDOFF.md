# 다음 작업의 출발점

전체 MIO WORLD 또는 APK가 완료되었다고 가정하지 않는다. 현재 정확한 상태는 `reports/phase_status.json`과 `IMPLEMENTATION_REPORT.md`다.

1. 원문 MASTER SPEC, ARCHITECTURE, PHASE_GATES 및 현재 테스트 결과를 읽는다.
2. Python 엔진은 `mio.py simulate`로 실행 가능하다. 실제 정본과 mock 데이터를 섞지 않는다.
3. P3 실제 연결은 서버의 키를 설정한 후 `mio.py decision-smoke`로 검증한다. 실패 시 전체 세계를 멈추지 않고 해당 사건만 건너뛴다.
4. P5는 `connectors/resources.json`의 실제 native Notion/Calendar 구조를 사용한다. 작업 시작 시 해당 정본을 새로 읽는다. `reports/P5_sources/`는 이전 읽기 증거이고 최신 상태를 대신하지 않는다.
5. 현재 Notion 지갑은 native 페이지+MONEY LOG 표, Inventory는 native DB다. 구조를 JSON snapshot 한 페이지로 치환하지 않는다. 지갑·표·DB·관계·취향·연속성의 원래 의미와 원문을 유지하며 field별 version guard와 mutation plan을 만든다.
6. 비어 있는 Inventory에 fixture 물건을 넣지 않는다. 불확실한 가격·브랜드·취득일을 채우지 않는다. 관계의 연령·점수·현재 위치처럼 원문에 없는 값은 정본 사실로 만들지 않는다. 엔진 초기 내부 점수는 명시적인 초기화 근거로 구분한다.
7. P5의 `write_coordinator.py`·`native_plans.py`와 `P5_WRITES.md`를 읽는다. durable coordinator·native 계획·HTTP 어댑터·Canonical Validator/cache 게시가 로컬 HTTP 모의 서버에서 검증되었다. canonical_runtime.py와 native_http_adapter.py를 함께 읽는다. runtime_bootstrap.py·runtime/hourly.py·P5_HOURLY.md를 읽는다. 명시적인 초기화·hourly runner·종일 일정 매핑은 fixture에서 검증했다. 실제 초기화 근거와 별도 runtime 페이지를 확인한다. P5_EFFECTS.md와 native_rebase.py를 읽는다. 일반 지출·조건부 일정 취소와 동일 월 원장/Inventory 복구는 fixture에서 검증했다. P5_RESTORE.md·clock_merge.py·native_restore.py를 읽는다. 검증 가능한 시간 재생과 native full cache/인과 checkpoint 복원은 fixture에서 통과했다. 복원에는 기존 coordinator/초기화 proof DB가 필요하다. P5_MONTH.md·wallet_month.py를 읽는다. 명시적인 native 대상 월에 근거한 월 경계/과거 날짜 조정은 fixture에서 검증했다. 실제 native 월 마감 근거를 설정·검증한다. P5_DISASTER.md·database_recovery.py를 읽는다. 독립 vault/witness/key가 남은 fixture DB 전체 유실 복구는 31개 시험에서 통과했다. 운영 백업·검증 기록·키 보존과 운영 scheduler를 구성·검증한다. Notion 동시 편집 보호를 설계하고 실제 서버에서 검증한다. prepare → durable outbox → 각 connector 검증/쓰기 → receipt → commit 단계를 둔다. event/transaction 단위 멱등 키, 부분 실패 보상, 전송 후 응답 유실, 중간 process 종료, 외부 편집 충돌을 시험한다. rollback도 실패하면 RECONCILE_REQUIRED로 남겨 금전/소유/일정 확정을 막고 정본을 재조회한다.
8. 정본 읽기·쓰기·재읽기 및 장애 복구가 실제로 통과한 뒤에만 `apply_live`와 live commit을 활성화한다. 현재 차단을 지우기만 해서 통과로 만들지 않는다. lost Notion PATCH 응답은 필드 일치만으로 작성 주체를 증명하지 못하므로 자동 확정하지 않는다. 서버 배포와 안전한 credential 입력 경로도 남아 있다.
9. P6에서 committed facts로만 대화/SNS 후보를 만든다. 게시 전 Drive 보관 등의 최신 사용자 지침과 실제 연결 상태를 확인한다. 생성하지 않은 사진이나 완료되지 않은 외출을 공유하지 않는다.
10. P7 Android에서 엔진의 read/proposal API를 사용하고 UI가 Wallet/Inventory를 직접 쓰지 않게 한다. APK 빌드·실기기 상태/타임라인/디버그 검증을 마친다. Overlay/화면 인식은 별도 Android 권한 및 실기기 검증을 요구한다.
11. P8의 30~90일 장기 시험은 실제 연결을 포함해 다시 실시한다. P2 사전 headless 시험을 P8로 재분류하지 않는다.

서버의 API 키와 OAuth credential은 현재 제공되지 않았다. Source ZIP에는 키가 없으며, 앱에 키를 넣는 구조도 구현하지 않았다. GPT 기본 모델은 명시된 `gpt-5.6-luna`를 유지한다. 다른 모델로 바꾸려면 실제 접근 가능 여부와 예산을 함께 확인한다.

500개 Canon 장면과 참고 이미지의 원래 Library ID를 보존했다. Android에 쓸 시각 자료는 원본에서 가져온다. 폴더 `app/`은 P7 이전까지 제품 UI가 없는 상태이며, 지금의 실행 결과는 headless 시뮬레이터다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.

## 우선 실행 환경: 사용자 Z Fold8

사용자의 상시 온라인 기기인 Z Fold8을 우선 호스트로 검토한다. `P5_MOBILE_HOST.md`와 `deployment/host_target.json`에 Android 절전·지연 tick·기존 Python 내장·credential 보호·기기 밖 백업의 검증 순서를 기록했다. 기기 검사 및 지연 복구 소스는 fixture에서 검증했으며 APK/Android 실행 시험은 미진행이다. 개발 호스트 PASS를 Android 시험으로 표시하지 않는다. P5 완료 전 P6~P8은 진행하지 않는다.

## P5 기기 검사 소스

`android-probe/README.md`의 진단 Activity는 기존 엔진과 160 Family를 그대로 staging한다. Python 진입점에서 6→12시간 fixture 저장 재개, native hourly·DB 유실·host resume와 원본 import 경로를 제외한 staging 사본 실행을 검증했다. Android 의존성·컴파일·설치 시험은 미진행이며, 기기용 APK는 아직 없다.

## P5 실행 지연 복구

`runtime/host_resume.py`는 휴대폰 절전처럼 실행이 멈춘 뒤, 누락 시간을 기존 physics로 한 시간씩 진행하는 별도 복구 경로다. 한 호출은 최대 24개 시간 기록을 처리하고 UTC 기준으로 중복·역행을 막는다. 해당 시간에는 GPT 판단·새 구매/외출·역사 snapshot을 만들지 않는다. 이미 확정된 이동·욕구·hook 기한과 기존 미완료 거래만 처리한다. 신규 요청 없이 전송 상태/영수증을 먼저 복구하고, fresh Notion/Calendar 재조회 전 새 요청과 확인된 사실의 공개를 차단한다.

지연 복구 체크포인트에서 22개 복구·16개 기기 검사 시험을 포함한 전체 331개 회귀와 해당 데모를 실행했다. 최신 인증 체크포인트의 368개 결과는 아래 항목을 따른다. P2 10,000시간 결과는 원본 core/data/reference가 바뀌지 않아 이전 PASS를 보존하며 재실행하지 않았다. **Android APK 빌드는 계속 BLOCKED, 실제 절전/재부팅·실기기 실행은 NOT_RUN**이다. P5 실제 연동 gate와 P0→P8 순서를 유지한다. 상세 계약과 증거: `P5_HOST_RESUME.md`, `reports/P5_host_resume_tests.json`, `reports/P5_host_resume_demo.json`.

## P5 인증 갱신·외부 빌드 준비

`connectors/google_oauth.py`와 `HTTPJSON/CalendarConnector`를 연결했다. 만료 전 갱신, invalid_grant 재인증 차단, retry 지연, GET 401 1회 재시도와 mutation 401 자동 재전송 금지를 fixture에서 검증했다. store는 메모리뿐이며 실제 로그인·Android 암호화 저장·재시작 credential 보존은 미구현이다. `P5_AUTH.md`를 따른다.

OAuth 35개·mobile 18개를 포함한 전체 368개 회귀와 168시간·월말 48시간·DB 유실 fixture를 이번 체크포인트에서 재실행했다. 개인 자료를 제외한 code-only build source의 독립 사본에서도 53개 mobile/OAuth 시험이 PASS다. 기존 P2 10,000시간 PASS는 byte-for-byte 보존하며 이번에 재실행하지 않았다. `P5_REMOTE_BUILD.md`의 수동 자동빌드 설정과 `deployment/MIO_P5_Build_Sources.zip`를 준비했지만 GitHub 계정/repository/job은 연결·실행하지 않았다. **APK/Android 실기기 시험은 아직 NOT_RUN, 로컬 빌드 준비는 BLOCKED**다. P5 실제 정본 gate와 개발 순서는 유지한다.

## Fold8에서 Colab 빌드 준비

PC를 사용할 수 없고 GitHub MFA 설정이 어려운 사용자 환경을 반영하여 `P5_COLAB_BUILD.md`의 Google Colab CPU 노트북을 준비했다. `deployment/MIO_P5_Fold8_Build.ipynb` 하나에 build source를 내장하므로 별도 source 업로드/GitHub 연결/Drive mount/API 키 입력은 필요 없다. Google 로그인은 필요하다. P0부터 368개 fixture를 순서대로 통과한 경우에만 기존 APK build helper를 실행하며 실패하면 진단 ZIP을 만든다.

이전 export는 agent가 직접 읽는 Core Identity를 누락해 독립 전체 회귀 P3가 실패했다. staging/export에 원본 Core Identity 하나를 추가하고 다른 reference 첨부는 제외했다. 수정한 254개 파일 export의 전체 368개 회귀가 독립 Linux/Python 3.12 환경에서 PASS다. 원본 core/data/reference와 기존 P2 10,000시간 보고서는 바꾸지 않았다. 노트북 JSON/Python 문법·내장 원본 hash·실패 시 빌드 차단을 검증했다. **Colab 실행/Python 3.13/Android 컴파일/APK/실기기 시험은 NOT_RUN**이며 P5 live gate와 P0→P8 순서는 유지한다. 이번 작업에서 168시간·월말 48시간·DB 유실 데모는 재실행하지 않았고 이전 보고서를 보존했다.

## Fold8의 GitHub 사이트에서 직접 빌드

사용자가 GitHub 웹 로그인과 저장소 생성을 할 수 있다고 확인하여 `P5_GITHUB_PHONE.md`의 직접 Actions 경로를 준비했다. source ZIP을 root에 올리고 `.github/workflows/mio-p5-phone.yml`을 기본 브랜치에 등록하면 runner가 hash/manifest를 확인하여 추출한다. ChatGPT GitHub 플러그인·PC·runtime API 키가 필요 없다. `deployment/MIO_GitHub_Fold8_Guide.html`에 파일 경로/전체 설정 복사 버튼과 수동 선택 대안을 포함했다.

변경하지 않은 254개 source ZIP과 이전 독립 전체 368 PASS를 유지했다. workflow 문법·실제 extraction shell의 254개 byte 일치·missing/corrupt ZIP 차단 3개·fixture acceptance gate 4개·APK receipt gate 5개 사례 및 안내 copy 원문/JS 문법을 확인했다. APK receipt gate에는 명시적인 모의 bytes만 사용했다. **실제 GitHub repository/job/Python 3.13/Android 컴파일/APK/실기기 검사는 NOT_RUN**이다. core/data/reference·P2 10,000시간 보고서와 P5 live gate는 보존한다. Colab도 별도 선택 경로로 남아 있다.

## 첫 GitHub 실행 확인 및 오류 표시 보완 (2026-10-06)

사용자가 올린 `logs_101431036398.zip`의 console에서 368개 fixture 전체 PASS를 실제 GitHub/Python 3.13.15 환경에서 확인했다. Java/javac 17·Gradle 8.13·Android SDK 검사도 적합했고 218개 runtime source/160 Family가 staging됐다. 이후 Android build가 Gradle exit 1/helper exit 2로 실패하여 APK는 없다. `reports/P5_github_run1.json`을 최신 상태로 따른다. 이전 NOT_RUN 기록은 해당 준비 체크포인트 당시 상태다.

console에는 helper가 파일로 저장한 실제 Gradle 오류가 없다. 첫 실행의 [MIO_P5_build_diagnostics.zip](https://github.com/qkdghsthzn-cyber/Miooi/actions/runs/37447059977/artifacts/11403891732) 업로드 성공/33,532 bytes를 확인했지만 파일 내용은 아직 받지 못했다. 해당 ZIP을 먼저 받으면 재실행 없이 분석할 수 있다. Download logs의 ZIP과 Summary/Artifacts의 진단 ZIP은 서로 다르다.

phone workflow에 실패한 Android build 뒤 `Show Android build error log`를 추가했다. 마지막 200줄을 표시하며 원래 build 실패/후속 APK 차단은 유지한다. 누락/빈/200줄 제한 로그 3사례, YAML/shell/inline Python·안내 JS/copy 원문을 확인했다. 원본 source ZIP과 core/data/reference 193개 및 기존 회귀/P2 보고서는 변경하지 않았다. **실패 원인은 미확인/미수정이고 새 workflow remote 실행은 NOT_RUN**이다. 진단 ZIP을 받을 수 없는 경우에만 YAML 본문을 교체하여 Commit 후 **새 Run workflow**로 실행한다. P5 live gate와 P6~P8 NOT_STARTED를 유지한다.

## Android 바이너리 의존성 오류 수정 (2026-10-06)

첫 실행의 `MIO_P5_build_diagnostics.zip`(SHA `8eb7e1a…83c80e`)에서 실제 18단계 368 PASS와 Gradle 원인을 확인했다. `:probe:installDebugPythonRequirements`가 Pydantic 2.13 계열의 정확한 `pydantic-core` Android wheel을 찾지 못해 실패했다. Gradle 8.13 안내 경고가 실패 이유는 아니다. 최신 증거는 `reports/P5_android_dependencies_fix.json`이다.

엔진/스키마/requirements 범위를 바꾸지 않고 Android 빌드 constraint에 첫 실행 버전 Pydantic 2.13.5/core 2.46.5를 고정했다. `tools/build_android_wheels.py`는 SHA가 고정된 공식 upstream sdist를 추출하고 Cargo.lock을 유지하여 cibuildwheel 4.3.0/Rust 1.88.0으로 CPython 3.13/API24/arm64-v8a와 x86_64 wheel을 만든다. cibuildwheel이 실제 Android libpython/sysconfig·NDK·Cargo linker/PyO3 환경을 제공한다. version/tag/native ELF architecture/16KiB LOAD alignment와 두 ABI receipt를 확인한 경우에만 Gradle find-links로 공급한다. 새 temp output을 사용해 실패 후 이전 wheel을 재사용하지 않는다. Gradle 실패는 stacktrace와 native-wheel/Gradle 진단 로그로 남긴다. 설치/런타임 적합성은 여전히 실기기 검증 대상이다.

기존 368개와 새 synthetic binary receipt/source guard 10개를 포함한 **378개 회귀가 개발 tree 및 배포 ZIP의 독립 Linux/Python 3.12.14 사본에서 모두 PASS**다. 실제 upstream hash/extraction·cibuildwheel의 두 대상 선택·wheel 실패 시 Gradle/APK 차단·workflow/notebook/guide 문법과 embedded ZIP/copy 원문을 확인했다. synthetic bytes를 실제 wheel/APK로 내보내지 않는다. 원본 engine/data/reference/mobile 227개와 160 Family, P2 10,000시간 보고서 및 live gate를 보존했다.

새 source ZIP은 258개 파일/SHA `feb53d33ffe39372cd88cd7b4c81294e0a40e6ec9c9989205c3501634e6a18fe`이다. **소스 ZIP과 phone YAML 둘 다 교체·Commit하고 새 Run workflow를 실행해야 한다.** 이전 실행의 Re-run jobs는 이전 revision을 사용한다. Colab 노트북에도 새 ZIP/constraint/378개 gate를 반영했으나 선택 경로이며 실행하지 않았다. **수정본의 native wheel compilation·Gradle/APK·Android 실행은 NOT_RUN**이다. P5가 완료된 것으로 표시하지 않으며 P6~P8은 계속 NOT_STARTED다.

공식 빌드 참고: [Chaquopy Android wheel 빌드](https://github.com/chaquo/chaquopy/blob/master/server/pypi/README.md), [cibuildwheel Android](https://cibuildwheel.pypa.io/en/stable/platforms/#android), [PyO3 cross compilation](https://pyo3.rs/main/building-and-distribution.html#cross-compiling).
