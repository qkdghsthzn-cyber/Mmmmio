# Fold8 전용 원격 빌드 준비

사용자는 PC를 사용할 수 없고 GitHub MFA 설정이 어려워 Fold8만 사용한다. 기본 후보를 Google Colab의 CPU 런타임으로 바꿨다. GitHub 계정·플러그인·repository 연결은 이 경로의 요구사항이 아니다. Google 로그인과 해당 계정의 로그인 정책은 그대로 적용된다. 무료 runtime 제공과 실제 빌드 성공을 보장하지 않는다.

`deployment/MIO_P5_Fold8_Build.ipynb` 하나에 필수 build source가 포함된다. 원본 엔진·160 Family·runtime Core Identity·의존성 계약을 유지한다. 원본 첨부 문서/사진·정본 읽기 증거·resources.json·DB·credential은 제외했다. 빌드에 runtime API 키와 Drive mount는 필요 없다.

## 휴대폰에서 실행

1. Chrome에서 https://colab.research.google.com/ 를 연다. 메뉴가 좁으면 데스크톱 사이트를 켠다.
2. 파일 → 노트북 업로드에서 `.ipynb`를 선택한다.
3. 기본 CPU 런타임에서 런타임 → 모두 실행을 누른다. 실행 시 노트북에 링크된 Android SDK 약관을 수락한다.
4. 성공한 경우 검증된 `MIO_P5_Device_Probe.apk`만 다운로드한다. 실패 시 `MIO_P5_Build_Diagnostics.zip`을 첨부하여 원인을 확인한다. 자동 다운로드가 열리지 않으면 Colab 파일 메뉴에서 출력에 표시된 경로를 내려받는다.

Python 3.13·JDK 17·Gradle 8.13·Android platform 36/build-tools 35.0.0을 runtime 안에 준비한다. SDK와 Gradle ZIP은 공식 체크섬으로 검증하고, 내장 ZIP과 개별 파일은 hash로 검증한다. P0부터 368개 fixture 시험을 순서대로 실행하며 모두 통과해야 기존 APK build helper를 호출한다. 시험/SDK 설치/의존성 해결/컴파일 실패는 실패로 남긴다. Android native wheel 부족을 이유로 Pydantic이나 원본 schema를 바꾸지 않는다.

## 준비 과정에서 수정한 결함

이전 code-only export는 `MioDecisionAgent.context()`가 직접 읽는 `reference/01_Core_Identity.md`를 제외하여 독립 전체 회귀의 P3가 실패했다. staging/export에 이 파일 하나만 원본 그대로 포함하고 나머지 reference는 제외했다. 정체성 내용을 잘라내거나 빈 fixture로 바꾸지 않았다. 53개 mobile/OAuth 시험만으로 전체 export 회귀를 보장할 수 없었으므로 이번에는 분리한 export 전체를 시험한다.

준비/host 시험과 Colab 실제 실행은 구분한다. `reports/P5_colab_build.json`의 상태는 READY_NOT_RUN이며 Android 컴파일·APK·기기 검사 결과는 NOT_RUN이다. 출력물은 P5 검사 앱이고 제품 overlay·credential 입력·상시 Android scheduler는 미완료다. 기존 live gate와 P0→P8 순서를 유지한다.

재생성:

```bash
python -m tools.package_android_sources
python -m tools.package_colab_notebook
```

공식 참고: [Colab FAQ](https://research.google.com/colaboratory/faq.html), [파일 다운로드](https://colab.research.google.com/notebooks/io.ipynb), [Android SDK](https://developer.android.com/studio), [Gradle 체크섬](https://gradle.org/release-checksums/), [uv Python](https://docs.astral.sh/uv/guides/install-python/).

## Android 바이너리 의존성 오류 수정 (2026-10-06)

첫 실행의 `MIO_P5_build_diagnostics.zip`(SHA `8eb7e1a…83c80e`)에서 실제 18단계 368 PASS와 Gradle 원인을 확인했다. `:probe:installDebugPythonRequirements`가 Pydantic 2.13 계열의 정확한 `pydantic-core` Android wheel을 찾지 못해 실패했다. Gradle 8.13 안내 경고가 실패 이유는 아니다. 최신 증거는 `reports/P5_android_dependencies_fix.json`이다.

엔진/스키마/requirements 범위를 바꾸지 않고 Android 빌드 constraint에 첫 실행 버전 Pydantic 2.13.5/core 2.46.5를 고정했다. `tools/build_android_wheels.py`는 SHA가 고정된 공식 upstream sdist를 추출하고 Cargo.lock을 유지하여 cibuildwheel 4.3.0/Rust 1.88.0으로 CPython 3.13/API24/arm64-v8a와 x86_64 wheel을 만든다. cibuildwheel이 실제 Android libpython/sysconfig·NDK·Cargo linker/PyO3 환경을 제공한다. version/tag/native ELF architecture/16KiB LOAD alignment와 두 ABI receipt를 확인한 경우에만 Gradle find-links로 공급한다. 새 temp output을 사용해 실패 후 이전 wheel을 재사용하지 않는다. Gradle 실패는 stacktrace와 native-wheel/Gradle 진단 로그로 남긴다. 설치/런타임 적합성은 여전히 실기기 검증 대상이다.

기존 368개와 새 synthetic binary receipt/source guard 10개를 포함한 **378개 회귀가 개발 tree 및 배포 ZIP의 독립 Linux/Python 3.12.14 사본에서 모두 PASS**다. 실제 upstream hash/extraction·cibuildwheel의 두 대상 선택·wheel 실패 시 Gradle/APK 차단·workflow/notebook/guide 문법과 embedded ZIP/copy 원문을 확인했다. synthetic bytes를 실제 wheel/APK로 내보내지 않는다. 원본 engine/data/reference/mobile 227개와 160 Family, P2 10,000시간 보고서 및 live gate를 보존했다.

새 source ZIP은 258개 파일/SHA `feb53d33ffe39372cd88cd7b4c81294e0a40e6ec9c9989205c3501634e6a18fe`이다. **소스 ZIP과 phone YAML 둘 다 교체·Commit하고 새 Run workflow를 실행해야 한다.** 이전 실행의 Re-run jobs는 이전 revision을 사용한다. Colab 노트북에도 새 ZIP/constraint/378개 gate를 반영했으나 선택 경로이며 실행하지 않았다. **수정본의 native wheel compilation·Gradle/APK·Android 실행은 NOT_RUN**이다. P5가 완료된 것으로 표시하지 않으며 P6~P8은 계속 NOT_STARTED다.

공식 빌드 참고: [Chaquopy Android wheel 빌드](https://github.com/chaquo/chaquopy/blob/master/server/pypi/README.md), [cibuildwheel Android](https://cibuildwheel.pypa.io/en/stable/platforms/#android), [PyO3 cross compilation](https://pyo3.rs/main/building-and-distribution.html#cross-compiling).
