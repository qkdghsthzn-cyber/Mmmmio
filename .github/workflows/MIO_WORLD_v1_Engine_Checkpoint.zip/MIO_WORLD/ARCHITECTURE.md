# MIO WORLD v1 실행 구조

`core/clock → state_manager → candidate_generator/event_grammar → probability_engine/novelty_engine → agents → validator → transaction_manager → consequence → snapshot`

UI는 엔진의 상태를 읽고 명시적인 입력을 제출한다. Wallet/Calendar/Inventory를 직접 바꾸지 않는다.

| 명세의 영역 | 구현/저장 위치 | 변경 근거 |
|---|---|---|
| WORLD_STATE / 욕구 | `State.world`, SQLite state | tick mutation 또는 transaction |
| EVENT_LOG | SQLite events | 상태에 바인딩된 grammar 후보 |
| DECISION_LOG | SQLite decisions | 구조화 Decision |
| WALLET | State.wallet + ledger | 검증된 지출 transaction |
| INVENTORY / Wishlist | State.inventory/catalog/wishlist | 동일 구매 transaction |
| RELATIONSHIPS | State.relationships | 해당 NPC의 interaction evidence |
| TASTE | State.taste | 수락한 사건의 evidence |
| CONTINUITY | SQLite continuity_archive + 최근 256개 cache | event → consequence + transaction |
| CALENDAR | State.calendar + native Calendar 증거/cache bridge | 시간/이동 검증 |
| NOVELTY_MEMORY | State.novelty_memory + window index | commit된 사건 features |
| Social | State.social | P6의 committed-fact output |

SQLite의 `BEGIN IMMEDIATE`는 같은 DB에 접근하는 중복 scheduler를 직렬화한다. tick ID는 시간대가 포함된 ISO 시각이며 unique key다. 중단된 tick의 lock과 기록은 함께 rollback된다. 상태 revision이 바뀐 오래된 proposal은 reject된다.

Event 하나는 최대 한 transaction을 갖는다. Wallet 차감·Inventory 추가·Wishlist 변경·Continuity 기록이 하나의 transaction으로 저장되며, 도중 실패하면 전부 rollback된다. 외부 connector에는 이 SQLite transaction을 그대로 적용할 수 없으므로 P5의 `connectors/write_coordinator.py`가 별도의 durable outbox/receipt/compensation을 제공한다. 네이티브 HTTP 어댑터와 canonical 증거/cache bridge는 로컬 HTTP 모의 서버에서 검증되었고 production mutation은 차단되어 있다.

이동은 `Journey`에 출발/도착 시각과 원인 event/transaction을 기록하고, 이후 tick의 resolver가 실제 도착 시각이 지난 경우에만 위치를 갱신한다. 현재 위치에서 불가능한 실내 행동과 고정 일정의 이동 여유 부족은 거부한다.

전체 인과 기록은 SQLite에 보존된다. 매시간의 hot snapshot에는 최근 256개 인과 edge만 들어가며, `mio.py dump`와 `StateStore.load(history=True)`는 전체 기록을 복구한다. 이 cache 제한은 원본 기록을 삭제하지 않는다.

Family JSON은 코드 밖에서 관리된다. 새로운 Family를 추가할 때 validator가 지원하는 effect와 requires/forbids를 사용한다. 알 수 없는 effect/constraint는 로드 단계에서 거부한다. 실제 날씨·가격 등은 검증된 신호가 없는 상태에서 현실 사실로 생성하지 않는다.

서버 비밀 값은 환경변수로 제공한다. API 키를 APK나 assets에 넣는 구조를 사용하지 않는다. Android 화면 인식/overlay는 P7 이후 별도 실기기 검증 대상이다.

P5의 영수증 기반 commit은 별도 `canonical_commits`에 scope를 저장한다. fixture commit을 live `State`나 정본으로 승격하지 않는다. `confirmations_allowed()`의 영역 잠금은 미해결 Wallet/Inventory/Calendar 등의 사실 확정을 막으며, cache bridge에 연결되어 있으나 production 초기화·운영 scheduler 연결은 남아 있다. 상세한 상태/복구 계약은 P5_WRITES.md를 따른다.

CanonicalValidator는 최신 native 증거·명시적인 세계 초기화 근거·scope·cache hash를 검증한 뒤 core Validator의 공통 순수 계산을 사용한다. mock 공개 진입점의 live 차단은 유지한다. cache binding과 outbox prepare는 하나의 SQLite transaction이다. 외부 COMMITTED 뒤 영수증 재읽기·revision 검증을 통과해야 native ID를 반영한 cache와 event committed를 원자적으로 공개한다. 읽기 실패·외부 편집은 해당 영역만 stale/frozen으로 만든다. 외부 원장/Inventory 변경의 cache rebase는 immutable 원장 prefix·금액/월 지출 산술·두 번의 안정적인 native 조회·cache hash가 모두 일치할 때 수행하며, 월 경계/과거 날짜는 명시적인 native 대상 월과 월별 누적 증거로 읽기 전용 조정한다. 실제 native 월 마감 설정/검증은 남아 있다. 미확정 거래 중에는 clock-only 변화의 전체 상태 hash chain을 검증해 원래 projection에 시간 변화를 재생한다. 종일 일정 매핑은 native Calendar timezone 증거로 검증했다. 원문에 없는 위치·상태·프로필 값은 정본으로 생성하지 않는다.

초기화와 native 시간별 실행은 connectors/runtime_bootstrap.py → runtime/hourly.py에 있다. 기존 Simulator와 별도 진입점이며 같은 Grammar/Probability/Novelty/Rule Validator/Chain을 사용한다. 각 시간의 선택 후보·realization·decision 호출 상태·cursor·snapshot을 durable stage로 보존한다. native commit 후 인과/hook/Novelty와 cache는 같은 transaction에서 공개한다. WORLD_STATE는 기존 지갑과 다른 명시적 페이지에 append하고 historical snapshot 복구는 현재 시계를 덮어쓰지 않는다. 종일 일정은 native Calendar timezone으로 해석하며 계획을 참석/도착 사실로 만들지 않는다. 독립 vault/witness/key가 남은 fixture DB 전체 유실 복구는 P5_DISASTER.md에서 검증했다. production·운영 timer·독립 백업 운영 구성은 미완료다.

일반 spend는 MONEY LOG와 Wallet·Continuity만 변경한다. calendar.cancel은 런타임 생성/게시 영수증으로 소유권을 확인한 단발 일정에 If-Match PATCH를 보내며, 취소 marker가 없는 tombstone은 UNKNOWN이다. NativeCacheReconciler는 원장 행과 Inventory raw 증거를 durable import journal에 남기고 cache·anchor·증거를 같은 SQLite transaction에 반영한다. 제거된 소유권의 이전 기록도 보존한다.

캐시 게시의 before hash가 다르면 cache_binding_bases와 cache_clock_steps로 검증 가능한 시간 변화만 허용한다. 임의 변경은 RECONCILE_REQUIRED로 남긴다. native cache checkpoint의 각 조각은 outbox 영수증의 native hash/version/parent와 일치해야 하며, 최신 clock·mutation·commit·rebase 집합을 확인한 뒤 cache와 archive를 원자적으로 복원한다. 바깥 영역은 fresh native 조회 전 stale로 유지한다.

월 경계 tick은 물리 시계를 먼저 저장하고 SELECT 단계를 남긴다. 새 현지 월의 native 자료를 다시 읽고 조정한 뒤 후보를 선택한다. SELECT 중 재시작해도 시계나 판단을 중복 실행하지 않는다. NativeCacheReconciler의 월별 합계/알 수 없는 과거 월의 추가 지출/원문 날짜 증거는 원장·cache·anchor와 함께 원자적으로 저장한다. freshness는 UTC 경과 시간으로 검사해 DST 반복 시각의 오래된 증거를 거부한다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.

## 우선 실행 환경: 사용자 Z Fold8

사용자의 상시 온라인 기기인 Z Fold8을 우선 호스트로 검토한다. `P5_MOBILE_HOST.md`와 `deployment/host_target.json`에 Android 절전·지연 tick·기존 Python 내장·credential 보호·기기 밖 백업의 검증 순서를 기록했다. 기기 검사 및 지연 복구 소스는 fixture에서 검증했으며 APK/Android 실행 시험은 미진행이다. 개발 호스트 PASS를 Android 시험으로 표시하지 않는다. P5 완료 전 P6~P8은 진행하지 않는다.

## P5 기기 검사 소스

`android-probe/README.md`의 진단 Activity는 기존 엔진과 160 Family를 그대로 staging한다. Python 진입점에서 6→12시간 fixture 저장 재개, native hourly·DB 유실·host resume와 원본 import 경로를 제외한 staging 사본 실행을 검증했다. Android 의존성·컴파일·설치 시험은 미진행이며, 기기용 APK는 아직 없다.

## P5 실행 지연 복구

`runtime/host_resume.py`는 휴대폰 절전처럼 실행이 멈춘 뒤, 누락 시간을 기존 physics로 한 시간씩 진행하는 별도 복구 경로다. 한 호출은 최대 24개 시간 기록을 처리하고 UTC 기준으로 중복·역행을 막는다. 해당 시간에는 GPT 판단·새 구매/외출·역사 snapshot을 만들지 않는다. 이미 확정된 이동·욕구·hook 기한과 기존 미완료 거래만 처리한다. 신규 요청 없이 전송 상태/영수증을 먼저 복구하고, fresh Notion/Calendar 재조회 전 새 요청과 확인된 사실의 공개를 차단한다.

지연 복구 체크포인트에서 22개 복구·16개 기기 검사 시험을 포함한 전체 331개 회귀와 해당 데모를 실행했다. 최신 인증 체크포인트의 368개 결과는 아래 항목을 따른다. P2 10,000시간 결과는 원본 core/data/reference가 바뀌지 않아 이전 PASS를 보존하며 재실행하지 않았다. **Android APK 빌드는 계속 BLOCKED, 실제 절전/재부팅·실기기 실행은 NOT_RUN**이다. P5 실제 연동 gate와 P0→P8 순서를 유지한다. 상세 계약과 증거: `P5_HOST_RESUME.md`, `reports/P5_host_resume_tests.json`, `reports/P5_host_resume_demo.json`.

## P5 인증 갱신·외부 빌드 준비

`connectors/google_oauth.py`와 `HTTPJSON/CalendarConnector`를 연결했다. 만료 전 갱신, invalid_grant 재인증 차단, retry 지연, GET 401 1회 재시도와 mutation 401 자동 재전송 금지를 fixture에서 검증했다. store는 메모리뿐이며 실제 로그인·Android 암호화 저장·재시작 credential 보존은 미구현이다. `P5_AUTH.md`를 따른다.

OAuth 35개·mobile 18개를 포함한 전체 368개 회귀와 168시간·월말 48시간·DB 유실 fixture를 이번 체크포인트에서 재실행했다. 개인 자료를 제외한 code-only build source의 독립 사본에서도 53개 mobile/OAuth 시험이 PASS다. 기존 P2 10,000시간 PASS는 byte-for-byte 보존하며 이번에 재실행하지 않았다. `P5_REMOTE_BUILD.md`의 수동 자동빌드 설정과 `deployment/MIO_P5_Build_Sources.zip`를 준비했지만 GitHub 계정/repository/job은 연결·실행하지 않았다. **APK/Android 실기기 시험은 아직 NOT_RUN, 로컬 빌드 준비는 BLOCKED**다. P5 실제 정본 gate와 개발 순서는 유지한다.
