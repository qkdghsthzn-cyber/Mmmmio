# P5 — 독립 체크포인트를 통한 coordinator DB 복원

현재 지원 범위는 **명시적인 fixture 세계와 loopback HTTP 검증**이다. `connectors/database_recovery.py`는 primary SQLite DB 전체가 삭제되어도 독립 체크포인트·최신 검증 기록(witness)·서명 키가 남아 있을 때 복원한다. 실제 서비스 활성화나 운영 백업 배포는 완료되지 않았다. P5의 production gate를 우회하지 않는다.

## 보존하는 계약

State만 저장하지 않는다. SQLite online backup으로 WAL의 commit까지 포함하여 outbox, 전송/보상 상태, 영수증, domain lock, proposal/cache binding, 초기화 proof, CALLING 판단 상태, hourly cursor/snapshot, clock journal, 월별 anchor/import, 전체 인과 기록을 함께 보존한다. 기존 Notion 지갑·MONEY LOG 표·Inventory DB·Calendar 구조는 변경하지 않는다.

coordinator의 모든 atomic mutation 전에 별도 witness에 서명한 `DIRTY` fence를 fsync한다. SQL commit 뒤 전체 이미지와 `CLEAN` witness를 순서대로 저장한다. `APPLYING`과 `UNDOING`도 외부 요청 전에 저장·백업되므로 복원 후 전송 여부가 불확실한 요청을 무조건 다시 보내지 않는다. 미완료 SQL transaction 안에서는 외부 provider I/O를 허용하지 않는다.

SQL rollback에는 이전 CLEAN witness를 복구한다. SQL commit 후 백업 실패에는 이미 commit된 DB를 rollback했다고 표시하지 않고 DIRTY를 유지하며 새 요청·사실 확정을 막는다. 살아 있는 primary에 대해서만 `vault.repair_live(coordinator)`로 검증 후 새 체크포인트를 만들 수 있다. DIRTY 상태에서 primary까지 잃으면 이전 이미지로 fallback하지 않는다.

## 독립적인 복구 근거

| 근거 | 조건 |
|---|---|
| 전체 DB 이미지 | primary DB 디렉터리 밖의 vault, 최신 이미지가 손상 없이 남아 있어야 함 |
| 최신 witness | primary 디렉터리 및 vault 밖의 별도 보호 경로, 최신 sequence·세계·lineage·원래 DB 경로·해시를 인증 |
| HMAC 서명 키 | 호출자가 별도 공급·보호, DB/이미지/witness에 저장하지 않음 |

경로 분리는 물리적 장애 도메인 분리를 증명하지 않는다. 운영 환경에서 독립 저장소, 권한, 백업 보존·내구성과 복원 절차를 실제로 검증해야 한다. HMAC-SHA256은 이미지의 인증이며 암호화가 아니다. 이미지에는 세계와 거래 기록이 포함된다.

보호된 witness 자체가 과거의 정상 서명 버전으로 되돌아가는 경우를 탐지하려면 별도 보관한 최신 sequence를 `expected_sequence`에 제공해야 한다. 이미지·witness·키를 모두 잃거나 모든 신뢰 근거가 함께 rollback된 재난 복구를 지원한다고 주장하지 않는다.

## 진입점과 순서

Linux/Unix의 file lock을 사용한다. fixture 초기화와 `NativeHourlyRuntime` 생성으로 필요한 테이블을 모두 만든 뒤 활성화한다. 운영 CLI의 기본값으로 활성화되지 않는다.

```python
from connectors.database_recovery import DatabaseRecoveryVault, revalidate_recovered

# signing_key는 호출자가 별도 보호 경로에서 공급한 bytes다.
vault = DatabaseRecoveryVault(vault_directory, witness_path, signing_key, world_id)
coordinator.enable_recovery(vault)

# 장애 후 모든 worker를 닫고 잔존 파일을 보존·점검한 뒤 실행한다.
vault.restore(original_db_path, expected_sequence=independently_retained_sequence)
# 복원된 DB로 coordinator/bridge/runtime를 다시 생성한다.
coordinator.enable_recovery(vault)
result = revalidate_recovered(runtime)
```

복원은 인증된 **동일한 원래 DB 경로**만 허용한다. 기존 DB, WAL/SHM, worker/scheduler 파일이 있으면 거부하며 자동 삭제·덮어쓰기는 하지 않는다. SQLite integrity, 세계/lineage/sequence, 전체 hash, 초기화 proof, State invariants, transaction/plan/outbox/lock/commit 연결을 검사한다. 최신 이미지가 없거나 손상되면 오래된 이미지로 대체하지 않는다.

복원 후 `NEEDS_REVALIDATION` gate를 별도 생성하며 State의 revision·현재 시계·clock journal을 그대로 보존한다. gate가 해제되기 전 새 tick·판단·proposal·사실 확정을 막는다. vault를 재연결하지 않으면 외부 I/O도 막힌다. `revalidate_recovered`는 이미 기록된 durable intent만 재확인하고 native 사실을 다시 읽는다. 새 판단 호출이나 시계 진행을 하지 않는다. 응답 유실된 Notion 생성이 아직 조회되지 않으면 `WAITING_NATIVE_RECOVERY`로 유지하고 재전송하지 않는다. 근거가 생긴 뒤 한 번만 반영한다. 작성 주체를 입증하지 못하는 PATCH나 설명되지 않은 잔액은 보류한다.

## 실행과 검증

```bash
python3 tools/test_report.py P5_disaster
python3 mio.py p5-disaster-demo
```

31개 장애 시험과 전체 회귀 293개가 PASS다. 실제 primary DB와 companion 파일 삭제, 모든 proof 테이블 보존, 미확정 생성/전송·늦은 provider 완료·중복 지출 방지, 보존된 CALLING 판단의 재호출 금지, clock replay, 월별 import, fresh read 실패, 변조/잘못된 키·세계·경로·sequence, WAL backup, 잔존 파일, 열린 worker의 DB 교체, 실패한 checkpoint와 살아 있는 DB 수리, 실제 subprocess 강제 종료의 DIRTY fence를 검사했다.

`reports/P5_disaster_demo.json`: 삭제 시 sequence 25, `RESTORED_FROZEN` → `WAITING_NATIVE_RECOVERY` → `VERIFIED`, 기존 판단 호출 1회, fixture 원장 1행·잔액 ¥27,600, 현재 시계 유지, 다음 시간 `COMPLETED`, unresolved binding 0개. 실제 정본 쓰기는 0회이며 서명 키도 시험용이다. 이 데모는 임시 경로를 사용하므로 운영 백업을 남기는 배포 명령이 아니다.

기존 168시간 hourly와 월말 48시간 fixture도 현재 코드에서 PASS했다. P2의 이전 10,000시간 PASS 보고서는 보존했고 이번에는 재실행하지 않았다.

## 남은 P5 조건

전체 이미지 크기는 최대 64 MiB, witness는 최대 64 KiB이며 같은 lineage의 최신 이미지 3개를 보존한다. 매 commit 전체 backup의 비용·규모와 운영 보존 정책은 검증이 필요하다. 지원되지 않는 범위는 primary 유실 시 DIRTY 상태, host/vault/witness/key 동시 유실, native 문서만으로 전체 coordinator 재구성이다. 기존 native cache 복원 계약은 `P5_RESTORE.md`를 따른다.

실제 GPT·Notion·Calendar 왕복/보상/재시작, 실제 세계 초기화·native 월 마감 근거·비용 signal, Notion 동시 편집/PATCH 작성 주체 보호, 독립 vault/witness/key 운영 구성·복원 실습·성능, 안전한 credential 입력·timer/서버 배포가 남아 있다. P5 완료 전 P6~P8을 진행하지 않는다.
