# P5 호스트 실행 지연 복구

범위는 loopback HTTP fixture다. 실제 Android scheduler·Doze 시험과 GPT/Notion/Calendar 운영 연동은 완료하지 않았다. MASTER SPEC의 기존 event/decision/transaction/State 구조와 P0→P8 순서를 보존한다.

## 재개 계약

`resume_after_delay(runtime, observed_at, max_hours=24)`는 timezone-aware 실제 관측 시각을 입력받는다. 기존 scheduler lock을 확보하고 DB 복구 gate·vault CLEAN 여부를 확인한다. wall clock이 State보다 과거이면 거부하며, 한 호출의 시간 기록 처리량은 1..24다. 전체 시간 기준은 UTC, 표현은 기존 세계 timezone이다.

1. `host_resume_gate`를 NEEDS_FRESH_NATIVE로 durable 저장한다. State 본문을 건드려 진행 중 거래의 clock hash를 깨뜨리지 않는다.
2. 기존 external transaction과 cache binding의 전송 상태/영수증만 복구한다. UNKNOWN 요청을 새 ID로 재전송하지 않는다. 이미 준비된 단계(기존 snapshot intent 포함)는 원래 조건 검증과 coordinator 복구 규칙을 따른다. 새 snapshot intent는 만들지 않는다.
3. 과거 미완료 tick의 unprepared proposal/CALLING 판단·realization을 SKIPPED로 남긴다. 이미 bound intent 및 terminal 판단은 보존한다. 단계별 DB atomic 처리를 반복해 부분 종료 뒤 안전하게 재개한다.
4. 누락된 매시간에 원래 `runtime.physics.advance`를 적용한다. 욕구, 확정된 기존 이동, 기한이 있는 기존 hook만 진행한다. 미확정 거래가 있으면 검증 가능한 clock journal에도 같은 단계를 기록한다. State/시간 기록 저장은 한 SQLite transaction이며 opt-in vault에서도 checkpoint한다.
5. 예산이 끝났으면 MORE_CLOCK_CATCHUP_REQUIRED를 반환한다. 최종 관측 시각보다 미래로 진행하지 않는다. 같은 관측 시각 재호출은 시간을 중복 적용하지 않는다. 부트스트랩 직후 중단된 첫 기록은 물리 변화 없이 RECOVERED로 남긴다.

이 경로는 event generator/realizer/decision agent/new prepare를 호출하지 않는다. 누락 시간의 가짜 native snapshot도 생성하지 않는다. 기존 Calendar의 시간 구간 종료 상태는 새 참석/외출 증거가 아니다. 새 Calendar 일정을 과거 이동 사실로 만들지 않는다.

## 실행 재개 조건

`revalidate_host_resume(runtime, observed_at)`는 모든 시간 처리와 기존 거래 복구가 끝난 뒤 새로운 native reader로 Notion과 unfiltered Calendar를 읽는다. 기존 월/원장/Inventory 산술·prefix·두 번의 안정적인 읽기 검증을 그대로 적용한다. 새 일정은 원래 native calendar mapping으로 반영한다. 최신 조회 실패·설명되지 않은 잔액·미확정 거래가 있으면 gate를 유지한다.

관측 시각은 논리 시각보다 0..1시간 미만 앞설 수 있다. native 조정의 관측 근거에는 실제 wall time을 기록하며 State 시계는 시간 격자를 유지한다. 두 시각의 현지 월이 다르면 WAITING_LOGICAL_MONTH_BOUNDARY로 보류한다. 월 경계 처리 후에도 native 대상 월과 지출 근거 없이는 열리지 않는다. 과거 시간에 최신 native 사실을 넣은 판단을 실행하지 않는다.

gate가 남아 있으면 normal tick, coordinator.prepare, bridge.confirmed_state/confirmed_domain은 차단된다. fresh 조회와 sync를 통과한 State 저장 및 gate VERIFIED는 atomic이다. 전체 DB 복원 gate와는 독립적이며, 두 확인을 모두 통과해야 신규 작업/확정 사실의 공개가 가능하다.

## 합격 근거와 실행

22개 전용 시험: 337분·48시간 지연, 24개씩 bounded 처리, 중복/역행/naive 입력, worker 충돌, process restart, 불확실한 지출 1회 복구, 미준비 판단 생략, 실패한 조회의 차단 유지, 새 native 일정, 외부 원장의 실제 관측 시각, 월 경계, DST 반복 시각, 알려진 이동/hook 만료, hour atomic rollback, vault checkpoint 및 primary DB 삭제 후 독립 gate 복구.

```bash
python tools/test_report.py P5_host_resume
python mio.py p5-host-resume-demo
python tools/mobile_probe.py host_resume --workspace /tmp/mio-qualification
```

데모는 loopback에서 337분 지연→5시간 clock-only→DB 재연결 후 차단 유지→기존 지출의 늦은 응답→1개 원장/27,600 fixture 잔액→fresh 재확인→다음 시간 진행을 검증한다. 추가 GPT 판단 0회, 원래 모호한 append 전송 1회, 과거 snapshot 0개다. 실제 미오 잔액·생활 사실이 아니다.

전체 331개 회귀 및 168시간·월말 48시간·DB 유실 데모를 재실행했다. P2 10,000시간은 이전 PASS 보존이며 core/data/reference는 변경하지 않았다. 증거는 `reports/P5_host_resume_tests.json`, `reports/P5_host_resume_demo.json`, `reports/P5_mobile_host_resume.json`, `reports/P5_host_resume_summary.json`이다.

## 미완료 항목

기기에서 관측 시각을 공급하는 lifecycle/scheduler 연결, OS 실제 중단·재부팅·force-stop 시험, 실제 credential/OAuth 갱신, live roundtrip/동시 편집 보호, 독립 백업 운영이 남아 있다. `android-probe/`의 버튼은 fixture 호출용 소스이며 APK 컴파일과 실기기 실행은 미진행이다. Android 절전 중 매시간 실행을 보장하거나 실제 생활을 복구했다고 표시하지 않는다. 최신 wall/native 상황에 맞춘 실제 행동 정책과 운영 성능은 service/device 검증을 거쳐야 한다. P5 완료 전 P6~P8로 진행하지 않는다.
