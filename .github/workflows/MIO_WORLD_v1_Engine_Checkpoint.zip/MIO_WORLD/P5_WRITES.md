# P5 네이티브 HTTP·복구·캐시 체크포인트

네이티브 HTTP 어댑터와 정본 증거 검증·캐시 게시 경로를 구현하고 로컬 HTTP 모의 서버에서 검증했다. 실제 정본 쓰기, GPT 호출, 서버 배포와 P5 완료 조건은 아직 통과하지 않았다. production mutation은 차단되어 있다.

## 원래 구조를 보존하는 계획

`native_plans.py`는 최근 5분 이내 raw Notion block/schema/row 증거를 사용한다. 구매 시 기존 잔액·월 지출 bullet의 금액만 바꾸며 서식·링크·다른 문장을 보존한다. 기존 MONEY LOG에 native table_row를 추가하고 기존 Inventory data source에 native properties로 항목을 만든다. 지정한 Wishlist 행의 메모를 보존하며 Continuity에 원인 문장을 추가한다. 확인하지 않은 Brand, Condition, Favorite, 보관 위치를 채우지 않는다. 과거 월 구매는 원장 재조정을 요구한다.

Calendar 생성은 안정적인 event ID, event/transaction 출처, 시간대를 갖는다. 초대 수신자는 추가하지 않는다. `CanonicalValidator`가 고정 일정 충돌과 이동시간을 검사한다. 필터 없는 전체 일정 조회와 제안 구간을 포함하는 검증 창을 요구한다. 종일 일정은 조회한 Calendar metadata의 시간대와 exclusive end로 매핑한다. 미확인 시간대는 거부하고, 미확인 장소는 unknown으로 남긴다.

## outbox와 HTTP 어댑터

`write_coordinator.py`는 WAL/synchronous=FULL SQLite에 계획·outbox·영수증·보상·감사 로그를 보존한다. 동일 event의 다른 제안과 decision 재사용을 거부한다. worker lock과 영역 잠금은 중복 실행과 불확실한 사실 확정을 막는다. 여러 서버의 분산 실행은 검증하지 않았다.

| 상태 | 의미 |
|---|---|
| PREPARED | 계획·cache binding을 같은 로컬 transaction에 저장하고 잠금 확보 |
| APPLYING | 전송 전에 outbox 기록, 네이티브 요청·재읽기 수행 |
| COMMITTED | 모든 영수증과 최종 네이티브 재읽기가 일치함 |
| COMPENSATING | 확실한 실패의 앞선 변경을 역순 보상 |
| ROLLED_BACK | 미전송 또는 보상·최종 재읽기로 원상복구 확인 |
| RECONCILE_REQUIRED | 결과·외부 편집·보상이 불확실해 관련 영역 확정을 차단 |

`native_http_adapter.py`의 apply/observe/compensate는 실제 HTTP 전송 계층을 사용한다. 이번 시험의 대상은 loopback 모의 Notion/Calendar 서버다. production 읽기와 쓰기 경로를 구분하며 fixture=True 또는 credential만으로 production 쓰기를 열 수 없다. 허용 origin·상대 경로·헤더를 검사하고 redirect를 차단한다. 오류에는 토큰·응답 본문을 노출하지 않는다.

Notion 생성은 transaction marker와 필드·parent를 확인한다. 응답이 유실되고 marker가 없으면 자동 재전송하지 않는다. marker가 정확히 하나이고 내용이 일치하면 영수증을 회수한다. 중복 marker는 충돌이다. 블록 PATCH 응답 유실은 현재 필드가 같아도 작성 주체를 증명하지 못하므로 UNKNOWN으로 남긴다. read-before-write는 실제 Notion의 원자적 CAS가 아니다. 사람의 동시 편집에 대한 production 보호 설계와 실검증이 남아 있다.

Calendar는 supplied ID로 생성 응답을 회수하고, 보상 DELETE에 영수증 etag의 If-Match를 사용한다. 외부 편집이면 삭제하지 않는다. 삭제 응답 유실은 재읽기의 부재로 확인한다. Notion 보상도 영수증 native hash/version과 일치할 때만 소유한 변경을 되돌린다.

## 정본 증거 검증과 cache 게시

1. `RuntimeEvidenceReader`: 최신 native schema·wallet·Inventory·Continuity와 필터 없는 Calendar를 읽는다. 실패한 영역만 stale로 표시한다. 다른 영역은 계속 검증할 수 있다.
2. `CanonicalValidator`: 명시적인 세계 초기화 근거, cache hash, 출처 scope, 시간, 잔액·예약금·소유권·일정 증거를 확인한다. 실제 구매 가격은 최신 external_verified catalog를 요구한다. 기본 bridge는 구매·spend·calendar_create·런타임 소유 calendar_cancel을 지원한다. 초기화 증거가 있는 hourly 경로는 명시적인 allow_internal 설정으로 observe/need_update/use_item/move/relationship_update를 native 인과·수치 변화 기록에 연결한다.
3. `CanonicalCacheBridge`: 사전에 기록된 event만 받아 outbox와 cache binding을 원자적으로 prepare한다. native COMMITTED 뒤 모든 영수증을 다시 읽고 기존 cache hash가 같을 때만 상태와 event committed를 함께 게시한다.
4. Inventory/Calendar의 모의 ID는 영수증의 native ID로 교체한다. fixture provenance는 mock을 유지하며 live로 재분류하지 않는다. 불확실한 item 위치·상태는 None이다.

게시 직전 외부 편집, 읽기 실패, cache revision 변경은 새 상태를 노출하지 않고 해당 영역을 잠근다. 재시작 후 같은 event를 처리해도 중복 POST나 cache 재게시가 없다. `confirmed_domain()`은 독립적으로 확인된 영역만 반환한다.

일반 지출·조건부 일정 취소·원장 근거가 있는 cache rebase를 추가했다. hourly reader는 복구를 활성화하며 일반 reader는 명시적으로 reconcile_external=True를 요청해야 한다. 임의의 잔액 차이, 수정/삭제된 원장 prefix, 명시적인 대상 월이 없는 월 경계/과거 월 기록, 미확정 거래는 stale/frozen으로 남긴다. 대상 월과 원장 산술이 증명되면 P5_MONTH.md의 월별 조정을 수행한다. Inventory 변화는 raw 증거와 이전 소유권을 보존하며 구매 이야기를 추정하지 않는다. 상세 계약은 P5_EFFECTS.md를 따른다. 검증 가능한 clock-only journal replay와 native 전체 cache/인과 checkpoint 복원을 추가했다(P5_RESTORE.md). 실제 초기화·운영 scheduler·독립 vault/witness/key의 운영 검증은 남아 있다.

## 테스트

```bash
python tools/test_report.py P5_contract P5_recovery P5_http P5_runtime P5_hourly P5_effects P5_clock P5_restore P5_month P5_disaster
python mio.py p5-demo
```

읽기 계약 6개, durable 복구 39개, HTTP 14개, 정본 정책/cache 26개와 초기화/hourly 30개, 일반 지출·일정 취소·rebase 39개, 복구 중 시계 14개·native 복원 19개·월 경계/과거 날짜 34개가 통과했다. HTTP 시험은 네이티브 요청 형태·pagination·응답 유실·403/503·marker 중복·외부 편집·If-Match 412·삭제 유실·토큰 비노출·production 차단을 검사한다. cache 시험은 검증→계획→HTTP→영수증→게시, stale 영역 분리, 시간/이동 충돌, cache drift, 원자적 prepare와 재시작을 검사한다. 실제 정본 쓰기는 0회다.

## 다음 완료 조건

- 서버 API credential로 P3 실제 GPT 계약·실패 복구 검증.
- 실제 native 정본의 최신 재조회, 명시적인 세계 초기화와 내부 수치 근거 확정.
- 실제 native 월 마감 설정/검증, 독립 vault/witness/key 운영 구성·복원 실습, 운영 scheduler 배포.
- Notion 동시 편집·응답 유실 보호 설계와 production canary/실제 read→write→read·보상·재시작 검증.
- 서버 배포와 안전한 secret 입력 경로. 자격증명만 넣고 live gate를 제거하지 않는다.

이 조건이 통과한 뒤 P5 완료를 기록하고 P6로 진행한다. `reports/P5_sources`는 이전 조회 증거이며 최신 실행 상태를 대신하지 않는다.

공식 계약: [Notion Update a block](https://developers.notion.com/reference/update-a-block), [Notion Append block children](https://developers.notion.com/reference/patch-block-children), [Notion Create a page](https://developers.notion.com/reference/post-page), [Notion Delete a block](https://developers.notion.com/reference/delete-a-block), [Calendar conditional modification](https://developers.google.com/workspace/calendar/api/guides/version-resources), [Calendar Delete](https://developers.google.com/workspace/calendar/api/v3/reference/events/delete).

초기화·hourly 단계와 168시간 HTTP fixture 시험은 P5_HOURLY.md에 기록했다. clock replay·native cache 복원의 fixture 검증과 production 완료를 구분한다. native 복원에는 기존 영수증/초기화 DB가 필요하며, 누락된 시간의 historical snapshot을 만들어내지 않는다.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.
