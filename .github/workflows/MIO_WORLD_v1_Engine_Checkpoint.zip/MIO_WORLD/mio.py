#!/usr/bin/env python3
import argparse
import json
import os
from pathlib import Path
from core.state_manager import StateStore
from core.mock_state import mock_state
from core.simulator import Simulator
from core.models import State,Event,Decision,TransactionRecord
from core.chain_engine import ChainEngine
from core.event_grammar import Grammar


def main():
    # A server-local .env is data, never shell code. Existing environment wins.
    env_path=Path(__file__).resolve().parent/".env"
    if env_path.is_file():
        allowed={"OPENAI_API_KEY","OPENAI_MODEL","NOTION_TOKEN","MIO_NOTION_PAGE_ID","GOOGLE_ACCESS_TOKEN","MIO_CALENDAR_ID","MIO_MONTHLY_API_BUDGET_USD"}
        for line in env_path.read_text().splitlines():
            if not line.strip() or line.lstrip().startswith("#") or "=" not in line: continue
            key,value=line.split("=",1); key=key.strip()
            if key in allowed: os.environ.setdefault(key,value.strip().strip("\"'"))
    parser=argparse.ArgumentParser(description="MIO WORLD headless engine; mock and live facts are separate")
    sub=parser.add_subparsers(dest="command",required=True)
    sim=sub.add_parser("simulate",help="Replay artificial hours using deterministic mock policy, no API calls")
    sim.add_argument("--hours",type=int,default=168); sim.add_argument("--seed",type=int,default=42)
    sim.add_argument("--db",default="world-mock.sqlite3"); sim.add_argument("--report",default="reports/latest.json")
    sim.add_argument("--no-novelty",action="store_true")
    sim.add_argument("--no-chains",action="store_true")
    dump=sub.add_parser("dump"); dump.add_argument("--db",default="world-mock.sqlite3")
    dump.add_argument("--output",default="reports/state.json")
    sub.add_parser("schema")
    sub.add_parser("doctor")
    p5=sub.add_parser("p5-demo",help="Native purchase/outbox recovery in isolated fixture providers; no network")
    p5.add_argument("--report",default="reports/P5_offline_demo.json")
    hourly=sub.add_parser("p5-hourly-demo",help="Native hourly stages on loopback HTTP fixtures; no real API/credentials")
    hourly.add_argument("--hours",type=int,default=168)
    hourly.add_argument("--report",default="reports/P5_hourly_demo.json")
    month=sub.add_parser("p5-month-demo",help="48h native month-boundary fixture, late ledger row, restart and cache restore")
    month.add_argument("--report",default="reports/P5_month_demo.json")
    disaster=sub.add_parser("p5-disaster-demo",help="Full primary DB deletion and authenticated backup recovery in HTTP fixtures")
    disaster.add_argument("--report",default="reports/P5_disaster_demo.json")
    resume=sub.add_parser("p5-host-resume-demo",help="Clock-only catch-up, process restart and late receipt in HTTP fixtures")
    resume.add_argument("--report",default="reports/P5_host_resume_demo.json")
    oauth=sub.add_parser("p5-oauth-demo",help="Refresh/reauthorization and no mutation replay in isolated OAuth/native HTTP fixtures")
    oauth.add_argument("--report",default="reports/P5_oauth_demo.json")
    smoke=sub.add_parser("decision-smoke",help="One live API decision on a clearly marked mock event; no canonical commit")
    smoke.add_argument("--report",default="reports/P3_live.json")
    args=parser.parse_args()
    if args.command=="doctor":
        names=["OPENAI_API_KEY","OPENAI_MODEL","NOTION_TOKEN","MIO_NOTION_PAGE_ID","GOOGLE_ACCESS_TOKEN","MIO_CALENDAR_ID"]
        print(json.dumps({"configured":{name:bool(os.getenv(name)) for name in names},"mock_ready":True,"live_world_enabled":False},indent=2))
    elif args.command in {"p5-disaster-demo","p5-host-resume-demo","p5-oauth-demo"}:
        if args.command=="p5-disaster-demo":
            from tools.p5_disaster_demo import run_demo
        elif args.command=="p5-host-resume-demo":
            from tools.p5_host_resume_demo import run_demo
        else:
            from tools.p5_oauth_demo import run_demo
        report=run_demo()
        Path(args.report).parent.mkdir(parents=True,exist_ok=True)
        Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
        print(json.dumps(report,ensure_ascii=False,indent=2))
        return 0 if report['status']=='PASS' else 2
    elif args.command in {"p5-hourly-demo","p5-month-demo"}:
        if args.command=="p5-hourly-demo" and not 1<=args.hours<=720: parser.error("hourly demo hours must be 1..720")
        from tools.p5_hourly_demo import run_demo
        report=run_demo(48,month_boundary=True) if args.command=="p5-month-demo" else run_demo(args.hours)
        Path(args.report).parent.mkdir(parents=True,exist_ok=True)
        Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
        print(json.dumps(report,ensure_ascii=False,indent=2))
        return 0 if report["status"]=="PASS" else 2
    elif args.command=="p5-demo":
        from tools.p5_offline_demo import run_demo
        report=run_demo()
        Path(args.report).parent.mkdir(parents=True,exist_ok=True)
        Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
        print(json.dumps({k:v for k,v in report.items() if k!="native_purchase_requests"},ensure_ascii=False,indent=2))
        return 0 if report["status"]=="PASS" else 2
    elif args.command=="decision-smoke":
        from agents.openai_transport import OpenAITransport,RequestBudget,ProviderUnavailable
        from agents.mio_llm import MioDecisionAgent
        try:
            transport=OpenAITransport(budget=RequestBudget("usage-budget.sqlite3",monthly_usd=float(os.getenv("MIO_MONTHLY_API_BUDGET_USD","5"))))
            grammar=Grammar(); state=mock_state()
            from core.candidate_generator import CandidateGenerator
            from core.novelty_engine import NoveltyEngine
            event=next(e for e in CandidateGenerator(grammar).generate(state,42,NoveltyEngine(grammar.rules)) if e.family!="NO_EVENT")
            agent=MioDecisionAgent(transport,grammar); decision=agent.decide(state,event)
            report={"status":"PASS" if decision else "FAIL","live_api":True,"model":transport.model,"dry_run":True,
                    "decision":decision.model_dump(mode="json") if decision else None,"failures":agent.failures}
        except ProviderUnavailable as error:
            report={"status":"BLOCKED","live_api":False,"dry_run":True,"reason":str(error)}
        Path(args.report).parent.mkdir(parents=True,exist_ok=True)
        Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
        print(json.dumps(report,ensure_ascii=False,indent=2))
        return 0 if report["status"]=="PASS" else 2
    elif args.command=="schema":
        Path("schemas").mkdir(exist_ok=True)
        for model in [State,Event,Decision,TransactionRecord]:
            Path(f"schemas/{model.__name__}.schema.json").write_text(json.dumps(model.model_json_schema(),ensure_ascii=False,indent=2)+"\n")
        print("Wrote 4 JSON schemas")
    elif args.command=="dump":
        store=StateStore(args.db)
        Path(args.output).parent.mkdir(parents=True,exist_ok=True)
        Path(args.output).write_text(store.load(history=True).model_dump_json(indent=2)+"\n")
        store.close(); print(args.output)
    elif args.command=="simulate":
        if not 1<=args.hours<=100000: parser.error("hours must be 1..100000")
        store=StateStore(args.db); store.initialize(mock_state())
        if store.load().mode!="mock": parser.error("simulate cannot use a live canonical database")
        chain=None if args.no_chains else ChainEngine(Grammar())
        report=Simulator(store,args.seed,not args.no_novelty,chain=chain).run(args.hours,progress=lambda n:print(f"Replayed {n} hours",flush=True))
        Path(args.report).parent.mkdir(parents=True,exist_ok=True)
        Path(args.report).write_text(json.dumps(report,ensure_ascii=False,indent=2)+"\n")
        print(json.dumps({k:v for k,v in report.items() if k!="family_counts"},ensure_ascii=False,indent=2)); store.close()

if __name__=="__main__": raise SystemExit(main())
