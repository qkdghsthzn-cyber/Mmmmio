# MIO WORLD v1 — 실행 가능한 headless 엔진

첨부 MASTER TECHNICAL SPECIFICATION을 기준으로 P0부터 순서대로 구현했다. 단계별 상태와 실제 시험 결과는 `IMPLEMENTATION_REPORT.md`, 원문은 `reference/`에 있다.

현재 P0~P2의 규칙 엔진이 동작하며, P3~P4의 계약·실패 복구·후속 사건은 로컬 검증을 통과했다. P5는 native 변경 계획·durable outbox·HTTP 어댑터·정본 증거 검증·cache 게시·명시적인 초기화·시간별 실행을 구현하고 로컬 HTTP 모의 서버에서 검증했다. **실제 정본 쓰기·복구 검증, GPT 호출, 실제 세계 초기화·운영 scheduler 배포, Android APK는 완료되지 않았다.** P5 완료 조건이 통과하기 전 P6~P8로 넘어가지 않는다.

## 바로 실행

Python 3.11 이상이 설치된 PC에서 실행한다. Windows는 `run_mock.bat`, macOS/Linux는 `run_mock.sh`를 실행하면 의존성을 설치하고 가상 7일을 재생한다. 패키지 설치 단계에는 인터넷이 필요하다. 이미 설치된 환경에서는 아래 두 번째 명령만 실행하면 된다.

```bash
python -m pip install -r requirements.txt
python mio.py simulate --hours 168
python mio.py dump
```

이 명령은 API 호출 없이 가상 생활을 재생한다. `world-mock.sqlite3`에 사건·판단·거래·상태가 저장된다. 다시 실행하면 마지막 저장 시점의 다음 시간부터 이어진다. 새로운 실험에는 다른 DB 파일명을 지정한다.

```bash
python mio.py simulate --hours 720 --seed 97 --db experiment.sqlite3 --report reports/experiment.json
python mio.py simulate --hours 10000 --no-chains --db p2-check.sqlite3
python mio.py simulate --hours 720 --no-novelty --db novelty-off.sqlite3
python mio.py doctor
```

기본 simulate는 P4 Chain을 사용한다. P2만 검증하려면 `--no-chains`를 쓴다. `doctor`는 설정 여부만 보여 주며 키 값을 출력하지 않는다.

## 테스트 재실행

```bash
python tools/test_report.py P0 P1 P2 P3 P4 P5_contract P5_recovery P5_http P5_runtime P5_hourly P5_effects P5_clock P5_restore P5_month P5_disaster P5_mobile
python tools/p2_acceptance.py
```

P0~P4 테스트 41개, P5 읽기 계약 6개, 쓰기 계획·복구 39개, HTTP 14개, 정본 검증·cache 26개, 초기화·시간별 실행 30개, 일반 지출·일정 취소·원장 복구 39개, 복구 중 시계 14개, native 상태 복원 19개, 월 경계/과거 날짜 조정 34개, 독립 전체 DB 복구 31개와 기기 검사 코드의 개발 호스트 검증 14개로 누적 307개가 통과했다. 두 번째 명령은 API/외부 쓰기 없이 10,000시간을 재생하고 규칙 위반 0건을 검사한다. 실행 시간은 컴퓨터에 따라 달라진다.

`reports/demo-48h.json`, `reports/demo-state.json`, `reports/demo-world.sqlite3`는 실행 예시다. 이 예시는 P2 시점에 생성되었으며 가상 fixture다. 실제 현재 미오의 소지품·잔액으로 사용하지 않는다.

## GPT 연결 시험

`.env.example`을 `.env`로 복사한 뒤 서버의 `OPENAI_API_KEY`를 설정한다. 모델 기본값은 명시된 `gpt-5.6-luna`이며, 서버에서 키를 보관한다. 실제 응답을 확인하는 명령은 다음과 같다.

```bash
python mio.py decision-smoke
```

명시적인 mock 사건 하나에 대한 JSON 판단을 요청하며, 정본을 변경하지 않는다. 결과는 `reports/P3_live.json`에 기록된다. 키가 없으면 BLOCKED이고, JSON을 두 번 받아도 유효하지 않으면 FAIL이다. 로컬 모의 응답 통과를 실제 GPT 통과로 표시하지 않는다. 월 예산은 `.env`의 `MIO_MONTHLY_API_BUDGET_USD`로 설정하고, 사용 예약은 세계 transaction과 독립된 DB에 보존한다.

현재의 `simulator_policy.py`는 규칙 검증용 선택기다. 실제 미오의 GPT 지능을 대체하는 제품 기능으로 표시하지 않는다.

## 실제 정본과 P5

`connectors/resources.json`에는 실제로 읽어 확인한 Notion 페이지와 Inventory data-source ID가 들어 있다. `reports/P5_sources/`는 그 시점의 원본 읽기 증거다. 최신 실행 전에 정본을 다시 읽어야 한다.

- 지갑: native 페이지의 잔액과 MONEY LOG 표.
- 소지품: 기존 native Notion DB의 원래 properties와 상태.
- 관계·취향·연속성: 기존 문서의 의미와 불확실성을 보존.
- 일정: 기존 Calendar의 반복 일정과 생활 루틴.

서버용 Notion/Google 인증정보가 필요하며 ChatGPT의 연결 세션에서 자동으로 복사되지 않는다. `.env`에 키가 있어도 현재 `apply_live()`는 P5의 쓰기·reconciliation 완료 전까지 막혀 있다. native 지갑/표/DB 계획과 durable outbox·부분 성공 보상·HTTP 어댑터·Canonical Validator/cache 게시가 loopback 모의 서버에서 동작한다. 초기화와 hourly runner·종일 일정 매핑은 fixture에서 검증했다. 일반 지출·런타임 소유 일정 취소·근거가 있는 원장/소유권 복구를 추가했다. 실제 초기화·운영 scheduler·native 월 마감 근거 설정/실연동 검증·독립 vault/witness/key 운영 구성·유실 복원 실습, Notion 동시 편집 보호와 실제 왕복 검증이 남아 있다. 상세 범위는 `P5_WRITES.md`에 있다.

키 없이 복구 시나리오를 실행할 수 있다:

```bash
python mio.py p5-demo
```

실제 쓰기는 0회이며 `reports/P5_offline_demo.json`에 결과와 네이티브 요청 계획을 저장한다.

실제 읽기에서 확인된 지갑은 ¥32,000이고 Inventory DB는 0행이었다. 가상 fixture의 ¥27,850과 5개 소지품은 별도의 시험 데이터다.

## 확장

160 Family는 `data/event_families/*.json`, Modifier는 `data/modifiers/`, 제약과 chain은 `data/rules/`에 있다. Family에는 requires / forbids / binds / effects_if_committed 계약이 있다. 정의 파일을 추가해 확장할 수 있으며, 새 effect는 Validator 구현과 함께 검증해야 한다.

사진 참고자료는 이미 제공된 원본을 사용한다. `reference/asset_index.json`에 원본 파일의 ID와 해시를 보존했다. Android UI에서 엔진 로직을 다시 작성하지 않는다. 날짜·가격·소유권·과거 행동을 GPT 문장만으로 확정하지 않는다.

공식 API 참고: [Structured Outputs](https://developers.openai.com/api/docs/guides/structured-outputs), [GPT-5.6 Luna](https://developers.openai.com/api/docs/models/gpt-5.6-luna), [Notion pages](https://developers.notion.com/reference/page), [Calendar events](https://developers.google.com/workspace/calendar/api/v3/reference/events).

## 네이티브 시간별 실행 시험

```bash
python mio.py p5-hourly-demo --hours 168
```

별도의 loopback HTTP 모의 서버에서 초기화→동기화→욕구→기존 Grammar/Probability/Novelty→판단→native commit→인과/hook→snapshot 순서로 가상 7일을 처리한다. 키·실제 GPT 호출·정본 쓰기는 없다. 168개 snapshot을 재읽기로 검증했다. 초기화 계약과 장애·재시작 제한은 P5_HOURLY.md, 결과는 reports/P5_hourly_demo.json에 있다.

일반 지출·일정 취소·외부 원장/Inventory 복구의 지원 범위와 제한은 `P5_EFFECTS.md`를 따른다. 실제 비용 증거 없이 fixture 고정 지출을 live 사실로 승격하지 않는다.

미확정 거래 중에는 clock-only journal로 시각·욕구·확정된 이동·후속 기한만 진행한다. 거래가 확인되면 projection에 같은 시간 변화를 재생하여 시계 역행을 막는다. 새 native checkpoint는 전체 cache와 인과 기록을 조각으로 저장하며, 영수증/초기화 DB가 보존된 캐시 삭제·손상에서 복원할 수 있다. 지원 범위·복원 진입점: `P5_RESTORE.md`.

월 경계·늦게 추가된 원장 행은 원문의 `支出対象月: YYYY-MM`과 안정적인 원장/잔액/월 지출 증거가 있을 때 읽기 전용으로 조정한다. native 월 지출을 임의로 reset하거나 대상 월 block을 자동 생성하지 않는다. `python mio.py p5-month-demo`는 월말을 포함한 48시간, 지난달 지출의 늦은 import, 재시작과 캐시 삭제 후 복원을 검증한다. 상세 계약: `P5_MONTH.md`, 결과: `reports/P5_month_demo.json`.

## 독립 DB 복구 체크포인트

`P5_DISASTER.md`의 opt-in vault는 전체 coordinator DB와 WAL commit을 인증한 이미지로 보존한다. fixture DB 전체 삭제 후 전송 상태·영수증·시계·월별 근거를 복원하고 정본 재확인 전까지 실행을 동결한다. 31개 신규 장애 시험, 전체 회귀 293개, 168시간·월말 48시간 fixture가 PASS다. 실제 정본 쓰기는 0회다. 독립 이미지·최신 witness·서명 키가 남아 있어야 하며, 운영 배포·동시 유실 복구를 완료했다고 표시하지 않는다.

키 없이 DB 전체 삭제·복구 데모를 실행한다:

```bash
python mio.py p5-disaster-demo
```

결과: `reports/P5_disaster_demo.json`.

## 우선 실행 환경: 사용자 Z Fold8

사용자의 상시 온라인 기기인 Z Fold8을 우선 호스트로 검토한다. `P5_MOBILE_HOST.md`와 `deployment/host_target.json`에 Android 절전·지연 tick·기존 Python 내장·credential 보호·기기 밖 백업의 검증 순서를 기록했다. 기기 검사 및 지연 복구 소스는 fixture에서 검증했으며 APK/Android 실행 시험은 미진행이다. 개발 호스트 PASS를 Android 시험으로 표시하지 않는다. P5 완료 전 P6~P8은 진행하지 않는다.

## P5 기기 검사 소스

`android-probe/README.md`의 진단 Activity는 기존 엔진과 160 Family를 그대로 staging한다. Python 진입점에서 6→12시간 fixture 저장 재개, native hourly·DB 유실·host resume와 원본 import 경로를 제외한 staging 사본 실행을 검증했다. Android 의존성·컴파일·설치 시험은 미진행이며, 기기용 APK는 아직 없다.

## P5 실행 지연 복구

`runtime/host_resume.py`는 휴대폰 절전처럼 실행이 멈춘 뒤, 누락 시간을 기존 physics로 한 시간씩 진행하는 별도 복구 경로다. 한 호출은 최대 24개 시간 기록을 처리하고 UTC 기준으로 중복·역행을 막는다. 해당 시간에는 GPT 판단·새 구매/외출·역사 snapshot을 만들지 않는다. 이미 확정된 이동·욕구·hook 기한과 기존 미완료 거래만 처리한다. 신규 요청 없이 전송 상태/영수증을 먼저 복구하고, fresh Notion/Calendar 재조회 전 새 요청과 확인된 사실의 공개를 차단한다.

지연 복구 체크포인트에서 22개 복구·16개 기기 검사 시험을 포함한 전체 331개 회귀와 해당 데모를 실행했다. 최신 인증 체크포인트의 368개 결과는 아래 항목을 따른다. P2 10,000시간 결과는 원본 core/data/reference가 바뀌지 않아 이전 PASS를 보존하며 재실행하지 않았다. **Android APK 빌드는 계속 BLOCKED, 실제 절전/재부팅·실기기 실행은 NOT_RUN**이다. P5 실제 연동 gate와 P0→P8 순서를 유지한다. 상세 계약과 증거: `P5_HOST_RESUME.md`, `reports/P5_host_resume_tests.json`, `reports/P5_host_resume_demo.json`.

## P5 인증 갱신·외부 빌드 준비

`connectors/google_oauth.py`와 `HTTPJSON/CalendarConnector`를 연결했다. 만료 전 갱신, invalid_grant 재인증 차단, retry 지연, GET 401 1회 재시도와 mutation 401 자동 재전송 금지를 fixture에서 검증했다. store는 메모리뿐이며 실제 로그인·Android 암호화 저장·재시작 credential 보존은 미구현이다. `P5_AUTH.md`를 따른다.

OAuth 35개·mobile 18개를 포함한 전체 368개 회귀와 168시간·월말 48시간·DB 유실 fixture를 이번 체크포인트에서 재실행했다. 개인 자료를 제외한 code-only build source의 독립 사본에서도 53개 mobile/OAuth 시험이 PASS다. 기존 P2 10,000시간 PASS는 byte-for-byte 보존하며 이번에 재실행하지 않았다. `P5_REMOTE_BUILD.md`의 수동 자동빌드 설정과 `deployment/MIO_P5_Build_Sources.zip`를 준비했지만 GitHub 계정/repository/job은 연결·실행하지 않았다. **APK/Android 실기기 시험은 아직 NOT_RUN, 로컬 빌드 준비는 BLOCKED**다. P5 실제 정본 gate와 개발 순서는 유지한다.

## Fold8에서 Colab 빌드 준비

PC를 사용할 수 없고 GitHub MFA 설정이 어려운 사용자 환경을 반영하여 `P5_COLAB_BUILD.md`의 Google Colab CPU 노트북을 준비했다. `deployment/MIO_P5_Fold8_Build.ipynb` 하나에 build source를 내장하므로 별도 source 업로드/GitHub 연결/Drive mount/API 키 입력은 필요 없다. Google 로그인은 필요하다. P0부터 368개 fixture를 순서대로 통과한 경우에만 기존 APK build helper를 실행하며 실패하면 진단 ZIP을 만든다.

이전 export는 agent가 직접 읽는 Core Identity를 누락해 독립 전체 회귀 P3가 실패했다. staging/export에 원본 Core Identity 하나를 추가하고 다른 reference 첨부는 제외했다. 수정한 254개 파일 export의 전체 368개 회귀가 독립 Linux/Python 3.12 환경에서 PASS다. 원본 core/data/reference와 기존 P2 10,000시간 보고서는 바꾸지 않았다. 노트북 JSON/Python 문법·내장 원본 hash·실패 시 빌드 차단을 검증했다. **Colab 실행/Python 3.13/Android 컴파일/APK/실기기 시험은 NOT_RUN**이며 P5 live gate와 P0→P8 순서는 유지한다. 이번 작업에서 168시간·월말 48시간·DB 유실 데모는 재실행하지 않았고 이전 보고서를 보존했다.

## Fold8의 GitHub 사이트에서 직접 빌드

사용자가 GitHub 웹 로그인과 저장소 생성을 할 수 있다고 확인하여 `P5_GITHUB_PHONE.md`의 직접 Actions 경로를 준비했다. source ZIP을 root에 올리고 `.github/workflows/mio-p5-phone.yml`을 기본 브랜치에 등록하면 runner가 hash/manifest를 확인하여 추출한다. ChatGPT GitHub 플러그인·PC·runtime API 키가 필요 없다. `deployment/MIO_GitHub_Fold8_Guide.html`에 파일 경로/전체 설정 복사 버튼과 수동 선택 대안을 포함했다.

변경하지 않은 254개 source ZIP과 이전 독립 전체 368 PASS를 유지했다. workflow 문법·실제 extraction shell의 254개 byte 일치·missing/corrupt ZIP 차단 3개·fixture acceptance gate 4개·APK receipt gate 5개 사례 및 안내 copy 원문/JS 문법을 확인했다. APK receipt gate에는 명시적인 모의 bytes만 사용했다. **실제 GitHub repository/job/Python 3.13/Android 컴파일/APK/실기기 검사는 NOT_RUN**이다. core/data/reference·P2 10,000시간 보고서와 P5 live gate는 보존한다. Colab도 별도 선택 경로로 남아 있다.

## 첫 GitHub 실행 확인 및 오류 표시 보완 (2026-10-06)

사용자가 올린 `logs_101431036398.zip`의 console에서 368개 fixture 전체 PASS를 실제 GitHub/Python 3.13.15 환경에서 확인했다. Java/javac 17·Gradle 8.13·Android SDK 검사도 적합했고 218개 runtime source/160 Family가 staging됐다. 이후 Android build가 Gradle exit 1/helper exit 2로 실패하여 APK는 없다. `reports/P5_github_run1.json`을 최신 상태로 따른다. 이전 NOT_RUN 기록은 해당 준비 체크포인트 당시 상태다.

console에는 helper가 파일로 저장한 실제 Gradle 오류가 없다. 첫 실행의 [MIO_P5_build_diagnostics.zip](https://github.com/qkdghsthzn-cyber/Miooi/actions/runs/37447059977/artifacts/11403891732) 업로드 성공/33,532 bytes를 확인했지만 파일 내용은 아직 받지 못했다. 해당 ZIP을 먼저 받으면 재실행 없이 분석할 수 있다. Download logs의 ZIP과 Summary/Artifacts의 진단 ZIP은 서로 다르다.

phone workflow에 실패한 Android build 뒤 `Show Android build error log`를 추가했다. 마지막 200줄을 표시하며 원래 build 실패/후속 APK 차단은 유지한다. 누락/빈/200줄 제한 로그 3사례, YAML/shell/inline Python·안내 JS/copy 원문을 확인했다. 원본 source ZIP과 core/data/reference 193개 및 기존 회귀/P2 보고서는 변경하지 않았다. **실패 원인은 미확인/미수정이고 새 workflow remote 실행은 NOT_RUN**이다. 진단 ZIP을 받을 수 없는 경우에만 YAML 본문을 교체하여 Commit 후 **새 Run workflow**로 실행한다. P5 live gate와 P6~P8 NOT_STARTED를 유지한다.

## Android 바이너리 의존성 오류 수정 (2026-10-06)

첫 실행의 `MIO_P5_build_diagnostics.zip`(SHA `8eb7e1a…83c80e`)에서 실제 18단계 368 PASS와 Gradle 원인을 확인했다. `:probe:installDebugPythonRequirements`가 Pydantic 2.13 계열의 정확한 `pydantic-core` Android wheel을 찾지 못해 실패했다. Gradle 8.13 안내 경고가 실패 이유는 아니다. 최신 증거는 `reports/P5_android_dependencies_fix.json`이다.

엔진/스키마/requirements 범위를 바꾸지 않고 Android 빌드 constraint에 첫 실행 버전 Pydantic 2.13.5/core 2.46.5를 고정했다. `tools/build_android_wheels.py`는 SHA가 고정된 공식 upstream sdist를 추출하고 Cargo.lock을 유지하여 cibuildwheel 4.3.0/Rust 1.88.0으로 CPython 3.13/API24/arm64-v8a와 x86_64 wheel을 만든다. cibuildwheel이 실제 Android libpython/sysconfig·NDK·Cargo linker/PyO3 환경을 제공한다. version/tag/native ELF architecture/16KiB LOAD alignment와 두 ABI receipt를 확인한 경우에만 Gradle find-links로 공급한다. 새 temp output을 사용해 실패 후 이전 wheel을 재사용하지 않는다. Gradle 실패는 stacktrace와 native-wheel/Gradle 진단 로그로 남긴다. 설치/런타임 적합성은 여전히 실기기 검증 대상이다.

기존 368개와 새 synthetic binary receipt/source guard 10개를 포함한 **378개 회귀가 개발 tree 및 배포 ZIP의 독립 Linux/Python 3.12.14 사본에서 모두 PASS**다. 실제 upstream hash/extraction·cibuildwheel의 두 대상 선택·wheel 실패 시 Gradle/APK 차단·workflow/notebook/guide 문법과 embedded ZIP/copy 원문을 확인했다. synthetic bytes를 실제 wheel/APK로 내보내지 않는다. 원본 engine/data/reference/mobile 227개와 160 Family, P2 10,000시간 보고서 및 live gate를 보존했다.

새 source ZIP은 258개 파일/SHA `feb53d33ffe39372cd88cd7b4c81294e0a40e6ec9c9989205c3501634e6a18fe`이다. **소스 ZIP과 phone YAML 둘 다 교체·Commit하고 새 Run workflow를 실행해야 한다.** 이전 실행의 Re-run jobs는 이전 revision을 사용한다. Colab 노트북에도 새 ZIP/constraint/378개 gate를 반영했으나 선택 경로이며 실행하지 않았다. **수정본의 native wheel compilation·Gradle/APK·Android 실행은 NOT_RUN**이다. P5가 완료된 것으로 표시하지 않으며 P6~P8은 계속 NOT_STARTED다.

공식 빌드 참고: [Chaquopy Android wheel 빌드](https://github.com/chaquo/chaquopy/blob/master/server/pypi/README.md), [cibuildwheel Android](https://cibuildwheel.pypa.io/en/stable/platforms/#android), [PyO3 cross compilation](https://pyo3.rs/main/building-and-distribution.html#cross-compiling).
