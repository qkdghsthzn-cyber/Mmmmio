"""Authenticated full coordinator checkpoints; isolated fixture scope only.

The vault, protected latest witness, and signing key must survive primary DB
loss. A dirty witness forbids fallback. Images authenticate, not encrypt, data.
"""
try: import fcntl
except ImportError: fcntl=None
import hashlib
import hmac
import json
import os
import re
import secrets
import sqlite3
import tempfile
from contextlib import contextmanager
from pathlib import Path
from core.models import State, Event
from core.validator import Validator
from .http_json import ConnectorUnavailable
from .write_models import WritePlan, digest

MAX_BYTES = 64 * 1024 * 1024
REQUIRED = {'external_transactions','external_outbox','external_locks','canonical_commits','external_audit',
            'runtime_cache','cache_bindings','cache_binding_bases','cache_clock_steps','canonical_events',
            'runtime_initialization','native_rebase_anchor','native_rebase_journal','hourly_ticks',
            'hourly_decisions','hourly_realizations','hourly_snapshots','hourly_mutations','runtime_continuity_archive'}


class RecoveryUnavailable(ConnectorUnavailable):
    pass


def _json(value):
    return json.dumps(value,sort_keys=True,ensure_ascii=False,separators=(',',':'),allow_nan=False).encode()


def _fsync_directory(path):
    descriptor=os.open(path,os.O_RDONLY | os.O_DIRECTORY)
    try: os.fsync(descriptor)
    finally: os.close(descriptor)


def _write(path,data):
    fd,name=tempfile.mkstemp(prefix='.recovery-',dir=path.parent)
    try:
        with os.fdopen(fd,'wb') as out:
            out.write(data); out.flush(); os.fsync(out.fileno())
        os.replace(name,path); _fsync_directory(path.parent)
    finally:
        if os.path.exists(name): os.unlink(name)


def _copy_no_replace(path,data):
    """Install verified bytes without following links or replacing a target.

    Android app sandboxes may deny hard-link creation even when both paths are
    private app files.  O_EXCL preserves the restore gate's no-overwrite rule;
    a failed copy is removed while the caller still owns the recovery lock.
    """
    flags=os.O_WRONLY | os.O_CREAT | os.O_EXCL
    flags |= getattr(os,'O_CLOEXEC',0) | getattr(os,'O_NOFOLLOW',0)
    created=False
    try:
        fd=os.open(path,flags,0o600); created=True
        with os.fdopen(fd,'wb') as out:
            out.write(data); out.flush(); os.fsync(out.fileno())
        _fsync_directory(Path(path).parent)
    except BaseException:
        if created:
            try: Path(path).unlink()
            except OSError: pass
        raise


def logical_hash(db,base=False):
    objects=[]
    for name,kind,sql in db.execute("SELECT name,type,sql FROM sqlite_master WHERE name NOT LIKE 'sqlite_%' ORDER BY name"):
        if base and name=='database_recovery_gate': continue
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',name): raise RecoveryUnavailable('unsupported recovery schema identity')
        rows=[]
        if kind=='table':
            for row in db.execute('SELECT * FROM "'+name+'" ORDER BY rowid'):
                rows.append([{'bytes':v.hex()} if isinstance(v,bytes) else v for v in row])
        objects.append([name,kind,sql,rows])
    return digest(objects)


def validate_database(db,world_id,lineage=None):
    if db.execute('PRAGMA integrity_check').fetchone()[0]!='ok': raise RecoveryUnavailable('recovery image integrity failed')
    tables={r[0] for r in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if not REQUIRED | {'database_recovery_identity'} <= tables: raise RecoveryUnavailable('full recovery proof tables are missing')
    identity=db.execute('SELECT world_id,lineage,sequence FROM database_recovery_identity WHERE id=1').fetchone()
    if not identity or identity[0]!=world_id or (lineage is not None and identity[1]!=lineage):
        raise RecoveryUnavailable('recovery world/lineage differs')
    cache=db.execute('SELECT body,scope FROM runtime_cache WHERE id=1').fetchone()
    if not cache or cache[1]!='fixture': raise RecoveryUnavailable('fixture recovery requires a complete fixture cache')
    state=State.model_validate_json(cache[0]); Validator.invariants(state)
    if state.mode!='mock': raise RecoveryUnavailable('fixture checkpoint cannot restore a live world')
    init=db.execute('SELECT body,proof_hash FROM runtime_initialization WHERE id=1').fetchone()
    if not init or digest(json.loads(init[0]))!=init[1] or json.loads(init[0])['scope']!='fixture':
        raise RecoveryUnavailable('recovery initialization proof differs')
    transactions={r['transaction_id']:r for r in db.execute('SELECT * FROM external_transactions')}
    for tx,row in transactions.items():
        plan=WritePlan.model_validate_json(row['plan'])
        if plan.evidence_scope!='fixture' or plan.transaction_id!=tx or plan.event_id!=row['event_id'] or plan.decision_id!=row['decision_id'] or digest(plan.model_dump(mode='json'))!=row['plan_hash']:
            raise RecoveryUnavailable('recovery transaction proof differs')
        if row['status'] not in {'PREPARED','APPLYING','COMPENSATING','RECONCILE_REQUIRED','COMMITTED','ROLLED_BACK'}:
            raise RecoveryUnavailable('unknown recovery transaction status')
        operations=db.execute('SELECT * FROM external_outbox WHERE transaction_id=? ORDER BY ordinal',(tx,)).fetchall()
        if len(operations)!=len(plan.operations): raise RecoveryUnavailable('recovery outbox is incomplete')
        for ordinal,(saved,op) in enumerate(zip(operations,plan.operations)):
            if saved['ordinal']!=ordinal or json.loads(saved['body'])!=op.model_dump(mode='json') or saved['status'] not in {'PENDING','APPLYING','APPLIED','FAILED','UNDOING','UNDONE'}:
                raise RecoveryUnavailable('recovery operation proof differs')
        locks={r[0] for r in db.execute('SELECT resource_key FROM external_locks WHERE transaction_id=?',(tx,))}
        expected={op.resource_key for op in plan.operations}|{'domain:'+op.domain for op in plan.operations}
        if locks != (set() if row['status'] in {'COMMITTED','ROLLED_BACK'} else expected):
            raise RecoveryUnavailable('recovery domain locks differ')
        commit=db.execute('SELECT * FROM canonical_commits WHERE transaction_id=?',(tx,)).fetchone()
        if bool(commit)!=(row['status']=='COMMITTED'): raise RecoveryUnavailable('recovery commit/status differs')
        if commit and (commit['event_id']!=plan.event_id or commit['decision_id']!=plan.decision_id or commit['evidence_scope']!='fixture'):
            raise RecoveryUnavailable('recovery commit identity differs')
    for table in ['external_outbox','external_locks','canonical_commits','cache_bindings','cache_binding_bases','cache_clock_steps']:
        if any(r[0] not in transactions for r in db.execute('SELECT transaction_id FROM '+table)):
            raise RecoveryUnavailable('orphan recovery transaction records')
    for row in db.execute('SELECT * FROM cache_bindings'):
        if row['status'] not in {'PENDING','PUBLISHED','ROLLED_BACK','RECONCILE_REQUIRED'}: raise RecoveryUnavailable('unknown cache binding status')
        State.model_validate_json(row['after_body'])
        base=db.execute('SELECT body FROM cache_binding_bases WHERE transaction_id=?',(row['transaction_id'],)).fetchone()
        if not base or digest(State.model_validate_json(base[0]).model_dump(mode='json'))!=row['before_hash']:
            raise RecoveryUnavailable('recovery cache binding base differs')
    for row in db.execute('SELECT body FROM canonical_events'): Event.model_validate_json(row[0])
    return identity


class DatabaseRecoveryVault:
    def __init__(self,directory,witness,key,world_id):
        if not isinstance(key,bytes) or len(key)<32 or not world_id:
            raise ValueError('explicit world identity and a separate 32-byte signing key required')
        self.directory=Path(directory).resolve(); self.witness=Path(witness).resolve()
        if self.witness.is_relative_to(self.directory): raise ValueError('latest witness must be outside the backup directory')
        self.key=key; self.world_id=world_id
        self.bound_connection=None; self.bound_inode=None
        self.directory.mkdir(parents=True,exist_ok=True,mode=0o700)
        self.witness.parent.mkdir(parents=True,exist_ok=True,mode=0o700)

    def _sign(self,body): return hmac.new(self.key,_json(body),hashlib.sha256).hexdigest()
    def _save_witness(self,body):
        try: _write(self.witness,_json({'body':body,'signature':self._sign(body)}))
        except OSError: raise RecoveryUnavailable('protected recovery witness could not be saved') from None

    def latest(self,allow_dirty=False):
        try:
            if self.witness.stat().st_size>65536: raise RecoveryUnavailable('recovery witness is oversized')
            envelope=json.loads(self.witness.read_bytes()); body=envelope['body']
            if not hmac.compare_digest(envelope['signature'],self._sign(body)):
                raise RecoveryUnavailable('recovery witness authentication failed')
            if body['format']!='mio-db-v1' or body['world_id']!=self.world_id or not re.fullmatch(r'[0-9a-f]{32}',body['lineage']) or type(body['sequence']) is not int or body['sequence']<1:
                raise RecoveryUnavailable('recovery witness identity differs')
            if body['status'] not in {'CLEAN','DIRTY'} or (body['status']!='CLEAN' and not allow_dirty):
                raise RecoveryUnavailable('checkpoint interrupted; no older image fallback')
            if body['status']=='CLEAN' and (body['file']!=f"checkpoint-{body['lineage']}-{body['sequence']}.sqlite3" or not 1<=body['size_bytes']<=MAX_BYTES):
                raise RecoveryUnavailable('recovery image identity/size differs')
            return body
        except (OSError,ValueError,KeyError,TypeError) as error:
            raise RecoveryUnavailable('recovery witness unavailable or invalid') from error

    @contextmanager
    def lock(self):
        if fcntl is None: raise RecoveryUnavailable('recovery vault requires a Linux/Unix host with file locks')
        fd=os.open(self.witness.with_suffix('.lock'),os.O_CREAT|os.O_RDWR,0o600)
        try:
            try: fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
            except BlockingIOError: raise RecoveryUnavailable('another checkpoint/recovery owns the witness') from None
            yield
        finally: os.close(fd)

    def _source(self,db):
        path=Path(db.execute('PRAGMA database_list').fetchone()[2]).resolve()
        if self.directory.is_relative_to(path.parent) or self.witness.is_relative_to(path.parent):
            raise RecoveryUnavailable('backup and witness must be outside the primary DB directory')
        if not path.is_file(): raise RecoveryUnavailable('primary DB disappeared; close workers before restoration')
        if db is self.bound_connection and (path.stat().st_dev,path.stat().st_ino)!=self.bound_inode:
            raise RecoveryUnavailable('primary DB was replaced while a worker was still open')
        return path

    def ensure_clean(self,db):
        path=self._source(db); head=self.latest()
        identity=db.execute('SELECT world_id,lineage,sequence FROM database_recovery_identity WHERE id=1').fetchone()
        if not identity or tuple(identity)!=(self.world_id,head['lineage'],head['sequence']) or str(path)!=head['database_path'] or logical_hash(db)!=head['logical_hash']:
            raise RecoveryUnavailable('primary database differs from latest protected checkpoint')
        return head

    def attach(self,coordinator):
        db=coordinator.db
        with self.lock():
            path=self._source(db)
            if self.witness.exists():
                head=self.latest()
                identity=validate_database(db,self.world_id,head['lineage'])
                if identity[2]!=head['sequence'] or str(path)!=head['database_path']:
                    raise RecoveryUnavailable('existing checkpoint cannot be replaced by another DB')
                if logical_hash(db)!=head['logical_hash']:
                    gate=db.execute("SELECT name FROM sqlite_master WHERE name='database_recovery_gate'").fetchone()
                    gate=db.execute('SELECT status,backup_hash FROM database_recovery_gate WHERE id=1').fetchone() if gate else None
                    if not gate or tuple(gate)!=('NEEDS_REVALIDATION',head['sha256']) or logical_hash(db,base=True)!=head['base_hash']:
                        raise RecoveryUnavailable('primary contents differ from checkpoint')
            else:
                if db.execute("SELECT name FROM sqlite_master WHERE name='database_recovery_identity'").fetchone():
                    raise RecoveryUnavailable('protected witness is missing; refusing to start a new lineage')
                db.execute('CREATE TABLE database_recovery_identity(id INTEGER PRIMARY KEY CHECK(id=1),world_id TEXT NOT NULL,lineage TEXT NOT NULL,sequence INTEGER NOT NULL)')
                db.execute('INSERT INTO database_recovery_identity VALUES(1,?,?,0)',(self.world_id,secrets.token_hex(16)))
                validate_database(db,self.world_id)
            previous=self.begin(db,initial=True)
            # Baseline attachment is not an external request. Persist its sequence
            # with its full image while the same witness lock is held.
            self.finish(db)
            self.bound_connection=db; self.bound_inode=(path.stat().st_dev,path.stat().st_ino)
        coordinator.recovery_vault=self

    def begin(self,db,initial=False):
        path=self._source(db)
        previous=self.latest() if self.witness.exists() else None
        if not initial: self.ensure_clean(db)
        identity=db.execute('SELECT world_id,lineage,sequence FROM database_recovery_identity WHERE id=1').fetchone()
        sequence=(previous['sequence'] if previous else identity[2])+1
        dirty={'format':'mio-db-v1','status':'DIRTY','world_id':self.world_id,'lineage':identity[1],
               'sequence':sequence,'database_path':str(path)}
        self._save_witness(dirty)
        db.execute('UPDATE database_recovery_identity SET sequence=? WHERE id=1',(sequence,))
        return previous

    def abort(self,previous):
        if previous is None: raise RecoveryUnavailable('initial checkpoint failed; protected witness remains dirty')
        self._save_witness(previous)

    def finish(self,db):
        dirty=self.latest(allow_dirty=True)
        if dirty['status']!='DIRTY': raise RecoveryUnavailable('checkpoint must follow a durable dirty fence')
        identity=validate_database(db,self.world_id,dirty['lineage'])
        if identity[2]!=dirty['sequence']: raise RecoveryUnavailable('checkpoint sequence differs from write fence')
        fd,name=tempfile.mkstemp(prefix='.image-',dir=self.directory); os.close(fd)
        try:
            destination=sqlite3.connect(name)
            try: db.backup(destination)
            finally: destination.close()
            path=Path(name)
            if path.stat().st_size>MAX_BYTES: raise RecoveryUnavailable('recovery image exceeds configured size bound')
            raw=path.read_bytes(); checksum=hashlib.sha256(raw).hexdigest()
            filename=f"checkpoint-{dirty['lineage']}-{dirty['sequence']}.sqlite3"
            _write(self.directory/filename,raw)
            clean={**dirty,'status':'CLEAN','file':filename,'size_bytes':len(raw),'sha256':checksum,
                   'logical_hash':logical_hash(db),'base_hash':logical_hash(db,base=True)}
            self._save_witness(clean)
            # Only obsolete files owned by this lineage are eligible for pruning.
            for old in self.directory.glob('checkpoint-'+dirty['lineage']+'-*.sqlite3'):
                match=re.fullmatch(r'checkpoint-'+dirty['lineage']+r'-(\d+)\.sqlite3',old.name)
                if match and int(match[1])<dirty['sequence']-2:
                    try: old.unlink()
                    except OSError: pass
            return clean
        except (OSError,sqlite3.Error):
            raise RecoveryUnavailable('full checkpoint could not be saved; protected witness remains dirty') from None
        finally: Path(name).unlink(missing_ok=True)

    def repair_live(self,coordinator):
        """Explicitly finish an interrupted checkpoint from the surviving DB."""
        db=coordinator.db
        with self.lock():
            dirty=self.latest(allow_dirty=True); path=self._source(db)
            if dirty['status']!='DIRTY' or str(path)!=dirty['database_path']:
                raise RecoveryUnavailable('repair requires the surviving primary and its dirty witness')
            identity=validate_database(db,self.world_id,dirty['lineage'])
            if identity[2] not in {dirty['sequence'],dirty['sequence']-1}:
                raise RecoveryUnavailable('surviving primary sequence differs from interrupted checkpoint')
            next_head={**dirty,'sequence':dirty['sequence']+1}
            db.execute('BEGIN IMMEDIATE')
            try:
                self._save_witness(next_head)
                db.execute('UPDATE database_recovery_identity SET sequence=? WHERE id=1',(next_head['sequence'],))
                db.execute('COMMIT')
            except BaseException:
                if db.in_transaction: db.execute('ROLLBACK')
                raise
            head=self.finish(db)
            self.bound_connection=db; self.bound_inode=(path.stat().st_dev,path.stat().st_ino)
        coordinator.recovery_vault=self
        return {'status':'CHECKPOINT_REPAIRED','sequence':head['sequence'],'external_writes':0}

    def restore(self,target,expected_sequence=None):
        target=Path(target).resolve()
        with self.lock():
            head=self.latest()
            if expected_sequence is not None and head['sequence']!=expected_sequence:
                raise RecoveryUnavailable('protected recovery sequence differs from caller witness')
            if str(target)!=head['database_path']: raise RecoveryUnavailable('recovery target differs from protected world path')
            if any(Path(str(target)+suffix).exists() for suffix in ['', '-wal', '-shm', '.worker', '.scheduler']):
                raise RecoveryUnavailable('close workers and preserve/remove primary remnants before restoring')
            image=self.directory/head['file']
            try:
                if image.stat().st_size!=head['size_bytes']: raise RecoveryUnavailable('recovery image size differs')
                raw=image.read_bytes()
            except OSError: raise RecoveryUnavailable('latest recovery image unavailable; no older fallback') from None
            if hashlib.sha256(raw).hexdigest()!=head['sha256']: raise RecoveryUnavailable('recovery image authentication differs')
            target.parent.mkdir(parents=True,exist_ok=True)
            fd,name=tempfile.mkstemp(prefix='.restore-',dir=target.parent); os.close(fd)
            try:
                Path(name).write_bytes(raw)
                db=sqlite3.connect(name,isolation_level=None); db.row_factory=sqlite3.Row
                try:
                    identity=validate_database(db,self.world_id,head['lineage'])
                    if identity[2]!=head['sequence'] or logical_hash(db)!=head['logical_hash']:
                        raise RecoveryUnavailable('recovery sequence/content differs')
                    db.execute('CREATE TABLE IF NOT EXISTS database_recovery_gate(id INTEGER PRIMARY KEY CHECK(id=1),status TEXT NOT NULL,backup_hash TEXT NOT NULL)')
                    db.execute("INSERT INTO database_recovery_gate VALUES(1,'NEEDS_REVALIDATION',?) ON CONFLICT(id) DO UPDATE SET status=excluded.status,backup_hash=excluded.backup_hash",(head['sha256'],))
                    db.execute('PRAGMA journal_mode=DELETE')
                finally: db.close()
                with open(name,'rb') as stream: os.fsync(stream.fileno())
                # Hard-link with no overwrite closes the target creation race.
                # Some Android app sandboxes deny hard links with EPERM. Keep
                # the same no-overwrite contract there with O_EXCL creation.
                try:
                    os.link(name,target); _fsync_directory(target.parent)
                except PermissionError:
                    _copy_no_replace(target,raw)
            finally: Path(name).unlink(missing_ok=True)
            return {'status':'RESTORED_FROZEN','sequence':head['sequence'],'external_writes':0}


def recovery_pending(db):
    if not db.execute("SELECT name FROM sqlite_master WHERE name='database_recovery_gate'").fetchone(): return False
    row=db.execute('SELECT status FROM database_recovery_gate WHERE id=1').fetchone()
    return row is not None and row[0]!='VERIFIED'


def revalidate_recovered(runtime):
    """Resume only durable intents, reread native facts, then release the gate."""
    bridge=runtime.bridge; coordinator=runtime.coordinator
    if not recovery_pending(bridge.db): return {'status':'ALREADY_VERIFIED','decision_calls':0}
    if coordinator.recovery_vault is None: raise RecoveryUnavailable('reattach the surviving vault before recovery I/O')
    with runtime.scheduler_lock():
        coordinator.recovery_vault.ensure_clean(bridge.db)
        for row in bridge.db.execute("SELECT transaction_id FROM external_transactions WHERE status NOT IN ('COMMITTED','ROLLED_BACK')").fetchall():
            tx=row[0]
            if coordinator.status(tx)=='RECONCILE_REQUIRED': coordinator.reconcile(tx)
            else: coordinator.run(tx)
        if not runtime._recover(): return {'status':'WAITING_NATIVE_RECOVERY','decision_calls':0}
        if not coordinator.confirmations_allowed(): return {'status':'WAITING_NATIVE_RECOVERY','decision_calls':0}
        try:
            evidence=runtime._read()
            if evidence.notion is None or evidence.calendar_stale or not evidence.calendar_complete:
                return {'status':'WAITING_FRESH_NATIVE_READ','decision_calls':0}
            runtime._refresh_calendar(evidence)
        except (ValueError,ConnectorUnavailable): return {'status':'WAITING_FRESH_NATIVE_READ','decision_calls':0}
        with coordinator.atomic():
            runtime._save(bridge.state(),'database.restore','verified_database_recovery')
            bridge.db.execute("UPDATE database_recovery_gate SET status='VERIFIED' WHERE id=1")
        return {'status':'VERIFIED','decision_calls':0}
