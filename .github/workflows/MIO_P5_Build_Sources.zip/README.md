# MIO P5 code-only qualification build

This repository export includes the unchanged engine, 160 Family files,
fixture tests and the manual GitHub Actions workflow. The unchanged runtime
Core Identity required by MioDecisionAgent is included. Original uploaded
documents/photos, native read evidence, resources.json, credentials and DB
are not included.

Use a private repository. Run Actions -> MIO P5 device probe -> Run workflow.
The job tests Python fixtures, installs the required Android SDK packages,
builds the debug APK and retains APK/diagnostics for seven days. No runtime API
keys are required. Missing binary wheels or failed compilation must fail the
job. This archive is build source, not an APK or successful build report.

APK success still requires installation and qualification on the actual phone.
Credential entry/login, encrypted storage and an Android scheduler remain
unimplemented. P5 live writes stay disabled, and P6-P8 have not started.
